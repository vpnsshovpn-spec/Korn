package com.example.filemanager.shizuku;

import com.example.filemanager.shizuku.RemoteFileEntry;

// Runs inside the process Shizuku spawns (adb "shell" user, or root — never
// this app's own uid), so it can see paths this app's process is blocked
// from touching directly, e.g. other apps' /Android/data folders. Every
// method here is ordinary java.io.File / stream work; nothing it does is
// anything more privileged than "adb shell" itself could already do.
interface IFileService {
    List<RemoteFileEntry> listDir(String path);
    boolean exists(String path);
    boolean isDirectory(String path);
    boolean isFile(String path);
    long length(String path);
    boolean mkdirs(String path);
    boolean delete(String path);
    boolean deleteRecursive(String path);
    boolean renameTo(String srcPath, String dstPath);
    boolean copyRecursive(String srcPath, String dstPath);
    boolean createNewFile(String path);
    // Read side of a pipe: the remote side streams the file's bytes into it.
    android.os.ParcelFileDescriptor openReadFd(String path);
    // Write side of a pipe: bytes the caller writes are streamed to path.
    android.os.ParcelFileDescriptor openWriteFd(String path, boolean append);
    void destroy();
}
