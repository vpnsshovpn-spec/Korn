package com.example.filemanager.shizuku;

parcelable RemoteFileEntry;
