package com.example.filemanager

import android.app.Application

/** Only exists so non-Activity singletons (e.g. ShizukuFileService) can read the package name. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
