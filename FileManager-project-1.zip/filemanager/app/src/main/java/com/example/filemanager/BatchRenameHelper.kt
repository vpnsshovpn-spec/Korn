package com.example.filemanager

import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Batch rename (multi-select "rename pattern with {n}") - extracted out of MainActivity.kt
 * (round 3 of the size-reduction plan). No logic changed, only location + widening
 * exitSelectionMode() and toastNoSelection() from private to internal so this file can call
 * them.
 */

internal fun MainActivity.batchRenameDialog() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }
    val box = android.widget.LinearLayout(this).apply {
        orientation = android.widget.LinearLayout.VERTICAL
        setPadding(32, 8, 32, 0)
    }
    val patternInput = EditText(this).apply {
        hint = "ชื่อ_{n}"
        setText("ชื่อ_{n}")
        selectAll()
    }
    val startInput = EditText(this).apply {
        hint = "เลขเริ่มต้น"
        setText("1")
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
    }
    box.addView(patternInput)
    box.addView(startInput)

    AlertDialog.Builder(this)
        .setTitle("เปลี่ยนชื่อหลายไฟล์ (${files.size} รายการ)")
        .setMessage("ใช้ {n} เป็นหมายเลขรันต่อ เช่น Addon_{n}")
        .setView(box)
        .setPositiveButton("เปลี่ยนชื่อ") { _, _ ->
            val pattern = patternInput.text.toString().trim()
            val start = startInput.text.toString().toIntOrNull() ?: 1
            if (pattern.isEmpty()) {
                Toast.makeText(this, "กรุณาใส่รูปแบบชื่อ", Toast.LENGTH_SHORT).show()
            } else {
                batchRename(files, pattern, start)
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.batchRename(files: List<File>, pattern: String, start: Int) {
    lifecycleScope.launch(Dispatchers.IO) {
        var renamed = 0
        var skipped = 0
        val reserved = mutableSetOf<String>()
        files.forEachIndexed { index, file ->
            try {
                var stem = pattern.replace("{n}", (start + index).toString())
                if (!pattern.contains("{n}")) stem += "_${start + index}"
                val dot = file.name.lastIndexOf('.')
                val hasExtensionInPattern = stem.lastIndexOf('.') > 0
                val newName = if (!file.isDirectory && !hasExtensionInPattern && dot > 0) {
                    stem + file.name.substring(dot)
                } else stem
                if (newName.isBlank() || newName == file.name ||
                    newName.contains("/") || newName.contains("\\") ||
                    newName in reserved
                ) {
                    skipped++
                    return@forEachIndexed
                }
                val dest = File(file.parentFile, newName)
                if (dest.exists() && dest.absolutePath != file.absolutePath) {
                    skipped++
                    return@forEachIndexed
                }
                if (file.renameTo(dest)) {
                    reserved.add(newName)
                    renamed++
                } else skipped++
            } catch (_: Exception) {
                skipped++
            }
        }
        withContext(Dispatchers.Main) {
            exitSelectionMode()
            Toast.makeText(
                this@batchRename,
                "เปลี่ยนชื่อสำเร็จ $renamed รายการ" +
                    if (skipped > 0) " (ข้าม $skipped รายการ)" else "",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
