package com.example.filemanager

import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

/**
 * Favorites (bookmarks) bar: adding a bookmark, rendering the horizontal chip bar, and the
 * "manage bookmarks" list dialog - extracted out of MainActivity.kt (round 7 of the size-
 * reduction plan). No logic changed, only location + widening several members from private to
 * internal (bookmarksBar, bookmarksManager, themeKey, chooseDestinationFolder()) so this file
 * can read/call them.
 */

internal fun MainActivity.addBookmark(dir: File) {
    val input = EditText(this)
    input.setText(dir.name)
    AlertDialog.Builder(this)
        .setTitle("เพิ่มในรายการโปรด")
        .setView(input)
        .setPositiveButton("บันทึก") { _, _ ->
            val name = input.text.toString().ifBlank { dir.name }
            bookmarksManager.add(name, dir.absolutePath)
            refreshBookmarksBar()
            Toast.makeText(this, "เพิ่มในรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.isDarkThemeActive(): Boolean {
    return themeKey == "dark" || (themeKey == "system" &&
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES)
}

internal fun MainActivity.refreshBookmarksBar() {
    val activity: MainActivity = this
    bookmarksBar.removeAllViews()
    val bookmarks = bookmarksManager.getAll()
    for (bm in bookmarks) {
        val chip = TextView(this).apply {
            text = "⭐ ${bm.name}"
            setPadding(24, 12, 24, 12)
            setBackgroundColor(if (isDarkThemeActive()) android.graphics.Color.rgb(55, 62, 70) else android.graphics.Color.rgb(227, 242, 253))
            setTextColor(if (isDarkThemeActive()) android.graphics.Color.rgb(235, 240, 245) else android.graphics.Color.rgb(21, 101, 192))
            textSize = 13f
            gravity = Gravity.CENTER
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = 12
            layoutParams = lp
            isClickable = true
            isFocusable = true
            isLongClickable = true
            setOnClickListener {
                val target = File(bm.path)
                if (target.exists()) loadDirectory(target)
                else Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
            }
            setOnLongClickListener {
                AlertDialog.Builder(activity)
                    .setTitle("ลบบุ๊คมาร์ก \"${bm.name}\"?")
                    .setPositiveButton("ลบ") { _, _ ->
                        bookmarksManager.remove(bm.path)
                        refreshBookmarksBar()
                    }
                    .setNegativeButton("ยกเลิก", null)
                    .show()
                true
            }
        }
        bookmarksBar.addView(chip)
    }
}

internal fun MainActivity.manageBookmarksDialog() {
    val bookmarks = bookmarksManager.getAll().toMutableList()
    val list = ListView(this)
    val names = bookmarks.map { "⭐ ${it.name}\n${it.path}" }.toMutableList()
    val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, names)
    list.adapter = listAdapter

    val dialog = AlertDialog.Builder(this)
        .setTitle("ตัวจัดการรายการโปรด")
        .setView(list)
        .setPositiveButton("＋ เพิ่มโฟลเดอร์") { _, _ ->
            chooseDestinationFolder { selected ->
                addBookmark(selected)
            }
        }
        .setNegativeButton("ปิด", null)
        .create()

    list.setOnItemClickListener { _, _, which, _ ->
        val target = File(bookmarks.getOrNull(which)?.path ?: return@setOnItemClickListener)
        if (target.isDirectory) {
            dialog.dismiss()
            loadDirectory(target)
        } else {
            Toast.makeText(this, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
        }
    }

    list.setOnItemLongClickListener { _, _, which, _ ->
        val bookmark = bookmarks.getOrNull(which) ?: return@setOnItemLongClickListener true
        AlertDialog.Builder(this)
            .setTitle("ลบรายการโปรด?")
            .setMessage("${bookmark.name}\n${bookmark.path}")
            .setPositiveButton("ลบ") { _, _ ->
                bookmarksManager.remove(bookmark.path)
                bookmarks.removeAt(which)
                names.removeAt(which)
                listAdapter.notifyDataSetChanged()
                refreshBookmarksBar()
                Toast.makeText(this, "ลบออกจากรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
        true
    }

    dialog.show()

    if (bookmarks.isEmpty()) {
        // Keep the manager usable even when there are no saved folders yet.
        listAdapter.notifyDataSetChanged()
        Toast.makeText(this, "ยังไม่มีรายการโปรด กด «＋ เพิ่มโฟลเดอร์» เพื่อเลือกโฟลเดอร์", Toast.LENGTH_LONG).show()
    }
}
