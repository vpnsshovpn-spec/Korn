package com.example.filemanager

import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

/**
 * Clipboard paste and create-file/folder UI extracted from MainActivity (STEP 15).
 * Existing clipboard and creation behavior is preserved.
 */
internal fun MainActivity.pasteClipboard() {
    val sources = clipboardFiles
    if (sources.isEmpty()) {
        Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
        return
    }
    val destDir = currentDir
    val cut = clipboardIsCut
    FileOperationService.start(this, sources, destDir, move = cut)
    clipboardFiles = emptyList()
    clipboardIsCut = false
    updateActionBars()
    Toast.makeText(this, "กำลังวางไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
}

internal fun MainActivity.showAddMenu() {
    AlertDialog.Builder(this)
        .setTitle("เพิ่ม")
        .setItems(arrayOf("📄 ไฟล์", "📁 โฟลเดอร์")) { _, which ->
            when (which) {
                0 -> newFileDialog()
                1 -> newFolderDialog()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.newFileDialog() {
    val input = EditText(this)
    input.hint = "ชื่อไฟล์.txt"
    AlertDialog.Builder(this)
        .setTitle("สร้างไฟล์ใหม่")
        .setMessage("ใน ${currentDir.absolutePath}")
        .setView(input)
        .setPositiveButton("สร้าง") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isEmpty()) return@setPositiveButton
            val newFile = File(currentDir, name)
            try {
                when {
                    newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                    newFile.createNewFileCompat() -> loadDirectory(currentDir)
                    else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.newFolderDialog() {
    val input = EditText(this)
    AlertDialog.Builder(this)
        .setTitle("สร้างโฟลเดอร์ใหม่")
        .setView(input)
        .setPositiveButton("สร้าง") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                File(currentDir, name).mkdirsCompat()
                loadDirectory(currentDir)
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
