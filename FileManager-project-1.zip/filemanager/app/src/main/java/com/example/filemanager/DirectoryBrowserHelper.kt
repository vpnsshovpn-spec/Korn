package com.example.filemanager

import android.os.Environment
import java.io.File

/**
 * Directory-listing logic used by the normal file-browser screen.
 *
 * This helper deliberately does not own Activity/UI state. It only resolves the
 * directory contents, applies the existing hidden-file/root-trash filters, and
 * applies the comparator supplied by MainActivity. This keeps the first part of
 * the directory-browsing refactor behavior-neutral and makes the larger STEP 17
 * work safer to continue in small, buildable pieces.
 */
class DirectoryBrowserHelper {

    data class Result(
        val directory: File,
        val entries: List<FileEntry>
    )

    fun load(
        dir: File,
        showHidden: Boolean,
        comparator: Comparator<FileEntry>
    ): Result {
        val isRoot = dir == Environment.getExternalStorageDirectory()
        val children = dir.listFilesCompat() ?: emptyList()
        val entries = children
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { !(isRoot && it.name == TrashManager.TRASH_FOLDER_NAME) }
            .map { FileEntry(it) }
            .sortedWith(comparator)
        return Result(dir, entries)
    }
}
