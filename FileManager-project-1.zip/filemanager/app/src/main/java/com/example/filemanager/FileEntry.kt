package com.example.filemanager

import java.io.File

/**
 * [displayName] / [subtitleOverride] let flat "virtual" lists (currently just the trash view)
 * show a friendlier name/subtitle than the raw backing [file] without changing how normal
 * directory browsing, category scans, or search results render.
 */
data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val displayName: String? = null,
    val subtitleOverride: CharSequence? = null
)
