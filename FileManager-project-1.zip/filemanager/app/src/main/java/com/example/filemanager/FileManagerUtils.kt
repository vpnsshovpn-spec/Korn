package com.example.filemanager

import java.io.File
import java.text.DecimalFormat

/**
 * Pure, stateless helpers shared across the file manager screens.
 *
 * These used to live as private methods on MainActivity.kt. They don't touch any Activity
 * state (no `this`, no views, no context), so moving them here is a behavior-neutral change:
 * same names, same package, same signatures - callers don't need to change at all. This is a
 * first, low-risk step towards trimming MainActivity.kt down; it does not touch any of the
 * stateful logic (selection mode, clipboard, sort key, etc.) which would need a real
 * ViewModel/State-holder migration to do safely.
 */

fun readableSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    val df = DecimalFormat("#,##0.#")
    return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
}

fun formatDateTime(time: Long): String =
    java.text.SimpleDateFormat("d MMM yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(time))

/** Returns a filename that doesn't already exist in [dir], appending " (1)", " (2)", ... if needed. */
fun uniqueName(dir: File, desired: String, isDir: Boolean = false): String {
    if (!File(dir, desired).exists()) return desired
    val dotIndex = desired.lastIndexOf('.')
    val base = if (!isDir && dotIndex > 0) desired.substring(0, dotIndex) else desired
    val ext = if (!isDir && dotIndex > 0) desired.substring(dotIndex) else ""
    var i = 1
    var candidate: String
    do {
        candidate = "$base ($i)$ext"
        i++
    } while (File(dir, candidate).exists())
    return candidate
}
