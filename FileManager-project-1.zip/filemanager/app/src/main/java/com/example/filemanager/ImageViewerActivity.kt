package com.example.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * KORN built-in image viewer.
 *
 * Opens common image files directly from the file manager instead of handing them to another
 * app. Loads every image in the same folder (sorted by name) into a ViewPager2 so the user can
 * swipe left/right to browse the whole gallery, shows "filename i/total" at the bottom, and
 * keeps the original pinch-zoom + pan support per image (see [ZoomableImageView]) - while
 * zoomed in, panning wins over swiping to the next/previous photo.
 */
class ImageViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_PATH = "image_path"
        private val GALLERY_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp")
    }

    private lateinit var pager: ViewPager2
    private lateinit var pageLabel: TextView
    private lateinit var images: List<File>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val path = intent.getStringExtra(EXTRA_IMAGE_PATH)
        val file = path?.let { File(it) }
        if (file == null || !file.isFile) {
            Toast.makeText(this, "ไม่พบรูปภาพ", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Every sibling image in the same folder, sorted by name - this is the swipe order.
        val siblings = (file.parentFile?.listFiles { f ->
            f.isFile && f.extension.lowercase() in GALLERY_EXTENSIONS
        } ?: emptyArray())
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })

        var startIndex = siblings.indexOfFirst { it.absolutePath == file.absolutePath }
        images = if (startIndex >= 0) siblings else listOf(file)
        if (startIndex < 0) startIndex = 0

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF101010.toInt())
        }

        pager = ViewPager2(this).apply {
            adapter = ImagePagerAdapter(images, lifecycleScope)
            offscreenPageLimit = 1
        }
        root.addView(pager, FrameLayout.LayoutParams(-1, -1))

        pageLabel = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(16), dp(6), dp(16), dp(6))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val labelParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(24)
        }
        root.addView(pageLabel, labelParams)

        setContentView(root)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateLabel(position)
            }
        })

        pager.setCurrentItem(startIndex, false)
        updateLabel(startIndex)
    }

    private fun updateLabel(position: Int) {
        if (position !in images.indices) return
        val f = images[position]
        supportActionBar?.title = f.name
        pageLabel.text = "${f.name}  ${position + 1}/${images.size}"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    /**
     * One page per image. Bitmaps are decoded off the main thread and downsampled the same
     * way the old single-image viewer did, so a folder full of large photos doesn't blow up
     * memory - only the current +/- 1 page (see [offscreenPageLimit]) is ever decoded at once.
     */
    private class ImagePagerAdapter(
        private val images: List<File>,
        private val scope: kotlinx.coroutines.CoroutineScope
    ) : RecyclerView.Adapter<ImagePagerAdapter.VH>() {

        class VH(val imageView: ZoomableImageView) : RecyclerView.ViewHolder(imageView) {
            var job: Job? = null
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val imageView = ZoomableImageView(parent.context).apply {
                layoutParams = ViewGroup.LayoutParams(-1, -1)
                setBackgroundColor(0xFF101010.toInt())
            }
            return VH(imageView)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val file = images[position]
            holder.job?.cancel()
            recycleCurrentBitmap(holder)
            holder.imageView.resetZoom()
            holder.job = scope.launch {
                val bitmap = withContext(Dispatchers.IO) { decodeSampledBitmap(file) }
                holder.imageView.setImageBitmap(bitmap)
                holder.imageView.resetZoom()
            }
        }

        override fun onViewRecycled(holder: VH) {
            super.onViewRecycled(holder)
            holder.job?.cancel()
            recycleCurrentBitmap(holder)
        }

        private fun recycleCurrentBitmap(holder: VH) {
            val drawable = holder.imageView.drawable
            holder.imageView.setImageDrawable(null)
            if (drawable is BitmapDrawable) drawable.bitmap.recycle()
        }

        override fun getItemCount(): Int = images.size

        private fun decodeSampledBitmap(file: File): Bitmap? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val maxPixels = 4096L * 4096L
            var sample = 1
            while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > maxPixels) {
                sample *= 2
            }

            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            return BitmapFactory.decodeFile(file.absolutePath, options)
        }
    }
}
