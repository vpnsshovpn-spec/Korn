package com.example.filemanager

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate

/**
 * Owns KORN's user preferences, settings/about dialogs, and main-screen theme palette.
 *
 * MainActivity remains responsible for screen navigation and state usage, while this
 * helper owns the settings UI and persistence details. Existing behavior is preserved;
 * this round primarily reduces MainActivity's size without changing the feature design.
 */
class SettingsHelper(private val activity: MainActivity) {

    fun applySavedNightMode() {
        when (activity.themeKey) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    fun loadUserPreferences() {
        val prefs = activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE)
        activity.showHidden = prefs.getBoolean("show_hidden", false)
        activity.isGridMode = prefs.getBoolean("grid_mode", false)
        activity.fileViewMode = when (prefs.getString("view_mode", if (activity.isGridMode) "GRID" else "LIST")) {
            "COMPACT" -> FileAdapter.ViewMode.COMPACT
            "GRID" -> FileAdapter.ViewMode.GRID
            "DETAILS" -> FileAdapter.ViewMode.DETAILS
            else -> FileAdapter.ViewMode.LIST
        }
        activity.isGridMode = activity.fileViewMode == FileAdapter.ViewMode.GRID
        activity.confirmDelete = prefs.getBoolean("confirm_delete", true)
        activity.sortKey = when (prefs.getString("sort_key", "NAME")) {
            "SIZE" -> MainActivity.SortKey.SIZE
            "DATE" -> MainActivity.SortKey.DATE
            else -> MainActivity.SortKey.NAME
        }
        activity.sortAscending = prefs.getBoolean("sort_ascending", true)
        activity.themeKey = prefs.getString("theme_key", "system") ?: "system"
    }

    fun saveUserPreferences() {
        activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE).edit()
            .putBoolean("show_hidden", activity.showHidden)
            .putBoolean("grid_mode", activity.isGridMode)
            .putString("view_mode", activity.fileViewMode.name)
            .putBoolean("confirm_delete", activity.confirmDelete)
            .putString("theme_key", activity.themeKey)
            .putString("sort_key", activity.sortKey.name)
            .putBoolean("sort_ascending", activity.sortAscending)
            .apply()
    }

    fun showAboutKornDialog() {
        AlertDialog.Builder(activity)
            .setTitle("เกี่ยวกับ KORN")
            .setMessage(
                "KORN File Manager — By KORN\n\n" +
                    "แอปพลิเคชันนี้เป็นผลงานของ KORN\n" +
                    "ห้ามคัดลอก ดัดแปลง แก้ไข แจกจ่าย หรือเผยแพร่ส่วนหนึ่งส่วนใดของแอปพลิเคชัน " +
                    "โดยไม่ได้รับอนุญาตจาก KORN"
            )
            .setPositiveButton("ตกลง", null)
            .show()
    }

    fun showSettingsDialog() {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val themeTitle = TextView(activity).apply {
            text = "ธีม"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        }
        container.addView(themeTitle)

        val themeOptions = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val themeKeys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val themeGroup = RadioGroup(activity).apply { orientation = RadioGroup.VERTICAL }
        themeOptions.forEachIndexed { index, label ->
            val radio = RadioButton(activity).apply {
                text = label
                id = View.generateViewId()
                isChecked = themeKeys[index] == activity.themeKey
            }
            themeGroup.addView(radio)
        }
        var pendingThemeKey = activity.themeKey
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = themeGroup.indexOfChild(themeGroup.findViewById(checkedId))
            pendingThemeKey = themeKeys.getOrElse(selected) { activity.themeKey }
        }
        container.addView(themeGroup)

        val hidden = CheckBox(activity).apply {
            text = "แสดงไฟล์ที่ซ่อน"
            isChecked = activity.showHidden
        }
        hidden.setOnCheckedChangeListener { _, checked ->
            activity.showHidden = checked
            activity.drawerHiddenSwitch?.setOnCheckedChangeListener(null)
            activity.drawerHiddenSwitch?.isChecked = checked
            activity.drawerHiddenSwitch?.setOnCheckedChangeListener { _, value ->
                if (activity.showHidden == value) return@setOnCheckedChangeListener
                activity.showHidden = value
                saveUserPreferences()
                activity.refreshCurrentView()
            }
            saveUserPreferences()
            activity.refreshCurrentView()
        }
        container.addView(hidden)

        val confirm = CheckBox(activity).apply {
            text = "ยืนยันก่อนลบ"
            isChecked = activity.confirmDelete
        }
        confirm.setOnCheckedChangeListener { _, checked ->
            activity.confirmDelete = checked
            saveUserPreferences()
        }
        container.addView(confirm)

        val grid = CheckBox(activity).apply {
            text = "ใช้มุมมองตาราง"
            isChecked = activity.isGridMode
        }
        grid.setOnCheckedChangeListener { _, checked ->
            if (activity.isGridMode != checked) activity.toggleGridMode()
        }
        container.addView(grid)

        val shizukuTitle = TextView(activity).apply {
            text = "การเข้าถึงระดับระบบ"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 16, 0, 4)
        }
        container.addView(shizukuTitle)

        val shizukuRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val shizukuStatus = TextView(activity).apply {
            text = "Shizuku: ${ShizukuManager.statusLabel()}"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val shizukuButton = Button(activity).apply { text = "เชื่อมต่อ" }
        shizukuRow.addView(shizukuStatus)
        shizukuRow.addView(shizukuButton)
        container.addView(shizukuRow)

        val shizukuHint = TextView(activity).apply {
            text = "ใช้เข้าถึงโฟลเดอร์ Android/data โดยไม่ต้อง root — ต้องติดตั้งและเปิดแอป Shizuku ไว้ก่อน"
            textSize = 12f
            setPadding(0, 2, 0, 8)
        }
        container.addView(shizukuHint)

        fun refreshShizukuRow() {
            shizukuStatus.text = "Shizuku: ${ShizukuManager.statusLabel()}"
            shizukuButton.isEnabled = ShizukuManager.isAvailable() && !ShizukuManager.hasPermission()
        }
        refreshShizukuRow()
        activity.onShizukuStatusChanged = { refreshShizukuRow() }

        shizukuButton.setOnClickListener {
            if (!ShizukuManager.isAvailable()) {
                Toast.makeText(
                    activity,
                    "ไม่พบ Shizuku — ติดตั้งและเปิดแอปจาก shizuku.rikka.app ก่อน",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                ShizukuManager.requestPermission()
            }
        }

        val settingsDialog = AlertDialog.Builder(activity)
            .setTitle("การตั้งค่า")
            .setView(container)
            .setNeutralButton("เรียงลำดับ") { _, _ -> activity.showSortDialog() }
            .setPositiveButton("เสร็จสิ้น") { _, _ ->
                activity.themeKey = pendingThemeKey
                saveUserPreferences()
                applySavedNightMode()
                applyThemePalette()
            }
            .setOnDismissListener { activity.onShizukuStatusChanged = null }
            .show()

        settingsDialog.window?.apply {
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.5f)
        }
    }

    fun applyThemePalette() {
        if (!activity.isMainThemeViewsInitialized) return

        val (primary, primaryDark, background) = ThemeHelper.colors(activity)
        activity.findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(primary)
        activity.window.statusBarColor = primaryDark
        activity.drawerLayout.setBackgroundColor(background)
        activity.findViewById<LinearLayout>(R.id.mainContent)?.setBackgroundColor(background)
        activity.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.fileList)?.setBackgroundColor(background)

        val systemDark = (activity.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val darkSurface = activity.themeKey == "dark" || (activity.themeKey == "system" && systemDark)
        activity.findViewById<android.widget.HorizontalScrollView>(R.id.breadcrumbScroll)?.setBackgroundColor(
            if (darkSurface) Color.rgb(42, 46, 51) else Color.rgb(238, 241, 244)
        )
        activity.navigationView.setBackgroundColor(if (darkSurface) Color.rgb(36, 39, 43) else background)
        val text = if (darkSurface) Color.rgb(245, 247, 249) else Color.rgb(32, 35, 39)
        val secondary = if (darkSurface) Color.rgb(190, 197, 204) else Color.rgb(82, 88, 96)
        activity.storageText.setTextColor(secondary)
        activity.storagePercent.setBackgroundColor(primary)
        activity.storagePercent.setTextColor(Color.WHITE)
        val tint = ColorStateList.valueOf(primary)
        activity.findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton)?.backgroundTintList = tint
        activity.findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton)?.backgroundTintList = tint

        val toolIds = listOf(R.id.addBookmarkButton, R.id.manageBookmarksButton, R.id.sortFilesButton, R.id.viewModeButton)
        val toolColor = if (activity.themeKey == "gray") Color.rgb(101, 109, 121) else primary
        toolIds.forEach { id ->
            activity.findViewById<Button>(id)?.apply {
                backgroundTintList = ColorStateList.valueOf(toolColor)
                setTextColor(Color.WHITE)
            }
        }

        activity.categoryBar.takeIf { activity.isMainThemeViewsInitialized }?.let { bar ->
            for (i in 0 until bar.childCount) {
                (bar.getChildAt(i) as? TextView)?.setBackgroundColor(primary)
            }
        }
        activity.navigationView.itemTextColor = ColorStateList.valueOf(text)
        activity.navigationView.itemIconTintList = ColorStateList.valueOf(
            if (darkSurface) Color.rgb(220, 225, 230) else Color.rgb(72, 78, 86)
        )
        activity.navigationView.getHeaderView(0)?.setBackgroundColor(primary)
    }

    fun showThemeDialog() {
        val labels = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val keys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val checked = keys.indexOf(activity.themeKey).coerceAtLeast(0)
        AlertDialog.Builder(activity)
            .setTitle("ธีมสี")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                activity.themeKey = keys[which]
                saveUserPreferences()
                applySavedNightMode()
                applyThemePalette()
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }
}
