package com.example.filemanager

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Thin wrapper around the Shizuku API.
 *
 * Shizuku is a separate app the user must install and start themselves
 * (via ADB pairing or a rooted device) — see https://shizuku.rikka.app.
 * Once its service is running, apps like this one can ask it for a
 * permission grant and then run privileged file operations (e.g. reading
 * /Android/data and /Android/obb on Android 11+) without the app itself
 * needing root.
 *
 * This class only talks to that already-running service; it does not and
 * cannot grant privileges on its own.
 */
object ShizukuManager {

    const val REQUEST_CODE = 9001

    /** True if the Shizuku app/service is installed and reachable. */
    fun isAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    /** True if the service is running AND this app already has permission. */
    fun hasPermission(): Boolean {
        if (!isAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                // Pre-v11 Shizuku used a normal Android permission grant.
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Requests permission from the user via the Shizuku app's own dialog.
     * The result arrives in the calling Activity's
     * onRequestPermissionsResult (register a Shizuku.OnRequestPermissionResultListener
     * or override that callback) — it is NOT synchronous.
     */
    fun requestPermission(requestCode: Int = REQUEST_CODE) {
        if (!isAvailable()) return
        if (hasPermission()) return
        Shizuku.requestPermission(requestCode)
    }

    fun statusLabel(): String = when {
        !isAvailable() -> "ยังไม่ได้เชื่อมต่อ (ไม่พบ Shizuku)"
        hasPermission() -> "เชื่อมต่อแล้ว ✓"
        else -> "พบ Shizuku แต่ยังไม่ได้รับสิทธิ์"
    }
}
