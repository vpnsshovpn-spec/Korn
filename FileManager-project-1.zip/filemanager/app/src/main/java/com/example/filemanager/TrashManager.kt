package com.example.filemanager

import android.content.Context
import android.os.Environment
import com.example.filemanager.renameToCompat
import com.example.filemanager.copyRecursivelyCompat
import com.example.filemanager.deleteRecursivelyCompat
import java.io.File

/**
 * Soft-delete ("recycle bin") support.
 *
 * Deleted files/folders are moved into a hidden folder at the root of external storage
 * instead of being deleted immediately. Original location + trash time are recorded in
 * SharedPreferences (same "name|value|value" string-set pattern as BookmarksManager) so
 * items can be restored to where they came from.
 */
class TrashManager(context: Context) {

    companion object {
        const val TRASH_FOLDER_NAME = ".trash_filemanager"
        const val PREFS_NAME = "trash_prefs"
        const val KEY_ENABLED = "isTrashEnabled"
        const val KEY_AUTO_DELETE_DAYS = "autoDeleteDays"
        const val DEFAULT_AUTO_DELETE_DAYS = 30
    }

    val trashDir: File = File(Environment.getExternalStorageDirectory(), TRASH_FOLDER_NAME)

    private val appContext = context.applicationContext
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val KEY = "trash_entries"

    init {
        // Keep the midnight auto-delete job in sync with current settings every time a
        // TrashManager is created (app start, or wherever a screen instantiates one),
        // so the background schedule never drifts from what the settings sheet shows.
        if (isEnabled() && autoDeleteDays() > 0) {
            TrashWorker.schedule(appContext)
        } else {
            TrashWorker.cancel(appContext)
        }
    }

    data class Entry(val trashedFile: File, val originalPath: String, val trashedAt: Long)

    private fun ensureDir() {
        if (!trashDir.exists()) trashDir.mkdirs()
    }

    // ---------- Settings ----------

    /** Whether deleted files go through the trash at all. false = delete permanently, right away. */
    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, true)

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (enabled && autoDeleteDays() > 0) TrashWorker.schedule(appContext) else TrashWorker.cancel(appContext)
    }

    /** Days an item stays in the trash before being purged automatically. 0 = never. */
    fun autoDeleteDays(): Int = prefs.getInt(KEY_AUTO_DELETE_DAYS, DEFAULT_AUTO_DELETE_DAYS)

    fun setAutoDeleteDays(days: Int) {
        prefs.edit().putInt(KEY_AUTO_DELETE_DAYS, days).apply()
        if (isEnabled() && days > 0) TrashWorker.schedule(appContext) else TrashWorker.cancel(appContext)
    }

    /** Moves [file] into the trash folder and records where it came from. Returns success.
     *  If the trash feature is disabled, deletes [file] permanently instead. */
    fun moveToTrash(file: File): Boolean {
        if (!isEnabled()) {
            return try {
                if (file.isDirectory) file.deleteRecursivelyCompat() else file.delete()
            } catch (e: Exception) {
                false
            }
        }
        ensureDir()
        val ts = System.currentTimeMillis()
        val trashedName = "${ts}_${file.name}"
        val dest = File(trashDir, trashedName)
        val moved = try {
            if (file.renameToCompat(dest)) {
                true
            } else {
                file.copyRecursivelyCompat(dest, overwrite = true) &&
                    file.deleteRecursivelyCompat()
            }
        } catch (e: Exception) {
            false
        }
        if (moved) {
            val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
            current.add("$trashedName|${file.absolutePath}|$ts")
            prefs.edit().putStringSet(KEY, current).apply()
        }
        return moved
    }

    /** All current trash entries, most recently trashed first. Purges anything past its
     *  retention period first, so callers never see (or have to wait on) expired items. */
    fun listEntries(): List<Entry> {
        purgeExpired()
        return rawEntries()
    }

    private fun rawEntries(): List<Entry> {
        val raw = prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()
        return raw.mapNotNull {
            val parts = it.split("|", limit = 3)
            if (parts.size == 3) {
                val f = File(trashDir, parts[0])
                if (f.exists()) Entry(f, parts[1], parts[2].toLongOrNull() ?: 0L) else null
            } else null
        }.sortedByDescending { it.trashedAt }
    }

    /** Permanently deletes any entry older than [autoDeleteDays]. A no-op when set to
     *  "never" (0). Safe to call often - used both by TrashWorker and opportunistically
     *  whenever the trash list is read. Returns how many entries were purged. */
    fun purgeExpired(): Int {
        val days = autoDeleteDays()
        if (days <= 0) return 0
        val cutoffMillis = System.currentTimeMillis() - days * 24L * 60L * 60L * 1000L
        val expired = rawEntries().filter { it.trashedAt < cutoffMillis }
        expired.forEach { deleteForever(it) }
        return expired.size
    }

    /** Moves [entry] back to its original location (or a "(restored N)" name if that path is now occupied). */
    fun restore(entry: Entry): Boolean {
        val originalFile = File(entry.originalPath)
        val destParent = originalFile.parentFile ?: return false
        destParent.mkdirs()
        val dest = if (originalFile.exists()) File(destParent, uniqueRestoreName(destParent, originalFile.name)) else originalFile
        val ok = try {
            if (entry.trashedFile.renameToCompat(dest)) {
                true
            } else {
                entry.trashedFile.copyRecursivelyCompat(dest, overwrite = true) &&
                    entry.trashedFile.deleteRecursivelyCompat()
            }
        } catch (e: Exception) {
            false
        }
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes [entry] from the trash folder. */
    fun deleteForever(entry: Entry): Boolean {
        val ok = if (entry.trashedFile.isDirectory) entry.trashedFile.deleteRecursively() else entry.trashedFile.delete()
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes everything currently in the trash. */
    fun emptyTrash() {
        trashDir.listFiles()?.forEach { if (it.isDirectory) it.deleteRecursively() else it.delete() }
        prefs.edit().remove(KEY).apply()
    }

    fun count(): Int = listEntries().size

    private fun removeMeta(trashedName: String) {
        val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
        current.removeAll { it.startsWith("$trashedName|") }
        prefs.edit().putStringSet(KEY, current).apply()
    }

    private fun uniqueRestoreName(dir: File, name: String): String {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base (restored $i)$ext"
            i++
        } while (File(dir, candidate).exists())
        return candidate
    }
}
