package com.example.filemanager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * Settings sheet opened from the gear icon on the trash screen. Reads/writes the same
 * "isTrashEnabled" / "autoDeleteDays" prefs that [TrashManager] and [TrashWorker] use,
 * so it never duplicates that storage or scheduling logic - it just calls into
 * [TrashManager]'s setters, which themselves keep the background job in sync.
 */
class TrashSettingsSheet : BottomSheetDialogFragment() {

    private var onChanged: (() -> Unit)? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.bottom_sheet_trash_settings, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val trashManager = TrashManager(requireContext())

        val enabledSwitch = view.findViewById<SwitchMaterial>(R.id.trashEnabledSwitch)
        val autoDeleteSection = view.findViewById<View>(R.id.autoDeleteSection)
        val autoDeleteGroup = view.findViewById<RadioGroup>(R.id.autoDeleteRadioGroup)

        val dayToRadioId = mapOf(
            7 to R.id.radio7Days,
            15 to R.id.radio15Days,
            30 to R.id.radio30Days,
            60 to R.id.radio60Days,
            0 to R.id.radioNever
        )
        val radioIdToDay = dayToRadioId.entries.associate { (day, id) -> id to day }

        enabledSwitch.isChecked = trashManager.isEnabled()
        autoDeleteGroup.check(dayToRadioId[trashManager.autoDeleteDays()] ?: R.id.radio30Days)
        setSectionEnabled(autoDeleteSection, autoDeleteGroup, trashManager.isEnabled())

        enabledSwitch.setOnCheckedChangeListener { _, isChecked ->
            trashManager.setEnabled(isChecked)
            setSectionEnabled(autoDeleteSection, autoDeleteGroup, isChecked)
            onChanged?.invoke()
        }

        autoDeleteGroup.setOnCheckedChangeListener { _, checkedId ->
            trashManager.setAutoDeleteDays(radioIdToDay[checkedId] ?: TrashManager.DEFAULT_AUTO_DELETE_DAYS)
            onChanged?.invoke()
        }
    }

    private fun setSectionEnabled(section: View, group: RadioGroup, enabled: Boolean) {
        section.alpha = if (enabled) 1f else 0.4f
        group.isEnabled = enabled
        for (i in 0 until group.childCount) {
            group.getChildAt(i).isEnabled = enabled
        }
    }

    companion object {
        /** [onChanged] fires whenever a setting changes, so the caller can refresh its view
         *  (e.g. re-run loadTrash() to reflect a freshly-disabled trash or a new item count). */
        fun newInstance(onChanged: () -> Unit = {}): TrashSettingsSheet =
            TrashSettingsSheet().apply { this.onChanged = onChanged }
    }
}
