package com.example.filemanager

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Background job for the "ลบอัตโนมัติ" trash setting. Runs once every 24h, timed to land
 * around midnight, and permanently deletes any trash entry older than the configured
 * retention period (see [TrashManager.purgeExpired]). A no-op when the trash feature is
 * disabled or retention is set to "ไม่ลบเลย" (0 days).
 *
 * [schedule]/[cancel] are idempotent - safe to call any time settings change, or every
 * time a [TrashManager] is constructed - WorkManager de-dupes by [WORK_NAME].
 */
class TrashWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            TrashManager(applicationContext).purgeExpired()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "trash_auto_delete_worker"

        fun schedule(context: Context) {
            val initialDelay = millisUntilNextMidnight()
            val request = PeriodicWorkRequestBuilder<TrashWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }

        private fun millisUntilNextMidnight(): Long {
            val now = Calendar.getInstance()
            val nextMidnight = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return (nextMidnight.timeInMillis - now.timeInMillis).coerceAtLeast(0L)
        }
    }
}
