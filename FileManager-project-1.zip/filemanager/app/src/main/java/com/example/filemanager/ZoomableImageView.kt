package com.example.filemanager

import android.content.Context
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.min

/**
 * ImageView with pinch-to-zoom + pan, meant to sit inside a ViewPager2 page.
 *
 * Pan/zoom logic here is the same matrix-based approach [ImageViewerActivity] always used;
 * it's just been pulled out into its own View so each gallery page can have one. While the
 * image is zoomed in (scale > 1x) it tells its parent (the ViewPager2) to stop intercepting
 * touches, so dragging around a zoomed photo pans instead of flipping to the next/previous
 * image. Back at the resting 1x scale, the pager is free to handle the swipe again.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ImageView(context, attrs) {

    private var scale = 1f
    private var dx = 0f
    private var dy = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scale = (scale * detector.scaleFactor).coerceIn(1f, 6f)
            applyMatrix()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            scale = if (scale > 1.05f) 1f else 2f
            dx = 0f
            dy = 0f
            applyMatrix()
            parent?.requestDisallowInterceptTouchEvent(scale > 1f)
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(scale > 1f)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // A second finger down means a pinch is starting - always claim the gesture.
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !scaleDetector.isInProgress && scale > 1f) {
                    dx += event.x - lastX
                    dy += event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    applyMatrix()
                }
                // Zoomed in: keep the pager from stealing the drag as a page swipe.
                // Back at 1x: let the pager see it, so a normal swipe still changes images.
                parent?.requestDisallowInterceptTouchEvent(scale > 1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    /** Resets zoom/pan back to the fitted 1x view - call this when a page is rebound to a new image. */
    fun resetZoom() {
        scale = 1f
        dx = 0f
        dy = 0f
        applyMatrix()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyMatrix()
    }

    override fun setImageBitmap(bm: android.graphics.Bitmap?) {
        super.setImageBitmap(bm)
        applyMatrix()
    }

    private fun applyMatrix() {
        val d = drawable ?: return
        val w = d.intrinsicWidth.toFloat()
        val h = d.intrinsicHeight.toFloat()
        if (w <= 0f || h <= 0f || width <= 0 || height <= 0) return

        val fit = min(width / w, height / h)
        val finalScale = fit * scale
        val matrix = Matrix()
        matrix.postScale(finalScale, finalScale)
        val left = (width - w * finalScale) / 2f + dx
        val top = (height - h * finalScale) / 2f + dy
        matrix.postTranslate(left, top)
        imageMatrix = matrix
    }
}
