package com.example.filemanager.shizuku

import android.os.Parcel
import android.os.Parcelable

data class RemoteFileEntry(
    val name: String,
    val isDirectory: Boolean,
    val length: Long,
    val lastModified: Long
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readByte() != 0.toByte(),
        parcel.readLong(),
        parcel.readLong()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeByte(if (isDirectory) 1 else 0)
        parcel.writeLong(length)
        parcel.writeLong(lastModified)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<RemoteFileEntry> {
        override fun createFromParcel(parcel: Parcel): RemoteFileEntry = RemoteFileEntry(parcel)
        override fun newArray(size: Int): Array<RemoteFileEntry?> = arrayOfNulls(size)
    }
}
