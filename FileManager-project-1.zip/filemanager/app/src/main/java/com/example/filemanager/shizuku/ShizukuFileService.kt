package com.example.filemanager.shizuku

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.os.ParcelFileDescriptor
import com.example.filemanager.App
import com.example.filemanager.ShizukuManager
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Binds the [FileServiceImpl] process through Shizuku and forwards plain
 * file operations to it. This is what lets the app reach paths its own
 * process is blocked from touching directly (e.g. other apps' folders
 * under /Android/data on Android 11+) — by asking a differently-privileged
 * process (Shizuku's "shell"/root process) to do the I/O instead.
 *
 * Every public function here is safe to call from a background thread; none
 * of them touch the UI. They fail closed (return false/null) if Shizuku
 * isn't available or permission hasn't been granted — callers should treat
 * that the same as "not accessible" and fall back to their normal error UI.
 */
object ShizukuFileService {

    private var service: IFileService? = null
    private var binding = false
    private val lock = Object()

    private fun args() = Shizuku.UserServiceArgs(
        ComponentName(App.instance.packageName, FileServiceImpl::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("fileservice")
        .debuggable(false)
        .version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            synchronized(lock) {
                service = if (binder != null && binder.pingBinder()) IFileService.Stub.asInterface(binder) else null
                binding = false
                lock.notifyAll()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            synchronized(lock) { service = null }
        }
    }

    val isConnected: Boolean get() = service != null

    /** Binds the remote process if needed and waits (up to [timeoutMs]) for it to be ready. */
    private fun ensureBound(timeoutMs: Long = 4000): Boolean {
        if (service != null) return true
        if (!ShizukuManager.hasPermission()) return false
        synchronized(lock) {
            if (service != null) return true
            if (!binding) {
                binding = true
                try {
                    Shizuku.bindUserService(args(), connection)
                } catch (e: Throwable) {
                    binding = false
                    return false
                }
            }
            try { lock.wait(timeoutMs) } catch (_: InterruptedException) {}
        }
        return service != null
    }

    fun unbind() {
        try { Shizuku.unbindUserService(args(), connection, true) } catch (_: Throwable) {}
        service = null
    }

    // ---- blocking helpers; call from Dispatchers.IO or a background thread ----

    fun listDir(path: String): List<RemoteFileEntry>? =
        runCatching { if (ensureBound()) service?.listDir(path) else null }.getOrNull()

    fun exists(path: String): Boolean =
        runCatching { ensureBound() && service?.exists(path) == true }.getOrDefault(false)

    fun mkdirs(path: String): Boolean =
        runCatching { ensureBound() && service?.mkdirs(path) == true }.getOrDefault(false)

    fun delete(path: String): Boolean =
        runCatching { ensureBound() && service?.delete(path) == true }.getOrDefault(false)

    fun deleteRecursive(path: String): Boolean =
        runCatching { ensureBound() && service?.deleteRecursive(path) == true }.getOrDefault(false)

    fun renameTo(srcPath: String, dstPath: String): Boolean =
        runCatching { ensureBound() && service?.renameTo(srcPath, dstPath) == true }.getOrDefault(false)

    fun copyRecursive(srcPath: String, dstPath: String): Boolean =
        runCatching { ensureBound() && service?.copyRecursive(srcPath, dstPath) == true }.getOrDefault(false)

    fun createNewFile(path: String): Boolean =
        runCatching { ensureBound() && service?.createNewFile(path) == true }.getOrDefault(false)

    /** Copies a remote (protected) file down onto app-accessible storage. */
    fun downloadToLocal(remotePath: String, localDest: File): Boolean = runCatching {
        if (!ensureBound()) return false
        val pfd: ParcelFileDescriptor = service?.openReadFd(remotePath) ?: return false
        localDest.parentFile?.mkdirs()
        ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input ->
            FileOutputStream(localDest).use { out -> input.copyTo(out) }
        }
        true
    }.getOrDefault(false)

    /** Uploads a local, app-accessible file up into a protected remote path. */
    fun uploadFromLocal(localSrc: File, remotePath: String, append: Boolean = false): Boolean = runCatching {
        if (!ensureBound()) return false
        val pfd: ParcelFileDescriptor = service?.openWriteFd(remotePath, append) ?: return false
        ParcelFileDescriptor.AutoCloseOutputStream(pfd).use { out ->
            FileInputStream(localSrc).use { input -> input.copyTo(out) }
        }
        true
    }.getOrDefault(false)
}
