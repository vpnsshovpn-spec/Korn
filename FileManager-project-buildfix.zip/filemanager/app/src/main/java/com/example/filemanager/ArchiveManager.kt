package com.example.filemanager

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri

import com.github.junrar.Archive
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.compressors.CompressorStreamFactory
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Multi-format archive bridge.
 *
 * Browse mode materializes a temporary ZIP in app cache and opens it with the
 * existing ZipBrowserActivity. This keeps the existing UI/editing code intact.
 * The original archive is never renamed to .zip.
 */
object ArchiveManager {
    val BROWSE_EXTENSIONS = setOf(
        "zip","mcpack","mcaddon","mcworld","7z","tar","tgz","tar.gz","bz2","tbz2","tar.bz2",
        "xz","txz","tar.xz","lz4","zst","rar","rar5","apk","apks","xapk","mtz","arj","cpio",
        "gz","lzh","cab","chm","wim","egg","alz","iso","img","dmg","deb","rpm"
    )
    val COMPRESS_FORMATS = listOf("7z","zip","tar","bz2","gz","xz","lz4","zst")

    fun isArchive(file: File): Boolean {
        val n = file.name.lowercase()
        return BROWSE_EXTENSIONS.any { n == it || n.endsWith(".$it") } ||
                n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")) ||
                n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                n.matches(Regex(".*\\.r\\d{2}$"))
    }

    fun isPasswordCandidate(file: File): Boolean =
        file.name.lowercase().let { it.endsWith(".rar") || it.endsWith(".rar5") ||
            it.contains(".part") && it.endsWith(".rar") ||
            it.endsWith(".7z") || it.matches(Regex(".*\\.7z\\.\\d{3}$")) }

    fun materializeForBrowse(input: File, cacheDir: File, password: String? = null): File {
        val actual = combineSplitIfNeeded(input, cacheDir)
        val out = File(cacheDir, "browse_${System.currentTimeMillis()}.zip")
        out.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            when (formatOf(actual)) {
                "zip" -> copyZipToZip(actual, zos)
                "7z" -> sevenZipToZip(actual, zos, password)
                "rar" -> rarToZip(actual, zos, password)
                "tar" -> FileInputStream(actual).use { archiveStreamToZip(it, "tar", zos) }
                "tar.gz","tgz" -> compressedArchiveToZip(actual, CompressorStreamFactory.GZIP, zos)
                "tar.bz2","tbz2" -> compressedArchiveToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "tar.xz","txz" -> compressedArchiveToZip(actual, CompressorStreamFactory.XZ, zos)
                "gz" -> singleCompressedToZip(actual, CompressorStreamFactory.GZIP, zos)
                "bz2" -> singleCompressedToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "xz" -> singleCompressedToZip(actual, CompressorStreamFactory.XZ, zos)
                "lz4" -> singleCompressedToZip(actual, CompressorStreamFactory.LZ4_FRAMED, zos)
                "zst" -> singleCompressedToZip(actual, CompressorStreamFactory.ZSTANDARD, zos)
                "arj","cpio","ar" -> FileInputStream(actual).use { archiveStreamToZip(it, null, zos) }
                else -> throw UnsupportedOperationException(
                    "KORN ยังไม่สามารถอ่าน ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
                )
            }
        }
        if (actual != input) actual.delete()
        return out
    }

    fun extract(input: File, destination: File, password: String? = null) {
        val actual = combineSplitIfNeeded(input, destination.parentFile ?: destination)
        destination.mkdirs()
        when (formatOf(actual)) {
            "zip" -> extractZip(actual, destination)
            "7z" -> extract7z(actual, destination, password)
            "rar" -> extractRar(actual, destination, password)
            "tar" -> FileInputStream(actual).use { extractArchiveStream(it, destination) }
            "tar.gz","tgz" -> extractCompressedArchive(actual, CompressorStreamFactory.GZIP, destination)
            "tar.bz2","tbz2" -> extractCompressedArchive(actual, CompressorStreamFactory.BZIP2, destination)
            "tar.xz","txz" -> extractCompressedArchive(actual, CompressorStreamFactory.XZ, destination)
            "gz" -> extractSingleCompressed(actual, CompressorStreamFactory.GZIP, destination)
            "bz2" -> extractSingleCompressed(actual, CompressorStreamFactory.BZIP2, destination)
            "xz" -> extractSingleCompressed(actual, CompressorStreamFactory.XZ, destination)
            "lz4" -> extractSingleCompressed(actual, CompressorStreamFactory.LZ4_FRAMED, destination)
            "zst" -> extractSingleCompressed(actual, CompressorStreamFactory.ZSTANDARD, destination)
            "arj","cpio","ar" -> FileInputStream(actual).use { extractArchiveStream(it, destination) }
            else -> throw UnsupportedOperationException(
                "KORN ยังไม่สามารถ Extract ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
            )
        }
        if (actual != input) actual.delete()
    }

    private fun formatOf(f: File): String {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") -> "tar.gz"
            n.endsWith(".tar.bz2") -> "tar.bz2"
            n.endsWith(".tar.xz") -> "tar.xz"
            n.endsWith(".tgz") -> "tgz"
            n.endsWith(".tbz2") -> "tbz2"
            n.endsWith(".txz") -> "txz"
            n.endsWith(".rar") || n.endsWith(".rar5") || n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                    n.matches(Regex(".*\\.r\\d{2}$")) -> "rar"
            n.endsWith(".7z") || n.matches(Regex(".*\\.7z\\.\\d{3}$")) -> "7z"
            n.endsWith(".zip") || n.endsWith(".mcpack") || n.endsWith(".mcaddon") ||
                    n.endsWith(".mcworld") || n.endsWith(".apk") || n.endsWith(".apks") ||
                    n.endsWith(".xapk") || n.endsWith(".mtz") -> "zip"
            n.endsWith(".tar") -> "tar"
            n.endsWith(".bz2") -> "bz2"
            n.endsWith(".gz") -> "gz"
            n.endsWith(".xz") -> "xz"
            n.endsWith(".lz4") -> "lz4"
            n.endsWith(".zst") -> "zst"
            n.endsWith(".arj") -> "arj"
            n.endsWith(".cpio") -> "cpio"
            n.endsWith(".ar") || n.endsWith(".deb") -> "ar"
            else -> n.substringAfterLast('.', "")
        }
    }

    private fun combineSplitIfNeeded(input: File, cacheDir: File): File {
        val n = input.name.lowercase()
        if (!(n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")))) return input
        val baseName = input.name.substringBeforeLast('.')
        val base = File(input.parentFile, baseName)
        val parts = (input.parentFile?.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("$baseName.", true) && it.name.substringAfterLast('.').toIntOrNull() != null }
            .sortedBy { it.name.substringAfterLast('.').toInt() }
        if (parts.isEmpty()) throw IOException("ไม่พบไฟล์ part ที่เหลือ")
        val combined = File(cacheDir, "joined_${System.currentTimeMillis()}_$baseName")
        combined.outputStream().buffered().use { out -> parts.forEach { it.inputStream().buffered().use { ins -> ins.copyTo(out) } } }
        return combined
    }

    private fun copyZipToZip(src: File, zos: ZipOutputStream) {
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val name = safeEntryName(entry.name) ?: continue
                zos.putNextEntry(ZipEntry(if (entry.isDirectory) "$name/" else name))
                if (!entry.isDirectory) zf.getInputStream(entry).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun sevenZipToZip(src: File, zos: ZipOutputStream, password: String?) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var e = seven.nextEntry
            while (e != null) {
                val name = safeEntryName(e.name)
                if (name == null) { e = seven.nextEntry; continue }
                zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                if (!e.isDirectory) {
                    val buf = ByteArray(8192)
                    var r = seven.read(buf)
                    while (r > 0) { zos.write(buf, 0, r); r = seven.read(buf) }
                }
                zos.closeEntry()
                e = seven.nextEntry
            }
        }
    }

    private fun rarToZip(src: File, zos: ZipOutputStream, password: String?) {
        Archive(src, password ?: "").use { archive ->
            for (h in archive.fileHeaders) {
                val name = safeEntryName(h.fileName) ?: continue
                zos.putNextEntry(ZipEntry(if (h.isDirectory) "$name/" else name))
                if (!h.isDirectory) archive.extractFile(h, zos)
                zos.closeEntry()
            }
        }
    }

    private fun archiveStreamToZip(input: InputStream, forced: String?, zos: ZipOutputStream) {
        input.use { raw ->
            val ais: ArchiveInputStream<*> = if (forced == "tar") {
                TarArchiveInputStream(BufferedInputStream(raw))
            } else {
                ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            }
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val name = safeEntryName(e.name)
                    if (name != null && stream.canReadEntryData(e)) {
                        zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                        if (!e.isDirectory) stream.copyTo(zos)
                        zos.closeEntry()
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun compressedArchiveToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                archiveStreamToZip(cin, "tar", zos)
            }
        }
    }

    private fun singleCompressedToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        val outName = src.name.substringBeforeLast('.')
        zos.putNextEntry(ZipEntry(outName))
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { it.copyTo(zos) }
        }
        zos.closeEntry()
    }

    private fun extractZip(src: File, dest: File) {
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val out = safeOutput(dest, entry.name) ?: continue
                if (entry.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); zf.getInputStream(entry).use { input -> out.outputStream().use { output -> input.copyTo(output) } } }
            }
        }
    }

    private fun extract7z(src: File, dest: File, password: String?) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var e = seven.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { seven.getInputStream(e).copyTo(it) } }
                }
                e = seven.nextEntry
            }
        }
    }

    private fun extractRar(src: File, dest: File, password: String?) {
        Archive(src, password ?: "").use { archive ->
            for (h in archive.fileHeaders) {
                val out = safeOutput(dest, h.fileName) ?: continue
                if (h.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); out.outputStream().use { archive.extractFile(h, it) } }
            }
        }
    }

    private fun extractArchiveStream(input: InputStream, dest: File) {
        input.use { raw ->
            val ais: ArchiveInputStream<*> = ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val out = safeOutput(dest, e.name)
                    if (out != null) {
                        if (e.isDirectory) out.mkdirs()
                        else if (stream.canReadEntryData(e)) { out.parentFile?.mkdirs(); out.outputStream().use { stream.copyTo(it) } }
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun extractCompressedArchive(src: File, algorithm: String, dest: File) {
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                extractTarStream(cin, dest)
            }
        }
    }

    private fun extractTarStream(input: InputStream, dest: File) {
        TarArchiveInputStream(BufferedInputStream(input)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { tar.copyTo(it) } }
                }
                e = tar.nextEntry
            }
        }
    }

    private fun extractSingleCompressed(src: File, algorithm: String, dest: File) {
        val out = safeOutput(dest, src.name.substringBeforeLast('.')) ?: throw SecurityException("ชื่อไฟล์ไม่ปลอดภัย")
        out.parentFile?.mkdirs()
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { input -> out.outputStream().use { output -> input.copyTo(output) } }
        }
    }

    private fun safeEntryName(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val n = raw.replace('\\','/').trimStart('/')
        if (n.split('/').any { it == ".." }) return null
        return n
    }

    private fun safeOutput(dest: File, raw: String?): File? {
        val name = safeEntryName(raw) ?: return null
        val out = File(dest, name)
        val base = dest.canonicalPath + File.separator
        if (!out.canonicalPath.startsWith(base)) return null
        return out
    }

    fun compress(source: File, destination: File, format: String) {
        when (format.lowercase()) {
            "zip" -> createZip(source, destination)
            "7z" -> create7z(source, destination)
            "tar" -> createTar(source, destination)
            "gz","bz2","xz","lz4","zst" -> createSingleCompressed(source, destination, format.lowercase())
            else -> throw UnsupportedOperationException("ไม่รองรับรูปแบบ $format")
        }
    }

    private fun createZip(source: File, out: File) {
        // Write directly to the final destination. Do not use a temporary file/rename,
        // because the file manager needs the final path to become visible immediately.
        var fos: FileOutputStream? = null
        var zos: ZipOutputStream? = null
        try {
            fos = FileOutputStream(out)
            zos = ZipOutputStream(BufferedOutputStream(fos))
            addTreeToZip(source, source.name, zos)
        } finally {
            // ZipOutputStream must be closed first so the ZIP central directory is written.
            try {
                zos?.close()
            } finally {
                // The ZipOutputStream owns/closes the underlying FileOutputStream.
                // Keep this explicit as a safety net for every exit path.
                try {
                    fos?.close()
                } catch (_: Exception) {
                }
            }
        }

        // Force the completed archive to disk before notifying the media scanner.
        FileOutputStream(out).use { syncStream ->
            syncStream.fd.sync()
        }

        val context = applicationContextForArchiveScan()
        if (context != null) {
            MediaScannerConnection.scanFile(
                context,
                arrayOf(out.absolutePath),
                arrayOf("application/zip"),
                null
            )
            context.sendBroadcast(
                Intent(
                    Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    Uri.fromFile(out)
                )
            )
        }
    }

    /**
     * ArchiveManager intentionally has no Activity/Context parameter because its public API
     * is used from the existing MainActivity. Resolve the process Application context here
     * without changing any other source file.
     */
    private fun applicationContextForArchiveScan(): Context? {
        return try {
            val activityThread = Class.forName("android.app.ActivityThread")
            val currentApplication = activityThread
                .getDeclaredMethod("currentApplication")
                .invoke(null) as? Application
            currentApplication?.applicationContext
        } catch (_: Exception) {
            null
        }
    }

    private fun create7z(source: File, out: File) {
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(out).use { seven ->
            addTreeTo7z(source, source.name, seven)
        }
    }

    private fun createTar(source: File, out: File) {
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(BufferedOutputStream(FileOutputStream(out))).use { tar ->
            addTreeToTar(source, source.name, tar)
        }
    }

    private fun createSingleCompressed(source: File, out: File, format: String) {
        FileOutputStream(out).buffered().use { fos ->
            val cout = CompressorStreamFactory().createCompressorOutputStream(format, fos)
            cout.use { source.inputStream().use { it.copyTo(cout) } }
        }
    }

    private fun addTreeToZip(f: File, name: String, zos: ZipOutputStream) {
        if (f.isDirectory) {
            zos.putNextEntry(ZipEntry("$name/")); zos.closeEntry()
            f.listFiles()?.forEach { addTreeToZip(it, "$name/${it.name}", zos) }
        } else {
            zos.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(zos) }; zos.closeEntry()
        }
    }

    private fun addTreeTo7z(f: File, name: String, seven: org.apache.commons.compress.archivers.sevenz.SevenZOutputFile) {
        val e = org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry()
        e.name = name
        e.isDirectory = f.isDirectory
        seven.putArchiveEntry(e)
        if (!f.isDirectory) {
            f.inputStream().use { input ->
                val buffer = ByteArray(8192)
                var count = input.read(buffer)
                while (count > 0) {
                    seven.write(buffer, 0, count)
                    count = input.read(buffer)
                }
            }
        }
        seven.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTreeTo7z(it, "$name/${it.name}", seven) }
    }

    private fun addTreeToTar(f: File, name: String, tar: org.apache.commons.compress.archivers.tar.TarArchiveOutputStream) {
        val e = org.apache.commons.compress.archivers.tar.TarArchiveEntry(name)
        e.size = if (f.isFile) f.length() else 0
        tar.putArchiveEntry(e)
        if (f.isFile) f.inputStream().use { it.copyTo(tar) }
        tar.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTreeToTar(it, "$name/${it.name}", tar) }
    }

    /** Writes an edited temporary ZIP back to the original archive format safely. */
    fun syncEditedArchive(editedZip: File, original: File) {
        if (editedZip.absolutePath == original.absolutePath) return
        val format = formatOf(original)
        val temp = File(original.parentFile, ".${original.name}.korn-repack-${System.currentTimeMillis()}.tmp")
        try {
            repackZipToFormat(editedZip, temp, format)
            FileOutputStream(temp, true).use { it.fd.sync() }
            val backup = File(original.parentFile, ".${original.name}.korn-backup-${System.currentTimeMillis()}.tmp")
            if (backup.exists()) backup.delete()
            if (!original.renameTo(backup)) throw IOException("ไม่สามารถเตรียมไฟล์เดิมสำหรับแทนที่ได้")
            try {
                if (!temp.renameTo(original)) {
                    backup.renameTo(original)
                    throw IOException("ไม่สามารถแทนที่ไฟล์เดิมได้")
                }
                backup.delete()
            } catch (e: Exception) {
                if (!original.exists()) backup.renameTo(original)
                throw e
            }
            val context = applicationContextForArchiveScan()
            if (context != null) {
                MediaScannerConnection.scanFile(
                    context, arrayOf(original.absolutePath), arrayOf(mimeForArchive(original)), null
                )
                context.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(original)))
            }
        } finally {
            if (temp.exists()) temp.delete()
        }
    }

    private fun repackZipToFormat(zip: File, out: File, format: String) {
        when (format) {
            "zip" -> zip.inputStream().use { input -> out.outputStream().use { input.copyTo(it) } }
            "7z" -> repackZipTo7z(zip, out)
            "tar" -> repackZipToTar(zip, out, null)
            "tar.gz", "tgz" -> repackZipToTar(zip, out, CompressorStreamFactory.GZIP)
            "tar.bz2", "tbz2" -> repackZipToTar(zip, out, CompressorStreamFactory.BZIP2)
            "tar.xz", "txz" -> repackZipToTar(zip, out, CompressorStreamFactory.XZ)
            "gz" -> repackZipToSingleCompressed(zip, out, CompressorStreamFactory.GZIP)
            "bz2" -> repackZipToSingleCompressed(zip, out, CompressorStreamFactory.BZIP2)
            "xz" -> repackZipToSingleCompressed(zip, out, CompressorStreamFactory.XZ)
            "lz4" -> repackZipToSingleCompressed(zip, out, CompressorStreamFactory.LZ4_FRAMED)
            "zst" -> repackZipToSingleCompressed(zip, out, CompressorStreamFactory.ZSTANDARD)
            else -> throw UnsupportedOperationException("ไม่สามารถบันทึก ${format.uppercase()} หลังแก้ไขได้")
        }
    }

    private fun repackZipTo7z(zip: File, out: File) {
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(out).use { seven ->
            ZipFile(zip).use { zf ->
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    val name = safeEntryName(e.name) ?: continue
                    val outEntry = org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry().apply {
                        this.name = name
                        setDirectory(e.isDirectory)
                    }
                    seven.putArchiveEntry(outEntry)
                    if (!e.isDirectory) zf.getInputStream(e).use { input ->
                        val buffer = ByteArray(8192)
                        var count = input.read(buffer)
                        while (count > 0) {
                            seven.write(buffer, 0, count)
                            count = input.read(buffer)
                        }
                    }
                    seven.closeArchiveEntry()
                }
            }
        }
    }

    private fun repackZipToTar(zip: File, out: File, compressor: String?) {
        val raw = FileOutputStream(out).buffered()
        val target: OutputStream = if (compressor == null) raw else
            CompressorStreamFactory().createCompressorOutputStream(compressor, raw)
        target.use { compressed ->
            org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(compressed).use { tar ->
                ZipFile(zip).use { zf ->
                    val entries = zf.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val name = safeEntryName(e.name) ?: continue
                        val te = org.apache.commons.compress.archivers.tar.TarArchiveEntry(name).apply {
                            setDirectory(e.isDirectory)
                            if (!e.isDirectory && e.size >= 0) setSize(e.size)
                            if (e.time >= 0) setModTime(java.util.Date(e.time))
                        }
                        tar.putArchiveEntry(te)
                        if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(tar) }
                        tar.closeArchiveEntry()
                    }
                    tar.finish()
                }
            }
        }
    }

    private fun repackZipToSingleCompressed(zip: File, out: File, compressor: String) {
        ZipFile(zip).use { zf ->
            val files = zf.entries().asSequence().filter { !it.isDirectory }.toList()
            if (files.size != 1) throw IOException("ไฟล์รูปแบบ ${compressor.uppercase()} ต้องมีข้อมูลหลักเพียง 1 รายการ")
            val raw = FileOutputStream(out).buffered()
            CompressorStreamFactory().createCompressorOutputStream(compressor, raw).use { cout ->
                zf.getInputStream(files[0]).use { it.copyTo(cout) }
            }
        }
    }

    private fun mimeForArchive(file: File): String = when (formatOf(file)) {
        "zip" -> "application/zip"
        "7z" -> "application/x-7z-compressed"
        "tar", "tar.gz", "tgz", "tar.bz2", "tbz2", "tar.xz", "txz" -> "application/x-tar"
        else -> "application/octet-stream"
    }

}
