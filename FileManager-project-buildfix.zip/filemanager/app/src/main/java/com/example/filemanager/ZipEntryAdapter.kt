package com.example.filemanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.DecimalFormat
import kotlin.math.ln
import kotlin.math.pow

class ZipEntryAdapter(
    private var items: List<ZipVirtualEntry>,
    private val onClick: (ZipVirtualEntry) -> Unit,
    private val onLongClick: (ZipVirtualEntry) -> Boolean
) : RecyclerView.Adapter<ZipEntryAdapter.ViewHolder>() {

    private val selected = linkedSetOf<String>()

    fun toggleSelection(entry: ZipVirtualEntry) {
        if (!selected.add(entry.path)) selected.remove(entry.path)
        notifyDataSetChanged()
    }
    fun clearSelection() { selected.clear(); notifyDataSetChanged() }
    fun hasSelection(): Boolean = selected.isNotEmpty()
    fun selectedCount(): Int = selected.size
    fun selectedPaths(): Set<String> = selected.toSet()
    fun selectedEntries(): List<ZipVirtualEntry> = items.filter { it.path in selected }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView = view.findViewById(R.id.entryIcon)
        val name: TextView = view.findViewById(R.id.entryName)
        val subtitle: TextView = view.findViewById(R.id.entrySubtitle)
    }

    fun updateItems(newItems: List<ZipVirtualEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_zip_entry, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.name.text = entry.name
        if (entry.isDirectory) {
            holder.icon.text = "📁"
            holder.subtitle.text = "โฟลเดอร์"
        } else {
            holder.icon.text = iconFor(entry.name)
            holder.subtitle.text = readableSize(entry.size)
        }
        holder.itemView.isActivated = selected.contains(entry.path)
        holder.itemView.alpha = if (selected.contains(entry.path)) 0.65f else 1f
        holder.itemView.setOnClickListener { onClick(entry) }
        holder.itemView.setOnLongClickListener { onLongClick(entry) }
    }

    override fun getItemCount(): Int = items.size

    private fun iconFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in FileCategories.IMAGES -> "🖼️"
            in FileCategories.VIDEOS -> "🎬"
            in FileCategories.MUSIC -> "🎵"
            in FileCategories.DOCS -> "📄"
            in FileCategories.APPS -> "📦"
            in FileCategories.ARCHIVES -> "🗜️"
            else -> "📄"
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / 1024.0.pow(digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
