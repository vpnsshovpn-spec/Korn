package com.example.filemanager

import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.ArchiveManager
import com.example.filemanager.data.repository.existsCompat
import com.example.filemanager.data.service.ArchiveOperationService

/**
 * Extract's counterpart to CopyMoveConflictResolver.kt (Part 2/3) - same 3 pieces, same order,
 * just driven by archive entry relative paths (strings) instead of source Files, since an
 * archive's contents aren't File objects on disk until they're actually extracted:
 *   - conflict detection:  ArchiveManager.listEntries()  (new in this file's companion change)
 *   - the prompt itself:   ConflictDialogHelper.kt (showConflictDialog) - the exact same dialog
 *     Copy/Move uses, per ConflictDialogHelper.kt's own class doc
 *   - the actual transfer: ArchiveOperationService.kt/ArchiveManager.kt (extract logic itself
 *     unchanged - just now told which entries to overwrite/skip/rename)
 *
 * FileClickHelper.kt's startArchiveExtraction() calls [startExtractWithConflictCheck] instead
 * of starting ArchiveOperationService directly - no extraction logic lives here.
 *
 * Unlike Copy/Move (a flat list of top-level sources), RENAME needs to be recorded here rather
 * than left to an existing auto-rename fallback - extract() never had one (existing behavior
 * for any entry it doesn't know about is silent overwrite, not auto-rename - see
 * KORN-Conflict-Dialog-Part2-Status.txt's note on this). ArchiveManager.safeOutput() picks a
 * fresh unique name for exactly the entries listed in [renameEntries] and nothing else, so
 * entries with no conflict keep behaving exactly as before this feature existed.
 *
 * Rotation Safety #2: same change as CopyMoveConflictResolver.kt - the batch now lives in
 * MainViewModel.extractConflictBatch instead of local recursion, so it survives process death.
 * See MainViewModel's class-doc note on why the archive password specifically is NOT part of
 * what's persisted to SavedStateHandle. ConflictBatchObserver.kt drives the actual loop.
 */
internal fun MainActivity.startExtractWithConflictCheck(file: File, destination: File, mode: Int, password: String?) {
    // Mode 0 ("อัตโนมัติ") always extracts into a brand-new folder made with uniqueName() right
    // before this is called (see startArchiveExtraction in FileClickHelper.kt) - that folder is
    // guaranteed empty, so it can never collide with anything. Skip the scan entirely instead
    // of spending time reading the archive for a result that's always "no conflicts".
    if (mode == 0) {
        beginArchiveExtraction(file, destination, password, emptySet(), emptySet(), emptySet())
        return
    }

    lifecycleScope.launch {
        val entries = try {
            withContext(Dispatchers.IO) { ArchiveManager.listEntries(file, cacheDir, password) }
        } catch (e: Exception) {
            // Can't be scanned ahead of time (wrong password, corrupt/unsupported archive,
            // etc.) - fall back to starting extraction directly, exactly as it always has. The
            // real attempt inside ArchiveOperationService still runs and reports its own
            // success/failure the normal way; this feature just can't offer a conflict dialog
            // for an archive it couldn't read in the first place.
            emptyList()
        }
        val conflicts = entries.filter { relPath -> File(destination, relPath).existsCompat() }
        if (conflicts.isEmpty()) {
            beginArchiveExtraction(file, destination, password, emptySet(), emptySet(), emptySet())
            return@launch
        }
        viewModel.startExtractConflictBatch(
            MainViewModel.ExtractConflictBatch(
                filePath = file.absolutePath,
                destinationPath = destination.absolutePath,
                remaining = conflicts,
                overwriteEntries = emptySet(),
                skipEntries = emptySet(),
                renameEntries = emptySet(),
                forcedAction = null,
                hadPassword = password != null
            ),
            password = password
        )
    }
}

/**
 * Extract's counterpart to CopyMoveConflictResolver.kt's applyCopyMoveResolution() - same
 * shape, called from ConflictBatchObserver.kt.
 */
internal fun MainActivity.applyExtractResolution(
    batch: MainViewModel.ExtractConflictBatch,
    resolution: ConflictResolution
) {
    val current = batch.remaining.firstOrNull() ?: return
    if (resolution.action == ConflictAction.CANCEL) {
        Toast.makeText(this, "ยกเลิกการแตกไฟล์แล้ว", Toast.LENGTH_SHORT).show()
        viewModel.clearExtractConflictBatch()
        return
    }
    val nextBatch = batch.copy(
        remaining = batch.remaining.drop(1),
        overwriteEntries = if (resolution.action == ConflictAction.OVERWRITE) batch.overwriteEntries + current else batch.overwriteEntries,
        skipEntries = if (resolution.action == ConflictAction.SKIP) batch.skipEntries + current else batch.skipEntries,
        renameEntries = if (resolution.action == ConflictAction.RENAME) batch.renameEntries + current else batch.renameEntries,
        forcedAction = if (resolution.applyToAll) resolution.action else batch.forcedAction
    )
    if (nextBatch.remaining.isEmpty()) {
        viewModel.clearExtractConflictBatch()
        beginArchiveExtraction(
            File(nextBatch.filePath), File(nextBatch.destinationPath), viewModel.currentExtractPassword(),
            nextBatch.overwriteEntries, nextBatch.skipEntries, nextBatch.renameEntries
        )
    } else {
        viewModel.updateExtractConflictBatch(nextBatch)
    }
}

private fun MainActivity.beginArchiveExtraction(
    file: File,
    destination: File,
    password: String?,
    overwriteEntries: Set<String>,
    skipEntries: Set<String>,
    renameEntries: Set<String>
) {
    startArchiveOperationWithNotificationCheck {
        Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
        viewModel.setArchiveOpStarted(isUnzip = true, archiveName = file.name)
        ArchiveOperationService.startUnzip(this, file, destination, password, overwriteEntries, skipEntries, renameEntries)
    }
}
