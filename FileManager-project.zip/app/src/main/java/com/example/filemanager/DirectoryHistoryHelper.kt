package com.example.filemanager

import android.content.Context
import java.io.File

/**
 * Persistence helpers for directory navigation history.
 *
 * This class owns only DataStore-backed history data. UI state, navigation mode and
 * Activity lifecycle remain in MainActivity so existing browsing behavior is preserved.
 *
 * Task 3: previously stored recent folders / open windows as a single SharedPreferences
 * string joined with "\n". That format silently corrupted (or dropped) any path
 * containing a literal backslash-n and had no room to grow (e.g. per-entry timestamps)
 * without inventing another delimiter. Now stored as a JSON string array via
 * [AppDataStore], one key per list. See [AppDataStore] for why reads/writes here stay
 * synchronous (`runBlocking` bridge) instead of suspend functions.
 */
class DirectoryHistoryHelper(private val context: Context) {

    companion object {
        private val KEY_RECENT_FOLDERS = AppDataStore.key("recent_folders_json")
        private val KEY_OPEN_WINDOWS = AppDataStore.key("open_windows_json")
    }

    fun rememberRecentFolder(dir: File, isTrashMode: Boolean) {
        if (isTrashMode || !dir.isDirectory) return

        val old = AppDataStore.readStringList(context, KEY_RECENT_FOLDERS)
        val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath }).take(15)
        AppDataStore.writeStringList(context, KEY_RECENT_FOLDERS, updated)
    }

    fun loadRecentFolders(): List<File> {
        return AppDataStore.readStringList(context, KEY_RECENT_FOLDERS)
            .mapNotNull { path ->
                File(path).takeIf { file -> file.isDirectory && file.canRead() }
            }
    }

    fun clearRecentHistory() {
        AppDataStore.writeStringList(context, KEY_RECENT_FOLDERS, emptyList())
        AppDataStore.writeStringList(context, KEY_OPEN_WINDOWS, emptyList())
        // Also clears recently-opened *files* (FileOpenHelper.rememberRecentFile) - same
        // behavior as the old code, which cleared the "recent_files" SharedPreferences here.
        AppDataStore.writeStringList(context, RECENT_FILES_KEY, emptyList())
    }

    fun loadOpenWindows(): List<String> {
        return AppDataStore.readStringList(context, KEY_OPEN_WINDOWS)
            .mapNotNull { path ->
                File(path).takeIf { it.isDirectory }?.absolutePath
            }
    }

    fun saveOpenWindows(paths: List<String>) {
        AppDataStore.writeStringList(context, KEY_OPEN_WINDOWS, paths.take(12))
    }

    fun rememberOpenWindow(dir: File, currentPaths: List<String>): List<String> {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        val updated = currentPaths.filter { it != path }.toMutableList()
        updated.add(0, path)
        while (updated.size > 12) updated.removeAt(updated.lastIndex)
        saveOpenWindows(updated)
        return updated
    }
}
