package com.example.filemanager

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.Button
import android.graphics.Typeface
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    // Launches the system folder picker so the user can grant access to a
    // folder ordinary File APIs can't reach (e.g. another app's Android/data
    // on Android 11+). Whether that folder is even selectable depends on
    // the device/OS - Google blocks this at the system level on most stock
    // builds, this just uses whatever the picker allows.
    private val safFolderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            startActivity(Intent(this, SafBrowserActivity::class.java).apply {
                putExtra(SafBrowserActivity.EXTRA_TREE_URI, uri.toString())
            })
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดโฟลเดอร์นี้ไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSafFolderPicker() {
        AlertDialog.Builder(this)
            .setTitle("เข้าถึงโฟลเดอร์พิเศษ (SAF)")
            .setMessage(
                "หน้าจอถัดไปจะให้เลือกโฟลเดอร์ผ่านตัวเลือกไฟล์ของระบบ Android เอง " +
                    "ถ้าต้องการเข้า Android/data ให้กดเข้าไปเลือกโฟลเดอร์นั้นตรงๆ\n\n" +
                    "หมายเหตุ: Android 11 ขึ้นไปบล็อกโฟลเดอร์ Android/data และ Android/obb " +
                    "ไว้ที่ระดับระบบปฏิบัติการ บางเครื่อง/บางยี่ห้อจะเลือกไม่ได้เลย ไม่ใช่ปัญหาของแอปนี้"
            )
            .setPositiveButton("เลือกโฟลเดอร์") { _, _ ->
                safFolderPicker.launch(null)
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private enum class Mode { NORMAL, CATEGORY, SEARCH, TRASH, APPS }
    private enum class SortKey { NAME, SIZE, DATE }

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var breadcrumbBar: LinearLayout
    private lateinit var breadcrumbScroll: android.widget.HorizontalScrollView
    private lateinit var storagePercent: TextView
    private lateinit var bookmarksBar: android.widget.LinearLayout
    private lateinit var categoryBar: android.widget.LinearLayout
    private lateinit var storageBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var adapter: FileAdapter
    private lateinit var bookmarksManager: BookmarksManager
    private lateinit var trashManager: TrashManager
    private lateinit var selectionActionBar: LinearLayout
    private lateinit var clipboardActionBar: LinearLayout
    private lateinit var trashActionBar: LinearLayout
    private lateinit var selectionMoreButton: TextView
    private lateinit var clipboardPasteButton: TextView
    private lateinit var toolbarHomeButton: android.widget.ImageButton
    private val openWindows = mutableListOf<String>()

    private var currentDir: File = Environment.getExternalStorageDirectory()
    private var lastNormalDir: File = Environment.getExternalStorageDirectory()
    private var clipboardFiles: List<File> = emptyList()
    private var clipboardIsCut = false

    // Pending archive extraction destination: 0=auto, 1=current, 2=chosen.
    private var pendingArchiveFile: File? = null
    private var pendingArchivePassword: String? = null
    private var pendingArchiveMode: Int = 0

    private var mode = Mode.NORMAL
    private var showHidden = false
    private var currentCategoryLabel: String? = null
    private var currentCategoryExts: Set<String>? = null
    private var lastSearchQuery: String? = null

    private var sortKey = SortKey.NAME
    private var sortAscending = true
    private var isGridMode = false
    private var fileViewMode = FileAdapter.ViewMode.LIST
    private var confirmDelete = true
    private var themeKey = "blue"
    private var drawerHiddenSwitch: com.google.android.material.switchmaterial.SwitchMaterial? = null

    private val STORAGE_PERMISSION_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        // IMPORTANT: AppCompat must know the requested night mode BEFORE
        // super.onCreate() inflates/resolves the activity theme resources.
        // If this is done after super.onCreate(), a saved "system" preference
        // can leave the first frame using the light palette (white background)
        // while text is already resolved from the night palette (light gray).
        loadUserPreferences()
        applySavedNightMode()
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        setSupportActionBar(findViewById(R.id.toolbar))
        setupNavigationDrawer()
        setupToolbarHomeButton()
        setupToolbarSearchButton()
        supportActionBar?.title = getString(R.string.app_name)

        breadcrumbBar = findViewById(R.id.breadcrumbBar)
        breadcrumbScroll = findViewById(R.id.breadcrumbScroll)
        storagePercent = findViewById(R.id.storagePercent)
        storagePercent.setOnClickListener { startActivity(Intent(this, StorageAnalyzerActivity::class.java)) }
        recyclerView = findViewById(R.id.fileList)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        bookmarksBar = findViewById(R.id.bookmarksBar)
        categoryBar = findViewById(R.id.categoryBar)
        storageBar = findViewById(R.id.storageBar)
        storageText = findViewById(R.id.storageText)
        applyThemePalette()

        selectionActionBar = findViewById(R.id.selectionActionBar)
        clipboardActionBar = findViewById(R.id.clipboardActionBar)
        trashActionBar = findViewById(R.id.trashActionBar)
        findViewById<com.google.android.material.button.MaterialButton>(R.id.emptyTrashButton).setOnClickListener { emptyTrashConfirm() }
        trashActionBar.visibility = View.GONE
        selectionMoreButton = findViewById(R.id.selectionMoreButton)
        clipboardPasteButton = findViewById(R.id.clipboardPasteButton)
        findViewById<TextView>(R.id.selectionCopyButton).setOnClickListener { copySelected() }
        findViewById<TextView>(R.id.selectionCutButton).setOnClickListener { moveSelected() }
        findViewById<TextView>(R.id.selectionRenameButton).setOnClickListener { renameSelected() }
        findViewById<TextView>(R.id.selectionDeleteButton).setOnClickListener { deleteSelectedToTrash() }
        findViewById<TextView>(R.id.selectionCancelButton).setOnClickListener { exitSelectionMode() }
        selectionMoreButton.setOnClickListener { showSelectionMoreMenu() }
        clipboardPasteButton.setOnClickListener { pasteClipboard() }
        findViewById<TextView>(R.id.clipboardNewButton).setOnClickListener { newFolderDialog() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton).setOnClickListener { showAddMenu() }
        findViewById<android.widget.Button>(R.id.addBookmarkButton).setOnClickListener { addBookmark(currentDir) }
        findViewById<android.widget.Button>(R.id.manageBookmarksButton).setOnClickListener { manageBookmarksDialog() }
        findViewById<android.widget.Button>(R.id.sortFilesButton).setOnClickListener { showSortDialog() }
        findViewById<android.widget.Button>(R.id.viewModeButton).setOnClickListener { toggleGridMode() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton).setOnClickListener { showWindowsDialog() }
        findViewById<TextView>(R.id.clipboardCancelButton).setOnClickListener {
            clipboardFiles = emptyList()
            clipboardIsCut = false
            updateActionBars()
        }

        bookmarksManager = BookmarksManager(this)
        trashManager = TrashManager(this)
        loadOpenWindows()
        intent.getStringExtra("start_path")?.let { File(it).takeIf { f -> f.isDirectory }?.let { f ->
            currentDir = f
            lastNormalDir = f
        }}

        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter = FileAdapter(this, emptyList(), ::onItemClick, ::onItemLongClick, ::onStartFileDrag, ::onDropOnFolder)
        adapter.onSelectionChanged = {
            updateSelectionSubtitle()
            updateActionBars()
        }
        recyclerView.adapter = adapter
        adapter.setViewMode(fileViewMode)
        updateActionBars()

        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { refreshCurrentView() }

        setupCategoryBar()
        applyThemePalette()
        MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager)
        checkPermissionsAndLoad()
    }

    override fun onResume() {
        super.onResume()
        ensureDevelopmentBookmarksSafe()
        refreshBookmarksBar()
        updateStorageBar()
    }

    private fun ensureDevelopmentBookmarksSafe() {
        try { MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager) } catch (_: Exception) {}
    }

    private fun applySavedNightMode() {
        when (themeKey) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun loadUserPreferences() {
        val prefs = getSharedPreferences("korn_settings", MODE_PRIVATE)
        showHidden = prefs.getBoolean("show_hidden", false)
        isGridMode = prefs.getBoolean("grid_mode", false)
        fileViewMode = when (prefs.getString("view_mode", if (isGridMode) "GRID" else "LIST")) {
            "COMPACT" -> FileAdapter.ViewMode.COMPACT
            "GRID" -> FileAdapter.ViewMode.GRID
            "DETAILS" -> FileAdapter.ViewMode.DETAILS
            else -> FileAdapter.ViewMode.LIST
        }
        isGridMode = fileViewMode == FileAdapter.ViewMode.GRID
        confirmDelete = prefs.getBoolean("confirm_delete", true)
        sortKey = when (prefs.getString("sort_key", "NAME")) {
            "SIZE" -> SortKey.SIZE
            "DATE" -> SortKey.DATE
            else -> SortKey.NAME
        }
        sortAscending = prefs.getBoolean("sort_ascending", true)
        themeKey = prefs.getString("theme_key", "system") ?: "system"
    }

    private fun saveUserPreferences() {
        getSharedPreferences("korn_settings", MODE_PRIVATE).edit()
            .putBoolean("show_hidden", showHidden)
            .putBoolean("grid_mode", isGridMode)
            .putString("view_mode", fileViewMode.name)
            .putBoolean("confirm_delete", confirmDelete)
            .putString("theme_key", themeKey)
            .putString("sort_key", sortKey.name)
            .putBoolean("sort_ascending", sortAscending)
            .apply()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_overflow_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_about_korn -> {
                showAboutKornDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutKornDialog() {
        AlertDialog.Builder(this)
            .setTitle("เกี่ยวกับ KORN")
            .setMessage(
                "KORN File Manager — By KORN\n\n" +
                "แอปพลิเคชันนี้เป็นผลงานของ KORN\n" +
                "ห้ามคัดลอก ดัดแปลง แก้ไข แจกจ่าย หรือเผยแพร่ส่วนหนึ่งส่วนใดของแอปพลิเคชัน " +
                "โดยไม่ได้รับอนุญาตจาก KORN"
            )
            .setPositiveButton("ตกลง", null)
            .show()
    }

    private fun showSettingsDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val themeTitle = TextView(this).apply {
            text = "ธีม"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        }
        container.addView(themeTitle)
        val themeOptions = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val themeKeys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val themeGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.RadioGroup.VERTICAL }
        themeOptions.forEachIndexed { index, label ->
            val radio = android.widget.RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                isChecked = themeKeys[index] == themeKey
            }
            themeGroup.addView(radio)
        }
        // Only remember the tapped option here; do NOT touch night mode or
        // repaint the UI while the dialog is still open. Doing that on every
        // radio tap (especially the first one, before the dialog has finished
        // laying out) is what caused the dim/washed-out flash on first open.
        var pendingThemeKey = themeKey
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = themeGroup.indexOfChild(themeGroup.findViewById(checkedId))
            pendingThemeKey = themeKeys.getOrElse(selected) { themeKey }
        }
        container.addView(themeGroup)

        val hidden = android.widget.CheckBox(this).apply {
            text = "แสดงไฟล์ที่ซ่อน"
            isChecked = showHidden
        }
        hidden.setOnCheckedChangeListener { _, checked ->
            showHidden = checked
            drawerHiddenSwitch?.setOnCheckedChangeListener(null)
            drawerHiddenSwitch?.isChecked = checked
            drawerHiddenSwitch?.setOnCheckedChangeListener { _, value ->
                if (showHidden == value) return@setOnCheckedChangeListener
                showHidden = value
                saveUserPreferences()
                refreshCurrentView()
            }
            saveUserPreferences()
            refreshCurrentView()
        }
        container.addView(hidden)

        val confirm = android.widget.CheckBox(this).apply {
            text = "ยืนยันก่อนลบ"
            isChecked = confirmDelete
        }
        confirm.setOnCheckedChangeListener { _, checked ->
            confirmDelete = checked
            saveUserPreferences()
        }
        container.addView(confirm)

        val grid = android.widget.CheckBox(this).apply {
            text = "ใช้มุมมองตาราง"
            isChecked = isGridMode
        }
        grid.setOnCheckedChangeListener { _, checked ->
            if (isGridMode != checked) toggleGridMode()
        }
        container.addView(grid)

        val settingsDialog = AlertDialog.Builder(this)
            .setTitle("การตั้งค่า")
            .setView(container)
            .setNeutralButton("เรียงลำดับ") { _, _ -> showSortDialog() }
            .setPositiveButton("เสร็จสิ้น") { _, _ ->
                themeKey = pendingThemeKey
                saveUserPreferences()
                when (themeKey) {
                    "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
                applyThemePalette()
            }
            .show()

        // Prevent the dialog's own dim overlay from stacking with the
        // activity's dim on the very first show, which is what produced the
        // washed-out/dim look until the dialog was reopened once.
        settingsDialog.window?.apply {
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.5f)
        }
    }

    // Delegates to ThemeHelper so every screen in the app (text editor, zip
    // browser, storage analyzer, open-with picker) reads the exact same
    // palette as the main screen instead of each activity guessing its own.
    private fun themeColors(): Triple<Int, Int, Int> = ThemeHelper.colors(this)

    private fun applyThemePalette() {
        // setupNavigationDrawer() is called early in onCreate(), before the
        // storage/category views are initialized. Do not touch lateinit views
        // until all of them are ready; the full palette is applied again later.
        if (!::drawerLayout.isInitialized ||
            !::storageText.isInitialized ||
            !::storagePercent.isInitialized ||
            !::categoryBar.isInitialized) return
        val (primary, primaryDark, background) = themeColors()
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(primary)
        window.statusBarColor = primaryDark
        drawerLayout.setBackgroundColor(background)
        findViewById<android.widget.LinearLayout>(R.id.mainContent)?.setBackgroundColor(background)
        findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.fileList)?.setBackgroundColor(background)
        val systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val darkSurface = themeKey == "dark" || (themeKey == "system" && systemDark)
        findViewById<android.widget.HorizontalScrollView>(R.id.breadcrumbScroll)?.setBackgroundColor(
            if (darkSurface) android.graphics.Color.rgb(42, 46, 51) else android.graphics.Color.rgb(238, 241, 244)
        )
        navigationView.setBackgroundColor(if (darkSurface) android.graphics.Color.rgb(36, 39, 43) else background)
        val text = if (darkSurface) android.graphics.Color.rgb(245, 247, 249) else android.graphics.Color.rgb(32, 35, 39)
        val secondary = if (darkSurface) android.graphics.Color.rgb(190, 197, 204) else android.graphics.Color.rgb(82, 88, 96)
        storageText.setTextColor(secondary)
        storagePercent.setBackgroundColor(primary)
        storagePercent.setTextColor(android.graphics.Color.WHITE)
        val tint = android.content.res.ColorStateList.valueOf(primary)
        findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton)?.backgroundTintList = tint
        findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton)?.backgroundTintList = tint
        val toolIds = listOf(R.id.addBookmarkButton, R.id.manageBookmarksButton, R.id.sortFilesButton, R.id.viewModeButton)
        if (themeKey == "gray") {
            // Gray theme: keep the tool row clearly enabled and readable.
            // Use a neutral slate-gray distinct from the Black theme's blue-gray primary.
            val grayTool = android.graphics.Color.rgb(101, 109, 121)
            toolIds.forEach { id ->
                findViewById<android.widget.Button>(id)?.apply {
                    backgroundTintList = android.content.res.ColorStateList.valueOf(grayTool)
                    setTextColor(android.graphics.Color.WHITE)
                }
            }
        } else {
            toolIds.forEach { id ->
                findViewById<android.widget.Button>(id)?.apply {
                    backgroundTintList = android.content.res.ColorStateList.valueOf(primary)
                    setTextColor(android.graphics.Color.WHITE)
                }
            }
        }
        val category = categoryBar.takeIf { ::categoryBar.isInitialized }
        category?.let { bar -> for (i in 0 until bar.childCount) { (bar.getChildAt(i) as? TextView)?.setBackgroundColor(primary) } }
        navigationView.itemTextColor = android.content.res.ColorStateList.valueOf(text)
        navigationView.itemIconTintList = android.content.res.ColorStateList.valueOf(if (darkSurface) android.graphics.Color.rgb(220,225,230) else android.graphics.Color.rgb(72,78,86))
        // The drawer's header (logo/title strip at the top) is a separate view
        // added via app:headerLayout - it isn't part of the list items above,
        // so it needs its background set explicitly or it stays whatever
        // android:background is hardcoded to in nav_header.xml regardless of
        // the theme picked here.
        navigationView.getHeaderView(0)?.setBackgroundColor(primary)
    }

    private fun showSortDialog() {
        val options = arrayOf(
            "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
            "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
            "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
        )
        val checked = when {
            sortKey == SortKey.NAME && sortAscending -> 0
            sortKey == SortKey.NAME -> 1
            sortKey == SortKey.SIZE && !sortAscending -> 2
            sortKey == SortKey.SIZE -> 3
            !sortAscending -> 4
            else -> 5
        }
        AlertDialog.Builder(this).setTitle("เรียงลำดับ").setSingleChoiceItems(options, checked) { d, which ->
            when (which) {
                0 -> applySort(SortKey.NAME, true)
                1 -> applySort(SortKey.NAME, false)
                2 -> applySort(SortKey.SIZE, false)
                3 -> applySort(SortKey.SIZE, true)
                4 -> applySort(SortKey.DATE, false)
                5 -> applySort(SortKey.DATE, true)
            }
            saveUserPreferences()
            d.dismiss()
        }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun clearRecentHistory() {
        getSharedPreferences("recent_files", MODE_PRIVATE).edit().clear().apply()
        getSharedPreferences("recent_folders", MODE_PRIVATE).edit().clear().apply()
        Toast.makeText(this, "ล้างประวัติล่าสุดแล้ว", Toast.LENGTH_SHORT).show()
    }

    private fun setupNavigationDrawer() {
        // Keep the original simple 3-line hamburger icon.
        // Clicking it opens/closes the drawer; edge-swipe remains enabled by DrawerLayout.
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_hamburger)
        toolbar.setNavigationOnClickListener {
            if (drawerLayout.isDrawerOpen(Gravity.START)) {
                drawerLayout.closeDrawer(Gravity.START)
            } else {
                drawerLayout.openDrawer(Gravity.START)
            }
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home, R.id.nav_internal -> loadDirectory(Environment.getExternalStorageDirectory())
                R.id.nav_removable -> {
                    val removable = getRemovableStorageDirectories().firstOrNull()
                    if (removable != null) loadDirectory(removable)
                    else Toast.makeText(this, "ไม่พบ SD Card / USB ที่เชื่อมต่ออยู่", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_minecraft -> {
                    val d = File(Environment.getExternalStorageDirectory(), "KORN/MinecraftAddons")
                    d.mkdirs()
                    loadDirectory(d)
                }
                R.id.nav_minecraft_tools -> MinecraftAddonTools.showTools(this, currentDir)
                R.id.nav_recent -> loadRecentFolders()
                R.id.nav_clear_recent -> clearRecentHistory()
                R.id.nav_bookmarks -> manageBookmarksDialog()
                R.id.nav_trash -> loadTrash()
                R.id.nav_analyzer -> startActivity(Intent(this, StorageAnalyzerActivity::class.java))
                R.id.nav_saf_data -> openSafFolderPicker()
                R.id.nav_theme -> showThemeDialog()
            }
            drawerLayout.closeDrawers()
            true
        }
        updateRemovableStorageDrawerItem()
        setupDrawerQuickControls()
        applyThemePalette()
    }

    private fun setupDrawerQuickControls() {
        val hiddenItem = navigationView.menu.findItem(R.id.nav_show_hidden)
        val switch = hiddenItem?.actionView as? com.google.android.material.switchmaterial.SwitchMaterial
        drawerHiddenSwitch = switch
        switch?.isChecked = showHidden
        switch?.setOnCheckedChangeListener { _, checked ->
            if (showHidden == checked) return@setOnCheckedChangeListener
            showHidden = checked
            saveUserPreferences()
            refreshCurrentView()
        }
    }

    private fun showThemeDialog() {
        val labels = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val keys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val checked = keys.indexOf(themeKey).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("ธีมสี").setSingleChoiceItems(labels, checked) { dialog, which ->
            themeKey = keys[which]
            saveUserPreferences()
            when (themeKey) {
                "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            applyThemePalette()
            dialog.dismiss()
        }.setNegativeButton("ยกเลิก", null).show()
    }



    private fun getRemovableStorageDirectories(): List<File> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return emptyList()
        val sm = getSystemService(StorageManager::class.java)
        return sm.storageVolumes.mapNotNull { volume ->
            if (!volume.isRemovable) return@mapNotNull null
            volume.directory?.takeIf { it.isDirectory }
        }
    }

    private fun updateRemovableStorageDrawerItem() {
        val item = navigationView.menu.findItem(R.id.nav_removable) ?: return
        val dirs = getRemovableStorageDirectories()
        item.isVisible = dirs.isNotEmpty()
        if (dirs.isNotEmpty()) {
            item.title = if (dirs.size == 1) "SD Card / USB" else "SD Card / USB (${dirs.size})"
        }
    }


    // ---------- Storage usage bar ----------

    private fun updateStorageBar() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = total - free
            val pct = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0
            storageBar.max = 100
            storageBar.progress = pct.coerceIn(0, 100)
            storagePercent.text = "$pct%"
            storageText.text = "ใช้ไป ${readableSize(used)} จาก ${readableSize(total)} (เหลือ ${readableSize(free)})"
        } catch (e: Exception) {
            storageText.text = ""
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }

    // ---------- Sorting ----------

    private fun comparator(): Comparator<FileEntry> {
        val byField: Comparator<FileEntry> = when (sortKey) {
            SortKey.NAME -> compareBy { it.file.name.lowercase() }
            SortKey.SIZE -> compareBy { if (it.isDirectory) 0L else it.file.length() }
            SortKey.DATE -> compareBy { it.file.lastModified() }
        }
        val directional = if (sortAscending) byField else byField.reversed()
        // Folders always sort before files, regardless of the chosen field.
        return compareBy<FileEntry> { !it.isDirectory }.then(directional)
    }

    private fun applySort(key: SortKey, ascending: Boolean) {
        sortKey = key
        sortAscending = ascending
        saveUserPreferences()
        refreshCurrentView()
    }

    // ---------- Grid / list toggle ----------

    private fun toggleGridMode() {
        showViewModeDialog()
    }

    private fun applyFileViewMode(mode: FileAdapter.ViewMode) {
        fileViewMode = mode
        isGridMode = mode == FileAdapter.ViewMode.GRID
        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter.setViewMode(mode)
        saveUserPreferences()
    }

    private fun showViewModeDialog() {
        val labels = arrayOf("รายการปกติ", "รายการขนาดเล็ก", "ตาราง", "รายละเอียด: ขนาด + วันที่")
        val modes = arrayOf(FileAdapter.ViewMode.LIST, FileAdapter.ViewMode.COMPACT, FileAdapter.ViewMode.GRID, FileAdapter.ViewMode.DETAILS)
        val checked = modes.indexOf(fileViewMode).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("มุมมองไฟล์")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                applyFileViewMode(modes[which])
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Multi-select ----------

    private fun updateSelectionSubtitle() {
        supportActionBar?.subtitle = "เลือก ${adapter.selectionCount()} รายการ"
    }

    private fun exitSelectionMode() {
        adapter.setSelectionMode(false)
        swipeRefresh.isEnabled = true
        updateActionBars()
        refreshCurrentView()
    }

    private fun updateActionBars() {
        if (!::selectionActionBar.isInitialized) return
        selectionActionBar.visibility = if (adapter.selectionMode) View.VISIBLE else View.GONE
        clipboardActionBar.visibility =
            if (!adapter.selectionMode && clipboardFiles.isNotEmpty()) View.VISIBLE else View.GONE
        trashActionBar.visibility = if (!adapter.selectionMode && mode == Mode.TRASH) View.VISIBLE else View.GONE
    }

    private fun showSelectionMoreMenu() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }

        val popup = PopupMenu(this, selectionMoreButton)
        popup.menu.add("เลือกทั้งหมด").setOnMenuItemClickListener {
            adapter.selectAll()
            true
        }
        popup.menu.add("แชร์ที่เลือก").setOnMenuItemClickListener {
            shareSelected()
            true
        }

        if (files.size == 1) {
            val file = files[0]
            popup.menu.add("เปลี่ยนชื่อ").setOnMenuItemClickListener {
                renameDialog(file)
                true
            }
            if (file.isDirectory) {
                popup.menu.add("เพิ่มในรายการโปรด").setOnMenuItemClickListener {
                    addBookmark(file)
                    true
                }
            }
            popup.menu.add(if (file.name.startsWith(".")) "เลิกซ่อน" else "ซ่อน")
                .setOnMenuItemClickListener {
                    hideFile(file, !file.name.startsWith("."))
                    true
                }
            popup.menu.add(if (file.isDirectory) "บีบอัด…" else "บีบอัด…")
                .setOnMenuItemClickListener {
                    showCompressFormatDialog(file)
                    true
                }
            if (!file.isDirectory && ArchiveManager.isArchive(file)) {
                popup.menu.add("แตกไฟล์…").setOnMenuItemClickListener {
                    extractArchiveDialog(file)
                    true
                }
            }
        } else {
            popup.menu.add("เปลี่ยนชื่อหลายไฟล์").setOnMenuItemClickListener {
                batchRenameDialog()
                true
            }
        }
        popup.show()
    }

    private fun copySelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = false
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "คัดลอก ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun moveSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = true
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "เลือกย้าย ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun renameSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }
        if (files.size == 1) {
            renameDialog(files[0])
        } else {
            batchRenameDialog()
        }
    }

    private fun deleteSelectedToTrash() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        val action = {
            files.forEach { trashManager.moveToTrash(it) }
            exitSelectionMode()
            Toast.makeText(this, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
        }
        if (!confirmDelete) { action(); return }
        AlertDialog.Builder(this)
            .setTitle("ย้าย ${files.size} รายการไปถังขยะ?")
            .setPositiveButton("ย้ายไปถังขยะ") { _, _ -> action() }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun shareSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toastNoSelection() {
        Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
    }

    // ---------- Category shortcuts (images / video / music / docs / apps / archives) ----------

    private fun setupCategoryBar() {
        val categories: List<Pair<String, Set<String>?>> = listOf(
            "ทั้งหมด" to null,
            "รูปภาพ" to FileCategories.IMAGES,
            "วิดีโอ" to FileCategories.VIDEOS,
            "เพลง" to FileCategories.MUSIC,
            "เอกสาร" to FileCategories.DOCS,
            "แอปพลิเคชัน" to FileCategories.APPS,
            "ไฟล์บีบอัด" to FileCategories.ARCHIVES
        )
        for ((label, exts) in categories) {
            val chip = TextView(this).apply {
                text = label
                setPadding(28, 14, 28, 14)
                setBackgroundColor(themeColors().first)
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 10
                layoutParams = lp
                setOnClickListener {
                    if (label == "แอปพลิเคชัน") {
                        loadInstalledApps()
                    } else if (exts == null) {
                        mode = Mode.NORMAL
                        loadDirectory(lastNormalDir)
                    } else {
                        runCategoryScan(label, exts)
                    }
                }
            }
            categoryBar.addView(chip)
        }
    }

    private fun runCategoryScan(label: String, exts: Set<String>) {
        mode = Mode.CATEGORY
        trashActionBar.visibility = View.GONE
        currentCategoryLabel = label
        currentCategoryExts = exts
        showSpecialPath("หมวดหมู่: $label")
        supportActionBar?.subtitle = "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        lifecycleScope.launch {
            try {
                val results = withContext(Dispatchers.IO) { FileScanner.scanByExtensions(root, exts, hidden) }
                swipeRefresh.isRefreshing = false
                if (mode != Mode.CATEGORY || currentCategoryLabel != label) return@launch
                val entries = results.map { FileEntry(it) }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun loadInstalledApps() {
        mode = Mode.APPS
        trashActionBar.visibility = View.GONE
        showSpecialPath("แอปพลิเคชันในเครื่อง")
        supportActionBar?.subtitle = "กำลังโหลดแอป…"
        lifecycleScope.launch {
            try {
                val entries = withContext(Dispatchers.IO) {
                    packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                        .mapNotNull { app ->
                            val path = app.sourceDir ?: return@mapNotNull null
                            val file = File(path)
                            if (!file.exists() || !file.isFile) return@mapNotNull null
                            val label = packageManager.getApplicationLabel(app).toString().ifBlank { app.packageName }
                            FileEntry(file, displayName = label, subtitleOverride = "${app.packageName}  •  ${readableSize(file.length())}  •  ${formatDateTime(file.lastModified())}")
                        }
                        .sortedBy { it.displayName?.lowercase() ?: it.file.name.lowercase() }
                }
                if (mode != Mode.APPS) return@launch
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} แอป"
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun formatDateTime(time: Long): String =
        java.text.SimpleDateFormat("d MMM yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(time))

    private fun backupApplicationApk(entry: FileEntry) {
        val source = entry.file
        if (!source.exists()) {
            Toast.makeText(this, "ไม่พบ APK ของแอปนี้", Toast.LENGTH_SHORT).show()
            return
        }
        val safeName = (entry.displayName ?: source.nameWithoutExtension).replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "application" }
        val dest = File(currentDir, uniqueName(currentDir, "$safeName.apk", false))
        AlertDialog.Builder(this)
            .setTitle("สำรองแอปเป็น APK")
            .setMessage("${entry.displayName ?: source.name}\n\nจะบันทึกเป็น:\n${dest.name}")
            .setPositiveButton("สำรอง") { _, _ ->
                Thread {
                    try {
                        source.copyTo(dest, overwrite = false)
                        runOnUiThread {
                            Toast.makeText(this, "สำรอง APK แล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                            loadDirectory(currentDir)
                        }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "สำรองไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Search ----------

    private fun searchDialog() {
        val input = EditText(this)
        input.hint = "ชื่อไฟล์หรือโฟลเดอร์"
        AlertDialog.Builder(this)
            .setTitle("ค้นหาไฟล์")
            .setView(input)
            .setPositiveButton("ค้นหา") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) runSearch(q)
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun runSearch(query: String) {
        mode = Mode.SEARCH
        trashActionBar.visibility = View.GONE
        lastSearchQuery = query
        showSpecialPath("ผลค้นหา: \"$query\"")
        supportActionBar?.subtitle = "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        lifecycleScope.launch {
            try {
                val results = withContext(Dispatchers.IO) { FileScanner.searchByName(root, query, hidden) }
                swipeRefresh.isRefreshing = false
                if (mode != Mode.SEARCH || lastSearchQuery != query) return@launch
                val entries = results.map { FileEntry(it) }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun refreshCurrentView() {
        when (mode) {
            Mode.NORMAL -> loadDirectory(currentDir)
            Mode.CATEGORY -> {
                val label = currentCategoryLabel
                val exts = currentCategoryExts
                if (label != null && exts != null) runCategoryScan(label, exts) else loadDirectory(lastNormalDir)
            }
            Mode.SEARCH -> lastSearchQuery?.let { runSearch(it) } ?: loadDirectory(lastNormalDir)
            Mode.TRASH -> loadTrash()
            Mode.APPS -> loadInstalledApps()
        }
    }

    // ---------- Permissions ----------

    private fun checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
            } else {
                loadDirectory(currentDir)
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ), STORAGE_PERMISSION_CODE
                )
            } else {
                loadDirectory(currentDir)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(currentDir)
        }
    }

    // ---------- Recent folders ----------

    private fun rememberRecentFolder(dir: File) {
        if (mode != Mode.TRASH && dir.isDirectory) {
            val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
            val old = prefs.getString("paths", "")!!.split("\\n").filter { it.isNotBlank() }
            val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath }).take(15)
            prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
        }
    }

    private fun loadRecentFolders() {
        mode = Mode.SEARCH
        val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
        val paths = prefs.getString("paths", "")!!.split("\\n")
            .filter { it.isNotBlank() }
            .mapNotNull { File(it).takeIf { f -> f.isDirectory && f.canRead() } }

        if (paths.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีโฟลเดอร์ล่าสุด", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = paths.first()
        showSpecialPath("โฟลเดอร์ล่าสุด")
        adapter.updateItems(paths.map { FileEntry(it) }, showFullPath = true)
        supportActionBar?.subtitle = "${paths.size} โฟลเดอร์"
    }

    // ---------- Clickable breadcrumb path ----------

    private fun renderBreadcrumbs(dir: File) {
        breadcrumbBar.removeAllViews()

        val root = Environment.getExternalStorageDirectory().canonicalFile
        val target = try { dir.canonicalFile } catch (_: Exception) { dir.absoluteFile }
        val parts = mutableListOf<Pair<String, File>>()

        if (target == root || target.path.startsWith(root.path + File.separator)) {
            parts += "0" to root
            var cursor = root
            val relative = target.path.removePrefix(root.path)
                .trimStart(File.separatorChar)
            if (relative.isNotEmpty()) {
                for (name in relative.split(File.separatorChar).filter { it.isNotEmpty() }) {
                    cursor = File(cursor, name)
                    parts += name to cursor
                }
            }
        } else {
            parts += target.name.ifEmpty { target.path } to target
        }

        parts.forEachIndexed { index, (label, folder) ->
            if (index > 0) {
                breadcrumbBar.addView(TextView(this).apply {
                    text = ">"
                    textSize = 14f
                    setTextColor(getColor(R.color.text_secondary))
                    setPadding(4, 0, 4, 0)
                    gravity = Gravity.CENTER_VERTICAL
                })
            }

            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                typeface = if (index == parts.lastIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(getColor(R.color.text_primary))
                setPadding(12, 8, 12, 8)
                isSingleLine = true
                setOnClickListener { loadDirectory(folder) }
                contentDescription = "ไปที่โฟลเดอร์ $label"
                isClickable = true
                isFocusable = true
            }
            breadcrumbBar.addView(chip)
        }

        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    private fun showSpecialPath(label: String) {
        breadcrumbBar.removeAllViews()
        breadcrumbBar.addView(TextView(this).apply {
            text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(getColor(R.color.text_primary))
            setPadding(12, 8, 12, 8)
        })
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    // ---------- Windows (open folder windows) ----------

    private fun loadOpenWindows() {
        val raw = getSharedPreferences("korn_windows", MODE_PRIVATE)
            .getString("paths", "") ?: ""
        openWindows.clear()
        raw.split("\n").filter { it.isNotBlank() }.forEach { path ->
            val f = File(path)
            if (f.isDirectory) openWindows.add(f.absolutePath)
        }
    }

    private fun saveOpenWindows() {
        getSharedPreferences("korn_windows", MODE_PRIVATE)
            .edit()
            .putString("paths", openWindows.take(12).joinToString("\n"))
            .apply()
    }

    private fun rememberOpenWindow(dir: File) {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        openWindows.remove(path)
        openWindows.add(0, path)
        while (openWindows.size > 12) openWindows.removeAt(openWindows.lastIndex)
        saveOpenWindows()
    }

    private fun showWindowsDialog() {
        // Refresh stale paths before showing the list.
        openWindows.removeAll { !File(it).isDirectory }
        if (openWindows.isEmpty()) {
            openWindows.add(currentDir.absolutePath)
            saveOpenWindows()
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 8, 16, 8)
        }

        val list = ListView(this)
        val rows = openWindows.map { path ->
            val file = File(path)
            val name = if (file.name.isBlank()) file.path else file.name
            "$name\n$path"
        }.toTypedArray()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, rows)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            val path = openWindows.getOrNull(position) ?: return@setOnItemClickListener
            AlertDialog.Builder(this)
                .setTitle(if (File(path).name.isBlank()) File(path).path else File(path).name)
                .setItems(arrayOf("เปิดหน้าต่างนี้", "ปิดหน้าต่างนี้")) { _, which ->
                    when (which) {
                        0 -> {
                            val target = File(path)
                            if (target.isDirectory) loadDirectory(target)
                        }
                        1 -> {
                            openWindows.remove(path)
                            if (openWindows.isEmpty()) {
                                openWindows.add(currentDir.absolutePath)
                            }
                            saveOpenWindows()
                            showWindowsDialog()
                        }
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val path = openWindows.getOrNull(position) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("ปิดหน้าต่างนี้?")
                .setMessage(path)
                .setPositiveButton("ปิด") { _, _ ->
                    openWindows.remove(path)
                    if (openWindows.isEmpty()) openWindows.add(currentDir.absolutePath)
                    saveOpenWindows()
                    showWindowsDialog()
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
            true
        }
        container.addView(list, LinearLayout.LayoutParams(-1, 420))

        AlertDialog.Builder(this)
            .setTitle("หน้าต่าง (${openWindows.size})")
            .setView(container)
            .setPositiveButton("เปิดหน้าต่างนี้") { _, _ -> loadDirectory(currentDir) }
            .setNegativeButton("ปิด", null)
            .show()
    }

    // ---------- Directory browsing ----------

    private fun loadDirectory(dir: File) {
        if (!dir.exists() || !dir.canRead()) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้", Toast.LENGTH_SHORT).show()
            swipeRefresh.isRefreshing = false
            return
        }
        mode = Mode.NORMAL
        trashActionBar.visibility = View.GONE
        currentDir = dir
        lastNormalDir = dir
        rememberRecentFolder(dir)
        rememberOpenWindow(dir)
        renderBreadcrumbs(dir)

        val isRoot = dir == Environment.getExternalStorageDirectory()
        val children = dir.listFiles()?.toList() ?: emptyList()
        val entries = children
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { !(isRoot && it.name == TrashManager.TRASH_FOLDER_NAME) }
            .map { FileEntry(it) }
            .sortedWith(comparator())
        adapter.updateItems(entries, showFullPath = false)
        supportActionBar?.subtitle = "${entries.size} รายการ"
        updateStorageBar()
        swipeRefresh.isRefreshing = false
    }

    private fun onItemClick(entry: FileEntry) {
        if (mode == Mode.APPS) {
            backupApplicationApk(entry)
            return
        }
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return
        }
        if (entry.isDirectory) {
            // Tapping a folder always drops back into normal browsing, even from a
            // flat category/search result list.
            loadDirectory(entry.file)
        } else if (ArchiveManager.isArchive(entry.file)) {
            showArchiveOpenOptions(entry.file)
        } else {
            openFile(entry.file)
        }
    }

    /**
     * Archives stay browsable inside KORN, but the user can always hand them to another
     * application through the Android chooser. Minecraft pack extensions also get a
     * dedicated Minecraft action when the OS has an app registered for them.
     */
    private fun showArchiveOpenOptions(file: File) {
        val items = mutableListOf("เปิดภายใน KORN")
        val isMinecraftPack = file.name.lowercase().let {
            it.endsWith(".mcpack") || it.endsWith(".mcaddon") || it.endsWith(".mcworld")
        }
        if (isMinecraftPack) items.add("เปิด/ส่งให้ Minecraft")
        items.add("แตกไฟล์…")
        items.add("เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "เปิดภายใน KORN" -> openArchiveInsideKorn(file)
                    "เปิด/ส่งให้ Minecraft" -> openFile(file)
                    "แตกไฟล์…" -> extractArchiveDialog(file)
                    "เปิดด้วยแอปอื่น…" -> openFile(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openArchiveInsideKorn(file: File) {
        // Keep ZIP-family/Minecraft archives on the existing browser so their
        // current in-place edit/rename/delete/add features remain unchanged.
        val zipLike = file.name.lowercase().let {
            it.endsWith(".zip") || it.endsWith(".mcpack") || it.endsWith(".mcaddon") ||
            it.endsWith(".mcworld") || it.endsWith(".apk") || it.endsWith(".apks") ||
            it.endsWith(".xapk") || it.endsWith(".mtz")
        }
        if (zipLike) {
            startActivity(Intent(this, ZipBrowserActivity::class.java).apply {
                putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, file.absolutePath)
            })
            return
        }

        val needsPassword = ArchiveManager.isPasswordCandidate(file)
        if (needsPassword) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("เปิด") { _, _ ->
                    materializeAndOpen(file, input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            materializeAndOpen(file, null)
        }
    }

    private fun materializeAndOpen(file: File, password: String?) {
        Toast.makeText(this, "กำลังอ่านไฟล์…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val tempZip = withContext(Dispatchers.IO) {
                    ArchiveManager.materializeForBrowse(file, cacheDir, password)
                }
                startActivity(Intent(this@MainActivity, ZipBrowserActivity::class.java).apply {
                    putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, tempZip.absolutePath)
                    putExtra("korn_temp_archive", true)
                })
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this@MainActivity, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun extractArchiveDialog(file: File) {
        val choices = arrayOf(
            "อัตโนมัติ — สร้างโฟลเดอร์ชื่อเดียวกับไฟล์ในที่เดิม",
            "เส้นทางปัจจุบัน — แตกลงโฟลเดอร์ที่กำลังเปิดอยู่",
            "เลือกเส้นทาง… — เลือกโฟลเดอร์ปลายทางเอง"
        )

        AlertDialog.Builder(this)
            .setTitle("แตกไฟล์ไปยัง")
            .setSingleChoiceItems(choices, 0) { dialog, which ->
                dialog.dismiss()
                if (which == 2) {
                    chooseDestinationFolder { destination ->
                        askArchivePasswordThenExtract(file, 2, destination)
                    }
                } else {
                    askArchivePasswordThenExtract(file, which, null)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun askArchivePasswordThenExtract(file: File, mode: Int, chosenDestination: File?) {
        pendingArchiveFile = file
        pendingArchiveMode = mode

        val finish = { password: String? ->
            pendingArchivePassword = password
            val destination = when (mode) {
                1 -> currentDir
                2 -> chosenDestination
                else -> file.parentFile ?: currentDir
            } ?: currentDir
            startArchiveExtraction(file, destination, mode, password)
        }

        if (ArchiveManager.isPasswordCandidate(file)) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("แตกไฟล์") { _, _ ->
                    finish(input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            finish(null)
        }
    }

    private fun startArchiveExtraction(
        file: File,
        destinationRoot: File,
        mode: Int,
        password: String?
    ) {
        val dest = if (mode == 0) {
            val base = file.name.substringBeforeLast('.').substringBeforeLast('.')
                .ifBlank { file.nameWithoutExtension.ifBlank { "extracted" } }
            File(destinationRoot, uniqueName(destinationRoot, base, true))
        } else {
            destinationRoot
        }

        if (!dest.exists() && !dest.mkdirs()) {
            Toast.makeText(this, "ไม่สามารถสร้างโฟลเดอร์ปลายทางได้", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                ArchiveManager.extract(file, dest, password)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "แตกไฟล์เสร็จแล้ว: ${dest.absolutePath}",
                        Toast.LENGTH_LONG
                    ).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                if (mode == 0) dest.deleteRecursively()
                runOnUiThread {
                    Toast.makeText(this, "แตกไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                pendingArchiveFile = null
                pendingArchivePassword = null
            }
        }.start()
    }

    /**
     * A lightweight filesystem folder chooser. It works with the same File-based
     * storage model used by ArchiveManager, so the selected destination can be
     * passed directly to the existing extraction code.
     */
    private fun chooseDestinationFolder(onSelected: (File) -> Unit) {
        var chooserDir = currentDir.takeIf { it.isDirectory }
            ?: Environment.getExternalStorageDirectory()

        val list = ListView(this)
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        list.adapter = adapter

        fun refreshChooser() {
            adapter.clear()
            if (chooserDir.parentFile != null) adapter.add("⬆ ..")
            chooserDir.listFiles()
                ?.filter { it.isDirectory && !it.isHidden }
                ?.sortedBy { it.name.lowercase() }
                ?.forEach { adapter.add("📁 ${it.name}") }
            adapter.notifyDataSetChanged()
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("เลือกโฟลเดอร์ปลายทาง")
            .setView(list)
            .setPositiveButton("เลือกโฟลเดอร์นี้") { _, _ -> onSelected(chooserDir) }
            .setNegativeButton("ยกเลิก", null)
            .create()

        list.setOnItemClickListener { _, _, position, _ ->
            val parentOffset = if (chooserDir.parentFile != null) 1 else 0
            if (parentOffset == 1 && position == 0) {
                chooserDir.parentFile?.let { chooserDir = it }
            } else {
                val index = position - parentOffset
                val dirs = chooserDir.listFiles()
                    ?.filter { it.isDirectory && !it.isHidden }
                    ?.sortedBy { it.name.lowercase() }
                    ?: emptyList()
                dirs.getOrNull(index)?.let { chooserDir = it }
            }
            refreshChooser()
            dialog.setTitle("เลือกโฟลเดอร์: ${chooserDir.name.ifBlank { chooserDir.path }}")
        }

        refreshChooser()
        dialog.show()
    }

    private fun rememberRecentFile(file: File) {
        if (!file.isFile) return
        val prefs = getSharedPreferences("recent_files", MODE_PRIVATE)
        val old = prefs.getString("paths", "")!!.split("\\n").filter { it.isNotBlank() }
        val updated = (listOf(file.absolutePath) + old.filter { it != file.absolutePath }).take(30)
        prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
    }

    /**
     * Opens any regular file with a choice when KORN has a suitable internal viewer.
     * Supported internal viewers currently include text files and images. For all other
     * file types, Android's normal external-app chooser is used directly.
     */
    private fun openFile(file: File) {
        rememberRecentFile(file)

        // Every regular file gets a KORN option. Text is edited normally; unknown/binary
        // formats use the universal HEX editor. Images keep their existing image viewer.
        val options = arrayOf("เปิดด้วย KORN", "เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openFileInternally(file)
                    1 -> openFileExternally(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
        }

    private fun openFileInternally(file: File) {
        val ext = file.extension.lowercase()
        try {
            if (FileCategories.IMAGES.contains(ext)) {
                startActivity(Intent(this, ImageViewerActivity::class.java).apply {
                    putExtra(ImageViewerActivity.EXTRA_IMAGE_PATH, file.absolutePath)
                })
                return
            }

            // Text and every other binary/unknown file are editable. TextEditActivity
            // automatically chooses UTF-8 text mode or HEX mode.
            startActivityForResult(Intent(this, TextEditActivity::class.java).apply {
                putExtra(TextEditActivity.EXTRA_FILE_PATH, file.absolutePath)
            }, REQUEST_TEXT_EDIT)
            return
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFileExternally(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val REQUEST_TEXT_EDIT = 4101
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return
        }
        if (mode != Mode.NORMAL) {
            loadDirectory(lastNormalDir)
            return
        }
        val parent = currentDir.parentFile
        if (parent != null && currentDir != Environment.getExternalStorageDirectory()) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Drag & drop ----------

    private fun onStartFileDrag(entry: FileEntry, sourceView: View): Boolean {
        val paths = if (adapter.selectionMode && adapter.getSelectedFiles().any {
                it.absolutePath == entry.file.absolutePath
            }) {
            adapter.getSelectedFiles().map { it.absolutePath }
        } else {
            listOf(entry.file.absolutePath)
        }
        val clip = android.content.ClipData.newPlainText(
            "KORN_FILES",
            paths.joinToString("\n")
        )
        val shadow = View.DragShadowBuilder(sourceView)
        val started = sourceView.startDragAndDrop(clip, shadow, null, 0)
        if (started) {
            Toast.makeText(this, "ลากไปวางบนโฟลเดอร์เพื่อย้าย", Toast.LENGTH_SHORT).show()
        }
        return started
    }

    private fun onDropOnFolder(folder: File, paths: List<String>): Boolean {
        if (!folder.isDirectory || paths.isEmpty()) return false
        val sources = paths.map { File(it) }.filter { it.exists() }
        if (sources.isEmpty()) return false

        Thread {
            var moved = 0
            var skipped = 0
            for (src in sources.distinctBy { it.absolutePath }) {
                try {
                    if (src.absoluteFile == folder.absoluteFile) {
                        skipped++
                        continue
                    }
                    if (src.isDirectory) {
                        val srcPath = src.canonicalFile.toPath()
                        val destPath = folder.canonicalFile.toPath()
                        if (destPath.startsWith(srcPath)) {
                            skipped++
                            continue
                        }
                    }
                    var dest = File(folder, src.name)
                    if (dest.canonicalFile == src.canonicalFile) {
                        skipped++
                        continue
                    }
                    if (dest.exists()) dest = File(folder, uniqueName(folder, src.name, src.isDirectory))
                    val ok = src.renameTo(dest)
                    if (ok) moved++ else skipped++
                } catch (_: Exception) {
                    skipped++
                }
            }
            runOnUiThread {
                exitSelectionModeIfNeededAfterDrag()
                loadDirectory(currentDir)
                val msg = if (skipped == 0) "ย้าย $moved รายการไปที่ ${folder.name} แล้ว"
                else "ย้ายสำเร็จ $moved รายการ (ข้าม $skipped รายการ)"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
        return true
    }

    private fun exitSelectionModeIfNeededAfterDrag() {
        if (adapter.selectionMode) {
            adapter.setSelectionMode(false)
            swipeRefresh.isEnabled = true
            updateActionBars()
        }
    }

    // ---------- Batch rename ----------

    private fun batchRenameDialog() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
        }
        val patternInput = EditText(this).apply {
            hint = "ชื่อ_{n}"
            setText("ชื่อ_{n}")
            selectAll()
        }
        val startInput = EditText(this).apply {
            hint = "เลขเริ่มต้น"
            setText("1")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(patternInput)
        box.addView(startInput)

        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อหลายไฟล์ (${files.size} รายการ)")
            .setMessage("ใช้ {n} เป็นหมายเลขรันต่อ เช่น Addon_{n}")
            .setView(box)
            .setPositiveButton("เปลี่ยนชื่อ") { _, _ ->
                val pattern = patternInput.text.toString().trim()
                val start = startInput.text.toString().toIntOrNull() ?: 1
                if (pattern.isEmpty()) {
                    Toast.makeText(this, "กรุณาใส่รูปแบบชื่อ", Toast.LENGTH_SHORT).show()
                } else {
                    batchRename(files, pattern, start)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun batchRename(files: List<File>, pattern: String, start: Int) {
        Thread {
            var renamed = 0
            var skipped = 0
            val reserved = mutableSetOf<String>()
            files.forEachIndexed { index, file ->
                try {
                    var stem = pattern.replace("{n}", (start + index).toString())
                    if (!pattern.contains("{n}")) stem += "_${start + index}"
                    val dot = file.name.lastIndexOf('.')
                    val hasExtensionInPattern = stem.lastIndexOf('.') > 0
                    val newName = if (!file.isDirectory && !hasExtensionInPattern && dot > 0) {
                        stem + file.name.substring(dot)
                    } else stem
                    if (newName.isBlank() || newName == file.name ||
                        newName.contains("/") || newName.contains("\\") ||
                        newName in reserved
                    ) {
                        skipped++
                        return@forEachIndexed
                    }
                    val dest = File(file.parentFile, newName)
                    if (dest.exists() && dest.absolutePath != file.absolutePath) {
                        skipped++
                        return@forEachIndexed
                    }
                    if (file.renameTo(dest)) {
                        reserved.add(newName)
                        renamed++
                    } else skipped++
                } catch (_: Exception) {
                    skipped++
                }
            }
            runOnUiThread {
                exitSelectionMode()
                Toast.makeText(
                    this,
                    "เปลี่ยนชื่อสำเร็จ $renamed รายการ" +
                        if (skipped > 0) " (ข้าม $skipped รายการ)" else "",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    // ---------- Long-press context menu ----------

    private fun onItemLongClick(entry: FileEntry): Boolean {
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return true
        }

        if (!adapter.selectionMode) {
            // Do not rebind the RecyclerView while the long-press finger is still
            // down; the adapter keeps the current touch listener alive so the
            // same gesture can immediately transition into drag.
            adapter.setSelectionMode(true, notify = false)
            swipeRefresh.isEnabled = false
            updateSelectionSubtitle()
            updateActionBars()
        }
        if (entry.file.absolutePath !in adapter.getSelectedFiles().map { it.absolutePath }) {
            adapter.selectPath(entry.file.absolutePath, notify = false)
        }
        return true
    }

    // ---------- Hide / unhide ----------

    private fun hideFile(file: File, hide: Boolean) {
        val newName = if (hide) {
            if (file.name.startsWith(".")) file.name else ".${file.name}"
        } else {
            file.name.trimStart('.').ifEmpty { file.name }
        }
        if (newName == file.name) {
            refreshCurrentView()
            return
        }
        val dest = File(file.parentFile, newName)
        if (file.renameTo(dest)) {
            Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            refreshCurrentView()
        } else {
            Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Multi-format archive ----------

    private fun showCompressFormatDialog(source: File) {
        val formats = ArchiveManager.COMPRESS_FORMATS.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("เลือกชนิดไฟล์บีบอัด")
            .setItems(formats.map { ".$it" }.toTypedArray()) { _, which ->
                compressEntry(source, formats[which])
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun compressEntry(source: File, format: String) {
        val parent = source.parentFile ?: currentDir
        val base = if (source.isDirectory) source.name else source.nameWithoutExtension.ifEmpty { source.name }
        val dest = File(parent, uniqueName(parent, "$base.$format"))
        Toast.makeText(this, "กำลังสร้าง ${dest.name}…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                ArchiveManager.compress(source, dest, format)
                runOnUiThread {
                    Toast.makeText(this, "บีบอัดเสร็จแล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                dest.delete()
                runOnUiThread {
                    Toast.makeText(this, "บีบอัดไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Returns a filename that doesn't already exist in [dir], appending " (1)", " (2)", ... if needed. */
    private fun uniqueName(dir: File, desired: String, isDir: Boolean = false): String {
        if (!File(dir, desired).exists()) return desired
        val dotIndex = desired.lastIndexOf('.')
        val base = if (!isDir && dotIndex > 0) desired.substring(0, dotIndex) else desired
        val ext = if (!isDir && dotIndex > 0) desired.substring(dotIndex) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base ($i)$ext"
            i++
        } while (File(dir, candidate).exists())
        return candidate
    }

    private fun addBookmark(dir: File) {
        val input = EditText(this)
        input.setText(dir.name)
        AlertDialog.Builder(this)
            .setTitle("เพิ่มในรายการโปรด")
            .setView(input)
            .setPositiveButton("บันทึก") { _, _ ->
                val name = input.text.toString().ifBlank { dir.name }
                bookmarksManager.add(name, dir.absolutePath)
                refreshBookmarksBar()
                Toast.makeText(this, "เพิ่มในรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameDialog(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val newFile = File(file.parentFile, newName)
                    if (file.renameTo(newFile)) {
                        loadDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Recycle bin (soft delete) ----------

    private fun loadTrash() {
        mode = Mode.TRASH
        adapter.setSelectionMode(false)
        trashActionBar.visibility = View.VISIBLE
        showSpecialPath("ถังขยะ")
        val trashEntries = trashManager.listEntries()
        val fileEntries = trashEntries.map { e ->
            FileEntry(
                file = e.trashedFile,
                displayName = e.trashedFile.name.replaceFirst(Regex("^\\d+_"), ""),
                subtitleOverride = "จาก: ${e.originalPath}"
            )
        }
        adapter.updateItems(fileEntries, showFullPath = false)
        supportActionBar?.subtitle = "${fileEntries.size} รายการในถังขยะ"
        swipeRefresh.isRefreshing = false
    }

    private fun onTrashItemAction(entry: FileEntry) {
        val trashEntry = trashManager.listEntries()
            .find { it.trashedFile.absolutePath == entry.file.absolutePath } ?: return
        val title = entry.displayName ?: entry.file.name
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("กู้คืน", "ลบถาวร")) { _, which ->
                when (which) {
                    0 -> {
                        if (trashManager.restore(trashEntry)) {
                            Toast.makeText(this, "กู้คืนแล้ว", Toast.LENGTH_SHORT).show()
                            loadTrash()
                        } else {
                            Toast.makeText(this, "กู้คืนไม่สำเร็จ (อาจไม่พบโฟลเดอร์ต้นทางแล้ว)", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> {
                        AlertDialog.Builder(this)
                            .setTitle("ลบถาวร \"$title\"?")
                            .setMessage("ไม่สามารถกู้คืนได้อีก")
                            .setPositiveButton("ลบถาวร") { _, _ ->
                                trashManager.deleteForever(trashEntry)
                                loadTrash()
                            }
                            .setNegativeButton("ยกเลิก", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun emptyTrashConfirm() {
        AlertDialog.Builder(this)
            .setTitle("ล้างถังขยะทั้งหมด?")
            .setMessage("ไฟล์ทั้งหมดในถังขยะจะถูกลบถาวร ไม่สามารถกู้คืนได้")
            .setPositiveButton("ล้างถังขยะ") { _, _ ->
                trashManager.emptyTrash()
                loadTrash()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setupToolbarHomeButton() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbarHomeButton = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_home)
            background = null
            contentDescription = "หน้าแรก"
            setPadding(12, 8, 12, 8)
            setOnClickListener { loadDirectory(Environment.getExternalStorageDirectory()) }
        }
        val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
            dp(48),
            dp(48),
            Gravity.START or Gravity.CENTER_VERTICAL
        ).apply {
            marginStart = dp(56)
        }
        toolbar.addView(toolbarHomeButton, lp)
    }

    private fun setupToolbarSearchButton() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        val button = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            background = null
            contentDescription = "ค้นหา"
            setPadding(12, 8, 12, 8)
            setOnClickListener { if (mode != Mode.TRASH && mode != Mode.APPS) searchDialog() }
        }
        val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
            dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL
        )
        toolbar.addView(button, lp)
    }

    // ---------- Drag & drop ----------

    private fun pasteClipboard() {
        val sources = clipboardFiles
        if (sources.isEmpty()) {
            Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
            return
        }
        val destDir = currentDir
        val cut = clipboardIsCut
        Toast.makeText(this, "กำลังวางไฟล์...", Toast.LENGTH_SHORT).show()
        Thread {
            var successCount = 0
            for (src in sources) {
                try {
                    var dest = File(destDir, src.name)
                    if (dest.exists()) dest = File(destDir, uniqueName(destDir, src.name, src.isDirectory))
                    if (cut) {
                        if (!src.renameTo(dest)) {
                            src.copyRecursively(dest, overwrite = true)
                            src.deleteRecursively()
                        }
                    } else {
                        src.copyRecursively(dest, overwrite = true)
                    }
                    successCount++
                } catch (e: Exception) {
                    // Skip failed item, continue with the rest.
                }
            }
            clipboardFiles = emptyList()
            clipboardIsCut = false
            runOnUiThread {
                updateActionBars()
                    loadDirectory(currentDir)
                Toast.makeText(this, "วางสำเร็จ $successCount รายการ", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun showAddMenu() {
        AlertDialog.Builder(this)
            .setTitle("เพิ่ม")
            .setItems(arrayOf("📄 ไฟล์", "📁 โฟลเดอร์")) { _, which ->
                when (which) {
                    0 -> newFileDialog()
                    1 -> newFolderDialog()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun newFileDialog() {
        val input = EditText(this)
        input.hint = "ชื่อไฟล์.txt"
        AlertDialog.Builder(this)
            .setTitle("สร้างไฟล์ใหม่")
            .setMessage("ใน ${currentDir.absolutePath}")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val newFile = File(currentDir, name)
                try {
                    when {
                        newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                        newFile.createNewFile() -> loadDirectory(currentDir)
                        else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun newFolderDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    File(currentDir, name).mkdirs()
                    loadDirectory(currentDir)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Favorites (bookmarks) bar & management ----------

    private fun isDarkThemeActive(): Boolean {
        return themeKey == "dark" || (themeKey == "system" &&
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES)
    }

    private fun refreshBookmarksBar() {
        bookmarksBar.removeAllViews()
        val bookmarks = bookmarksManager.getAll()
        for (bm in bookmarks) {
            val chip = TextView(this).apply {
                text = "⭐ ${bm.name}"
                setPadding(24, 12, 24, 12)
                setBackgroundColor(if (isDarkThemeActive()) android.graphics.Color.rgb(55, 62, 70) else android.graphics.Color.rgb(227, 242, 253))
                setTextColor(if (isDarkThemeActive()) android.graphics.Color.rgb(235, 240, 245) else android.graphics.Color.rgb(21, 101, 192))
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 12
                layoutParams = lp
                isClickable = true
                isFocusable = true
                isLongClickable = true
                setOnClickListener {
                    val target = File(bm.path)
                    if (target.exists()) loadDirectory(target)
                    else Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("ลบบุ๊คมาร์ก \"${bm.name}\"?")
                        .setPositiveButton("ลบ") { _, _ ->
                            bookmarksManager.remove(bm.path)
                            refreshBookmarksBar()
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                    true
                }
            }
            bookmarksBar.addView(chip)
        }
    }

    private fun manageBookmarksDialog() {
        val bookmarks = bookmarksManager.getAll().toMutableList()
        val list = ListView(this)
        val names = bookmarks.map { "⭐ ${it.name}\n${it.path}" }.toMutableList()
        val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, names)
        list.adapter = listAdapter

        val dialog = AlertDialog.Builder(this)
            .setTitle("ตัวจัดการรายการโปรด")
            .setView(list)
            .setPositiveButton("＋ เพิ่มโฟลเดอร์") { _, _ ->
                chooseDestinationFolder { selected ->
                    addBookmark(selected)
                }
            }
            .setNegativeButton("ปิด", null)
            .create()

        list.setOnItemClickListener { _, _, which, _ ->
            val target = File(bookmarks.getOrNull(which)?.path ?: return@setOnItemClickListener)
            if (target.isDirectory) {
                dialog.dismiss()
                loadDirectory(target)
            } else {
                Toast.makeText(this, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
            }
        }

        list.setOnItemLongClickListener { _, _, which, _ ->
            val bookmark = bookmarks.getOrNull(which) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("ลบรายการโปรด?")
                .setMessage("${bookmark.name}\n${bookmark.path}")
                .setPositiveButton("ลบ") { _, _ ->
                    bookmarksManager.remove(bookmark.path)
                    bookmarks.removeAt(which)
                    names.removeAt(which)
                    listAdapter.notifyDataSetChanged()
                    refreshBookmarksBar()
                    Toast.makeText(this, "ลบออกจากรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
            true
        }

        dialog.show()

        if (bookmarks.isEmpty()) {
            // Keep the manager usable even when there are no saved folders yet.
            listAdapter.notifyDataSetChanged()
            Toast.makeText(this, "ยังไม่มีรายการโปรด กด «＋ เพิ่มโฟลเดอร์» เพื่อเลือกโฟลเดอร์", Toast.LENGTH_LONG).show()
        }
    }
}
