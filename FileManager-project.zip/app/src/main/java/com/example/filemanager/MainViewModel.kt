package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.FileScanner
import com.example.filemanager.data.search.SearchIndexManager

/**
 * Holds UI state that doesn't belong to directory browsing specifically: app-wide settings
 * (themeKey), one-off events (toasts/ArchiveOpDone/CompressOpDone), archive + compress
 * background-operation progress, the extract conflict-resolution batch, the search dialog-open
 * flag, and text/content search.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see round2-instructions.txt): directory
 * browsing/listing state (currentDir, lastNormalDir, mode, category filter, sort key/
 * ascending, showHidden, grid/view mode, and the directoryState listing itself + its
 * loadDirectory() loader - originally added in Round 17) has moved out to its own
 * DirectoryViewModel. This class keeps everything else Round 14-22 had already put here.
 * onSearchQueryChanged()/runSearchImmediate() below now take sortKey/sortAscending as explicit
 * parameters (same pattern as the pre-existing showHidden parameter) since that state no
 * longer lives in this ViewModel.
 *
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): clipboard
 * (clipboardFiles/clipboardIsCut), multi-select (selectionMode/selectedPaths), copy/move
 * progress (fileOpState) + its UiEvent.FileOpDone, the "เพิ่มเติม" menu flag
 * (selectionMoreMenuOpen), the trash-confirm dialog flag (trashConfirmDialogOpen), and the
 * copy/move conflict batch (copyMoveConflictBatch/CopyMoveConflictBatch) have moved out to
 * their own FileOperationViewModel. extractConflictBatch/ExtractConflictBatch stay here -
 * round2-instructions.txt scopes step 2 to the copy/move side only, not extract's.
 */
class MainViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val directoryBrowserHelper = DirectoryBrowserHelper()

    // ---------- Local Search Index (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6) ----------

    private var searchIndexManager: SearchIndexManager? = null

    /**
     * เรียกครั้งเดียวจาก MainActivity.onCreate() ทันทีหลังสร้าง SearchIndexManager
     * MainViewModel สร้างผ่าน `by viewModels()` (no-arg constructor ตามแพทเทิร์นเดิมของ
     * โปรเจกต์) จึงรับ SearchIndexManager ผ่าน constructor ตรงๆ ไม่ได้โดยไม่เพิ่ม Factory
     * ที่โปรเจกต์นี้ไม่เคยใช้มาก่อน — attach แบบนี้แทน ไม่ผูก SearchIndexManager เป็น
     * singleton object ลอยๆ ตามที่แผนกำหนดไว้ (ข้อ 6.1)
     *
     * SearchIndexManager เก็บแค่ applicationContext ไว้ภายในตัวเอง (ดู
     * SearchIndexManager.appContext) การเก็บ reference นี้ไว้ใน ViewModel ข้าม config
     * change (เช่น หมุนจอ) จึงไม่ leak Activity — เรียกซ้ำได้ทุก onCreate เฉยๆ แค่แทนที่
     * ด้วย instance ใหม่ที่ชี้ไปที่ Room DB ไฟล์เดิม
     */
    fun attachSearchIndexManager(manager: SearchIndexManager) {
        searchIndexManager = manager
    }

    // ---------- One-off UI events (toasts, etc.) ----------

    sealed class UiEvent {
        data class Toast(val message: String) : UiEvent()

        /** One-shot "zip/unzip finished" signal from ArchiveOperationService. Round 2 (step 2 of
         * 4): the FileOpDone counterpart for copy/move moved to FileOperationViewModel.events. */
        data class ArchiveOpDone(
            val isUnzip: Boolean,
            val archiveName: String,
            val success: Boolean,
            val error: String?,
            val destinationPath: String? = null
        ) : UiEvent()

        /**
         * Part 3/3 of the "สร้างไฟล์ ของฉัน" feature: one-shot "archive creation finished" signal
         * from CompressOperationService. Kept separate from [ArchiveOpDone] above (which is the
         * older, unrelated "บีบอัด"/"แตกไฟล์" menu path - see ArchiveOperationService.kt's own
         * class doc) since this new path has its own exception types
         * (ArchiveEngineException/ArchiveCancelledException from ArchiveEngine.kt) and a
         * genuinely user-cancellable job, which the old path never supported. [cancelled] is
         * true when the user tapped "ยกเลิก" mid-job - MainActivity shows that as a plain
         * "ยกเลิกแล้ว" toast rather than as an error.
         */
        data class CompressOpDone(
            val archiveName: String,
            val success: Boolean,
            val cancelled: Boolean,
            val error: String?,
            val createdPaths: List<String> = emptyList(),
            val deletedPaths: List<String> = emptyList()
        ) : UiEvent()
    }

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<UiEvent> = _events

    // ---------- Settings / display state (Round 14) ----------
    //
    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): showHidden/
    // sortKey/sortAscending/isGridMode/fileViewMode moved out to DirectoryViewModel (directory-
    // browsing display settings). themeKey stays here - it's an app-wide setting, not a
    // directory-browsing one, and refactor-instructions.txt's DirectoryViewModel field list
    // deliberately excludes it.

    private val _themeKey = MutableStateFlow("blue")
    val themeKey: StateFlow<String> = _themeKey
    fun setThemeKey(value: String) { _themeKey.value = value }

    // Round 2 (MainViewModel split, step 2 of 4): clipboardFiles/clipboardIsCut (Round 15)
    // moved out to FileOperationViewModel - see that class instead.

    // ---------- Navigation / directory state ----------
    //
    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): currentDir/
    // lastNormalDir/mode/currentCategoryLabel/currentCategoryExts (Round 16, SavedStateHandle-
    // backed since Round 22) moved out to DirectoryViewModel along with directoryState/
    // loadDirectory() below. lastSearchQuery/lastSearchContentEnabled stay here for now - the
    // plan's SearchFilterViewModel (step 4) is where those move, not this step.

    private val _lastSearchQuery = MutableStateFlow(savedStateHandle.get<String>(KEY_SEARCH_QUERY))
    val lastSearchQuery: StateFlow<String?> = _lastSearchQuery
    fun setLastSearchQuery(value: String?) {
        _lastSearchQuery.value = value
        savedStateHandle[KEY_SEARCH_QUERY] = value
    }

    private val _lastSearchContentEnabled = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_CONTENT) ?: false
    )
    val lastSearchContentEnabled: StateFlow<Boolean> = _lastSearchContentEnabled
    fun setLastSearchContentEnabled(value: Boolean) {
        _lastSearchContentEnabled.value = value
        savedStateHandle[KEY_SEARCH_CONTENT] = value
    }

    // ---------- Dialog-open flags (Rotation Safety #4) ----------

    // Rotation Safety #4: "ค้นหาไฟล์" (SearchHelper.kt) is a plain KornDialog.Builder dialog,
    // not backed by any ViewModel-held batch the way the Rotation Safety #2 conflict dialogs
    // are. That's fine for a rotation (FragmentManager recreates the DialogFragment itself, and
    // KornDialog.take() still finds the spec in the in-memory map because the process never
    // died), but it fails silently on a real process death: KornDialogFragment.onCreate()'s
    // spec = specId?.let { KornDialog.take(it) } comes back null (the static specs map was
    // wiped along with the rest of the process), so the restored fragment just calls
    // dismissAllowingStateLoss() on itself - the dialog never reappears and nothing tells the
    // user it's gone.
    //
    // Same fix shape as Rotation Safety #2: a plain "is this dialog open" flag now lives here,
    // backed by SavedStateHandle so it survives process death too. The entry point
    // (searchDialog()) now only flips this flag to true; the actual KornDialog.Builder call
    // happens in SearchHelper.kt's observeXxxDialog() (wired from MainActivity.onCreate(), same
    // as observeConflictBatches()), which reacts to the flow the same way on a normal open, a
    // rotation, and a process-death relaunch alike - collect() always replays the latest value
    // to a fresh STARTED collector. The dialog's own setOnDismissListener flips the flag back
    // to false on every real dismissal (button tap, outside touch, back press) - never called
    // for the transient teardown a rotation causes, per KornDialogFragment.onDismiss()'s doc
    // comment, so rotation restore is unaffected.
    //
    // No extra state needs to be persisted for the search dialog's typed text/checkbox - those
    // already live in lastSearchQuery/lastSearchContentEnabled above (kept in sync on every
    // keystroke by onSearchQueryChanged()), so whenever the dialog is rebuilt it pre-fills
    // correctly regardless of why it's reappearing.
    //
    // Round 2 (MainViewModel split, step 2 of 4): trashConfirmDialogOpen (Rotation Safety #4's
    // other dialog) and selectionMoreMenuOpen (Rotation Safety #5) moved out to
    // FileOperationViewModel - see that class instead.

    private val _searchDialogOpen = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_DIALOG_OPEN) ?: false
    )
    val searchDialogOpen: StateFlow<Boolean> = _searchDialogOpen
    fun setSearchDialogOpen(open: Boolean) {
        _searchDialogOpen.value = open
        savedStateHandle[KEY_SEARCH_DIALOG_OPEN] = open
    }

    // Round 2 (MainViewModel split, step 2 of 4): multi-select state (selectionMode/
    // selectedPaths, Round A) and copy/move progress state (fileOpState, Round B) moved out to
    // FileOperationViewModel - see that class instead.

    // ---------- Background Archive Operations (zip/unzip) progress state ----------

    /**
     * Mirrors [FileOpUiState] above but for ArchiveOperationService. [hidden] tracks whether
     * the user tapped "ซ่อน" on the progress dialog during the current run - MainActivity
     * uses it to avoid popping the dialog back up on every subsequent progress tick once the
     * user has dismissed it; it resets automatically the next time a run starts.
     */
    data class ArchiveOpUiState(
        val isRunning: Boolean = false,
        val isUnzip: Boolean = false,
        val archiveName: String = "",
        val percent: Int = 0,
        val hidden: Boolean = false
    )

    private val _archiveOpState = MutableStateFlow(ArchiveOpUiState())
    val archiveOpState: StateFlow<ArchiveOpUiState> = _archiveOpState

    fun setArchiveOpStarted(isUnzip: Boolean, archiveName: String) {
        _archiveOpState.value = ArchiveOpUiState(isRunning = true, isUnzip = isUnzip, archiveName = archiveName, percent = 0, hidden = false)
    }

    fun setArchiveOpProgress(percent: Int, isUnzip: Boolean, archiveName: String) {
        val current = _archiveOpState.value
        _archiveOpState.value = current.copy(isRunning = true, isUnzip = isUnzip, archiveName = archiveName, percent = percent)
    }

    fun setArchiveDialogHidden(hidden: Boolean) {
        _archiveOpState.update { it.copy(hidden = hidden) }
    }

    fun setArchiveOpDone(
        isUnzip: Boolean,
        archiveName: String,
        success: Boolean,
        error: String?,
        destinationPath: String? = null
    ) {
        _archiveOpState.value = ArchiveOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(UiEvent.ArchiveOpDone(isUnzip, archiveName, success, error, destinationPath))
        }
    }

    // ---------- Part 3/3 "สร้างไฟล์ ของฉัน" - CompressOperationService progress state ----------

    /**
     * Mirrors [ArchiveOpUiState] above but for CompressOperationService (the new ZArchiver-style
     * "สร้างไฟล์ Archive" dialog from CompressDialog.kt, parts 1-2/3). [currentItemIndex]/
     * [totalItems] are only meaningful when [CompressOptions.createSeparateArchivePerItem] was
     * checked and there's more than one source item - CompressProgressDialogHelper.kt shows a
     * "(i/n)" suffix in that case and omits it otherwise (totalItems <= 1).
     */
    data class CompressOpUiState(
        val isRunning: Boolean = false,
        val archiveName: String = "",
        val percent: Int = 0,
        val currentItemIndex: Int = 0,
        val totalItems: Int = 0,
        val hidden: Boolean = false
    )

    private val _compressOpState = MutableStateFlow(CompressOpUiState())
    val compressOpState: StateFlow<CompressOpUiState> = _compressOpState

    /** เรียกครั้งเดียวตอนเริ่มงาน - รีเซ็ต [CompressOpUiState.hidden] เผื่อรอบก่อนหน้าผู้ใช้เคยกด "ซ่อน" ไว้ */
    fun setCompressOpStarted(archiveName: String) {
        _compressOpState.value = CompressOpUiState(isRunning = true, archiveName = archiveName, percent = 0, hidden = false)
    }

    fun setCompressOpProgress(percent: Int, archiveName: String, currentItemIndex: Int, totalItems: Int) {
        val current = _compressOpState.value
        _compressOpState.value = current.copy(
            isRunning = true,
            archiveName = archiveName,
            percent = percent,
            currentItemIndex = currentItemIndex,
            totalItems = totalItems
        )
    }

    fun setCompressDialogHidden(hidden: Boolean) {
        _compressOpState.update { it.copy(hidden = hidden) }
    }

    fun setCompressOpDone(
        archiveName: String,
        success: Boolean,
        cancelled: Boolean,
        error: String?,
        createdPaths: List<String> = emptyList(),
        deletedPaths: List<String> = emptyList()
    ) {
        _compressOpState.value = CompressOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(UiEvent.CompressOpDone(archiveName, success, cancelled, error, createdPaths, deletedPaths))
        }
    }

    // ---------- Search UI & Dynamic Performance ----------

    /**
     * Drives the search screen's visibility state. Loading shows the centered progress
     * wheel, Empty shows the folder+magnifier placeholder, Success renders the results into
     * the normal file list, Error surfaces a message. See SearchHelper.kt for the
     * MainActivity-side rendering of each state.
     */
    sealed class SearchUiState {
        object Loading : SearchUiState()
        object Empty : SearchUiState()
        data class Success(val entries: List<FileEntry>) : SearchUiState()
        data class Error(val message: String) : SearchUiState()
    }

    private val _searchUiState = MutableStateFlow<SearchUiState>(SearchUiState.Loading)
    val searchUiState: StateFlow<SearchUiState> = _searchUiState

    // Mode.SEARCH is reused by the unrelated "recent folders" screen (loadRecentFolders() in
    // MainActivity.kt), which never touches searchUiState. This flag is what actually tells
    // SearchHelper.kt's overlay observer "a real text search is active right now" so it
    // doesn't render a stale Loading/Empty/Success overlay on top of that screen instead.
    private val _searchActive = MutableStateFlow(false)
    val searchActive: StateFlow<Boolean> = _searchActive

    /** Called from loadRecentFolders() and anywhere else that reuses Mode.SEARCH for something else. */
    fun clearSearchOverlay() {
        searchJob?.cancel()
        _searchActive.value = false
    }

    private var searchJob: Job? = null

    /**
     * Debounced entry point for live typing in the search box: waits [SEARCH_DEBOUNCE_MS]
     * after the last keystroke, and unconditionally cancels any in-flight search job first
     * so a fast typist never has two scans racing to publish [searchUiState].
     */
    // Round 2 (MainViewModel split, step 1 of 4): sortKey/sortAscending now live on
    // DirectoryViewModel, not here - runSearchNow() needs them for its result comparator, so
    // both entry points below now take them as explicit parameters instead of reading a local
    // _sortKey/_sortAscending, the same way [showHidden] already was passed in rather than read
    // from viewModel state directly. Callers pass directoryViewModel.sortKey.value/
    // directoryViewModel.sortAscending.value (see SearchHelper.kt).
    internal fun onSearchQueryChanged(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        if (query.isBlank()) {
            _searchUiState.value = SearchUiState.Empty
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending)
        }
    }

    /** Same scan, no debounce wait - used for the dialog's "ค้นหา" button and refresh/rotation. */
    internal fun runSearchImmediate(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        searchJob = viewModelScope.launch { runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending) }
    }

    /**
     * Hybrid strategy (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6.1): searchContent == true
     * ยังเดินสแกนสดผ่าน FileScanner เหมือนเดิมเสมอ (ค้นเนื้อไฟล์ไม่ทำ index ตามที่ตกลงกัน)
     * ส่วน searchContent == false (ค้นชื่ออย่างเดียว) เปลี่ยนไป query จาก
     * [SearchIndexManager] แทนการเดินดิสก์สด "ถ้า" index ถูก build ไปแล้วอย่างน้อยหนึ่งครั้ง
     * (searchIndexManager != null && !isEmpty()) — ถ้า index ยังว่างอยู่ (เช่นเปิดแอปครั้งแรก
     * แล้ว rebuildFullIndex() ตอน initialize() ยังทำงานไม่เสร็จ) ให้ fallback ไปเดินสแกนสด
     * แบบเดิมแทนที่จะคืนผลว่างเปล่า เพื่อไม่ให้ประสบการณ์แย่ลงกว่าเดิมในช่วงสั้นๆ นั้น
     */
    private suspend fun runSearchNow(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        _searchUiState.value = SearchUiState.Loading
        try {
            val results = withContext(Dispatchers.IO) {
                val indexManager = searchIndexManager
                if (!searchContent && indexManager != null && !indexManager.isEmpty()) {
                    indexManager.search(query, showHidden).map { FileScanner.ContentMatch(it, "") }
                } else {
                    FileScanner.searchByNameAndContent(root, query, showHidden, searchContent)
                }
            }
            val comparator = directoryBrowserHelper.comparator(sortKey, sortAscending)
            val entries = results.map { match ->
                FileEntry(match.file, subtitleOverride = match.line.ifEmpty { null })
            }.sortedWith(comparator)
            _searchUiState.value = if (entries.isEmpty()) SearchUiState.Empty else SearchUiState.Success(entries)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _searchUiState.value = SearchUiState.Error(e.message ?: "เกิดข้อผิดพลาดในการค้นหา")
        }
    }

    companion object {
        private const val SEARCH_DEBOUNCE_MS = 250L
        private const val KEY_SEARCH_QUERY = "search_query"
        private const val KEY_SEARCH_CONTENT = "search_content"

        // Rotation Safety #4 (search dialog-open flag, process-death-safe) key. Round 2 (step 2
        // of 4): KEY_TRASH_CONFIRM_OPEN/KEY_SELECTION_MORE_MENU_OPEN and the Rotation Safety #2
        // copy/move (KEY_CM_*) keys moved to FileOperationViewModel.
        private const val KEY_SEARCH_DIALOG_OPEN = "search_dialog_open"

        private const val KEY_EX_ACTIVE = "ex_conflict_active"
        private const val KEY_EX_FILE = "ex_conflict_file"
        private const val KEY_EX_DEST = "ex_conflict_dest"
        private const val KEY_EX_REMAINING = "ex_conflict_remaining"
        private const val KEY_EX_OVERWRITE = "ex_conflict_overwrite"
        private const val KEY_EX_SKIP = "ex_conflict_skip"
        private const val KEY_EX_RENAME = "ex_conflict_rename"
        private const val KEY_EX_FORCED = "ex_conflict_forced"
        private const val KEY_EX_HAD_PASSWORD = "ex_conflict_had_password"
    }

    // ---------- Conflict-resolution batch state (Rotation Safety #2) ----------
    //
    // Previously CopyMoveConflictResolver.kt/ArchiveConflictResolver.kt held the whole
    // in-progress batch (remaining conflicts, overwrite/skip sets, the "apply to all"
    // choice) as parameters on a private recursive function - i.e. only on the call
    // stack of whichever MainActivity instance started it. That "survived" rotation
    // only by accident, because KornDialog.specs is a static map that kept the dialog
    // itself alive; the batch state driving *what happens after* the dialog was still
    // tied to the old, now-destroyed Activity's stack. A real process death (Android
    // killing the app in the background under memory pressure, not just a rotation)
    // wipes that stack completely - specs[id] is gone too, the fragment silently calls
    // dismissAllowingStateLoss(), and every file after the current one in the batch is
    // never copied/moved/extracted, with no error shown to the user.
    //
    // Fix: the batch now lives here as ViewModel state instead of a local recursion,
    // backed by SavedStateHandle (same mechanism as Round 22's currentDir/mode) so it
    // survives process death too, not just rotation. MainActivity no longer recurses
    // through the conflict list itself - it observes copyMoveConflictBatch/
    // extractConflictBatch and reacts to whatever the current head of the batch is,
    // the same way it already reacts to archiveOpState/compressOpState.
    //
    // The one piece deliberately NOT persisted to SavedStateHandle is the archive
    // password for an in-progress extract batch - SavedStateHandle's Bundle can be
    // written to disk for process-death recovery, and a plaintext password sitting in
    // that file is a worse tradeoff than the (rare) inconvenience of asking the user to
    // restart extraction after a real process kill. [ExtractConflictBatch.hadPassword]
    // records whether one was needed so restoreExtractBatch() can tell "safe to silently
    // resume" (no password was ever needed) apart from "must not resume - notify the
    // user instead" (a password was needed and is gone).

    // Round 2 (MainViewModel split, step 2 of 4): CopyMoveConflictBatch + its
    // persist/restore/start/update/clear functions moved to FileOperationViewModel - see that
    // class instead. Extract's counterpart (below) stays here.

    data class ExtractConflictBatch(
        val filePath: String,
        val destinationPath: String,
        val remaining: List<String>,
        val overwriteEntries: Set<String>,
        val skipEntries: Set<String>,
        val renameEntries: Set<String>,
        val forcedAction: ConflictAction?,
        val hadPassword: Boolean
    )

    /** Not persisted to SavedStateHandle - see the class-doc note above. Config-change (rotation)
     * safe via the ViewModel instance itself; deliberately not process-death safe. */
    private var pendingExtractPassword: String? = null

    private fun persistExtractBatch(batch: ExtractConflictBatch?) {
        savedStateHandle[KEY_EX_ACTIVE] = batch != null
        if (batch == null) return
        savedStateHandle[KEY_EX_FILE] = batch.filePath
        savedStateHandle[KEY_EX_DEST] = batch.destinationPath
        savedStateHandle[KEY_EX_REMAINING] = ArrayList(batch.remaining)
        savedStateHandle[KEY_EX_OVERWRITE] = ArrayList(batch.overwriteEntries)
        savedStateHandle[KEY_EX_SKIP] = ArrayList(batch.skipEntries)
        savedStateHandle[KEY_EX_RENAME] = ArrayList(batch.renameEntries)
        savedStateHandle[KEY_EX_FORCED] = batch.forcedAction?.name
        savedStateHandle[KEY_EX_HAD_PASSWORD] = batch.hadPassword
    }

    /** Returns null (and wipes the persisted batch) when a password was needed but didn't
     * survive - see the class-doc note above. [interruptedEvent] tells the caller whether
     * that happened, so it can notify the user instead of silently doing nothing. */
    private fun restoreExtractBatch(): ExtractConflictBatch? {
        if (savedStateHandle.get<Boolean>(KEY_EX_ACTIVE) != true) return null
        val file = savedStateHandle.get<String>(KEY_EX_FILE)
        val dest = savedStateHandle.get<String>(KEY_EX_DEST)
        if (file == null || dest == null) return null
        val remaining = savedStateHandle.get<ArrayList<String>>(KEY_EX_REMAINING) ?: arrayListOf()
        if (remaining.isEmpty()) return null
        val hadPassword = savedStateHandle.get<Boolean>(KEY_EX_HAD_PASSWORD) ?: false
        if (hadPassword && pendingExtractPassword == null) {
            // Real process death: the password (never written to SavedStateHandle) is gone.
            // Can't safely resume - wipe the stale persisted batch and tell MainActivity to
            // notify the user, instead of leaving a phantom batch nothing will ever finish.
            persistExtractBatch(null)
            viewModelScope.launch { _events.emit(UiEvent.Toast("การแตกไฟล์ที่ค้างไว้ถูกยกเลิก (แอปถูกปิดกลางคัน) กรุณาลองใหม่")) }
            return null
        }
        return ExtractConflictBatch(
            filePath = file,
            destinationPath = dest,
            remaining = remaining,
            overwriteEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_OVERWRITE)?.toSet() ?: emptySet(),
            skipEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_SKIP)?.toSet() ?: emptySet(),
            renameEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_RENAME)?.toSet() ?: emptySet(),
            forcedAction = savedStateHandle.get<String>(KEY_EX_FORCED)
                ?.let { name -> runCatching { ConflictAction.valueOf(name) }.getOrNull() },
            hadPassword = hadPassword
        )
    }

    private val _extractConflictBatch = MutableStateFlow(restoreExtractBatch())
    val extractConflictBatch: StateFlow<ExtractConflictBatch?> = _extractConflictBatch

    /** Starts a brand-new batch (called only from startExtractWithConflictCheck). [password] is
     * kept in-memory only - see the class-doc note above. */
    fun startExtractConflictBatch(batch: ExtractConflictBatch, password: String?) {
        pendingExtractPassword = password
        updateExtractConflictBatch(batch)
    }

    fun updateExtractConflictBatch(batch: ExtractConflictBatch?) {
        _extractConflictBatch.value = batch
        persistExtractBatch(batch)
        if (batch == null) pendingExtractPassword = null
    }

    fun clearExtractConflictBatch() = updateExtractConflictBatch(null)

    /** The in-progress batch's password, for whichever call site finally calls
     * ArchiveOperationService.startUnzip() - a plain getter, not "consuming" anything, since
     * the same value may be needed again if the user answers several conflicts in a row. */
    fun currentExtractPassword(): String? = pendingExtractPassword

    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): the
    // "Directory listing data flow (Round 17 / Task 1)" section (DirectoryUiState,
    // directoryState, loadDirectory()) that used to live here has moved to
    // DirectoryViewModel.kt in full, together with the currentDir/lastNormalDir/mode state it
    // reads and writes - see that file instead.
}
