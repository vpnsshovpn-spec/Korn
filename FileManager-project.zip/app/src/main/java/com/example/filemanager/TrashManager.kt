package com.example.filemanager

import android.content.Context
import com.example.filemanager.renameToCompat
import com.example.filemanager.copyRecursivelyCompat
import com.example.filemanager.deleteRecursivelyCompat
import kotlinx.serialization.Serializable
import java.io.File

/**
 * Soft-delete ("recycle bin") support.
 *
 * Deleted files/folders are moved into a hidden folder instead of being deleted
 * immediately. Original location + trash time are recorded so items can be restored to
 * where they came from.
 *
 * Task 3 changes:
 * - Trash folder moved from the root of external storage
 *   (Environment.getExternalStorageDirectory()) to this app's own external files dir
 *   (context.getExternalFilesDir(null)). Writing app data into shared external storage
 *   is what Android 11+'s Scoped Storage rules restrict; app-specific external storage
 *   is exempt from those restrictions, requires no storage permission to use, and is
 *   automatically cleaned up on uninstall - a better fit for a "hidden trash folder"
 *   than the shared root ever was. Falls back to internal filesDir if external storage
 *   isn't currently available (e.g. removable SD unmounted).
 * - Entries switched from the old "name|path|timestamp" strings in a SharedPreferences
 *   StringSet to a JSON-encoded List<Entry> via DataStore (see [AppDataStore]), same
 *   reasoning as [DirectoryHistoryHelper]. StringSet order is undocumented/unstable
 *   anyway, which is why listEntries() always re-sorts by trashedAt.
 * - isEnabled/autoDeleteDays settings moved off SharedPreferences booleans/ints onto the
 *   same DataStore. Public method signatures are unchanged (see [AppDataStore]'s
 *   class-level note on why reads/writes stay synchronous here).
 */
class TrashManager(context: Context) {

    companion object {
        const val TRASH_FOLDER_NAME = ".trash_filemanager"
        const val DEFAULT_AUTO_DELETE_DAYS = 30

        private val KEY_ENABLED = AppDataStore.boolKey("trash_is_enabled")
        private val KEY_AUTO_DELETE_DAYS = AppDataStore.intKey("trash_auto_delete_days")
        private val KEY_ENTRIES = AppDataStore.key("trash_entries_json")
    }

    val trashDir: File = File(
        context.getExternalFilesDir(null) ?: context.filesDir,
        TRASH_FOLDER_NAME
    )

    private val appContext = context.applicationContext

    init {
        // Keep the midnight auto-delete job in sync with current settings every time a
        // TrashManager is created (app start, or wherever a screen instantiates one),
        // so the background schedule never drifts from what the settings sheet shows.
        if (isEnabled() && autoDeleteDays() > 0) {
            TrashWorker.schedule(appContext)
        } else {
            TrashWorker.cancel(appContext)
        }
    }

    @Serializable
    data class EntryRecord(val trashedName: String, val originalPath: String, val trashedAt: Long)

    data class Entry(val trashedFile: File, val originalPath: String, val trashedAt: Long)

    private fun ensureDir() {
        if (!trashDir.exists()) trashDir.mkdirs()
    }

    // ---------- Settings ----------

    /** Whether deleted files go through the trash at all. false = delete permanently, right away. */
    fun isEnabled(): Boolean = AppDataStore.readBool(appContext, KEY_ENABLED, true)

    fun setEnabled(enabled: Boolean) {
        AppDataStore.writeBool(appContext, KEY_ENABLED, enabled)
        if (enabled && autoDeleteDays() > 0) TrashWorker.schedule(appContext) else TrashWorker.cancel(appContext)
    }

    /** Days an item stays in the trash before being purged automatically. 0 = never. */
    fun autoDeleteDays(): Int = AppDataStore.readInt(appContext, KEY_AUTO_DELETE_DAYS, DEFAULT_AUTO_DELETE_DAYS)

    fun setAutoDeleteDays(days: Int) {
        AppDataStore.writeInt(appContext, KEY_AUTO_DELETE_DAYS, days)
        if (isEnabled() && days > 0) TrashWorker.schedule(appContext) else TrashWorker.cancel(appContext)
    }

    // ---------- Entries ----------

    private fun readRecords(): List<EntryRecord> =
        AppDataStore.readBlocking(appContext, KEY_ENTRIES, emptyList(), EntryRecordListSerializer)

    private fun writeRecords(records: List<EntryRecord>) =
        AppDataStore.writeBlocking(appContext, KEY_ENTRIES, records, EntryRecordListSerializer)

    /** Moves [file] into the trash folder and records where it came from. Returns success.
     *  If the trash feature is disabled, deletes [file] permanently instead. */
    fun moveToTrash(file: File): Boolean {
        if (!isEnabled()) {
            return try {
                if (file.isDirectory) file.deleteRecursivelyCompat() else file.delete()
            } catch (e: Exception) {
                false
            }
        }
        ensureDir()
        val ts = System.currentTimeMillis()
        val trashedName = "${ts}_${file.name}"
        val dest = File(trashDir, trashedName)
        val moved = try {
            if (file.renameToCompat(dest)) {
                true
            } else {
                file.copyRecursivelyCompat(dest, overwrite = true) &&
                    file.deleteRecursivelyCompat()
            }
        } catch (e: Exception) {
            false
        }
        if (moved) {
            writeRecords(readRecords() + EntryRecord(trashedName, file.absolutePath, ts))
        }
        return moved
    }

    /** All current trash entries, most recently trashed first. Purges anything past its
     *  retention period first, so callers never see (or have to wait on) expired items. */
    fun listEntries(): List<Entry> {
        purgeExpired()
        return rawEntries()
    }

    private fun rawEntries(): List<Entry> {
        return readRecords().mapNotNull { record ->
            val f = File(trashDir, record.trashedName)
            if (f.exists()) Entry(f, record.originalPath, record.trashedAt) else null
        }.sortedByDescending { it.trashedAt }
    }

    /** Permanently deletes any entry older than [autoDeleteDays]. A no-op when set to
     *  "never" (0). Safe to call often - used both by TrashWorker and opportunistically
     *  whenever the trash list is read. Returns how many entries were purged. */
    fun purgeExpired(): Int {
        val days = autoDeleteDays()
        if (days <= 0) return 0
        val cutoffMillis = System.currentTimeMillis() - days * 24L * 60L * 60L * 1000L
        val expired = rawEntries().filter { it.trashedAt < cutoffMillis }
        expired.forEach { deleteForever(it) }
        return expired.size
    }

    /** Moves [entry] back to its original location (or a "(restored N)" name if that path is now occupied). */
    fun restore(entry: Entry): Boolean {
        val originalFile = File(entry.originalPath)
        val destParent = originalFile.parentFile ?: return false
        destParent.mkdirs()
        val dest = if (originalFile.exists()) File(destParent, uniqueRestoreName(destParent, originalFile.name)) else originalFile
        val ok = try {
            if (entry.trashedFile.renameToCompat(dest)) {
                true
            } else {
                entry.trashedFile.copyRecursivelyCompat(dest, overwrite = true) &&
                    entry.trashedFile.deleteRecursivelyCompat()
            }
        } catch (e: Exception) {
            false
        }
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes [entry] from the trash folder. */
    fun deleteForever(entry: Entry): Boolean {
        val ok = if (entry.trashedFile.isDirectory) entry.trashedFile.deleteRecursively() else entry.trashedFile.delete()
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes everything currently in the trash. */
    fun emptyTrash() {
        trashDir.listFiles()?.forEach { if (it.isDirectory) it.deleteRecursively() else it.delete() }
        writeRecords(emptyList())
    }

    fun count(): Int = listEntries().size

    private fun removeMeta(trashedName: String) {
        writeRecords(readRecords().filter { it.trashedName != trashedName })
    }

    private fun uniqueRestoreName(dir: File, name: String): String {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base (restored $i)$ext"
            i++
        } while (File(dir, candidate).exists())
        return candidate
    }
}

private val EntryRecordListSerializer = kotlinx.serialization.builtins.ListSerializer(TrashManager.EntryRecord.serializer())
