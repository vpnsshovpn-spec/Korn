package com.example.filemanager

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import com.example.filemanager.data.repository.listFilesCompat

/**
 * Card-preview "Window Manager" - replaces the old plain Dialog+ListView.
 *
 * Each open folder ("window") is shown as a card with a small live preview of its
 * contents, plus:
 *  - a lock badge (top-left) to keep a window from being closed by mistake,
 *  - a red close badge (top-right) to close that window,
 *  - a blue checkmark (bottom-right) on whichever window is currently open.
 *
 * A "หน้าแรก" (home) card is always shown first and is never lockable/closable.
 *
 * This file only reads/mutates the same "korn_windows" SharedPreferences and
 * [MutableList] of paths that MainActivity already owns; it does not duplicate
 * that storage logic.
 */
class WindowManagerDialog(
    private val context: Context,
    private val windows: MutableList<String>,
    private val currentPath: String,
    private val onSelectHome: () -> Unit,
    private val onSelectWindow: (File) -> Unit,
    private val onWindowsChanged: () -> Unit
) {
    private val prefs = context.getSharedPreferences("korn_windows", Context.MODE_PRIVATE)
    private var dialog: KornDialogHandle? = null
    private var titleText: TextView? = null
    private lateinit var adapter: WindowCardAdapter

    private fun loadLocked(): MutableSet<String> =
        (prefs.getString("locked", "") ?: "")
            .split("\n").filter { it.isNotBlank() }.toMutableSet()

    private fun saveLocked(locked: Set<String>) {
        prefs.edit().putString("locked", locked.joinToString("\n")).apply()
    }

    private fun saveWindows() {
        prefs.edit().putString("paths", windows.take(12).joinToString("\n")).apply()
    }

    private fun clearAllUnlocked() {
        val locked = loadLocked()
        val before = windows.size
        windows.removeAll { !locked.contains(it) }
        if (windows.size == before) {
            Toast.makeText(context, "หน้าต่างทั้งหมดถูกล็อคอยู่", Toast.LENGTH_SHORT).show()
            return
        }
        if (windows.isEmpty()) windows.add(currentPath)
        saveWindows()
        onWindowsChanged()
        adapter.updateWindows(windows)
        titleText?.text = "หน้าต่าง (${windows.size})"
    }

    fun show() {
        windows.removeAll { !File(it).isDirectory }
        if (windows.isEmpty()) {
            windows.add(currentPath)
            saveWindows()
        }

        val recyclerView = RecyclerView(context).apply {
            layoutManager = GridLayoutManager(context, 2)
            setPadding(dp(8), dp(12), dp(8), dp(12))
            clipToPadding = false
        }

        adapter = WindowCardAdapter(
            context = context,
            windows = windows,
            lockedPaths = loadLocked(),
            currentPath = currentPath,
            onTapHome = {
                dialog?.dismiss()
                onSelectHome()
            },
            onTapWindow = { path ->
                dialog?.dismiss()
                onSelectWindow(File(path))
            },
            onToggleLock = { path, locked ->
                val set = loadLocked()
                if (locked) set.add(path) else set.remove(path)
                saveLocked(set)
            },
            onClose = { path, locked ->
                if (locked) {
                    Toast.makeText(context, "หน้าต่างนี้ถูกล็อคอยู่ ปลดล็อคก่อนปิด", Toast.LENGTH_SHORT).show()
                } else {
                    windows.remove(path)
                    if (windows.isEmpty()) windows.add(currentPath)
                    saveWindows()
                    onWindowsChanged()
                    adapter.updateWindows(windows)
                    titleText?.text = "หน้าต่าง (${windows.size})"
                }
            }
        )
        recyclerView.adapter = adapter

        val titleView = LayoutInflater.from(context).inflate(R.layout.dialog_window_manager_title, null)
        titleText = titleView.findViewById(R.id.windowDialogTitleText)
        titleText?.text = "หน้าต่าง (${windows.size})"
        titleView.findViewById<View>(R.id.windowDialogClearAllBtn).setOnClickListener { clearAllUnlocked() }

        dialog = KornDialog.Builder(context)
            .setCustomTitle(titleView)
            .setView(recyclerView)
            .setNegativeButton("ปิด", null)
            .create()
        dialog?.show()
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}

private class WindowCardAdapter(
    private val context: Context,
    windows: List<String>,
    private val lockedPaths: MutableSet<String>,
    private val currentPath: String,
    private val onTapHome: () -> Unit,
    private val onTapWindow: (String) -> Unit,
    private val onToggleLock: (path: String, locked: Boolean) -> Unit,
    private val onClose: (path: String, locked: Boolean) -> Unit
) : RecyclerView.Adapter<WindowCardAdapter.VH>() {

    // Position 0 is always the virtual "หน้าแรก" (home) card; the rest map 1:1 to [windows].
    private var windows: List<String> = windows

    fun updateWindows(newWindows: List<String>) {
        windows = newWindows.toList()
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val card: View = view.findViewById(R.id.windowCard)
        val pathText: TextView = view.findViewById(R.id.windowPathText)
        val usageChip: TextView = view.findViewById(R.id.windowUsageChip)
        val previewList: LinearLayout = view.findViewById(R.id.windowPreviewList)
        val emptyText: TextView = view.findViewById(R.id.windowEmptyText)
        val lockBtn: View = view.findViewById(R.id.windowLockBtn)
        val lockIcon: android.widget.ImageView = view.findViewById(R.id.windowLockIcon)
        val closeBtn: View = view.findViewById(R.id.windowCloseBtn)
        val checkIcon: View = view.findViewById(R.id.windowCheckIcon)
        val labelText: TextView = view.findViewById(R.id.windowLabelText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(context).inflate(R.layout.item_window, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = windows.size + 1

    override fun onBindViewHolder(holder: VH, position: Int) {
        if (position == 0) {
            bindHome(holder)
        } else {
            bindWindow(holder, windows[position - 1])
        }
    }

    private fun bindHome(holder: VH) {
        val home = Environment.getExternalStorageDirectory()
        holder.labelText.text = "หน้าแรก"
        holder.pathText.text = "ที่เก็บข้อมูลภายใน"
        holder.usageChip.text = usagePercentLabel(home)
        holder.lockBtn.visibility = View.GONE
        holder.closeBtn.visibility = View.GONE
        holder.checkIcon.visibility = if (isSamePath(home.absolutePath, currentPath)) View.VISIBLE else View.GONE
        fillPreview(holder, home)
        holder.itemView.setOnClickListener { onTapHome() }
    }

    private fun bindWindow(holder: VH, path: String) {
        val dir = File(path)
        val name = if (dir.name.isBlank()) dir.path else dir.name
        holder.labelText.text = name
        holder.pathText.text = shortBreadcrumb(dir)
        holder.usageChip.text = usagePercentLabel(dir)

        holder.lockBtn.visibility = View.VISIBLE
        holder.closeBtn.visibility = View.VISIBLE
        val locked = lockedPaths.contains(path)
        holder.lockIcon.setImageResource(if (locked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        holder.lockBtn.setOnClickListener {
            val nowLocked = !lockedPaths.contains(path)
            if (nowLocked) lockedPaths.add(path) else lockedPaths.remove(path)
            onToggleLock(path, nowLocked)
            holder.lockIcon.setImageResource(if (nowLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open)
        }
        holder.closeBtn.setOnClickListener { onClose(path, lockedPaths.contains(path)) }

        holder.checkIcon.visibility = if (isSamePath(dir.absolutePath, currentPath)) View.VISIBLE else View.GONE
        fillPreview(holder, dir)
        holder.itemView.setOnClickListener { onTapWindow(path) }
    }

    private fun isSamePath(a: String, b: String): Boolean =
        try { File(a).canonicalPath == File(b).canonicalPath } catch (_: Exception) { a == b }

    private fun usagePercentLabel(dir: File): String = try {
        val stat = StatFs(dir.absolutePath)
        val total = stat.blockCountLong * stat.blockSizeLong
        val free = stat.availableBlocksLong * stat.blockSizeLong
        if (total <= 0L) "" else "${(((total - free) * 100) / total)}%"
    } catch (_: Exception) { "" }

    private fun shortBreadcrumb(dir: File): String {
        val segments = dir.absolutePath.trim('/').split('/')
        return segments.takeLast(3).joinToString(" > ")
    }

    /** Fills the card body with up to 6 rows previewing the folder's real contents. */
    private fun fillPreview(holder: VH, dir: File) {
        holder.previewList.removeAllViews()
        val children = try { dir.listFilesCompat() } catch (_: Exception) { null } ?: emptyList()
        val visible = children.sortedWith(
            compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        ).take(6)

        holder.emptyText.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
        for (entry in visible) {
            holder.previewList.addView(buildPreviewRow(entry))
        }
    }

    private fun buildPreviewRow(file: File): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }

        val icon = FileIconView(context)
        val iconSize = dp(18)
        row.addView(icon, LinearLayout.LayoutParams(iconSize, iconSize).apply { marginEnd = dp(6) })
        if (file.isDirectory) {
            icon.setFolderIcon(true, null)
        } else {
            icon.setFolderIcon(false)
            icon.setFileIconText(file.extension.take(3).ifBlank { "•" })
            icon.textSize = 6f
        }

        val name = TextView(context).apply {
            text = file.name
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(0xFF37474F.toInt())
        }
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val detail = TextView(context).apply {
            text = if (file.isDirectory) {
                val count = file.listFilesCompat()?.size ?: 0
                "$count รายการ"
            } else {
                readableFileSize(file.length())
            }
            textSize = 10f
            setTextColor(0xFF9AA3AC.toInt())
        }
        row.addView(detail, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(6)
        })

        return row
    }

    private fun readableFileSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes / 1024.0
        var index = 0
        while (value >= 1024 && index < units.size - 1) { value /= 1024.0; index++ }
        return "%.1f %s".format(value, units[index])
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
