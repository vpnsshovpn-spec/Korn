package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowToast
import java.io.File

/**
 * Tests for ClipboardHelper.kt.
 *
 * Only pasteClipboard()'s empty-clipboard guard clause is covered. The rest of the file
 * (showAddMenu, newFileDialog, newFolderDialog, and pasteClipboard()'s non-empty path)
 * builds or drives KornDialog.Builder dialogs and/or calls startCopyMoveWithConflictCheck
 * (CopyMoveConflictResolver.kt) - neither has an established test pattern anywhere in this
 * project yet (no existing test exercises a KornDialog callback or the conflict-check flow
 * directly), so rather than guess at that machinery's behavior, this is recorded honestly
 * as not covered here.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class ClipboardHelperTest {

    private lateinit var externalRoot: File
    private lateinit var activity: MainActivity

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }

    @Test
    fun `pasteClipboard with nothing copied shows a toast and leaves clipboard state untouched`() {
        // clipboardIsCut set to true (with an empty clipboardFiles list) so a false-positive
        // "state got cleared" would be visible - if the guard clause didn't return early,
        // setClipboardIsCut(false) at the end of pasteClipboard() would flip this back.
        activity.fileOperationViewModel.setClipboardFiles(emptyList())
        activity.fileOperationViewModel.setClipboardIsCut(true)

        activity.pasteClipboard()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
        assertTrue(activity.fileOperationViewModel.clipboardFiles.value.isEmpty())
        assertTrue(activity.fileOperationViewModel.clipboardIsCut.value)
    }
}
