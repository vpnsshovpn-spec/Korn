package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Round 17: unit tests for MainViewModel.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see round2-instructions.txt): the
 * showHidden/sortKey/sortAscending/isGridMode/fileViewMode and currentDir/lastNormalDir/mode/
 * category-filter tests that used to live here moved to DirectoryViewModelTest.kt along with
 * the state itself.
 *
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): the clipboard,
 * multi-select, and copy/move progress tests that used to live here moved to
 * FileOperationViewModelTest.kt along with the state itself. What remains here is everything
 * else Round 14-22 put on MainViewModel: themeKey and lastSearchQuery/lastSearchContentEnabled.
 * Same two things checked for each StateFlow: (1) it starts with the expected default value,
 * and (2) its setter function actually updates `.value`.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @Before
    fun setUp() {
        viewModel = MainViewModel(SavedStateHandle())
    }

    // ---- Round 14: settings/display state ----

    @Test
    fun `themeKey defaults to blue and can be updated`() {
        assertEquals("blue", viewModel.themeKey.value)
        viewModel.setThemeKey("purple")
        assertEquals("purple", viewModel.themeKey.value)
    }

    // ---- Round 15: clipboard state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)

    // ---- Round 16: search-related state that stayed on MainViewModel ----
    // (currentDir/lastNormalDir/mode/category-filter tests moved to DirectoryViewModelTest.kt
    // in Round 2, step 1 - see this file's class doc.)

    @Test
    fun `lastSearchQuery defaults to null and can be updated`() {
        assertNull(viewModel.lastSearchQuery.value)
        viewModel.setLastSearchQuery("photo")
        assertEquals("photo", viewModel.lastSearchQuery.value)
    }

    @Test
    fun `lastSearchContentEnabled defaults to false and can be updated`() {
        assertFalse(viewModel.lastSearchContentEnabled.value)
        viewModel.setLastSearchContentEnabled(true)
        assertTrue(viewModel.lastSearchContentEnabled.value)
    }

    // ---- Round A: multi-select state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)

    // ---- Round B: copy/move progress state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)
}
