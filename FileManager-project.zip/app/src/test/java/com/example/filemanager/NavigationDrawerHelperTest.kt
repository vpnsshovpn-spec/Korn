package com.example.filemanager

import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Tests for NavigationDrawerHelper.kt.
 *
 * Covered: sortLabel()'s 6 label combinations (pure function of viewModel state),
 * applySort()'s state update + callback invocation, applyFileViewMode()'s layoutManager
 * swap + viewModel state, and setupDrawerQuickControls()'s initial switch-sync (the part
 * that runs before the listener is attached, so it's safe to assert without also driving
 * refreshCurrentView()'s coroutine-backed directory reload).
 *
 * Not covered: showSortDialog(), showViewModeDialog(), toggleGridMode() (delegates to
 * showViewModeDialog()), setupNavigationDrawer() - all build/drive KornDialog.Builder
 * dialogs or wire up the toolbar/NavigationView's click listeners as one large orchestration,
 * matching this project's established "no dialog-callback test pattern" skip reason (see
 * ClipboardHelperTest.kt, ConflictDialogHelper skipped last round). setupDrawerQuickControls()'s
 * own checked-change listener is left untested for the same reason it's *set up* last in that
 * method: triggering it drives saveUserPreferences() + refreshCurrentView(), i.e. a real
 * coroutine-backed directory reload, which no existing test in this project synchronizes on.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class NavigationDrawerHelperTest {

    private lateinit var activity: MainActivity
    private lateinit var helper: NavigationDrawerHelper

    @Before
    fun setUp() {
        android.os.Environment.getExternalStorageDirectory().listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        helper = NavigationDrawerHelper(activity)
    }

    private fun setSort(key: MainActivity.SortKey, ascending: Boolean) {
        activity.directoryViewModel.setSortKey(key)
        activity.directoryViewModel.setSortAscending(ascending)
    }

    @Test
    fun `sortLabel covers all 6 key-and-direction combinations`() {
        setSort(MainActivity.SortKey.NAME, true)
        assertEquals("ชื่อ ก-ฮ", helper.sortLabel())

        setSort(MainActivity.SortKey.NAME, false)
        assertEquals("ชื่อ ฮ-ก", helper.sortLabel())

        setSort(MainActivity.SortKey.SIZE, true)
        assertEquals("ขนาด น้อย-มาก", helper.sortLabel())

        setSort(MainActivity.SortKey.SIZE, false)
        assertEquals("ขนาด มาก-น้อย", helper.sortLabel())

        setSort(MainActivity.SortKey.DATE, true)
        assertEquals("วันที่ เก่า-ใหม่", helper.sortLabel())

        setSort(MainActivity.SortKey.DATE, false)
        assertEquals("วันที่ ใหม่-เก่า", helper.sortLabel())
    }

    @Test
    fun `applySort updates sort state and invokes the callback`() {
        var callbackRan = false

        helper.applySort(MainActivity.SortKey.SIZE, ascending = false) { callbackRan = true }

        assertEquals(MainActivity.SortKey.SIZE, activity.directoryViewModel.sortKey.value)
        assertFalse(activity.directoryViewModel.sortAscending.value)
        assertTrue(callbackRan)
    }

    @Test
    fun `applyFileViewMode switches to a grid layout manager and marks grid mode on`() {
        helper.applyFileViewMode(FileAdapter.ViewMode.GRID)

        assertEquals(FileAdapter.ViewMode.GRID, activity.directoryViewModel.fileViewMode.value)
        assertTrue(activity.directoryViewModel.isGridMode.value)
        assertTrue(activity.recyclerView.layoutManager is GridLayoutManager)
    }

    @Test
    fun `applyFileViewMode switches back to a linear layout manager and marks grid mode off`() {
        helper.applyFileViewMode(FileAdapter.ViewMode.GRID)

        helper.applyFileViewMode(FileAdapter.ViewMode.LIST)

        assertEquals(FileAdapter.ViewMode.LIST, activity.directoryViewModel.fileViewMode.value)
        assertFalse(activity.directoryViewModel.isGridMode.value)
        assertTrue(activity.recyclerView.layoutManager is LinearLayoutManager)
    }

    @Test
    fun `setupDrawerQuickControls syncs the hidden-files switch to current viewModel state`() {
        activity.directoryViewModel.setShowHidden(true)

        helper.setupDrawerQuickControls()

        assertTrue(activity.drawerHiddenSwitch!!.isChecked)
    }
}
