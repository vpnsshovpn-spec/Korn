package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowToast
import java.io.File

/**
 * Tests for SelectionModeController.kt.
 *
 * Covered: updateSelectionSubtitle(), enterSelectionMode()/exitSelectionMode(), all three
 * updateActionBars() visibility rules, showSelectionMoreMenu()'s empty-selection guard,
 * copySelected()/moveSelected()'s guard clause and clipboard state, and toastNoSelection().
 *
 * Not covered: showSelectionMoreMenu()'s populated-selection branches (which menu items appear
 * for a single file vs. directory vs. hidden file vs. multi-selection - see the inline note
 * above that test), showPropertiesDialog(), deleteSelectedToTrash()'s confirm dialog and its
 * lifecycleScope-launched trash-move (Dispatchers.IO coroutine with no test-dispatcher/sync
 * point established anywhere in this project - same reasoning ClipboardHelperTest.kt/
 * FileOpenHelperTest.kt already used to skip their own coroutine-backed success paths),
 * shareSelected()'s success path (FileProvider.getUriForFile() depends on the app's real
 * fileprovider XML meta-data resolving under Robolectric, which isn't verified anywhere in
 * this project) - only its empty-selection guard is covered, and renameSelected()'s dialog
 * delegation (renameDialog()/batchRenameDialog() are both KornDialog builders).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class SelectionModeControllerTest {

    private lateinit var activity: MainActivity
    private lateinit var root: File

    @Before
    fun setUp() {
        root = android.os.Environment.getExternalStorageDirectory()
        root.listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }

    private fun selectFiles(vararg files: File): List<File> {
        val entries = files.map { FileEntry(it) }
        activity.adapter.updateItems(entries)
        files.forEach { activity.adapter.selectPath(it.absolutePath) }
        return files.toList()
    }

    // ---- updateSelectionSubtitle() ----

    @Test
    fun `updateSelectionSubtitle shows the current selection count`() {
        val a = File(root, "a.txt").apply { writeText("x") }
        val b = File(root, "b.txt").apply { writeText("x") }
        selectFiles(a, b)

        activity.updateSelectionSubtitle()

        assertEquals("เลือก 2 รายการ", activity.supportActionBar?.subtitle)
    }

    // ---- enterSelectionMode() / exitSelectionMode() ----

    @Test
    fun `enterSelectionMode turns on adapter selection mode, disables pull-to-refresh, and shows the selection bar`() {
        activity.enterSelectionMode()

        assertTrue(activity.adapter.selectionMode)
        assertFalse(activity.swipeRefresh.isEnabled)
        assertEquals(android.view.View.VISIBLE, activity.selectionActionBar.visibility)
    }

    @Test
    fun `exitSelectionMode turns off adapter selection mode, re-enables pull-to-refresh, and hides the selection bar`() {
        activity.enterSelectionMode()

        activity.exitSelectionMode()

        assertFalse(activity.adapter.selectionMode)
        assertTrue(activity.swipeRefresh.isEnabled)
        assertEquals(android.view.View.GONE, activity.selectionActionBar.visibility)
    }

    // ---- updateActionBars() ----

    @Test
    fun `updateActionBars shows only the selection bar while selection mode is on`() {
        activity.adapter.setSelectionMode(true)

        activity.updateActionBars()

        assertEquals(android.view.View.VISIBLE, activity.selectionActionBar.visibility)
        assertEquals(android.view.View.GONE, activity.clipboardActionBar.visibility)
        assertEquals(android.view.View.GONE, activity.trashActionBar.visibility)
    }

    @Test
    fun `updateActionBars shows the clipboard bar when not selecting and the clipboard has files`() {
        activity.adapter.setSelectionMode(false)
        activity.fileOperationViewModel.setClipboardFiles(listOf(File(root, "a.txt")))

        activity.updateActionBars()

        assertEquals(android.view.View.GONE, activity.selectionActionBar.visibility)
        assertEquals(android.view.View.VISIBLE, activity.clipboardActionBar.visibility)
        assertEquals(android.view.View.GONE, activity.trashActionBar.visibility)
    }

    @Test
    fun `updateActionBars shows the trash bar when not selecting and in trash mode`() {
        activity.adapter.setSelectionMode(false)
        activity.fileOperationViewModel.setClipboardFiles(emptyList())
        activity.directoryViewModel.setMode(MainActivity.Mode.TRASH)

        activity.updateActionBars()

        assertEquals(android.view.View.GONE, activity.selectionActionBar.visibility)
        assertEquals(android.view.View.GONE, activity.clipboardActionBar.visibility)
        assertEquals(android.view.View.VISIBLE, activity.trashActionBar.visibility)
    }

    // ---- showSelectionMoreMenu() ----

    @Test
    fun `showSelectionMoreMenu with nothing selected shows the no-selection toast and no menu`() {
        activity.showSelectionMoreMenu()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
    }

    // The populated-selection branches (which items appear for a single file vs. directory vs.
    // hidden file vs. multi-selection) now flip fileOperationViewModel.selectionMoreMenuOpen and let
    // observeSelectionMoreMenu() (Rotation Safety #5) build a real KornDialog via the
    // FragmentManager - same skip reason as every other KornDialog-driving method in this
    // project (showTrashConfirmDialog, searchDialog, etc.): no established pattern here drives/
    // awaits a repeatOnLifecycle collector + FragmentManager transaction synchronously in a
    // test, so it's left honestly untested rather than guessed at. Only the guard clause above
    // (nothing selected) is covered.

    // ---- copySelected() / moveSelected() ----

    @Test
    fun `copySelected with nothing selected shows the no-selection toast and leaves clipboard empty`() {
        activity.copySelected()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
        assertTrue(activity.fileOperationViewModel.clipboardFiles.value.isEmpty())
    }

    @Test
    fun `copySelected stages the selection as a non-cut clipboard and exits selection mode`() {
        val a = File(root, "a.txt").apply { writeText("x") }
        val files = selectFiles(a)
        activity.enterSelectionMode()

        activity.copySelected()

        assertEquals(files, activity.fileOperationViewModel.clipboardFiles.value)
        assertFalse(activity.fileOperationViewModel.clipboardIsCut.value)
        assertFalse(activity.adapter.selectionMode)
    }

    @Test
    fun `moveSelected stages the selection as a cut clipboard and exits selection mode`() {
        val a = File(root, "a.txt").apply { writeText("x") }
        val files = selectFiles(a)
        activity.enterSelectionMode()

        activity.moveSelected()

        assertEquals(files, activity.fileOperationViewModel.clipboardFiles.value)
        assertTrue(activity.fileOperationViewModel.clipboardIsCut.value)
        assertFalse(activity.adapter.selectionMode)
    }

    // ---- renameSelected() guard ----

    @Test
    fun `renameSelected with nothing selected shows the no-selection toast`() {
        activity.renameSelected()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
    }

    // ---- shareSelected() guard ----

    @Test
    fun `shareSelected with nothing selected shows the no-selection toast`() {
        activity.shareSelected()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
    }

    // ---- toastNoSelection() ----

    @Test
    fun `toastNoSelection shows the expected Thai message`() {
        activity.toastNoSelection()

        assertEquals("ยังไม่ได้เลือกไฟล์", ShadowToast.getTextOfLatestToast())
    }
}
