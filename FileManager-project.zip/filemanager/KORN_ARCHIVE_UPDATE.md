# KORN Archive Update

This update keeps the existing project structure and adds multi-format archive handling.

Implemented:
- Browse/extract: ZIP, MC Pack/Addon/World, APK/APKS/XAPK/MTZ (ZIP-based), 7Z, RAR/RAR5, TAR, TAR.GZ/TGZ, TAR.BZ2/TBZ2, TAR.XZ/TXZ, GZ, BZ2, XZ, LZ4, ZST, ARJ, CPIO.
- RAR multi-volume/password support through Junrar.
- 7Z password support through Apache Commons Compress.
- Compress: 7Z, ZIP, TAR, BZ2, GZ, XZ, LZ4, ZST.
- Existing ZIP/Minecraft in-place browser is preserved, including editing without changing .mcpack/.mcaddon/.mcworld extension.
- Non-ZIP formats are materialized into the app cache for browsing so the original file is not renamed or overwritten.

Not yet implemented natively:
ISO/IMG/DMG, CAB, LZH, CHM, WIM, EGG, ALZ, RPM. These require additional format-specific/native readers and are intentionally not faked as ZIP support.
