# KORN File Manager — Cleanup & Background Work Report

วันที่: 2026-08-12

## สิ่งที่ทำในรอบนี้

- เพิ่ม Kotlin Coroutines และ lifecycle-runtime-ktx
- เปลี่ยนงานที่ผูกกับหน้าจอโดยตรงให้ใช้ `lifecycleScope` + `Dispatchers.IO` เฉพาะจุดที่เหมาะสม:
  - Text Editor: อ่านไฟล์/ZIP entry
  - Text Editor: บันทึกไฟล์/ZIP entry
  - MainActivity: category scan
  - MainActivity: search scan
  - MainActivity: load installed apps
  - MainActivity: materialize archive เพื่อเปิดใน ZIP browser
  - Storage Analyzer: recursive size scan
- ไม่เปลี่ยนงานที่ควรทำต่อจนเสร็จ เช่น archive extraction/compression, copy/move, batch rename, paste และ Minecraft archive processing
- ไม่รื้อ ThumbnailLoader executor
- เพิ่ม cleanup ของ long-press callbacks ใน FileAdapter เมื่อ ViewHolder ถูก rebind/recycle
- เก็บ reference ของ TextWatcher ใน LineNumberEditText และถอดออกเมื่อ View ถูก detach
- ปิด OutputStream ที่ก่อนหน้านี้ถูกสร้างผ่าน `out.outputStream()` โดยไม่ใช้ `use` ใน ArchiveManager 2 จุด
- ไม่เปลี่ยน algorithm เลขบรรทัด, horizontal scrolling, fling, search/replace หรือ Minecraft workflows

## การตรวจที่ทำ

ตรวจจุด `Thread`, `Handler`, `TextWatcher`, `inputStream`, `outputStream` ใน source หลักแล้ว

Thread ที่ยังเหลือเป็นงานที่ตั้งใจเก็บไว้ เพราะเป็นงานไฟล์ที่ควรควบคุมการทำงานจนจบหรือมี workflow เฉพาะ เช่น archive, copy/move, rename, Minecraft และ ZIP browser

## Build

ไม่สามารถรัน Gradle build จริงในสภาพแวดล้อมนี้ได้ เนื่องจาก ZIP โปรเจกต์ไม่มี Gradle Wrapper และ environment นี้ไม่มี Gradle executable ติดตั้งอยู่

ก่อนใช้งานจริงควรเรียก `./gradlew assembleDebug` ในเครื่อง/CI ของโปรเจกต์
