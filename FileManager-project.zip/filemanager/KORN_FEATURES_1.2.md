# KORN File Manager 1.2 – feature update

Added:
- Android "Open with" chooser for normal files and archive options; Minecraft pack files can be opened internally or handed to another app.
- Batch rename with `{n}` sequential numbering and extension preservation.
- Storage analyzer for top-level files/folders with recursive size calculation.
- Drag-and-drop files onto folder rows; multi-file drag works after multi-select.
- Light/dark theme text and window background consistency improvements.
- Existing three-line hamburger navigation remains clickable.
- Version bumped to 1.2 (versionCode 3).

Notes:
- The uploaded source archive did not contain a Gradle wrapper and this environment has no Gradle installation,
  so `assembleDebug` could not be executed here. XML files were parsed successfully and the Kotlin source changes
  were checked for balanced blocks/references. The project remains ready for the repository's GitHub Actions build.
