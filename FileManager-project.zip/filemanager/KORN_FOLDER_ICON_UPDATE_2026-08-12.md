# KORN Folder Icon Update — 2026-08-12

- Kept the familiar yellow folder shape instead of replacing folders with category icons.
- Added a small semantic badge only to recognized Android public folders at the shared-storage root: Downloads, Pictures, DCIM, Movies/Videos, Music, Documents, Ringtones, Alarms, Notifications, Podcasts and Audiobooks.
- User-created folders and folders with the same names outside the storage root keep the normal folder without a badge.
- Folder fill is darker/golden with a clearer outline on light backgrounds; the dark theme uses a lighter gold variant.
- Badge is intentionally small so the folder remains the dominant visual.
- Implemented as a custom FileIconView so list, compact, details and grid modes use the same visual treatment.
- No file operations, navigation behavior, search/replace, line-number logic, archive processing, thumbnail executor, or Minecraft workflows were changed.
