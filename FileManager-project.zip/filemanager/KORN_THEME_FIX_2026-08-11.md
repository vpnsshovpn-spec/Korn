# KORN Theme Contrast Fix — 2026-08-11

- Made the default blue theme brighter and cleaner (#2196F3 / #1976D2).
- Fixed "ตามระบบ" (follow system) so dark system mode uses a dark surface and light text instead of forcing a white background.
- Improved light-theme secondary text contrast.
- Improved drawer icon/text contrast for dark and light surfaces.
- Existing functions and project structure are preserved.
