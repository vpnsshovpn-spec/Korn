# KORN File Manager UI update

- Changed the visible selection action from `ตัด` to `ย้าย`.
- Changed the clipboard action from ambiguous `ใหม่` to `สร้างโฟลเดอร์`.
- Added a persistent `＋ สร้างโฟลเดอร์` button to the normal file-browser screen.
- Existing functions and the existing selection/clipboard action bars are preserved.
