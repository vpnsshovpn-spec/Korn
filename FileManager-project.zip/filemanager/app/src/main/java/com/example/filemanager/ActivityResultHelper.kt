package com.example.filemanager

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.filemanager.shizuku.ShizukuFileService

/**
 * onActivityResult() body, split out of MainActivity.kt (see MainActivity-Slimdown-Plan.txt
 * ก้อน 3.4). Handles two request codes: REQUEST_TEXT_EDIT (Shizuku upload after editing a
 * file that was opened from a Shizuku-only path) and REQUEST_SAF_ANDROID_DATA (SAF tree-URI
 * picker result for Android/data access). The override itself stays in MainActivity.kt since
 * Android requires it directly on the Activity class.
 */
internal fun MainActivity.handleActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    if (requestCode == MainActivity.REQUEST_TEXT_EDIT) {
        val pending = pendingShizukuSync
        pendingShizukuSync = null
        if (pending != null) {
            val (cache, original) = pending
            lifecycleScope.launch(Dispatchers.IO) {
                ShizukuFileService.uploadFromLocal(cache, original.absolutePath)
            }
        }
    } else if (requestCode == MainActivity.REQUEST_SAF_ANDROID_DATA) {
        val treeUri = data?.data
        if (resultCode == Activity.RESULT_OK && treeUri != null) {
            val looksLikeAndroidData = treeUri.toString().contains("Android%2Fdata")
            if (!looksLikeAndroidData) {
                Toast.makeText(
                    this,
                    "โฟลเดอร์ที่เลือกไม่ใช่ Android/data — เข้าดูได้ แต่ไม่ใช่โฟลเดอร์ที่ตั้งใจไว้",
                    Toast.LENGTH_LONG
                ).show()
            }
            try {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Permission still works for this session even if persisting failed.
            }
            startActivity(Intent(this, SafDataBrowserActivity::class.java).apply {
                putExtra(SafDataBrowserActivity.EXTRA_TREE_URI, treeUri.toString())
            })
        }
    }
}
