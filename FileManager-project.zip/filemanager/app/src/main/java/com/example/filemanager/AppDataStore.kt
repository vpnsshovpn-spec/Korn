package com.example.filemanager

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/**
 * Task 3 - Storage & Persistence Standard.
 *
 * Single DataStore<Preferences> for the whole app, replacing the old per-feature
 * SharedPreferences files (recent_folders, korn_windows, trash_prefs, ...) that stored
 * lists as "\n"-joined strings and records as "a|b|c" strings.
 *
 * Values are now JSON (via kotlinx.serialization) under a handful of string keys, so
 * adding a field to a stored record no longer means inventing a new delimiter.
 *
 * Design note (intentional, not an oversight): DataStore's native API is suspend/Flow
 * based, but several existing call sites are synchronous and can't easily become suspend
 * in this round - most importantly TrashWorker.doWork() (a plain androidx.work.Worker,
 * not a CoroutineWorker) and ~6 UI call sites in MainActivity/TrashSettingsSheet/
 * StorageAnalyzerActivity that don't currently run inside a coroutine. Rather than
 * mechanically converting all of those (same risk the Task 1 notes called out for the
 * get/set wrapper removal), [readBlocking]/[writeBlocking] bridge DataStore with
 * `runBlocking` so DirectoryHistoryHelper and TrashManager can keep their existing
 * synchronous method signatures. The payload is a few short strings, so the bridge cost
 * is comparable to the SharedPreferences calls it replaces. A follow-up round can convert
 * TrashWorker to CoroutineWorker and the UI call sites to lifecycleScope.launch to drop
 * the bridge and read/write DataStore's Flow directly.
 */
val Context.appDataStore: DataStore<Preferences> by preferencesDataStore(name = "filemanager_store")

object AppDataStore {

    val json = Json { ignoreUnknownKeys = true }

    fun key(name: String) = stringPreferencesKey(name)
    fun boolKey(name: String) = booleanPreferencesKey(name)
    fun intKey(name: String) = intPreferencesKey(name)

    fun readBool(context: Context, prefKey: Preferences.Key<Boolean>, default: Boolean): Boolean =
        runBlocking(Dispatchers.IO) { context.appDataStore.data.first()[prefKey] ?: default }

    fun writeBool(context: Context, prefKey: Preferences.Key<Boolean>, value: Boolean) {
        runBlocking(Dispatchers.IO) { context.appDataStore.edit { it[prefKey] = value } }
    }

    fun readInt(context: Context, prefKey: Preferences.Key<Int>, default: Int): Int =
        runBlocking(Dispatchers.IO) { context.appDataStore.data.first()[prefKey] ?: default }

    fun writeInt(context: Context, prefKey: Preferences.Key<Int>, value: Int) {
        runBlocking(Dispatchers.IO) { context.appDataStore.edit { it[prefKey] = value } }
    }

    /** Blocking bridge for reads - see class-level note. Always run off the main thread's
     *  StrictMode expectations would prefer, but matches the previous SharedPreferences
     *  synchronous-read behavior these helpers replace. */
    fun <T> readBlocking(context: Context, prefKey: Preferences.Key<String>, default: T, serializer: KSerializer<T>): T =
        runBlocking(Dispatchers.IO) {
            val raw = context.appDataStore.data.first()[prefKey] ?: return@runBlocking default
            try {
                json.decodeFromString(serializer, raw)
            } catch (e: Exception) {
                default
            }
        }

    fun <T> writeBlocking(context: Context, prefKey: Preferences.Key<String>, value: T, serializer: KSerializer<T>) {
        runBlocking(Dispatchers.IO) {
            context.appDataStore.edit { prefs ->
                prefs[prefKey] = json.encodeToString(serializer, value)
            }
        }
    }

    suspend fun <T> read(context: Context, prefKey: Preferences.Key<String>, default: T, serializer: KSerializer<T>): T =
        context.appDataStore.data.first()[prefKey]?.let { raw ->
            try { json.decodeFromString(serializer, raw) } catch (_: Exception) { default }
        } ?: default

    suspend fun <T> write(context: Context, prefKey: Preferences.Key<String>, value: T, serializer: KSerializer<T>) {
        context.appDataStore.edit { prefs ->
            prefs[prefKey] = json.encodeToString(serializer, value)
        }
    }

    suspend fun readBoolAsync(context: Context, prefKey: Preferences.Key<Boolean>, default: Boolean): Boolean =
        context.appDataStore.data.first()[prefKey] ?: default

    suspend fun writeBoolAsync(context: Context, prefKey: Preferences.Key<Boolean>, value: Boolean) {
        context.appDataStore.edit { it[prefKey] = value }
    }

    suspend fun readIntAsync(context: Context, prefKey: Preferences.Key<Int>, default: Int): Int =
        context.appDataStore.data.first()[prefKey] ?: default

    suspend fun writeIntAsync(context: Context, prefKey: Preferences.Key<Int>, value: Int) {
        context.appDataStore.edit { it[prefKey] = value }
    }

    fun readStringList(context: Context, prefKey: Preferences.Key<String>): List<String> =
        readBlocking(context, prefKey, emptyList(), ListSerializer(String.serializer()))

    fun writeStringList(context: Context, prefKey: Preferences.Key<String>, value: List<String>) =
        writeBlocking(context, prefKey, value, ListSerializer(String.serializer()))
}
