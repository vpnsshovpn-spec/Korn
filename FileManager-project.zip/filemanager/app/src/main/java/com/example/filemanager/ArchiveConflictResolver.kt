package com.example.filemanager

import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Extract's counterpart to CopyMoveConflictResolver.kt (Part 2/3) - same 3 pieces, same order,
 * just driven by archive entry relative paths (strings) instead of source Files, since an
 * archive's contents aren't File objects on disk until they're actually extracted:
 *   - conflict detection:  ArchiveManager.listEntries()  (new in this file's companion change)
 *   - the prompt itself:   ConflictDialogHelper.kt (showConflictDialog) - the exact same dialog
 *     Copy/Move uses, per ConflictDialogHelper.kt's own class doc
 *   - the actual transfer: ArchiveOperationService.kt/ArchiveManager.kt (extract logic itself
 *     unchanged - just now told which entries to overwrite/skip/rename)
 *
 * FileClickHelper.kt's startArchiveExtraction() calls [startExtractWithConflictCheck] instead
 * of starting ArchiveOperationService directly - no extraction logic lives here.
 *
 * Unlike Copy/Move (a flat list of top-level sources), RENAME needs to be recorded here rather
 * than left to an existing auto-rename fallback - extract() never had one (existing behavior
 * for any entry it doesn't know about is silent overwrite, not auto-rename - see
 * KORN-Conflict-Dialog-Part2-Status.txt's note on this). ArchiveManager.safeOutput() picks a
 * fresh unique name for exactly the entries listed in [renameEntries] and nothing else, so
 * entries with no conflict keep behaving exactly as before this feature existed.
 */
internal fun MainActivity.startExtractWithConflictCheck(file: File, destination: File, mode: Int, password: String?) {
    // Mode 0 ("อัตโนมัติ") always extracts into a brand-new folder made with uniqueName() right
    // before this is called (see startArchiveExtraction in FileClickHelper.kt) - that folder is
    // guaranteed empty, so it can never collide with anything. Skip the scan entirely instead
    // of spending time reading the archive for a result that's always "no conflicts".
    if (mode == 0) {
        beginArchiveExtraction(file, destination, password, emptySet(), emptySet(), emptySet())
        return
    }

    lifecycleScope.launch {
        val entries = try {
            withContext(Dispatchers.IO) { ArchiveManager.listEntries(file, cacheDir, password) }
        } catch (e: Exception) {
            // Can't be scanned ahead of time (wrong password, corrupt/unsupported archive,
            // etc.) - fall back to starting extraction directly, exactly as it always has. The
            // real attempt inside ArchiveOperationService still runs and reports its own
            // success/failure the normal way; this feature just can't offer a conflict dialog
            // for an archive it couldn't read in the first place.
            emptyList()
        }
        val conflicts = entries.filter { relPath -> File(destination, relPath).existsCompat() }
        if (conflicts.isEmpty()) {
            beginArchiveExtraction(file, destination, password, emptySet(), emptySet(), emptySet())
            return@launch
        }
        resolveNextExtractConflict(
            file = file,
            destination = destination,
            password = password,
            remaining = conflicts.toMutableList(),
            overwriteEntries = mutableSetOf(),
            skipEntries = mutableSetOf(),
            renameEntries = mutableSetOf(),
            forcedAction = null
        )
    }
}

/**
 * Walks [remaining] (entry relative paths) one at a time, same "ask unless applyToAll already
 * fixed the answer" shape as CopyMoveConflictResolver.kt's resolveNextCopyMoveConflict(). The
 * dialog is shown the entry's file name only (not its full path inside the archive) - matches
 * what the Copy/Move dialog already shows (src.name), keeping the prompt readable for entries
 * buried a few folders deep in the archive.
 */
private fun MainActivity.resolveNextExtractConflict(
    file: File,
    destination: File,
    password: String?,
    remaining: MutableList<String>,
    overwriteEntries: MutableSet<String>,
    skipEntries: MutableSet<String>,
    renameEntries: MutableSet<String>,
    forcedAction: ConflictAction?
) {
    if (remaining.isEmpty()) {
        beginArchiveExtraction(file, destination, password, overwriteEntries, skipEntries, renameEntries)
        return
    }

    val current = remaining.removeAt(0)

    fun applyResolution(resolution: ConflictResolution) {
        when (resolution.action) {
            ConflictAction.OVERWRITE -> overwriteEntries.add(current)
            ConflictAction.RENAME -> renameEntries.add(current)
            ConflictAction.SKIP -> skipEntries.add(current)
            ConflictAction.CANCEL -> {
                Toast.makeText(this, "ยกเลิกการแตกไฟล์แล้ว", Toast.LENGTH_SHORT).show()
                return
            }
        }
        resolveNextExtractConflict(
            file, destination, password, remaining,
            overwriteEntries, skipEntries, renameEntries,
            forcedAction = if (resolution.applyToAll) resolution.action else null
        )
    }

    if (forcedAction != null) {
        applyResolution(ConflictResolution(forcedAction, applyToAll = true))
    } else {
        showConflictDialog(File(current).name) { resolution -> applyResolution(resolution) }
    }
}

private fun MainActivity.beginArchiveExtraction(
    file: File,
    destination: File,
    password: String?,
    overwriteEntries: Set<String>,
    skipEntries: Set<String>,
    renameEntries: Set<String>
) {
    startArchiveOperationWithNotificationCheck {
        Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
        viewModel.setArchiveOpStarted(isUnzip = true, archiveName = file.name)
        ArchiveOperationService.startUnzip(this, file, destination, password, overwriteEntries, skipEntries, renameEntries)
    }
}
