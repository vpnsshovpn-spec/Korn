package com.example.filemanager

import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

/**
 * Multi-format archive creation (compress/zip) - extracted out of MainActivity.kt (round 2 of
 * the size-reduction plan). The extraction (unzip) side, extractArchiveDialog(), stays in
 * MainActivity.kt for now since it's more tightly coupled with the destination-folder picker
 * flow (OpenWithActivity's chooseDestinationFolder) - moving it is a separate, more careful
 * step. No logic changed here, only location + a couple of members widened from private to
 * internal (currentDir, extractArchiveDialog) so this file can call/read them.
 */

internal fun MainActivity.showCompressFormatDialog(source: File) {
    val formats = ArchiveManager.COMPRESS_FORMATS.toTypedArray()
    var selectedFormat = 0
    AlertDialog.Builder(this)
        .setTitle("เลือกชนิดไฟล์บีบอัด")
        .setSingleChoiceItems(formats.map { ".$it" }.toTypedArray(), selectedFormat) { _, which ->
            selectedFormat = which
        }
        .setPositiveButton("ตกลง") { dialog, _ ->
            dialog.dismiss()
            compressEntry(source, formats[selectedFormat])
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.compressEntry(source: File, format: String) {
    val parent = source.parentFile ?: currentDir
    val base = if (source.isDirectory) source.name else source.nameWithoutExtension.ifEmpty { source.name }
    val dest = File(parent, uniqueName(parent, "$base.$format"))
    Toast.makeText(this, "กำลังสร้าง ${dest.name}…", Toast.LENGTH_SHORT).show()
    Thread {
        try {
            ArchiveManager.compress(source, dest, format)
            runOnUiThread {
                Toast.makeText(this, "บีบอัดเสร็จแล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                refreshCurrentView()
            }
        } catch (e: Exception) {
            dest.delete()
            runOnUiThread {
                Toast.makeText(this, "บีบอัดไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }.start()
}

internal fun MainActivity.zipEntry(source: File) = compressEntry(source, "zip")

internal fun MainActivity.unzipEntry(zipFileEntry: File) = extractArchiveDialog(zipFileEntry)
