package com.example.filemanager

import java.io.File

/**
 * Thin wrapper for opening the "แตกไฟล์…" (unzip) flow - extracted out of MainActivity.kt
 * (round 2 of the size-reduction plan). The old compress/zip side that used to live in this
 * file (showCompressFormatDialog/compressEntry/zipEntry, calling the legacy
 * ArchiveOperationService.startZip()/ArchiveManager.compress() path) was removed once the
 * newer "สร้างไฟล์ Archive…" flow (CompressOptions/CompressViewModel/CompressDialog/
 * ArchiveEngine/CompressOperationService) fully replaced it - see that flow for all archive
 * creation now. extractArchiveDialog() itself stays in MainActivity.kt since it's more tightly
 * coupled with the destination-folder picker flow (OpenWithActivity's chooseDestinationFolder).
 */

internal fun MainActivity.unzipEntry(zipFileEntry: File) = extractArchiveDialog(zipFileEntry)
