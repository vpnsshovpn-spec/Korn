package com.example.filemanager

import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel as Zip4jCompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.CompressorStreamFactory
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InterruptedIOException
import java.io.OutputStream

/**
 * ส่วนที่ 2/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน": Core Engine ที่รับ [CompressOptions] (พาร์ท 1/3)
 * แล้วสร้างไฟล์ archive จริงบนดิสก์ - ไม่มี UI, ไม่มี Notification, ไม่รู้จัก Service ใด ๆ ทั้งสิ้น
 * (สิ่งเหล่านั้นเป็นหน้าที่ของ Service ที่จะเขียนในพาร์ท 3/3) ไฟล์นี้ไม่แก้ไข MainActivity.kt หรือ
 * ArchiveManager.kt เดิม (ซึ่งยังใช้กับเมนู "บีบอัด" แบบเก่าอยู่) - เป็นเส้นทางใหม่ที่แยกจากกัน
 * โดยสิ้นเชิงเพื่อไม่ให้กระทบพฤติกรรมเดิม
 *
 * Library ที่ใช้:
 * - Zip4j: ใช้เฉพาะฟอร์แมต ZIP เท่านั้น เพราะเป็นตัวเดียวที่รองรับทั้งเข้ารหัส AES-256 และ
 *   แบ่งไฟล์ (Split Volume) แบบเขียนได้จริงในตัว - java.util.zip ของ JDK ทำทั้งสองอย่างนี้ไม่ได้
 * - Apache Commons Compress: ใช้กับ 7z และตระกูล TAR (tar/tar.gz/tar.bz2/tar.xz/tar.lz4/
 *   tar.zstd) ฟอร์แมตเหล่านี้ไม่มีการเข้ารหัสในตัวเอง (ยกเว้น 7z ซึ่ง commons-compress
 *   รองรับแค่ "อ่าน" ไฟล์ที่เข้ารหัสไว้แล้ว ไม่รองรับ "เขียน" เข้ารหัสใหม่ - ดู [ArchiveEngineException]
 *   ที่โยนถ้าผู้ใช้ตั้งรหัสผ่านไว้กับฟอร์แมต 7z) การแบ่งไฟล์ของฟอร์แมตกลุ่มนี้ทำเองแบบ generic
 *   post-process (ตัดไฟล์ archive ที่สร้างเสร็จแล้วเป็นชิ้น ๆ .001/.002/... เพราะ commons-compress
 *   ไม่มีการแบ่ง Volume ในตัวเหมือน Zip4j)
 */
object ArchiveEngine {

    /** ขนาด Split ขั้นต่ำที่ Zip4j ยอมรับจริง (65536 ไบต์ = 64KB) - ค่าต่ำกว่านี้ Zip4j จะโยน exception เอง */
    private const val MIN_ZIP4J_SPLIT_BYTES = 65536L
    private const val COPY_BUFFER_SIZE = 64 * 1024

    /**
     * สร้างไฟล์ archive ตาม [options] แบบ synchronous (ควรเรียกจาก background thread/coroutine
     * เสมอ - ฟังก์ชันนี้ blocking) คืนค่าเป็นรายการไฟล์ทั้งหมดที่ถูกสร้างขึ้นจริง (ไฟล์เดียวถ้าไม่แยก
     * ส่วน, หลายไฟล์เรียงตามลำดับถ้าแยกส่วน) เพื่อให้ผู้เรียก (Service ในพาร์ท 3/3) ใช้แสดงผล/ลบทิ้งได้
     *
     * @param options สเปกที่ผ่านการตรวจสอบแล้วจาก CompressViewModel.buildOptions()
     * @param onProgress ตัวเลข 0-100 เรียกเป็นระยะระหว่างบีบอัด (ถูกเรียกบน thread เดียวกับที่เรียก
     *   [compress] เอง - ผู้เรียกที่ต้องการอัปเดต UI ต้อง post กลับ main thread เอง)
     * @param onCancel "จุดเช็คการยกเลิก" - Engine เรียกฟังก์ชันนี้เป็นระยะระหว่างทำงาน (สลับกับ
     *   [onProgress]) ผู้เรียกที่ต้องการยกเลิกงานกลางคันให้ implement ฟังก์ชันนี้ให้ throw
     *   [ArchiveCancelledException] เมื่อผู้ใช้กดยกเลิก (เช่น เช็ค @Volatile flag แล้ว throw) - Engine
     *   เองไม่รู้จักกลไกการยกเลิกใด ๆ นอกจากเรียกฟังก์ชันนี้แล้วปล่อยให้ exception ที่โยนออกมาไหลผ่าน
     *   try-catch ของ Engine ไปเข้า catch block เดียวกับ Error ทั่วไป (ดูหัวข้อ cleanup ด้านล่าง)
     *
     * ความเสี่ยงที่ดักจับ (ทั้งจาก Error จริงและจากการยกเลิกผ่าน [onCancel]):
     * - Multi-part cleanup: ถ้าสร้างไฟล์แยกส่วนไปแล้วบางส่วนแล้วถูกยกเลิก/error กลางคัน จะลบไฟล์ส่วน
     *   ที่สร้างค้างไว้ทั้งหมดทิ้ง (.z01/.z02/.../.zip หรือ .001/.002/...) ไม่ทิ้งขยะไว้ในเครื่องผู้ใช้
     * - OutOfMemoryError, IOException (รวม "No space left on device"/EACCES ที่ห่อมาใน IOException
     *   บน Android), SecurityException, ZipException ถูกจับและแปลงเป็น [ArchiveEngineException]
     *   ที่มีข้อความภาษาไทยพร้อมแสดงผู้ใช้ได้ทันที
     */
    fun compress(
        options: CompressOptions,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ): List<File> {
        validateOrThrow(options)

        val createdParts = mutableListOf<File>()
        try {
            options.outputDir.mkdirs()
            when (options.format) {
                CompressFormat.ZIP -> compressZip(options, createdParts, onProgress, onCancel)
                CompressFormat.SEVEN_Z -> compressSevenZAndMaybeSplit(options, createdParts, onProgress, onCancel)
                CompressFormat.TAR,
                CompressFormat.TAR_GZ,
                CompressFormat.TAR_BZ2,
                CompressFormat.TAR_XZ,
                CompressFormat.TAR_LZ4,
                CompressFormat.TAR_ZSTD -> compressTarFamilyAndMaybeSplit(options, createdParts, onProgress, onCancel)
            }
            return createdParts.toList()
        } catch (e: ArchiveCancelledException) {
            cleanupParts(createdParts)
            throw e
        } catch (e: ArchiveEngineException) {
            cleanupParts(createdParts)
            throw e
        } catch (e: OutOfMemoryError) {
            cleanupParts(createdParts)
            throw ArchiveEngineException("หน่วยความจำไม่พอสำหรับบีบอัดไฟล์นี้ ลองปิดแอปอื่นแล้วลองใหม่ หรือเลือกไฟล์ที่เล็กลง", e)
        } catch (e: SecurityException) {
            cleanupParts(createdParts)
            throw ArchiveEngineException("ไม่มีสิทธิ์เข้าถึงไฟล์หรือโฟลเดอร์นี้ กรุณาตรวจสอบสิทธิ์การเข้าถึงแล้วลองใหม่", e)
        } catch (e: ZipException) {
            cleanupParts(createdParts)
            throw ArchiveEngineException(mapZip4jError(e), e)
        } catch (e: IOException) {
            cleanupParts(createdParts)
            throw ArchiveEngineException(mapIOError(e), e)
        } catch (e: Exception) {
            cleanupParts(createdParts)
            throw ArchiveEngineException("เกิดข้อผิดพลาดขณะบีบอัดไฟล์: ${e.message ?: e::class.java.simpleName}", e)
        }
    }

    private fun validateOrThrow(options: CompressOptions) {
        if (options.sourceFiles.isEmpty()) {
            throw ArchiveEngineException("ไม่มีไฟล์หรือโฟลเดอร์ต้นทางให้บีบอัด")
        }
        if (options.sourceFiles.any { !it.exists() }) {
            throw ArchiveEngineException("ไฟล์หรือโฟลเดอร์ต้นทางบางรายการถูกลบหรือย้ายไปแล้ว")
        }
        if (options.format == CompressFormat.SEVEN_Z && options.isEncrypted) {
            throw ArchiveEngineException("รุ่นนี้ยังไม่รองรับการตั้งรหัสผ่านสำหรับไฟล์ 7z (เขียนเข้ารหัสได้เฉพาะ ZIP เท่านั้น) กรุณาเปลี่ยนฟอร์แมตเป็น ZIP หรือไม่ตั้งรหัสผ่าน")
        }
        if (options.isSplit && options.volumeSizeBytes < MIN_ZIP4J_SPLIT_BYTES) {
            throw ArchiveEngineException("ขนาดไฟล์ต่อส่วนเล็กเกินไป ต้องมีอย่างน้อย 64KB")
        }
        val freeSpace = options.outputDir.let { if (it.exists()) it.usableSpace else it.parentFile?.usableSpace ?: Long.MAX_VALUE }
        val estimatedNeeded = sizeRecursive(options.sourceFiles)
        // เผื่อพื้นที่คร่าว ๆ อย่างน้อยเท่าต้นฉบับ (ไฟล์ที่บีบอัดไม่ได้จริงหรือถูกเข้ารหัสอาจมีขนาดใกล้เคียงเดิม)
        if (freeSpace in 0 until estimatedNeeded) {
            throw ArchiveEngineException("พื้นที่เก็บข้อมูลไม่พอ ต้องการอย่างน้อย ${readableSize(estimatedNeeded)} แต่เหลือว่าง ${readableSize(freeSpace)}")
        }
    }

    private fun sizeRecursive(files: List<File>): Long =
        files.sumOf { f -> if (f.isDirectory) (f.listFiles()?.let { sizeRecursive(it.toList()) } ?: 0L) else f.length().coerceAtLeast(0) }

    private fun readableSize(bytes: Long): String {
        if (bytes < 0) return "ไม่ทราบ"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.lastIndex) { value /= 1024; unitIndex++ }
        return "%.1f %s".format(value, units[unitIndex])
    }

    // ---------------------------------------------------------------------------------------
    // ZIP (Zip4j) - รองรับ AES-256 / ZipCrypto และ Split Volume แบบเขียนจริงในตัว
    // ---------------------------------------------------------------------------------------

    private fun compressZip(
        options: CompressOptions,
        createdParts: MutableList<File>,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val output = options.outputFile
        val zipFile = ZipFile(output)
        if (options.isEncrypted) {
            zipFile.setPassword(options.password!!.toCharArray())
        }

        val params = buildZipParameters(options)
        val totalBytes = sizeRecursive(options.sourceFiles).coerceAtLeast(1L)
        val processedBytes = longArrayOf(0L)
        // Split Volume ต้อง "เริ่ม" ด้วย createSplitZipFile(...)/createSplitZipFileFromFolder(...)
        // เพียงครั้งเดียวเท่านั้น (ตั้งค่า splitLength ลงใน model ของ ZipFile) - แหล่งข้อมูลถัดไป
        // (ถ้าผู้ใช้เลือกหลายไฟล์/โฟลเดอร์พร้อมกัน) ต้องเรียก addFile/addFolder ตามปกติ ซึ่ง Zip4j
        // จะยังคงเขียนต่อเข้าไฟล์ split ชุดเดิมตาม splitLength ที่ตั้งไว้แล้วโดยอัตโนมัติ - เรียก
        // createSplitZipFile ซ้ำสองครั้งกับ ZipFile เดียวกันจะทำให้ Zip4j โยน exception
        var splitStarted = false

        // หมายเหตุเรื่อง Progress: การเรียก Zip4j แต่ละครั้งด้านล่าง (addFile/addFolder/
        // createSplitZipFile...) เป็นการ block จนกว่าจะเขียนไฟล์/โฟลเดอร์นั้นเสร็จทั้งก้อน - Zip4j ไม่มี
        // API แบบ synchronous ให้ poll ความคืบหน้าไบต์ต่อไบต์ระหว่างเรียก (ProgressMonitor ของมัน
        // ออกแบบมาสำหรับโหมด async บน thread แยกเท่านั้น) จึงรายงาน [onProgress] แบบหยาบ - ต่อเมื่อ
        // ไฟล์/โฟลเดอร์ต้นทางแต่ละรายการเขียนเสร็จ ไม่ใช่ต่อบล็อกไบต์เหมือนฟอร์แมตอื่นด้านล่าง
        try {
            for (source in options.sourceFiles) {
                onCancel()
                if (options.isSplit && !splitStarted) {
                    if (source.isDirectory) {
                        zipFile.createSplitZipFileFromFolder(source, params, true, options.volumeSizeBytes)
                    } else {
                        zipFile.createSplitZipFile(listOf(source), params, true, options.volumeSizeBytes)
                    }
                    splitStarted = true
                } else {
                    if (source.isDirectory) {
                        zipFile.addFolder(source, params)
                    } else {
                        zipFile.addFile(source, params)
                    }
                }
                processedBytes[0] += fileOrFolderSize(source)
                onProgress(((processedBytes[0] * 100) / totalBytes).toInt().coerceIn(0, 100))
                onCancel()
            }
        } catch (e: ZipException) {
            // ทั้ง single-part และ split เขียนไฟล์ .zip/.z01/.z02... ลงดิสก์ทันทีตอน addFile/
            // addFolder/createSplitZipFile - ต้องเก็บชื่อไฟล์จริงที่ Zip4j สร้างไว้ (จากรายการชื่อไฟล์
            // ที่ zip4j ตั้งเองตาม convention .z01/.z02/../.zip) ก่อนโยนต่อให้ catch block ของ
            // compress() ไปลบทิ้งให้ - ทำผ่าน collectZip4jParts() ด้านล่างแทนการเดาชื่อเอง
            createdParts.addAll(collectZip4jParts(output))
            throw e
        }
        createdParts.addAll(collectZip4jParts(output))
        onProgress(100)
    }

    private fun buildZipParameters(options: CompressOptions): ZipParameters {
        val params = ZipParameters()
        params.compressionMethod = if (options.level == CompressionLevel.STORE) {
            CompressionMethod.STORE
        } else {
            CompressionMethod.DEFLATE
        }
        params.compressionLevel = mapZip4jLevel(options.level)
        if (options.isEncrypted) {
            params.isEncryptFiles = true
            params.encryptionMethod = when (options.encryptionType) {
                EncryptionType.AES256 -> EncryptionMethod.AES
                EncryptionType.ZIP_CRYPTO -> EncryptionMethod.ZIP_STANDARD
            }
            if (options.encryptionType == EncryptionType.AES256) {
                params.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
            }
        }
        return params
    }

    private fun mapZip4jLevel(level: CompressionLevel): Zip4jCompressionLevel = when (level) {
        CompressionLevel.STORE -> Zip4jCompressionLevel.FASTEST
        CompressionLevel.FASTEST -> Zip4jCompressionLevel.FASTEST
        CompressionLevel.FAST -> Zip4jCompressionLevel.FASTER
        CompressionLevel.NORMAL -> Zip4jCompressionLevel.NORMAL
        CompressionLevel.MAXIMUM -> Zip4jCompressionLevel.MAXIMUM
        CompressionLevel.ULTRA -> Zip4jCompressionLevel.ULTRA
    }

    /** หาไฟล์ .zip/.z01/.z02/... ทั้งหมดที่ Zip4j สร้างไว้จริงบนดิสก์สำหรับ archive ปลายทางนี้ */
    private fun collectZip4jParts(output: File): List<File> {
        val dir = output.parentFile ?: return listOfNotNull(output.takeIf { it.exists() })
        val baseName = output.nameWithoutExtension
        val zPartRegex = Regex(Regex.escape("$baseName.") + "z\\d{2,3}$", RegexOption.IGNORE_CASE)
        val found = dir.listFiles { f ->
            f.isFile && (f.name == output.name || zPartRegex.matches(f.name))
        } ?: emptyArray()
        return found.toList()
    }

    private fun fileOrFolderSize(f: File): Long =
        if (f.isDirectory) (f.listFiles()?.sumOf { fileOrFolderSize(it) } ?: 0L) else f.length().coerceAtLeast(0)

    // ---------------------------------------------------------------------------------------
    // 7z (Commons Compress) - ไม่รองรับเข้ารหัสตอนเขียน (ดักไว้ใน validateOrThrow แล้ว)
    // ---------------------------------------------------------------------------------------

    private fun compressSevenZAndMaybeSplit(
        options: CompressOptions,
        createdParts: MutableList<File>,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val unsplitTarget = if (options.isSplit) tempSiblingFile(options.outputFile) else options.outputFile
        createdParts.add(unsplitTarget)
        val total = sizeRecursive(options.sourceFiles).coerceAtLeast(1L)
        val counter = longArrayOf(0L)

        SevenZOutputFile(unsplitTarget).use { sevenZ ->
            sevenZ.setContentCompression(if (options.level == CompressionLevel.STORE) SevenZMethod.COPY else SevenZMethod.LZMA2)
            for (source in options.sourceFiles) {
                onCancel()
                addTreeTo7z(source, source.name, sevenZ, total, counter, onProgress, onCancel)
            }
        }

        if (options.isSplit) {
            createdParts.remove(unsplitTarget)
            createdParts.addAll(splitFileIntoParts(unsplitTarget, options.outputFile, options.volumeSizeBytes, onCancel))
            unsplitTarget.delete()
        }
        onProgress(100)
    }

    private fun addTreeTo7z(
        f: File,
        name: String,
        sevenZ: SevenZOutputFile,
        total: Long,
        counter: LongArray,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val entry = sevenZ.createArchiveEntry(f, name) as SevenZArchiveEntry
        sevenZ.putArchiveEntry(entry)
        if (f.isFile) {
            f.inputStream().use { input ->
                val buffer = ByteArray(COPY_BUFFER_SIZE)
                var read = input.read(buffer)
                while (read >= 0) {
                    onCancel()
                    sevenZ.write(buffer, 0, read)
                    counter[0] += read.toLong()
                    onProgress(((counter[0] * 100) / total).toInt().coerceIn(0, 100))
                    read = input.read(buffer)
                }
            }
        }
        sevenZ.closeArchiveEntry()
        if (f.isDirectory) {
            f.listFiles()?.forEach { addTreeTo7z(it, "$name/${it.name}", sevenZ, total, counter, onProgress, onCancel) }
        }
    }

    // ---------------------------------------------------------------------------------------
    // TAR family (Commons Compress) - tar / tar.gz / tar.bz2 / tar.xz / tar.lz4 / tar.zstd
    // ---------------------------------------------------------------------------------------

    private fun compressTarFamilyAndMaybeSplit(
        options: CompressOptions,
        createdParts: MutableList<File>,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val unsplitTarget = if (options.isSplit) tempSiblingFile(options.outputFile) else options.outputFile
        createdParts.add(unsplitTarget)
        val total = sizeRecursive(options.sourceFiles).coerceAtLeast(1L)
        val counter = longArrayOf(0L)

        val rawOut: OutputStream = BufferedOutputStream(FileOutputStream(unsplitTarget))
        val wrappedOut: OutputStream = when (options.format) {
            CompressFormat.TAR_GZ -> CompressorStreamFactory().createCompressorOutputStream(CompressorStreamFactory.GZIP, rawOut)
            CompressFormat.TAR_BZ2 -> CompressorStreamFactory().createCompressorOutputStream(CompressorStreamFactory.BZIP2, rawOut)
            CompressFormat.TAR_XZ -> CompressorStreamFactory().createCompressorOutputStream(CompressorStreamFactory.XZ, rawOut)
            CompressFormat.TAR_LZ4 -> CompressorStreamFactory().createCompressorOutputStream(CompressorStreamFactory.LZ4_FRAMED, rawOut)
            CompressFormat.TAR_ZSTD -> CompressorStreamFactory().createCompressorOutputStream(CompressorStreamFactory.ZSTANDARD, rawOut)
            else -> rawOut // CompressFormat.TAR เปล่า ๆ ไม่ต้องห่อ compressor เพิ่ม
        }

        TarArchiveOutputStream(wrappedOut).use { tar ->
            tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU)
            for (source in options.sourceFiles) {
                onCancel()
                addTreeToTar(source, source.name, tar, total, counter, onProgress, onCancel)
            }
        }

        if (options.isSplit) {
            createdParts.remove(unsplitTarget)
            createdParts.addAll(splitFileIntoParts(unsplitTarget, options.outputFile, options.volumeSizeBytes, onCancel))
            unsplitTarget.delete()
        }
        onProgress(100)
    }

    private fun addTreeToTar(
        f: File,
        name: String,
        tar: TarArchiveOutputStream,
        total: Long,
        counter: LongArray,
        onProgress: (Int) -> Unit,
        onCancel: () -> Unit
    ) {
        val entry = TarArchiveEntry(f, name)
        tar.putArchiveEntry(entry)
        if (f.isFile) {
            f.inputStream().use { input ->
                val buffer = ByteArray(COPY_BUFFER_SIZE)
                var read = input.read(buffer)
                while (read >= 0) {
                    onCancel()
                    tar.write(buffer, 0, read)
                    counter[0] += read.toLong()
                    onProgress(((counter[0] * 100) / total).toInt().coerceIn(0, 100))
                    read = input.read(buffer)
                }
            }
        }
        tar.closeArchiveEntry()
        if (f.isDirectory) {
            f.listFiles()?.forEach { addTreeToTar(it, "$name/${it.name}", tar, total, counter, onProgress, onCancel) }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Generic post-process splitting สำหรับฟอร์แมตที่ไม่มี Split Volume ในตัว (7z/tar family)
    // ตั้งชื่อไฟล์ตาม convention .001/.002/... (เช่น archive.7z.001, archive.tar.gz.002)
    // ---------------------------------------------------------------------------------------

    private fun tempSiblingFile(finalOutput: File): File =
        File(finalOutput.parentFile, "${finalOutput.name}.building")

    private fun splitFileIntoParts(source: File, finalOutputName: File, volumeSizeBytes: Long, onCancel: () -> Unit): List<File> {
        val parts = mutableListOf<File>()
        source.inputStream().buffered().use { input ->
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            var partIndex = 1
            var remainingInPart = volumeSizeBytes
            var out = openNextPart(finalOutputName, partIndex, parts)
            try {
                var read = input.read(buffer)
                while (read >= 0) {
                    onCancel()
                    var offset = 0
                    while (offset < read) {
                        if (remainingInPart <= 0) {
                            out.close()
                            partIndex++
                            out = openNextPart(finalOutputName, partIndex, parts)
                            remainingInPart = volumeSizeBytes
                        }
                        val toWrite = minOf((read - offset).toLong(), remainingInPart).toInt()
                        out.write(buffer, offset, toWrite)
                        offset += toWrite
                        remainingInPart -= toWrite
                    }
                    read = input.read(buffer)
                }
            } finally {
                out.close()
            }
        }
        return parts
    }

    private fun openNextPart(finalOutputName: File, partIndex: Int, parts: MutableList<File>): OutputStream {
        val partNumber = partIndex.toString().padStart(3, '0')
        val partFile = File(finalOutputName.parentFile, "${finalOutputName.name}.$partNumber")
        parts.add(partFile)
        return BufferedOutputStream(FileOutputStream(partFile))
    }

    // ---------------------------------------------------------------------------------------
    // Cleanup + การแปล Exception เป็นข้อความภาษาไทย
    // ---------------------------------------------------------------------------------------

    /** ลบไฟล์ทุกส่วน (single หรือ multi-part) ที่สร้างค้างไว้ตอนถูกยกเลิก/error - ไม่ทิ้งขยะ */
    private fun cleanupParts(parts: List<File>) {
        for (part in parts) {
            try {
                if (part.exists()) part.delete()
            } catch (_: Exception) {
                // การลบ cleanup เองพลาดไม่ควรบัง exception ตัวจริงที่กำลังจะโยนออกไป - เงียบไว้
            }
        }
    }

    private fun mapZip4jError(e: ZipException): String {
        val msg = e.message?.lowercase() ?: ""
        return when {
            "no space" in msg || "not enough space" in msg -> "พื้นที่เก็บข้อมูลไม่พอสำหรับสร้างไฟล์ archive กรุณาลบไฟล์ที่ไม่ใช้แล้วลองใหม่"
            "permission" in msg || "access is denied" in msg -> "ไม่มีสิทธิ์เขียนไฟล์ไปยังตำแหน่งที่เลือก กรุณาเลือกโฟลเดอร์อื่นหรือตรวจสอบสิทธิ์การเข้าถึง"
            "password" in msg -> "รหัสผ่านไม่ถูกต้องหรือไม่ได้ตั้งรหัสผ่านไว้"
            else -> "เกิดข้อผิดพลาดขณะสร้างไฟล์ ZIP: ${e.message ?: "ไม่ทราบสาเหตุ"}"
        }
    }

    private fun mapIOError(e: IOException): String {
        if (e is InterruptedIOException) return "การดำเนินการถูกยกเลิก"
        val msg = e.message?.lowercase() ?: ""
        return when {
            "enospc" in msg || "no space left" in msg || "not enough space" in msg ->
                "พื้นที่เก็บข้อมูลไม่พอสำหรับสร้างไฟล์ archive กรุณาลบไฟล์ที่ไม่ใช้แล้วลองใหม่"
            "eacces" in msg || "permission denied" in msg ->
                "ไม่มีสิทธิ์เขียนไฟล์ไปยังตำแหน่งที่เลือก กรุณาเลือกโฟลเดอร์อื่นหรือตรวจสอบสิทธิ์การเข้าถึง"
            "read-only" in msg -> "ตำแหน่งปลายทางเป็นแบบอ่านอย่างเดียว กรุณาเลือกโฟลเดอร์อื่น"
            else -> "เกิดข้อผิดพลาดขณะอ่าน/เขียนไฟล์: ${e.message ?: "ไม่ทราบสาเหตุ"}"
        }
    }
}

/**
 * โยนโดย [ArchiveEngine.compress] เมื่อเกิด Error ที่ทราบสาเหตุแน่ชัด (พื้นที่ไม่พอ, ไม่มีสิทธิ์,
 * หน่วยความจำไม่พอ, ตัวเลือกไม่ถูกต้อง ฯลฯ) - [message] เป็นภาษาไทยพร้อมแสดงผู้ใช้ได้ทันทีโดยไม่ต้อง
 * แปลซ้ำ ผู้เรียก (Service ในพาร์ท 3/3) ควรจับ exception นี้แยกจาก [ArchiveCancelledException]
 */
class ArchiveEngineException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * โยนจากภายใน callback [ArchiveEngine.compress]'s onCancel เมื่อผู้ใช้กดยกเลิกงานกลางคัน - Engine
 * จะดักจับที่ catch block เดียวกับ Error ทั่วไป (ทำ cleanup ไฟล์ multi-part ค้างแล้วโยนต่อ) ผู้เรียก
 * ควรจับ exception นี้แยกออกจาก [ArchiveEngineException] เพื่อไม่แสดงเป็น "ข้อผิดพลาด" ต่อผู้ใช้
 */
class ArchiveCancelledException(message: String = "ผู้ใช้ยกเลิกการบีบอัดไฟล์") : Exception(message)
