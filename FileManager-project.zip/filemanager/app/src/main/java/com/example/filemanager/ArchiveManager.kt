package com.example.filemanager

import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.compressors.CompressorInputStream
import org.apache.commons.compress.compressors.CompressorStreamFactory
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Multi-format archive bridge.
 *
 * Browse mode materializes a temporary ZIP in app cache and opens it with the
 * existing ZipBrowserActivity. This keeps the existing UI/editing code intact.
 * The original archive is never renamed to .zip.
 */
object ArchiveManager {
    val BROWSE_EXTENSIONS = setOf(
        "zip","mcpack","mcaddon","mcworld","7z","tar","tgz","tar.gz","bz2","tbz2","tar.bz2",
        "xz","txz","tar.xz","lz4","zst","rar","rar5","apk","apks","xapk","mtz","arj","cpio",
        "gz","lzh","cab","chm","wim","egg","alz","iso","img","dmg","deb","rpm"
    )
    val COMPRESS_FORMATS = listOf("7z","zip","tar","bz2","gz","xz","lz4","zst")

    fun isArchive(file: File): Boolean {
        val n = file.name.lowercase()
        return BROWSE_EXTENSIONS.any { n == it || n.endsWith(".$it") } ||
                n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")) ||
                n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                n.matches(Regex(".*\\.r\\d{2}$"))
    }

    fun isPasswordCandidate(file: File): Boolean =
        file.name.lowercase().let { it.endsWith(".rar") || it.endsWith(".rar5") ||
            it.contains(".part") && it.endsWith(".rar") ||
            it.endsWith(".7z") || it.matches(Regex(".*\\.7z\\.\\d{3}$")) }

    fun materializeForBrowse(input: File, password: String? = null): File {
        val work = File(input.parentFile ?: input, ".korn_cache") // only used for path fallback
        val cacheDir = File(System.getProperty("java.io.tmpdir") ?: input.parentFile?.absolutePath ?: ".", "korn_archive")
        // Android exposes java.io.tmpdir inside the app sandbox. Use input context-independent
        // cache sibling only as a last resort; MainActivity passes its cache directory below.
        throw IllegalStateException("ArchiveManager.materializeForBrowse(File,...) requires app cache overload")
    }

    fun materializeForBrowse(input: File, cacheDir: File, password: String? = null): File {
        val actual = combineSplitIfNeeded(input, cacheDir)
        val out = File(cacheDir, "browse_${System.currentTimeMillis()}.zip")
        out.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            when (formatOf(actual)) {
                "zip" -> copyZipToZip(actual, zos)
                "7z" -> sevenZipToZip(actual, zos, password)
                "rar" -> rarToZip(actual, zos, password)
                "tar" -> archiveStreamToZip(FileInputStream(actual), "tar", zos)
                "tar.gz","tgz" -> compressedArchiveToZip(actual, CompressorStreamFactory.GZIP, zos)
                "tar.bz2","tbz2" -> compressedArchiveToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "tar.xz","txz" -> compressedArchiveToZip(actual, CompressorStreamFactory.XZ, zos)
                "gz" -> singleCompressedToZip(actual, CompressorStreamFactory.GZIP, zos)
                "bz2" -> singleCompressedToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "xz" -> singleCompressedToZip(actual, CompressorStreamFactory.XZ, zos)
                "lz4" -> singleCompressedToZip(actual, CompressorStreamFactory.LZ4_FRAMED, zos)
                "zst" -> singleCompressedToZip(actual, CompressorStreamFactory.ZSTANDARD, zos)
                "arj","cpio","ar" -> archiveStreamToZip(FileInputStream(actual), null, zos)
                else -> throw UnsupportedOperationException(
                    "KORN ยังไม่สามารถอ่าน ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
                )
            }
        }
        if (actual != input) actual.delete()
        return out
    }

    fun extract(input: File, destination: File, password: String? = null) {
        val actual = combineSplitIfNeeded(input, destination.parentFile ?: destination)
        destination.mkdirs()
        when (formatOf(actual)) {
            "zip" -> extractZip(actual, destination)
            "7z" -> extract7z(actual, destination, password)
            "rar" -> extractRar(actual, destination, password)
            "tar" -> extractArchiveStream(FileInputStream(actual), destination)
            "tar.gz","tgz" -> extractCompressedArchive(actual, CompressorStreamFactory.GZIP, destination)
            "tar.bz2","tbz2" -> extractCompressedArchive(actual, CompressorStreamFactory.BZIP2, destination)
            "tar.xz","txz" -> extractCompressedArchive(actual, CompressorStreamFactory.XZ, destination)
            "gz" -> extractSingleCompressed(actual, CompressorStreamFactory.GZIP, destination)
            "bz2" -> extractSingleCompressed(actual, CompressorStreamFactory.BZIP2, destination)
            "xz" -> extractSingleCompressed(actual, CompressorStreamFactory.XZ, destination)
            "lz4" -> extractSingleCompressed(actual, CompressorStreamFactory.LZ4_FRAMED, destination)
            "zst" -> extractSingleCompressed(actual, CompressorStreamFactory.ZSTANDARD, destination)
            "arj","cpio","ar" -> extractArchiveStream(FileInputStream(actual), destination)
            else -> throw UnsupportedOperationException(
                "KORN ยังไม่สามารถ Extract ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
            )
        }
        if (actual != input) actual.delete()
    }

    private fun formatOf(f: File): String {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") -> "tar.gz"
            n.endsWith(".tar.bz2") -> "tar.bz2"
            n.endsWith(".tar.xz") -> "tar.xz"
            n.endsWith(".tgz") -> "tgz"
            n.endsWith(".tbz2") -> "tbz2"
            n.endsWith(".txz") -> "txz"
            n.endsWith(".rar") || n.endsWith(".rar5") || n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                    n.matches(Regex(".*\\.r\\d{2}$")) -> "rar"
            n.endsWith(".7z") || n.matches(Regex(".*\\.7z\\.\\d{3}$")) -> "7z"
            n.endsWith(".zip") || n.endsWith(".mcpack") || n.endsWith(".mcaddon") ||
                    n.endsWith(".mcworld") || n.endsWith(".apk") || n.endsWith(".apks") ||
                    n.endsWith(".xapk") || n.endsWith(".mtz") -> "zip"
            n.endsWith(".tar") -> "tar"
            n.endsWith(".bz2") -> "bz2"
            n.endsWith(".gz") -> "gz"
            n.endsWith(".xz") -> "xz"
            n.endsWith(".lz4") -> "lz4"
            n.endsWith(".zst") -> "zst"
            n.endsWith(".arj") -> "arj"
            n.endsWith(".cpio") -> "cpio"
            n.endsWith(".ar") || n.endsWith(".deb") -> "ar"
            else -> n.substringAfterLast('.', "")
        }
    }

    private fun combineSplitIfNeeded(input: File, cacheDir: File): File {
        val n = input.name.lowercase()
        if (!(n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")))) return input
        val baseName = input.name.substringBeforeLast('.')
        val base = File(input.parentFile, baseName)
        val parts = (input.parentFile?.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("$baseName.", true) && it.name.substringAfterLast('.').toIntOrNull() != null }
            .sortedBy { it.name.substringAfterLast('.').toInt() }
        if (parts.isEmpty()) throw IOException("ไม่พบไฟล์ part ที่เหลือ")
        val combined = File(cacheDir, "joined_${System.currentTimeMillis()}_$baseName")
        combined.outputStream().buffered().use { out -> parts.forEach { it.inputStream().buffered().use { ins -> ins.copyTo(out) } } }
        return combined
    }

    private fun copyZipToZip(src: File, zos: ZipOutputStream) {
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val name = safeEntryName(entry.name) ?: continue
                zos.putNextEntry(ZipEntry(if (entry.isDirectory) "$name/" else name))
                if (!entry.isDirectory) zf.getInputStream(entry).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun sevenZipToZip(src: File, zos: ZipOutputStream, password: String?) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var e = seven.nextEntry
            while (e != null) {
                val name = safeEntryName(e.name) ?: run { e = seven.nextEntry; continue }
                zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                if (!e.isDirectory) {
                    val buf = ByteArray(8192)
                    var r = seven.read(buf)
                    while (r > 0) { zos.write(buf, 0, r); r = seven.read(buf) }
                }
                zos.closeEntry()
                e = seven.nextEntry
            }
        }
    }

    private fun rarToZip(src: File, zos: ZipOutputStream, password: String?) {
        Archive(src, password ?: "").use { archive ->
            for (h in archive.fileHeaders) {
                val name = safeEntryName(h.fileName) ?: continue
                zos.putNextEntry(ZipEntry(if (h.isDirectory) "$name/" else name))
                if (!h.isDirectory) archive.extractFile(h, zos)
                zos.closeEntry()
            }
        }
    }

    private fun archiveStreamToZip(input: InputStream, forced: String?, zos: ZipOutputStream) {
        input.use { raw ->
            val ais: ArchiveInputStream<*> = if (forced == "tar") {
                TarArchiveInputStream(BufferedInputStream(raw))
            } else {
                ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            }
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val name = safeEntryName(e.name)
                    if (name != null && stream.canReadEntryData(e)) {
                        zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                        if (!e.isDirectory) stream.copyTo(zos)
                        zos.closeEntry()
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun compressedArchiveToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                archiveStreamToZip(cin, "tar", zos)
            }
        }
    }

    private fun singleCompressedToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        val outName = src.name.substringBeforeLast('.')
        zos.putNextEntry(ZipEntry(outName))
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { it.copyTo(zos) }
        }
        zos.closeEntry()
    }

    private fun extractZip(src: File, dest: File) {
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val out = safeOutput(dest, entry.name) ?: continue
                if (entry.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); zf.getInputStream(entry).use { it.copyTo(out.outputStream()) } }
            }
        }
    }

    private fun extract7z(src: File, dest: File, password: String?) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var e = seven.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { seven.getInputStream(e).copyTo(it) } }
                }
                e = seven.nextEntry
            }
        }
    }

    private fun extractRar(src: File, dest: File, password: String?) {
        Archive(src, password ?: "").use { archive ->
            for (h in archive.fileHeaders) {
                val out = safeOutput(dest, h.fileName) ?: continue
                if (h.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); out.outputStream().use { archive.extractFile(h, it) } }
            }
        }
    }

    private fun extractArchiveStream(input: InputStream, dest: File) {
        input.use { raw ->
            val ais = ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val out = safeOutput(dest, e.name)
                    if (out != null) {
                        if (e.isDirectory) out.mkdirs()
                        else if (stream.canReadEntryData(e)) { out.parentFile?.mkdirs(); out.outputStream().use { stream.copyTo(it) } }
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun extractCompressedArchive(src: File, algorithm: String, dest: File) {
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                extractTarStream(cin, dest)
            }
        }
    }

    private fun extractTarStream(input: InputStream, dest: File) {
        TarArchiveInputStream(BufferedInputStream(input)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { tar.copyTo(it) } }
                }
                e = tar.nextEntry
            }
        }
    }

    private fun extractSingleCompressed(src: File, algorithm: String, dest: File) {
        val out = safeOutput(dest, src.name.substringBeforeLast('.')) ?: throw SecurityException("ชื่อไฟล์ไม่ปลอดภัย")
        out.parentFile?.mkdirs()
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { it.copyTo(out.outputStream()) }
        }
    }

    private fun safeEntryName(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val n = raw.replace('\\','/').trimStart('/')
        if (n.split('/').any { it == ".." }) return null
        return n
    }

    private fun safeOutput(dest: File, raw: String?): File? {
        val name = safeEntryName(raw) ?: return null
        val out = File(dest, name)
        val base = dest.canonicalPath + File.separator
        if (!out.canonicalPath.startsWith(base)) return null
        return out
    }

    fun compress(source: File, destination: File, format: String) {
        when (format.lowercase()) {
            "zip" -> createZip(source, destination)
            "7z" -> create7z(source, destination)
            "tar" -> createTar(source, destination)
            "gz","bz2","xz","lz4","zst" -> createSingleCompressed(source, destination, format.lowercase())
            else -> throw UnsupportedOperationException("ไม่รองรับรูปแบบ $format")
        }
    }

    private fun createZip(source: File, out: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos -> addTreeToZip(source, source.name, zos) }
    }

    private fun create7z(source: File, out: File) {
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(out).use { seven ->
            addTreeTo7z(source, source.name, seven)
        }
    }

    private fun createTar(source: File, out: File) {
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(BufferedOutputStream(FileOutputStream(out))).use { tar ->
            addTreeToTar(source, source.name, tar)
        }
    }

    private fun createSingleCompressed(source: File, out: File, format: String) {
        FileOutputStream(out).buffered().use { fos ->
            val cout = CompressorStreamFactory().createCompressorOutputStream(format, fos)
            cout.use { source.inputStream().use { it.copyTo(cout) } }
        }
    }

    private fun addTreeToZip(f: File, name: String, zos: ZipOutputStream) {
        if (f.isDirectory) {
            zos.putNextEntry(ZipEntry("$name/")); zos.closeEntry()
            f.listFiles()?.forEach { addTreeToZip(it, "$name/${it.name}", zos) }
        } else {
            zos.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(zos) }; zos.closeEntry()
        }
    }

    private fun addTreeTo7z(f: File, name: String, seven: org.apache.commons.compress.archivers.sevenz.SevenZOutputFile) {
        val e = org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry()
        e.name = name
        e.isDirectory = f.isDirectory
        seven.putArchiveEntry(e)
        if (!f.isDirectory) f.inputStream().use { it.copyTo(seven) }
        seven.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTreeTo7z(it, "$name/${it.name}", seven) }
    }

    private fun addTreeToTar(f: File, name: String, tar: org.apache.commons.compress.archivers.tar.TarArchiveOutputStream) {
        val e = org.apache.commons.compress.archivers.tar.TarArchiveEntry(name)
        e.size = if (f.isFile) f.length() else 0
        tar.putArchiveEntry(e)
        if (f.isFile) f.inputStream().use { it.copyTo(tar) }
        tar.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTreeToTar(it, "$name/${it.name}", tar) }
    }
}
