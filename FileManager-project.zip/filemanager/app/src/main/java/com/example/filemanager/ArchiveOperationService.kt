package com.example.filemanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Runs archive extract ("unzip") jobs outside the Activity lifecycle, the same way
 * FileOperationService.kt already does for copy/move - see that file's class doc for the
 * underlying reasoning. This lets the user tap "ซ่อน" on the progress dialog and go do
 * something else in the app while the extraction keeps working in the background, with a
 * persistent notification tracking the percent.
 *
 * The old compress ("zip") side of this service (ACTION_ZIP/startZip(), calling
 * ArchiveManager.compress()) was removed once the newer "สร้างไฟล์ Archive…" flow
 * (CompressOperationService.kt / ArchiveEngine.kt) fully replaced it as the only way to create
 * archives in the app. This service now only handles extraction.
 *
 * notify() itself is throttled to at most once every [NOTIFY_THROTTLE_MS] (a plain elapsed-time
 * check, not a coroutine debounce) since ArchiveManager's onProgress callback can fire many
 * times a second for large archives - without this, updating the status bar that often can
 * make the UI feel like it's stuttering. The BROADCAST_PROGRESS broadcast used to drive the
 * in-app dialog/ViewModel is NOT throttled the same way (it's cheap, in-process, and the
 * dialog only redraws on collect anyway), so the dialog's progress bar still feels smooth even
 * though the system notification updates less often.
 *
 * MediaStore: after a successful extract, every extracted file gets scanned in one batch call
 * (notifyMediaScannerBatch, walking [destination] recursively) so extracted media shows up in
 * other apps' pickers right away instead of waiting for the next full media scan.
 */
class ArchiveOperationService : Service() {

    companion object {
        const val CHANNEL_ID = "archive_operations"
        private const val NOTIFICATION_ID = 4301
        private const val NOTIFY_THROTTLE_MS = 500L

        const val ACTION_UNZIP = "com.example.filemanager.action.ARCHIVE_UNZIP"
        private const val EXTRA_SOURCE = "extra_source"
        private const val EXTRA_DEST = "extra_dest"
        private const val EXTRA_PASSWORD = "extra_password"

        const val BROADCAST_PROGRESS = "com.example.filemanager.ARCHIVE_OP_PROGRESS"
        const val BROADCAST_DONE = "com.example.filemanager.ARCHIVE_OP_DONE"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_IS_UNZIP = "extra_is_unzip"
        const val EXTRA_ARCHIVE_NAME = "extra_archive_name"
        const val EXTRA_SUCCESS = "extra_success"
        const val EXTRA_ERROR = "extra_error"
        const val EXTRA_DEST_PATH = "extra_dest_path"

        /** Starts a background extract ("unzip") job. [source] is the archive file itself. */
        fun startUnzip(context: Context, source: File, destination: File, password: String?) {
            val intent = Intent(context, ArchiveOperationService::class.java).apply {
                action = ACTION_UNZIP
                putExtra(EXTRA_SOURCE, source.absolutePath)
                putExtra(EXTRA_DEST, destination.absolutePath)
                putExtra(EXTRA_PASSWORD, password)
            }
            startCompat(context, intent)
        }

        private fun startCompat(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "การแตกไฟล์", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sourcePath = intent?.getStringExtra(EXTRA_SOURCE)
        val destPath = intent?.getStringExtra(EXTRA_DEST)
        val password = intent?.getStringExtra(EXTRA_PASSWORD)

        if (sourcePath == null || destPath == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val source = File(sourcePath)
        val destination = File(destPath)
        val archiveName = source.name

        startForeground(NOTIFICATION_ID, buildNotification(archiveName, 0).build())

        job = scope.launch {
            var lastNotifyAt = 0L
            var success = true
            var errorMessage: String? = null
            try {
                val onProgress: (Int) -> Unit = { percent ->
                    broadcastProgress(percent, archiveName)
                    val now = System.currentTimeMillis()
                    if (now - lastNotifyAt >= NOTIFY_THROTTLE_MS) {
                        lastNotifyAt = now
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(archiveName, percent).build())
                    }
                }
                ArchiveManager.extract(source, destination, password, onProgress)
                notifyMediaScannerBatch(destination.walkTopDown().filter { it.isFile }.toList())
            } catch (e: Exception) {
                success = false
                errorMessage = e.message
                if (destination != source.parentFile) destination.deleteRecursively()
            }
            notificationManager.notify(NOTIFICATION_ID, buildNotification(archiveName, 100, success).build())
            broadcastDone(archiveName, destPath, success, errorMessage)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(archiveName: String, percent: Int, done: Boolean = false): NotificationCompat.Builder {
        val title = if (done) "แตกไฟล์เสร็จแล้ว" else "กำลังแตกไฟล์: $archiveName"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(if (done) archiveName else "$percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setAutoCancel(done)
            .setProgress(100, percent, false)
    }

    private fun broadcastProgress(percent: Int, archiveName: String) {
        sendBroadcast(Intent(BROADCAST_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_PERCENT, percent)
            putExtra(EXTRA_IS_UNZIP, true)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
        })
    }

    private fun broadcastDone(archiveName: String, destPath: String, success: Boolean, error: String?) {
        sendBroadcast(Intent(BROADCAST_DONE).apply {
            setPackage(packageName)
            putExtra(EXTRA_IS_UNZIP, true)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
            putExtra(EXTRA_DEST_PATH, destPath)
            putExtra(EXTRA_SUCCESS, success)
            putExtra(EXTRA_ERROR, error)
        })
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
