package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Round 2 (MainViewModel split, step 3 of 4 - see round2-next-steps-plan.txt): archive/compress
 * background-operation progress (archiveOpState/compressOpState) and the extract
 * conflict-resolution batch (extractConflictBatch/ExtractConflictBatch) now live here instead of
 * MainViewModel - same "ห้ามแก้ชื่อคลาส/ฟังก์ชันระหว่างย้าย" pure-move caution as steps 1-2.
 *
 * Events: this class gets its own sealed [UiEvent] + [events] flow (option ก from
 * round2-next-steps-plan.txt's note on this step) rather than reaching into MainViewModel's
 * private _events - same reasoning as DirectoryViewModel.toastEvents and
 * FileOperationViewModel.events. UiEvent.Toast moves here too (not just ArchiveOpDone/
 * CompressOpDone): the only place MainViewModel.UiEvent.Toast was ever emitted from was
 * restoreExtractBatch() below, when a real process death wipes an in-progress extract's
 * password - that logic is entirely part of this step's move, so its Toast event comes with it.
 * MainActivity collects this alongside directoryViewModel.toastEvents and
 * fileOperationViewModel.events - see DirectoryStateObserver.kt's observeArchiveOperationEvents().
 */
class ArchiveOperationViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    sealed class UiEvent {
        data class Toast(val message: String) : UiEvent()

        /** One-shot "zip/unzip finished" signal from ArchiveOperationService. */
        data class ArchiveOpDone(
            val isUnzip: Boolean,
            val archiveName: String,
            val success: Boolean,
            val error: String?,
            val destinationPath: String? = null
        ) : UiEvent()

        /** One-shot "archive creation finished" signal from CompressOperationService - see
         * MainViewModel's former class doc (now here) for why it's kept separate from
         * [ArchiveOpDone]. */
        data class CompressOpDone(
            val archiveName: String,
            val success: Boolean,
            val cancelled: Boolean,
            val error: String?,
            val createdPaths: List<String> = emptyList(),
            val deletedPaths: List<String> = emptyList()
        ) : UiEvent()
    }

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<UiEvent> = _events

    // ---------- Background Archive Operations (zip/unzip) progress state ----------

    /**
     * Mirrors [FileOperationViewModel.FileOpUiState] but for ArchiveOperationService. [hidden]
     * tracks whether the user tapped "ซ่อน" on the progress dialog during the current run -
     * MainActivity uses it to avoid popping the dialog back up on every subsequent progress
     * tick once the user has dismissed it; it resets automatically the next time a run starts.
     */
    data class ArchiveOpUiState(
        val isRunning: Boolean = false,
        val isUnzip: Boolean = false,
        val archiveName: String = "",
        val percent: Int = 0,
        val hidden: Boolean = false
    )

    private val _archiveOpState = MutableStateFlow(ArchiveOpUiState())
    val archiveOpState: StateFlow<ArchiveOpUiState> = _archiveOpState

    fun setArchiveOpStarted(isUnzip: Boolean, archiveName: String) {
        _archiveOpState.value = ArchiveOpUiState(isRunning = true, isUnzip = isUnzip, archiveName = archiveName, percent = 0, hidden = false)
    }

    fun setArchiveOpProgress(percent: Int, isUnzip: Boolean, archiveName: String) {
        val current = _archiveOpState.value
        _archiveOpState.value = current.copy(isRunning = true, isUnzip = isUnzip, archiveName = archiveName, percent = percent)
    }

    fun setArchiveDialogHidden(hidden: Boolean) {
        _archiveOpState.update { it.copy(hidden = hidden) }
    }

    fun setArchiveOpDone(
        isUnzip: Boolean,
        archiveName: String,
        success: Boolean,
        error: String?,
        destinationPath: String? = null
    ) {
        _archiveOpState.value = ArchiveOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(UiEvent.ArchiveOpDone(isUnzip, archiveName, success, error, destinationPath))
        }
    }

    // ---------- Part 3/3 "สร้างไฟล์ ของฉัน" - CompressOperationService progress state ----------

    /**
     * Mirrors [ArchiveOpUiState] above but for CompressOperationService (the new ZArchiver-style
     * "สร้างไฟล์ Archive" dialog from CompressDialog.kt, parts 1-2/3). [currentItemIndex]/
     * [totalItems] are only meaningful when [CompressOptions.createSeparateArchivePerItem] was
     * checked and there's more than one source item - CompressProgressDialogHelper.kt shows a
     * "(i/n)" suffix in that case and omits it otherwise (totalItems <= 1).
     */
    data class CompressOpUiState(
        val isRunning: Boolean = false,
        val archiveName: String = "",
        val percent: Int = 0,
        val currentItemIndex: Int = 0,
        val totalItems: Int = 0,
        val hidden: Boolean = false
    )

    private val _compressOpState = MutableStateFlow(CompressOpUiState())
    val compressOpState: StateFlow<CompressOpUiState> = _compressOpState

    /** เรียกครั้งเดียวตอนเริ่มงาน - รีเซ็ต [CompressOpUiState.hidden] เผื่อรอบก่อนหน้าผู้ใช้เคยกด "ซ่อน" ไว้ */
    fun setCompressOpStarted(archiveName: String) {
        _compressOpState.value = CompressOpUiState(isRunning = true, archiveName = archiveName, percent = 0, hidden = false)
    }

    fun setCompressOpProgress(percent: Int, archiveName: String, currentItemIndex: Int, totalItems: Int) {
        val current = _compressOpState.value
        _compressOpState.value = current.copy(
            isRunning = true,
            archiveName = archiveName,
            percent = percent,
            currentItemIndex = currentItemIndex,
            totalItems = totalItems
        )
    }

    fun setCompressDialogHidden(hidden: Boolean) {
        _compressOpState.update { it.copy(hidden = hidden) }
    }

    fun setCompressOpDone(
        archiveName: String,
        success: Boolean,
        cancelled: Boolean,
        error: String?,
        createdPaths: List<String> = emptyList(),
        deletedPaths: List<String> = emptyList()
    ) {
        _compressOpState.value = CompressOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(UiEvent.CompressOpDone(archiveName, success, cancelled, error, createdPaths, deletedPaths))
        }
    }

    // ---------- Conflict-resolution batch state (Rotation Safety #2) - Extract half ----------
    //
    // Copy/Move's half lives on FileOperationViewModel (see that class for the full history of
    // why this exists at all - process-death survival for an in-progress batch that used to
    // live only on the call stack). This is Extract's counterpart, unchanged in logic from when
    // it lived on MainViewModel.
    //
    // The one piece deliberately NOT persisted to SavedStateHandle is the archive password for
    // an in-progress extract batch - SavedStateHandle's Bundle can be written to disk for
    // process-death recovery, and a plaintext password sitting in that file is a worse tradeoff
    // than the (rare) inconvenience of asking the user to restart extraction after a real
    // process kill. [ExtractConflictBatch.hadPassword] records whether one was needed so
    // restoreExtractBatch() can tell "safe to silently resume" (no password was ever needed)
    // apart from "must not resume - notify the user instead" (a password was needed and is gone).

    data class ExtractConflictBatch(
        val filePath: String,
        val destinationPath: String,
        val remaining: List<String>,
        val overwriteEntries: Set<String>,
        val skipEntries: Set<String>,
        val renameEntries: Set<String>,
        val forcedAction: ConflictAction?,
        val hadPassword: Boolean
    )

    /** Not persisted to SavedStateHandle - see the class-doc note above. Config-change (rotation)
     * safe via the ViewModel instance itself; deliberately not process-death safe. */
    private var pendingExtractPassword: String? = null

    private fun persistExtractBatch(batch: ExtractConflictBatch?) {
        savedStateHandle[KEY_EX_ACTIVE] = batch != null
        if (batch == null) return
        savedStateHandle[KEY_EX_FILE] = batch.filePath
        savedStateHandle[KEY_EX_DEST] = batch.destinationPath
        savedStateHandle[KEY_EX_REMAINING] = ArrayList(batch.remaining)
        savedStateHandle[KEY_EX_OVERWRITE] = ArrayList(batch.overwriteEntries)
        savedStateHandle[KEY_EX_SKIP] = ArrayList(batch.skipEntries)
        savedStateHandle[KEY_EX_RENAME] = ArrayList(batch.renameEntries)
        savedStateHandle[KEY_EX_FORCED] = batch.forcedAction?.name
        savedStateHandle[KEY_EX_HAD_PASSWORD] = batch.hadPassword
    }

    /** Returns null (and wipes the persisted batch) when a password was needed but didn't
     * survive - see the class-doc note above. [interruptedEvent] tells the caller whether
     * that happened, so it can notify the user instead of silently doing nothing. */
    private fun restoreExtractBatch(): ExtractConflictBatch? {
        if (savedStateHandle.get<Boolean>(KEY_EX_ACTIVE) != true) return null
        val file = savedStateHandle.get<String>(KEY_EX_FILE)
        val dest = savedStateHandle.get<String>(KEY_EX_DEST)
        if (file == null || dest == null) return null
        val remaining = savedStateHandle.get<ArrayList<String>>(KEY_EX_REMAINING) ?: arrayListOf()
        if (remaining.isEmpty()) return null
        val hadPassword = savedStateHandle.get<Boolean>(KEY_EX_HAD_PASSWORD) ?: false
        if (hadPassword && pendingExtractPassword == null) {
            // Real process death: the password (never written to SavedStateHandle) is gone.
            // Can't safely resume - wipe the stale persisted batch and tell MainActivity to
            // notify the user, instead of leaving a phantom batch nothing will ever finish.
            persistExtractBatch(null)
            viewModelScope.launch { _events.emit(UiEvent.Toast("การแตกไฟล์ที่ค้างไว้ถูกยกเลิก (แอปถูกปิดกลางคัน) กรุณาลองใหม่")) }
            return null
        }
        return ExtractConflictBatch(
            filePath = file,
            destinationPath = dest,
            remaining = remaining,
            overwriteEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_OVERWRITE)?.toSet() ?: emptySet(),
            skipEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_SKIP)?.toSet() ?: emptySet(),
            renameEntries = savedStateHandle.get<ArrayList<String>>(KEY_EX_RENAME)?.toSet() ?: emptySet(),
            forcedAction = savedStateHandle.get<String>(KEY_EX_FORCED)
                ?.let { name -> runCatching { ConflictAction.valueOf(name) }.getOrNull() },
            hadPassword = hadPassword
        )
    }

    private val _extractConflictBatch = MutableStateFlow(restoreExtractBatch())
    val extractConflictBatch: StateFlow<ExtractConflictBatch?> = _extractConflictBatch

    /** Starts a brand-new batch (called only from startExtractWithConflictCheck). [password] is
     * kept in-memory only - see the class-doc note above. */
    fun startExtractConflictBatch(batch: ExtractConflictBatch, password: String?) {
        pendingExtractPassword = password
        updateExtractConflictBatch(batch)
    }

    fun updateExtractConflictBatch(batch: ExtractConflictBatch?) {
        _extractConflictBatch.value = batch
        persistExtractBatch(batch)
        if (batch == null) pendingExtractPassword = null
    }

    fun clearExtractConflictBatch() = updateExtractConflictBatch(null)

    /** The in-progress batch's password, for whichever call site finally calls
     * ArchiveOperationService.startUnzip() - a plain getter, not "consuming" anything, since
     * the same value may be needed again if the user answers several conflicts in a row. */
    fun currentExtractPassword(): String? = pendingExtractPassword

    companion object {
        private const val KEY_EX_ACTIVE = "ex_conflict_active"
        private const val KEY_EX_FILE = "ex_conflict_file"
        private const val KEY_EX_DEST = "ex_conflict_dest"
        private const val KEY_EX_REMAINING = "ex_conflict_remaining"
        private const val KEY_EX_OVERWRITE = "ex_conflict_overwrite"
        private const val KEY_EX_SKIP = "ex_conflict_skip"
        private const val KEY_EX_RENAME = "ex_conflict_rename"
        private const val KEY_EX_FORCED = "ex_conflict_forced"
        private const val KEY_EX_HAD_PASSWORD = "ex_conflict_had_password"
    }
}
