package com.example.filemanager

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * POST_NOTIFICATIONS runtime check/request (Android 13+) plus the "ซ่อน" (Hide) progress
 * dialog shown while ArchiveOperationService runs a zip/unzip in the background. Split out
 * of MainActivity.kt for the same reason PermissionFlowHelper.kt/FileClickHelper.kt already
 * are - MainActivity.kt only wires up the onCreate()/onRequestPermissionsResult() glue that
 * has to physically live there.
 */

internal const val ARCHIVE_NOTIFICATION_PERMISSION_CODE = 1002

/** Rotation Safety #3: stable KornDialog id - see KornDialog.dismissStale()'s doc for why this
 * dialog specifically needs one (only ever one archive progress dialog at a time). */
private const val ARCHIVE_PROGRESS_DIALOG_ID = "archive_progress"

/**
 * Runs [onGranted] immediately when POST_NOTIFICATIONS is already granted (or on API < 33,
 * where the permission doesn't exist). Otherwise asks for it first and runs [onGranted] once
 * MainActivity.onRequestPermissionsResult() reports back - regardless of whether the user
 * actually granted it, since the zip/unzip itself works either way; without the permission
 * Android just won't display the ongoing notification for it.
 */
internal fun MainActivity.startArchiveOperationWithNotificationCheck(onGranted: () -> Unit) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    ) {
        onGranted()
        return
    }
    pendingArchiveOperation = onGranted
    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), ARCHIVE_NOTIFICATION_PERMISSION_CODE)
}

/** Round 2: exposes this file's stable dialog id to MainActivity.onCreate() so it can clear a
 * FragmentManager-restored stale dialog fragment before that fragment reaches onStart() and
 * shows itself - see the call site's comment in MainActivity.kt for why this needs to run
 * earlier than showArchiveProgressDialog()'s own dismissStale() call below. */
internal fun MainActivity.dismissStaleArchiveProgressDialogIfAny() {
    KornDialog.dismissStale(this, ARCHIVE_PROGRESS_DIALOG_ID)
}

internal fun MainActivity.showArchiveProgressDialog() {
    if (archiveProgressDialogHandle?.isShowing == true) return
    // Rotation Safety #3: this Activity instance's handle field is null - either this is the
    // very first time, or a new Activity instance was just (re)created and FragmentManager may
    // already have silently auto-restored a fragment for this dialog under its stable tag.
    // Clear any such stale instance before building a fresh one bound to this Activity, so
    // observeArchiveOpState() re-collecting on every recreation can never stack two.
    KornDialog.dismissStale(this, ARCHIVE_PROGRESS_DIALOG_ID)
    val pad = dp(16)
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad / 2, pad, 0)
    }
    val label = TextView(this).apply { textSize = 14f }
    val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        isIndeterminate = false
    }
    val percentText = TextView(this).apply {
        gravity = Gravity.END
        textSize = 12f
    }
    container.addView(label, LinearLayout.LayoutParams(-1, -2))
    container.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    container.addView(percentText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

    archiveProgressLabel = label
    archiveProgressBar = bar
    archiveProgressPercentText = percentText

    archiveProgressDialogHandle = KornDialog.Builder(this, ARCHIVE_PROGRESS_DIALOG_ID)
        .setTitle("กำลังดำเนินการ")
        .setView(container)
        .setCancelable(false)
        .setNeutralButton("ซ่อน") { _, _ -> archiveOperationViewModel.setArchiveDialogHidden(true) }
        .show()
}

internal fun MainActivity.updateArchiveProgressDialog(state: ArchiveOperationViewModel.ArchiveOpUiState) {
    archiveProgressLabel?.text = if (state.isUnzip) "กำลังแตกไฟล์: ${state.archiveName}" else "กำลังบีบอัด: ${state.archiveName}"
    archiveProgressBar?.progress = state.percent
    archiveProgressPercentText?.text = "${state.percent}%"
}

internal fun MainActivity.dismissArchiveProgressDialog() {
    archiveProgressDialogHandle?.dismiss()
    archiveProgressDialogHandle = null
    archiveProgressLabel = null
    archiveProgressBar = null
    archiveProgressPercentText = null
}

/** Collects archiveOperationViewModel.archiveOpState for the lifetime of the Activity and drives the dialog above. */
internal fun MainActivity.observeArchiveOpState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            archiveOperationViewModel.archiveOpState.collect { state ->
                when {
                    !state.isRunning -> dismissArchiveProgressDialog()
                    state.hidden -> dismissArchiveProgressDialog()
                    else -> {
                        showArchiveProgressDialog()
                        updateArchiveProgressDialog(state)
                    }
                }
            }
        }
    }
}
