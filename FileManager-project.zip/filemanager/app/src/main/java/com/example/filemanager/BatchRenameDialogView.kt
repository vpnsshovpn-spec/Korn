package com.example.filemanager

import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

/**
 * Batch Rename V2 — UI Component
 *
 * View อิสระสำหรับฟอร์ม "เปลี่ยนชื่อเป็นกลุ่ม": Radio Group เลือกโหมด A/B,
 * ช่องกรอกที่เปลี่ยนไปตามโหมด, และช่องเปลี่ยนนามสกุล
 *
 * สร้างแบบ programmatic (ไม่ใช้ XML layout) ให้สอดคล้องกับรูปแบบไดอะล็อกเดิมของโปรเจกต์
 * (เช่นเดียวกับที่ BatchRenameHelper.kt เดิมเคยทำ) ไฟล์นี้ไม่พึ่งพา MainActivity
 * หรือโค้ดฟีเจอร์เดิมใดๆ — รับผิดชอบแค่การแสดงผลและอ่านค่าฟอร์มเท่านั้น
 */
class BatchRenameDialogView(context: Context) : LinearLayout(context) {

    companion object {
        private const val MODE_NAME_WITH_NUMBER = 1001
        private const val MODE_PREFIX_WITH_ORIGINAL = 1002
    }

    private val radioGroup = RadioGroup(context)
    private val modeAGroup: LinearLayout
    private val modeBGroup: LinearLayout

    private val baseNameInput = EditText(context)
    private val startNumberInput = EditText(context)
    private val prefixInput = EditText(context)
    private val extensionInput = EditText(context)

    init {
        orientation = VERTICAL
        val padH = (24 * resources.displayMetrics.density).toInt()
        val padTop = (8 * resources.displayMetrics.density).toInt()
        setPadding(padH, padTop, padH, 0)

        val radioModeA = RadioButton(context).apply {
            id = MODE_NAME_WITH_NUMBER
            text = "ชื่อใหม่ + หมายเลข"
        }
        val radioModeB = RadioButton(context).apply {
            id = MODE_PREFIX_WITH_ORIGINAL
            text = "คำนำหน้า + ชื่อเดิม"
        }
        radioGroup.orientation = VERTICAL
        radioGroup.addView(radioModeA)
        radioGroup.addView(radioModeB)
        radioGroup.check(MODE_NAME_WITH_NUMBER)
        addView(radioGroup)

        // โหมด A: ชื่อฐาน + เลขเริ่มต้น
        baseNameInput.hint = "ชื่อฐาน เช่น รูป"
        startNumberInput.hint = "เลขเริ่มต้น เช่น 1, 01, 001"
        startNumberInput.setText("1")
        startNumberInput.inputType = InputType.TYPE_CLASS_NUMBER
        modeAGroup = LinearLayout(context).apply {
            orientation = VERTICAL
            addView(baseNameInput)
            addView(startNumberInput)
        }
        addView(modeAGroup)

        // โหมด B: คำนำหน้า
        prefixInput.hint = "คำนำหน้า เช่น IMG_"
        modeBGroup = LinearLayout(context).apply {
            orientation = VERTICAL
            visibility = GONE
            addView(prefixInput)
        }
        addView(modeBGroup)

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val isModeA = checkedId == MODE_NAME_WITH_NUMBER
            modeAGroup.visibility = if (isModeA) VISIBLE else GONE
            modeBGroup.visibility = if (isModeA) GONE else VISIBLE
        }

        addView(TextView(context).apply {
            text = "เปลี่ยนนามสกุล (เว้นว่าง = คงเดิม)"
            setPadding(0, padTop, 0, 0)
        })
        extensionInput.hint = "เช่น jpg, txt (ไม่ต้องใส่จุด)"
        addView(extensionInput)
    }

    /**
     * อ่านค่าปัจจุบันของฟอร์ม คืนค่า null หากข้อมูลที่จำเป็นของโหมดที่เลือกยังไม่ครบ
     * (ให้ผู้เรียกแสดง error message เอง เพื่อให้ View นี้ไม่ผูกกับ Context การแสดงผล error)
     */
    fun readFormState(): BatchRenameFormState? {
        val mode = when (radioGroup.checkedRadioButtonId) {
            MODE_NAME_WITH_NUMBER -> {
                val baseName = baseNameInput.text.toString().trim()
                if (baseName.isEmpty()) return null
                val startText = startNumberInput.text.toString().trim().ifEmpty { "1" }
                BatchRenameMode.NameWithNumber(baseName, startText)
            }
            MODE_PREFIX_WITH_ORIGINAL -> {
                val prefix = prefixInput.text.toString().trim()
                if (prefix.isEmpty()) return null
                BatchRenameMode.PrefixWithOriginal(prefix)
            }
            else -> return null
        }
        return BatchRenameFormState(mode, extensionInput.text.toString().trim())
    }
}
