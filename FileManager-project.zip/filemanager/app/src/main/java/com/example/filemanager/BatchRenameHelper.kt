package com.example.filemanager

/**
 * Batch rename entry point — เดิมไฟล์นี้เคยมีทั้ง UI (Dialog) และ Logic การเปลี่ยนชื่อ
 * ทั้งหมดอยู่รวมกัน ตอนนี้ถูก refactor ออกเป็น:
 *   - BatchRenameMode.kt          (Data / State Model)
 *   - BatchRenameDialogView.kt    (UI Component)
 *   - BatchRenameEngine.kt        (Rename Engine / UseCase)
 *   - BatchRenameV2.kt            (จุดประกอบร่าง UI + Engine)
 *
 * ฟังก์ชัน batchRenameDialog() ยังคงชื่อและ signature เดิมทุกประการ (internal fun
 * MainActivity.batchRenameDialog()) เพื่อไม่ให้ต้องแก้ไข call site อื่นใดในโปรเจกต์
 * — จุดที่เรียกใช้จาก SelectionModeController.kt (บรรทัด batchRenameDialog())
 * ไม่ถูกแตะต้องเลย นี่คือจุดเดียวในโค้ดเดิมที่ถูกแก้ไขเพื่อเชื่อมต่อฟีเจอร์ใหม่
 */
internal fun MainActivity.batchRenameDialog() {
    showBatchRenameDialogV2()
}
