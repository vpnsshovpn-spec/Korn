package com.example.filemanager

/**
 * Batch Rename V2 — Data / State Model
 * โหมดการเปลี่ยนชื่อที่ผู้ใช้เลือกได้ในไดอะล็อก "เปลี่ยนชื่อเป็นกลุ่ม"
 *
 * ไฟล์นี้เป็นไฟล์ใหม่ทั้งหมด ไม่แก้ไข/ไม่พึ่งพาโค้ดเดิมของฟีเจอร์ batch rename เก่า
 */
sealed class BatchRenameMode {

    /**
     * โหมด A: ชื่อใหม่ + หมายเลขรัน
     * เช่น baseName = "รูป", startNumberText = "001" -> รูป001, รูป002, ...
     * startNumberText เก็บเป็น String (ไม่ใช่ Int) เพราะความยาวของมันเป็นตัวกำหนด
     * จำนวนหลักของ zero-padding (ดู BatchRenameEngine)
     */
    data class NameWithNumber(
        val baseName: String,
        val startNumberText: String
    ) : BatchRenameMode()

    /**
     * โหมด B: คำนำหน้า + ชื่อเดิม
     * เช่น prefix = "IMG_" -> IMG_<ชื่อไฟล์เดิม>
     */
    data class PrefixWithOriginal(
        val prefix: String
    ) : BatchRenameMode()
}

/**
 * สถานะทั้งหมดของฟอร์มไดอะล็อก ณ ตอนที่ผู้ใช้กด "ตกลง"
 *
 * @param mode โหมดที่เลือก พร้อมค่าที่กรอก
 * @param newExtension นามสกุลใหม่ (ไม่มีจุดนำหน้า) หรือว่างเปล่าถ้าต้องการคงนามสกุลเดิม
 */
data class BatchRenameFormState(
    val mode: BatchRenameMode,
    val newExtension: String
)
