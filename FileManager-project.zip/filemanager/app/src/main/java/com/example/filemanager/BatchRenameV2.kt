package com.example.filemanager

import com.example.filemanager.ui.dialogs.BatchRenameDialogView
import com.example.filemanager.ui.dialogs.KornDialog
import com.example.filemanager.ui.selection.exitSelectionMode
import com.example.filemanager.ui.selection.toastNoSelection
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.io.File
import com.example.filemanager.data.repository.BatchRenameEngine

/**
 * Batch Rename V2 — จุดประกอบร่าง (composition root) ของฟีเจอร์ใหม่
 *
 * ไฟล์นี้เป็นไฟล์ใหม่ ผูก UI Component (BatchRenameDialogView) เข้ากับ
 * Rename Engine (BatchRenameEngine) เท่านั้น ไม่มี business logic ของการคำนวณ
 * ชื่อไฟล์หรือการเปลี่ยนชื่ออยู่ในไฟล์นี้เลย
 *
 * showBatchRenameDialogV2() คือฟังก์ชันเดียวที่ถูกเรียกจากภายนอกไฟล์นี้
 * (เรียกจาก batchRenameDialog() ใน BatchRenameHelper.kt ซึ่งเป็นจุดเชื่อมต่อจุดเดียว
 * ที่ถูกแก้ไขในโค้ดเดิมของโปรเจกต์)
 */
internal fun MainActivity.showBatchRenameDialogV2() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }

    val formView = BatchRenameDialogView(this)

    KornDialog.Builder(this)
        .setTitle("เปลี่ยนชื่อเป็นกลุ่ม (${files.size} รายการ)")
        .setView(formView)
        .setPositiveButton("ตกลง") { _, _ ->
            val form = formView.readFormState()
            if (form == null) {
                Toast.makeText(this, "กรุณากรอกข้อมูลให้ครบถ้วน", Toast.LENGTH_SHORT).show()
            } else {
                runBatchRenameV2(files, form)
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

private fun MainActivity.runBatchRenameV2(files: List<File>, form: BatchRenameFormState) {
    val planned = BatchRenameEngine.planRenames(files, form)
    lifecycleScope.launch {
        val summary = BatchRenameEngine.execute(planned)
        exitSelectionMode()
        Toast.makeText(
            this@runBatchRenameV2,
            "เปลี่ยนชื่อสำเร็จ ${summary.renamed} รายการ" +
                if (summary.skipped > 0) " (ข้าม ${summary.skipped} รายการ)" else "",
            Toast.LENGTH_LONG
        ).show()
        // Local Search Index: รีเฟรชเฉพาะตอนเปลี่ยนชื่อสำเร็จอย่างน้อย 1 รายการจริง (พฤติกรรมเดิมคงไว้)
        if (summary.renamedPairs.isNotEmpty()) {
            lifecycleScope.launch {
                summary.renamedPairs.forEach { (oldFile, newFile) ->
                    searchIndexManager.renameOrMoveInIndex(oldFile, newFile)
                }
            }
        }
    }
}
