package com.example.filemanager

import android.content.Context

/**
 * Stores bookmarked folder paths using SharedPreferences.
 * Each bookmark is saved as "name|absolutePath" inside a StringSet.
 */
class BookmarksManager(context: Context) {

    private val prefs = context.getSharedPreferences("bookmarks_prefs", Context.MODE_PRIVATE)
    private val KEY = "bookmark_entries"

    data class Bookmark(val name: String, val path: String)

    fun getAll(): List<Bookmark> {
        val raw = prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()
        return raw.mapNotNull {
            val parts = it.split("|", limit = 2)
            if (parts.size == 2) Bookmark(parts[0], parts[1]) else null
        }.sortedBy { it.name.lowercase() }
    }

    fun add(name: String, path: String) {
        val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
        // remove existing bookmark with same path first
        current.removeAll { it.split("|", limit = 2).getOrNull(1) == path }
        current.add("$name|$path")
        prefs.edit().putStringSet(KEY, current).apply()
    }

    fun remove(path: String) {
        val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
        current.removeAll { it.split("|", limit = 2).getOrNull(1) == path }
        prefs.edit().putStringSet(KEY, current).apply()
    }

    fun isBookmarked(path: String): Boolean = getAll().any { it.path == path }
}
