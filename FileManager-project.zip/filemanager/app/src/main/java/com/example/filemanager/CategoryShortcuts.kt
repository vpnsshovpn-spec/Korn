package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.FileCategories
import com.example.filemanager.data.repository.FileScanner
import com.example.filemanager.data.repository.notifyMediaScannerPaths

/**
 * Category shortcut chips (รูปภาพ/วิดีโอ/เพลง/เอกสาร/แอปพลิเคชัน/ไฟล์บีบอัด) and the
 * installed-apps listing/APK-backup they lead to - extracted out of MainActivity.kt (round 5
 * of the size-reduction plan). No logic changed, only location + widening categoryBar,
 * themeColors(), comparator() from private to internal so this file can read/call them.
 * lastNormalDir/currentCategoryLabel/currentCategoryExts/showHidden/currentDir are read
 * via viewModel directly (round 18-19 wrapper removal).
 *
 * Selected-chip styling: a chip is "active" when it matches the current directoryViewModel.mode/
 * currentCategoryLabel (ทั้งหมด = NORMAL, แอปพลิเคชัน = APPS, everything else = CATEGORY
 * with a matching label). Chips re-render off a single combine() of those two StateFlows
 * instead of every click handler separately re-styling every chip, so this whole feature
 * stays in the one place it belongs instead of spreading edits across the file.
 */

internal fun MainActivity.setupCategoryBar() {
    val categories: List<Pair<String, Set<String>?>> = listOf(
        "ทั้งหมด" to null,
        "รูปภาพ" to FileCategories.IMAGES,
        "วิดีโอ" to FileCategories.VIDEOS,
        "เพลง" to FileCategories.MUSIC,
        "เอกสาร" to FileCategories.DOCS,
        "แอปพลิเคชัน" to FileCategories.APPS,
        "ไฟล์บีบอัด" to FileCategories.ARCHIVES
    )
    val chips = mutableListOf<Pair<String, TextView>>()
    for ((label, exts) in categories) {
        val chip = TextView(this).apply {
            text = label
            setPadding(dp(14), dp(8), dp(14), dp(8))
            textSize = 13f
            gravity = Gravity.CENTER
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dp(8)
            layoutParams = lp
            setOnClickListener {
                if (label == "แอปพลิเคชัน") {
                    loadInstalledApps()
                } else if (exts == null) {
                    directoryViewModel.setMode(MainActivity.Mode.NORMAL)
                    loadDirectory(directoryViewModel.lastNormalDir.value)
                } else {
                    runCategoryScan(label, exts)
                }
            }
        }
        chips.add(label to chip)
        categoryBar.addView(chip)
    }

    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            combine(directoryViewModel.mode, directoryViewModel.currentCategoryLabel) { mode, categoryLabel ->
                categoryChipActiveLabel(mode, categoryLabel)
            }.collect { activeLabel ->
                val primary = themeColors().first
                for ((label, chip) in chips) {
                    chip.setSelectedStyle(label == activeLabel, primary)
                }
            }
        }
    }
}

/**
 * Which category-chip label (if any) should render as "active" for a given
 * mode/currentCategoryLabel pair. Pulled out of the combine() block above so it's a plain
 * function of two values with no Android/ViewModel dependency - CategoryShortcutsTest.kt
 * covers it directly without needing Robolectric. Behavior is unchanged from before the
 * extraction (ทั้งหมด = NORMAL, แอปพลิเคชัน = APPS, everything else = CATEGORY with a
 * matching label, any other mode = nothing active).
 */
internal fun categoryChipActiveLabel(mode: MainActivity.Mode, categoryLabel: String?): String? {
    return when (mode) {
        MainActivity.Mode.NORMAL -> "ทั้งหมด"
        MainActivity.Mode.APPS -> "แอปพลิเคชัน"
        MainActivity.Mode.CATEGORY -> categoryLabel
        else -> null
    }
}

/**
 * Filled pill in the team color when active, otherwise an outline in that same color so
 * the unselected chips still read as "part of this theme" without competing for attention.
 */
private fun TextView.setSelectedStyle(selected: Boolean, primary: Int) {
    background = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = context.dpF(18)
        if (selected) {
            setColor(primary)
        } else {
            setColor(android.graphics.Color.TRANSPARENT)
            setStroke(context.dpI(1), primary)
        }
    }
    setTextColor(if (selected) 0xFFFFFFFF.toInt() else primary)
    setTypeface(typeface, if (selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
}

private fun android.content.Context.dpF(value: Int): Float = value * resources.displayMetrics.density
private fun android.content.Context.dpI(value: Int): Int = (value * resources.displayMetrics.density).toInt()

internal fun MainActivity.runCategoryScan(label: String, exts: Set<String>) {
    directoryViewModel.setMode(MainActivity.Mode.CATEGORY)
    trashActionBar.visibility = View.GONE
    directoryViewModel.setCurrentCategoryLabel(label)
    directoryViewModel.setCurrentCategoryExts(exts)
    showSpecialPath("หมวดหมู่: $label")
    supportActionBar?.subtitle = "กำลังค้นหา..."
    val root = Environment.getExternalStorageDirectory()
    val hidden = directoryViewModel.showHidden.value
    lifecycleScope.launch {
        try {
            val results = withContext(Dispatchers.IO) { FileScanner.scanByExtensions(root, exts, hidden) }
            swipeRefresh.isRefreshing = false
            if (directoryViewModel.mode.value != MainActivity.Mode.CATEGORY || directoryViewModel.currentCategoryLabel.value != label) return@launch
            val entries = results.map { FileEntry(it) }.sortedWith(comparator())
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} รายการ"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.loadInstalledApps() {
    directoryViewModel.setMode(MainActivity.Mode.APPS)
    trashActionBar.visibility = View.GONE
    showSpecialPath("แอปพลิเคชันในเครื่อง")
    supportActionBar?.subtitle = "กำลังโหลดแอป…"
    lifecycleScope.launch {
        try {
            val entries = withContext(Dispatchers.IO) {
                packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                    .mapNotNull { app ->
                        val path = app.sourceDir ?: return@mapNotNull null
                        val file = File(path)
                        if (!file.exists() || !file.isFile) return@mapNotNull null
                        val label = packageManager.getApplicationLabel(app).toString().ifBlank { app.packageName }
                        FileEntry(file, displayName = label, subtitleOverride = "${app.packageName}  •  ${readableSize(file.length())}  •  ${formatDateTime(file.lastModified())}")
                    }
                    .sortedBy { it.displayName?.lowercase() ?: it.file.name.lowercase() }
            }
            if (directoryViewModel.mode.value != MainActivity.Mode.APPS) return@launch
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} แอป"
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.backupApplicationApk(entry: FileEntry) {
    val source = entry.file
    if (!source.exists()) {
        Toast.makeText(this, "ไม่พบ APK ของแอปนี้", Toast.LENGTH_SHORT).show()
        return
    }
    val safeName = (entry.displayName ?: source.nameWithoutExtension).replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "application" }
    val dest = File(directoryViewModel.currentDir.value, uniqueName(directoryViewModel.currentDir.value, "$safeName.apk", false))
    KornDialog.Builder(this)
        .setTitle("สำรองแอปเป็น APK")
        .setMessage("${entry.displayName ?: source.name}\n\nจะบันทึกเป็น:\n${dest.name}")
        .setPositiveButton("สำรอง") { _, _ ->
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    source.copyTo(dest, overwrite = false)
                    notifyMediaScannerPaths(listOf(dest.absolutePath))
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@backupApplicationApk, "สำรอง APK แล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                        loadDirectory(directoryViewModel.currentDir.value)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(this@backupApplicationApk, "สำรองไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
