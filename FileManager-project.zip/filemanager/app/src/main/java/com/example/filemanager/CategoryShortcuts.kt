package com.example.filemanager

import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Category shortcut chips (รูปภาพ/วิดีโอ/เพลง/เอกสาร/แอปพลิเคชัน/ไฟล์บีบอัด) and the
 * installed-apps listing/APK-backup they lead to - extracted out of MainActivity.kt (round 5
 * of the size-reduction plan). No logic changed, only location + widening categoryBar,
 * themeColors(), comparator() from private to internal so this file can read/call them.
 * lastNormalDir/currentCategoryLabel/currentCategoryExts/showHidden/currentDir are read
 * via viewModel directly (round 18-19 wrapper removal).
 *
 * UX pass (category chip polish, 3 changes per the reference screenshots):
 * 1) Capsule/pill shape: chips now use a GradientDrawable with a corner radius larger than
 *    their own height (999px always exceeds it, so Android clamps it to a full pill) instead
 *    of a flat setBackgroundColor() rectangle, plus a wider marginEnd between chips.
 * 2) Active-state highlight: each chip's label is stashed in View.tag so
 *    updateCategoryChipHighlight() (called from MainActivity's observeCategoryHighlightState()
 *    and optimistically right in the click listener below) can tell which one is "selected"
 *    and give it a solid accent-color fill + white text, while the rest get a transparent
 *    fill with a thin accent-color outline + secondary text color. Both colors come from
 *    themeColors()/@color/text_secondary, so the highlight follows the user's theme/day-night
 *    setting automatically, same as the rest of the app.
 * 3) Fading edge: categoryScroll (the HorizontalScrollView wrapping categoryBar) now has a
 *    scroll-change listener that shows/hides categoryFadeEdge, a small overlay View at the
 *    right edge filled with a transparent-to-@color/surface GradientDrawable (built in code so
 *    it resolves the correct day/night surface color), only visible while there's more content
 *    to scroll to on the right.
 */

private const val CHIP_CORNER_RADIUS_PX = 999f

internal fun MainActivity.setupCategoryBar() {
    val categories: List<Pair<String, Set<String>?>> = listOf(
        "ทั้งหมด" to null,
        "รูปภาพ" to FileCategories.IMAGES,
        "วิดีโอ" to FileCategories.VIDEOS,
        "เพลง" to FileCategories.MUSIC,
        "เอกสาร" to FileCategories.DOCS,
        "แอปพลิเคชัน" to FileCategories.APPS,
        "ไฟล์บีบอัด" to FileCategories.ARCHIVES
    )
    for ((label, exts) in categories) {
        val chip = TextView(this).apply {
            text = label
            tag = label
            setPadding(30, 14, 30, 14)
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = 16
            layoutParams = lp
            setOnClickListener {
                if (label == "แอปพลิเคชัน") {
                    loadInstalledApps()
                } else if (exts == null) {
                    viewModel.setMode(MainActivity.Mode.NORMAL)
                    loadDirectory(viewModel.lastNormalDir.value)
                } else {
                    runCategoryScan(label, exts)
                }
                // Optimistic: don't wait for the mode/label StateFlow round-trip to repaint.
                updateCategoryChipHighlight()
            }
        }
        categoryBar.addView(chip)
    }
    updateCategoryChipHighlight()
    setupCategoryFadeEdge()
}

/** Which chip label counts as "selected" right now, derived from the same state the rest of
 *  the app already uses to know what's on screen (no new state introduced). */
private fun MainActivity.selectedCategoryLabel(): String = when (viewModel.mode.value) {
    MainActivity.Mode.APPS -> "แอปพลิเคชัน"
    MainActivity.Mode.CATEGORY -> viewModel.currentCategoryLabel.value ?: "ทั้งหมด"
    else -> "ทั้งหมด"
}

/**
 * Build-fix note: this used to start with `if (!::categoryBar.isInitialized) return` as a
 * defensive guard, but Kotlin only allows checking a lateinit var's `.isInitialized` from
 * inside the class that declares it (MainActivity.kt) - not from an extension function
 * declared in a different file like this one, even though it's the same module/package
 * (compile error: "Backing field of 'var categoryBar: LinearLayout' is not accessible at
 * this point"). Removed the guard instead of relocating it, since it was never actually
 * reachable unguarded anyway: this function is only ever called from setupCategoryBar()
 * itself (after categoryBar is assigned) or from observeCategoryHighlightState(), which only
 * starts collecting after onCreate() has already called setupCategoryBar() - so categoryBar
 * is guaranteed initialized every time this runs.
 */
internal fun MainActivity.updateCategoryChipHighlight() {
    val selectedLabel = selectedCategoryLabel()
    val accent = themeColors().first
    val strokeWidthPx = (1.5f * resources.displayMetrics.density).toInt().coerceAtLeast(1)
    for (i in 0 until categoryBar.childCount) {
        val chip = categoryBar.getChildAt(i) as? TextView ?: continue
        val label = chip.tag as? String ?: continue
        val isSelected = label == selectedLabel
        chip.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = CHIP_CORNER_RADIUS_PX
            if (isSelected) {
                setColor(accent)
            } else {
                setColor(Color.TRANSPARENT)
                setStroke(strokeWidthPx, accent)
            }
        }
        chip.setTextColor(if (isSelected) 0xFFFFFFFF.toInt() else getColor(R.color.text_secondary))
    }
}

private fun MainActivity.setupCategoryFadeEdge() {
    categoryFadeEdge.background = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(Color.TRANSPARENT, getColor(R.color.surface))
    )
    fun refreshFadeEdge() {
        categoryFadeEdge.visibility = if (categoryScroll.canScrollHorizontally(1)) View.VISIBLE else View.GONE
    }
    categoryScroll.setOnScrollChangeListener { _, _, _, _, _ -> refreshFadeEdge() }
    categoryScroll.post { refreshFadeEdge() }
}

internal fun MainActivity.runCategoryScan(label: String, exts: Set<String>) {
    viewModel.setMode(MainActivity.Mode.CATEGORY)
    trashActionBar.visibility = View.GONE
    viewModel.setCurrentCategoryLabel(label)
    viewModel.setCurrentCategoryExts(exts)
    showSpecialPath("หมวดหมู่: $label")
    supportActionBar?.subtitle = "กำลังค้นหา..."
    swipeRefresh.isRefreshing = true
    val root = Environment.getExternalStorageDirectory()
    val hidden = viewModel.showHidden.value
    lifecycleScope.launch {
        try {
            val results = withContext(Dispatchers.IO) { FileScanner.scanByExtensions(root, exts, hidden) }
            swipeRefresh.isRefreshing = false
            if (viewModel.mode.value != MainActivity.Mode.CATEGORY || viewModel.currentCategoryLabel.value != label) return@launch
            val entries = results.map { FileEntry(it) }.sortedWith(comparator())
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} รายการ"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.loadInstalledApps() {
    viewModel.setMode(MainActivity.Mode.APPS)
    trashActionBar.visibility = View.GONE
    showSpecialPath("แอปพลิเคชันในเครื่อง")
    supportActionBar?.subtitle = "กำลังโหลดแอป…"
    swipeRefresh.isRefreshing = true
    lifecycleScope.launch {
        try {
            val entries = withContext(Dispatchers.IO) {
                packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                    .mapNotNull { app ->
                        val path = app.sourceDir ?: return@mapNotNull null
                        val file = File(path)
                        if (!file.exists() || !file.isFile) return@mapNotNull null
                        val label = packageManager.getApplicationLabel(app).toString().ifBlank { app.packageName }
                        FileEntry(file, displayName = label, subtitleOverride = "${app.packageName}  •  ${readableSize(file.length())}  •  ${formatDateTime(file.lastModified())}")
                    }
                    .sortedBy { it.displayName?.lowercase() ?: it.file.name.lowercase() }
            }
            if (viewModel.mode.value != MainActivity.Mode.APPS) return@launch
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} แอป"
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.backupApplicationApk(entry: FileEntry) {
    val source = entry.file
    if (!source.exists()) {
        Toast.makeText(this, "ไม่พบ APK ของแอปนี้", Toast.LENGTH_SHORT).show()
        return
    }
    val safeName = (entry.displayName ?: source.nameWithoutExtension).replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "application" }
    val dest = File(viewModel.currentDir.value, uniqueName(viewModel.currentDir.value, "$safeName.apk", false))
    KornDialog.Builder(this)
        .setTitle("สำรองแอปเป็น APK")
        .setMessage("${entry.displayName ?: source.name}\n\nจะบันทึกเป็น:\n${dest.name}")
        .setPositiveButton("สำรอง") { _, _ ->
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    source.copyTo(dest, overwrite = false)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@backupApplicationApk, "สำรอง APK แล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                        loadDirectory(viewModel.currentDir.value)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(this@backupApplicationApk, "สำรองไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
