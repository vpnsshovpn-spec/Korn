package com.example.filemanager

import android.content.pm.PackageManager
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Category shortcut chips (รูปภาพ/วิดีโอ/เพลง/เอกสาร/แอปพลิเคชัน/ไฟล์บีบอัด) and the
 * installed-apps listing/APK-backup they lead to - extracted out of MainActivity.kt (round 5
 * of the size-reduction plan). No logic changed, only location + widening several members
 * from private to internal (categoryBar, showHidden, themeColors(), comparator()) so this
 * file can read/call them. lastNormalDir/currentCategoryLabel/currentCategoryExts are read
 * via viewModel directly (round 18 wrapper removal).
 */

internal fun MainActivity.setupCategoryBar() {
    val categories: List<Pair<String, Set<String>?>> = listOf(
        "ทั้งหมด" to null,
        "รูปภาพ" to FileCategories.IMAGES,
        "วิดีโอ" to FileCategories.VIDEOS,
        "เพลง" to FileCategories.MUSIC,
        "เอกสาร" to FileCategories.DOCS,
        "แอปพลิเคชัน" to FileCategories.APPS,
        "ไฟล์บีบอัด" to FileCategories.ARCHIVES
    )
    for ((label, exts) in categories) {
        val chip = TextView(this).apply {
            text = label
            setPadding(28, 14, 28, 14)
            setBackgroundColor(themeColors().first)
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = 10
            layoutParams = lp
            setOnClickListener {
                if (label == "แอปพลิเคชัน") {
                    loadInstalledApps()
                } else if (exts == null) {
                    mode = MainActivity.Mode.NORMAL
                    loadDirectory(viewModel.lastNormalDir.value)
                } else {
                    runCategoryScan(label, exts)
                }
            }
        }
        categoryBar.addView(chip)
    }
}

internal fun MainActivity.runCategoryScan(label: String, exts: Set<String>) {
    mode = MainActivity.Mode.CATEGORY
    trashActionBar.visibility = View.GONE
    viewModel.setCurrentCategoryLabel(label)
    viewModel.setCurrentCategoryExts(exts)
    showSpecialPath("หมวดหมู่: $label")
    supportActionBar?.subtitle = "กำลังค้นหา..."
    val root = Environment.getExternalStorageDirectory()
    val hidden = showHidden
    lifecycleScope.launch {
        try {
            val results = withContext(Dispatchers.IO) { FileScanner.scanByExtensions(root, exts, hidden) }
            swipeRefresh.isRefreshing = false
            if (mode != MainActivity.Mode.CATEGORY || viewModel.currentCategoryLabel.value != label) return@launch
            val entries = results.map { FileEntry(it) }.sortedWith(comparator())
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} รายการ"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.loadInstalledApps() {
    mode = MainActivity.Mode.APPS
    trashActionBar.visibility = View.GONE
    showSpecialPath("แอปพลิเคชันในเครื่อง")
    supportActionBar?.subtitle = "กำลังโหลดแอป…"
    lifecycleScope.launch {
        try {
            val entries = withContext(Dispatchers.IO) {
                packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                    .mapNotNull { app ->
                        val path = app.sourceDir ?: return@mapNotNull null
                        val file = File(path)
                        if (!file.exists() || !file.isFile) return@mapNotNull null
                        val label = packageManager.getApplicationLabel(app).toString().ifBlank { app.packageName }
                        FileEntry(file, displayName = label, subtitleOverride = "${app.packageName}  •  ${readableSize(file.length())}  •  ${formatDateTime(file.lastModified())}")
                    }
                    .sortedBy { it.displayName?.lowercase() ?: it.file.name.lowercase() }
            }
            if (mode != MainActivity.Mode.APPS) return@launch
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} แอป"
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

internal fun MainActivity.backupApplicationApk(entry: FileEntry) {
    val source = entry.file
    if (!source.exists()) {
        Toast.makeText(this, "ไม่พบ APK ของแอปนี้", Toast.LENGTH_SHORT).show()
        return
    }
    val safeName = (entry.displayName ?: source.nameWithoutExtension).replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "application" }
    val dest = File(currentDir, uniqueName(currentDir, "$safeName.apk", false))
    AlertDialog.Builder(this)
        .setTitle("สำรองแอปเป็น APK")
        .setMessage("${entry.displayName ?: source.name}\n\nจะบันทึกเป็น:\n${dest.name}")
        .setPositiveButton("สำรอง") { _, _ ->
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    source.copyTo(dest, overwrite = false)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@backupApplicationApk, "สำรอง APK แล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                        loadDirectory(currentDir)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(this@backupApplicationApk, "สำรองไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
