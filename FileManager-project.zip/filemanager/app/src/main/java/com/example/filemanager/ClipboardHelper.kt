package com.example.filemanager

import android.widget.EditText
import android.widget.Toast
import java.io.File
import com.example.filemanager.data.repository.createNewFileCompat
import com.example.filemanager.data.repository.mkdirsCompat

/**
 * Clipboard paste and create-file/folder UI extracted from MainActivity (STEP 15).
 * Existing clipboard and creation behavior is preserved.
 */
internal fun MainActivity.pasteClipboard() {
    val sources = viewModel.clipboardFiles.value
    if (sources.isEmpty()) {
        Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
        return
    }
    val destDir = directoryViewModel.currentDir.value
    val cut = viewModel.clipboardIsCut.value
    // Conflict scanning/dialog/starting the service is handled by
    // CopyMoveConflictResolver.kt - it shows "กำลังวางไฟล์ในพื้นหลัง…" itself once the
    // service actually starts (which may be after the user resolves 1+ conflicts).
    startCopyMoveWithConflictCheck(sources, destDir, cut)
    viewModel.setClipboardFiles(emptyList())
    viewModel.setClipboardIsCut(false)
    updateActionBars()
}

internal fun MainActivity.showAddMenu() {
    KornDialog.Builder(this)
        .setTitle("เพิ่ม")
        .setItems(arrayOf("📄 ไฟล์", "📁 โฟลเดอร์")) { _, which ->
            when (which) {
                0 -> newFileDialog()
                1 -> newFolderDialog()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.newFileDialog() {
    val input = EditText(this)
    input.hint = "ชื่อไฟล์.txt"
    KornDialog.Builder(this)
        .setTitle("สร้างไฟล์ใหม่")
        .setMessage("ใน ${directoryViewModel.currentDir.value.absolutePath}")
        .setView(input)
        .setPositiveButton("สร้าง") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isEmpty()) return@setPositiveButton
            val newFile = File(directoryViewModel.currentDir.value, name)
            try {
                when {
                    newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                    newFile.createNewFileCompat() -> { loadDirectory(directoryViewModel.currentDir.value); refreshSearchIndexIncremental { searchIndexManager.indexFile(newFile) } }
                    else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.newFolderDialog() {
    val input = EditText(this)
    KornDialog.Builder(this)
        .setTitle("สร้างโฟลเดอร์ใหม่")
        .setView(input)
        .setPositiveButton("สร้าง") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                val ok = File(directoryViewModel.currentDir.value, name).mkdirsCompat()
                loadDirectory(directoryViewModel.currentDir.value)
                // Local Search Index รอบ 4: โฟลเดอร์ใหม่ต้องโผล่ในผลค้นหาทันทีเหมือน
                // operation อื่นๆ ที่ hook ไว้แล้วในรอบ 3 — รีเฟรชเฉพาะตอนสร้างสำเร็จจริง
                if (ok) refreshSearchIndexIncremental { searchIndexManager.indexFile(File(directoryViewModel.currentDir.value, name)) }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
