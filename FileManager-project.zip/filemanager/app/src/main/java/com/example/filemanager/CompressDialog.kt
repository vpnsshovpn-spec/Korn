package com.example.filemanager

import android.content.DialogInterface
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import java.io.File
import com.example.filemanager.data.service.CompressOperationService

/**
 * ส่วนที่ 3/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน" (ถอดแบบจาก ZArchiver): หน้า UI Dialog ภาษาไทย
 * ที่ผูก [dialog_create_archive.xml] เข้ากับ [CompressViewModel] ไฟล์นี้ไม่มี logic การบีบอัดจริง -
 * ปุ่ม "ตกลง" เรียก [onConfirm] ด้วย [CompressOptions] ที่ผ่านการตรวจสอบแล้วเท่านั้น ส่วน Engine/
 * Service ที่จะรับ [CompressOptions] ไปบีบอัดจริงจะเขียนในพาร์ทถัดไป (ค่าเริ่มต้นของ [onConfirm]
 * เพียงแสดง Toast สรุปตัวเลือกที่จะสร้าง เพื่อให้ Dialog นี้ทดสอบได้ครบวงจรตั้งแต่วันนี้)
 *
 * เขียนเป็น extension function บน MainActivity แบบเดียวกับ showCompressFormatDialog() ใน
 * ArchiveDialogs.kt และ DestinationFolderPickerHelper ที่มีอยู่แล้ว - ไม่แก้ไข MainActivity.kt
 * หรือไฟล์อื่นใดที่มีอยู่ก่อนหน้านี้ ทุกอย่างเข้าถึงผ่าน field/method ที่เป็น internal อยู่แล้ว
 * (viewModel, bookmarksManager, comparator(), dp(), showSortDialog()).
 *
 * พาร์ท 3/3: [onConfirm] ตอนนี้เริ่มงานจริงผ่าน CompressOperationService (เดิมพาร์ท 1-2/3 แค่โชว์
 * Toast สรุปตัวเลือก) - เช็คสิทธิ์ POST_NOTIFICATIONS ก่อนด้วย startArchiveOperationWithNotificationCheck
 * ตัวเดิมที่ใช้ร่วมกับฝั่ง zip/unzip เก่าอยู่แล้ว (ดู ArchiveProgressDialogHelper.kt) - ฟังก์ชันนั้น
 * generic อยู่แล้ว ไม่ผูกกับ Service ตัวใดตัวหนึ่งโดยเฉพาะ
 *
 * @param sourceFiles ไฟล์/โฟลเดอร์ต้นทางที่จะถูกบีบอัด (มาจากรายการที่ผู้ใช้เลือกไว้ก่อนเปิด Dialog)
 * @param initialDir โฟลเดอร์ปลายทางเริ่มต้นที่จะบันทึกไฟล์ archive (ค่าเริ่มต้น = โฟลเดอร์ปัจจุบัน)
 * @param onConfirm callback เมื่อผู้ใช้กด "ตกลง" และข้อมูลผ่านการตรวจสอบแล้ว
 */
internal fun MainActivity.showCreateArchiveDialog(
    sourceFiles: List<File>,
    initialDir: File = directoryViewModel.currentDir.value,
    onConfirm: (CompressOptions) -> Unit = { options ->
        startArchiveOperationWithNotificationCheck {
            Toast.makeText(this, "กำลังสร้าง ${options.outputFileName}…", Toast.LENGTH_SHORT).show()
            archiveOperationViewModel.setCompressOpStarted(options.outputFileName)
            CompressOperationService.start(this, options)
        }
    }
) {
    if (sourceFiles.isEmpty()) return

    val compressViewModel = ViewModelProvider(this)[CompressViewModel::class.java]
    compressViewModel.init(sourceFiles, initialDir)

    val view = LayoutInflater.from(this).inflate(R.layout.dialog_create_archive, null)

    val fileNameEditText = view.findViewById<EditText>(R.id.fileNameEditText)
    val duplicateNameWarningText = view.findViewById<TextView>(R.id.duplicateNameWarningText)
    val outputDirText = view.findViewById<TextView>(R.id.outputDirText)
    val chooseFolderButton = view.findViewById<TextView>(R.id.chooseFolderButton)
    val formatSpinner = view.findViewById<Spinner>(R.id.formatSpinner)
    val levelSpinner = view.findViewById<Spinner>(R.id.levelSpinner)
    val encryptionSpinner = view.findViewById<Spinner>(R.id.encryptionSpinner)
    val passwordEditText = view.findViewById<EditText>(R.id.passwordEditText)
    val togglePasswordButton = view.findViewById<TextView>(R.id.togglePasswordButton)
    val splitSpinner = view.findViewById<Spinner>(R.id.splitSpinner)
    val customVolumeSizeContainer = view.findViewById<android.view.View>(R.id.customVolumeSizeContainer)
    val customVolumeSizeEditText = view.findViewById<EditText>(R.id.customVolumeSizeEditText)
    val deleteSourceCheckBox = view.findViewById<CheckBox>(R.id.deleteSourceCheckBox)
    val separateArchiveCheckBox = view.findViewById<CheckBox>(R.id.separateArchiveCheckBox)

    val formatValues = CompressFormat.values()
    val levelValues = CompressionLevel.values()
    val encryptionValues = EncryptionType.values()
    val splitValues = SplitVolumeOption.values()

    formatSpinner.adapter = simpleSpinnerAdapter(this, formatValues.map { ".${it.displayExtension}" })
    levelSpinner.adapter = simpleSpinnerAdapter(this, levelValues.map { it.labelTh })
    encryptionSpinner.adapter = simpleSpinnerAdapter(this, encryptionValues.map { it.labelTh })
    splitSpinner.adapter = simpleSpinnerAdapter(this, splitValues.map { it.labelTh })

    // ---------- ผู้ใช้พิมพ์/แตะ -> อัปเดต ViewModel ----------

    fileNameEditText.bindTextChanges { compressViewModel.setFileNameInput(it) }
    passwordEditText.bindTextChanges { compressViewModel.setPassword(it) }
    customVolumeSizeEditText.bindTextChanges { compressViewModel.setCustomVolumeSizeMbInput(it) }

    duplicateNameWarningText.setOnClickListener { compressViewModel.applySuggestedFileName() }

    chooseFolderButton.setOnClickListener {
        val picker = DestinationFolderPickerHelper(
            context = this,
            directoryBrowserHelper = DirectoryBrowserHelper(),
            bookmarksManager = bookmarksManager,
            comparator = { comparator() },
            dp = { dp(it) },
            showSortDialog = this::showSortDialog
        )
        picker.show(compressViewModel.uiState.value.outputDir) { chosen ->
            compressViewModel.setOutputDir(chosen)
        }
    }

    formatSpinner.bindSelection { position -> compressViewModel.setFormat(formatValues[position]) }
    levelSpinner.bindSelection { position -> compressViewModel.setLevel(levelValues[position]) }
    encryptionSpinner.bindSelection { position -> compressViewModel.setEncryptionType(encryptionValues[position]) }
    splitSpinner.bindSelection { position -> compressViewModel.setSplitOption(splitValues[position]) }

    togglePasswordButton.setOnClickListener { compressViewModel.togglePasswordVisibility() }
    deleteSourceCheckBox.setOnCheckedChangeListener { _, isChecked ->
        compressViewModel.setDeleteSourceAfterCompress(isChecked)
    }
    separateArchiveCheckBox.setOnCheckedChangeListener { _, isChecked ->
        compressViewModel.setCreateSeparateArchivePerItem(isChecked)
    }

    // ---------- Dialog เอง (ปุ่ม "ยกเลิก" / "ตกลง") ----------

    val handle = KornDialog.Builder(this)
        .setTitle("สร้างไฟล์ Archive")
        .setView(view)
        .setPositiveButton("ตกลง") { _, _ ->
            compressViewModel.buildOptions()?.let(onConfirm)
        }
        .setNegativeButton("ยกเลิก", null)
        .show()

    // ---------- State (ViewModel) -> View ----------

    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            compressViewModel.uiState.collect { state ->
                renderCompressDialogState(
                    state = state,
                    fileNameEditText = fileNameEditText,
                    duplicateNameWarningText = duplicateNameWarningText,
                    outputDirText = outputDirText,
                    formatSpinner = formatSpinner,
                    levelSpinner = levelSpinner,
                    encryptionSpinner = encryptionSpinner,
                    passwordEditText = passwordEditText,
                    togglePasswordButton = togglePasswordButton,
                    splitSpinner = splitSpinner,
                    customVolumeSizeContainer = customVolumeSizeContainer,
                    customVolumeSizeEditText = customVolumeSizeEditText,
                    deleteSourceCheckBox = deleteSourceCheckBox,
                    separateArchiveCheckBox = separateArchiveCheckBox,
                    formatValues = formatValues,
                    levelValues = levelValues,
                    encryptionValues = encryptionValues,
                    splitValues = splitValues
                )
                runCatching {
                    handle.getButton(DialogInterface.BUTTON_POSITIVE).isEnabled = state.isConfirmEnabled
                }
            }
        }
    }
}

/**
 * วาด [state] ปัจจุบันลงบน View ทั้งหมดของ Dialog แบบ "set เมื่อค่าต่างจากเดิมเท่านั้น" เพื่อไม่ให้
 * EditText.setText()/Spinner.setSelection() ที่เรียกจากการ collect StateFlow ไปตัดคำที่ผู้ใช้กำลัง
 * พิมพ์อยู่ หรือเด้ง listener กลับเข้า ViewModel เป็นลูปไม่รู้จบ
 */
private fun renderCompressDialogState(
    state: CompressUiState,
    fileNameEditText: EditText,
    duplicateNameWarningText: TextView,
    outputDirText: TextView,
    formatSpinner: Spinner,
    levelSpinner: Spinner,
    encryptionSpinner: Spinner,
    passwordEditText: EditText,
    togglePasswordButton: TextView,
    splitSpinner: Spinner,
    customVolumeSizeContainer: android.view.View,
    customVolumeSizeEditText: EditText,
    deleteSourceCheckBox: CheckBox,
    separateArchiveCheckBox: CheckBox,
    formatValues: Array<CompressFormat>,
    levelValues: Array<CompressionLevel>,
    encryptionValues: Array<EncryptionType>,
    splitValues: Array<SplitVolumeOption>
) {
    if (fileNameEditText.text.toString() != state.fileNameInput) {
        fileNameEditText.setText(state.fileNameInput)
        fileNameEditText.setSelection(fileNameEditText.text.length)
    }

    val suggested = state.suggestedFileName
    if (suggested != null) {
        duplicateNameWarningText.text = "ชื่อไฟล์นี้มีอยู่แล้ว แตะเพื่อใช้ชื่อ \"$suggested\" แทน"
        duplicateNameWarningText.visibility = android.view.View.VISIBLE
    } else {
        duplicateNameWarningText.visibility = android.view.View.GONE
    }

    outputDirText.text = state.outputDir.path

    val formatIndex = formatValues.indexOf(state.format)
    if (formatIndex >= 0 && formatSpinner.selectedItemPosition != formatIndex) {
        formatSpinner.setSelection(formatIndex)
    }
    val levelIndex = levelValues.indexOf(state.level)
    if (levelIndex >= 0 && levelSpinner.selectedItemPosition != levelIndex) {
        levelSpinner.setSelection(levelIndex)
    }
    val encryptionIndex = encryptionValues.indexOf(state.encryptionType)
    if (encryptionIndex >= 0 && encryptionSpinner.selectedItemPosition != encryptionIndex) {
        encryptionSpinner.setSelection(encryptionIndex)
    }
    val splitIndex = splitValues.indexOf(state.splitOption)
    if (splitIndex >= 0 && splitSpinner.selectedItemPosition != splitIndex) {
        splitSpinner.setSelection(splitIndex)
    }

    val encryptionEnabled = state.isEncryptionSupported
    encryptionSpinner.isEnabled = encryptionEnabled
    encryptionSpinner.alpha = if (encryptionEnabled) 1f else 0.4f
    passwordEditText.isEnabled = encryptionEnabled
    togglePasswordButton.isEnabled = encryptionEnabled
    passwordEditText.alpha = if (encryptionEnabled) 1f else 0.4f
    togglePasswordButton.alpha = if (encryptionEnabled) 1f else 0.4f

    if (passwordEditText.text.toString() != state.password) {
        passwordEditText.setText(state.password)
        passwordEditText.setSelection(passwordEditText.text.length)
    }
    val passwordInputType = if (state.isPasswordVisible) {
        android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
    } else {
        android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    if (passwordEditText.inputType != passwordInputType) {
        val selectionEnd = passwordEditText.selectionEnd.coerceAtLeast(0)
        passwordEditText.inputType = passwordInputType
        passwordEditText.setSelection(selectionEnd.coerceAtMost(passwordEditText.text.length))
    }
    togglePasswordButton.text = if (state.isPasswordVisible) "🙈" else "👁"

    customVolumeSizeContainer.visibility =
        if (state.splitOption == SplitVolumeOption.CUSTOM) android.view.View.VISIBLE else android.view.View.GONE
    if (customVolumeSizeEditText.text.toString() != state.customVolumeSizeMbInput) {
        customVolumeSizeEditText.setText(state.customVolumeSizeMbInput)
        customVolumeSizeEditText.setSelection(customVolumeSizeEditText.text.length)
    }

    if (deleteSourceCheckBox.isChecked != state.deleteSourceAfterCompress) {
        deleteSourceCheckBox.isChecked = state.deleteSourceAfterCompress
    }
    if (separateArchiveCheckBox.isChecked != state.createSeparateArchivePerItem) {
        separateArchiveCheckBox.isChecked = state.createSeparateArchivePerItem
    }
}

private fun simpleSpinnerAdapter(context: android.content.Context, items: List<String>): ArrayAdapter<String> =
    ArrayAdapter(context, android.R.layout.simple_spinner_item, items).apply {
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

private fun EditText.bindTextChanges(onChanged: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) { onChanged(s?.toString() ?: "") }
    })
}

private fun Spinner.bindSelection(onSelected: (position: Int) -> Unit) {
    onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
            onSelected(position)
        }
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}
