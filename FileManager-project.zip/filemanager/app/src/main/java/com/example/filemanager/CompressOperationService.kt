package com.example.filemanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * ส่วนที่ 3/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน" (ถอดแบบจาก ZArchiver): Service ที่รับ [CompressOptions]
 * (พาร์ท 1/3) มาเรียก [ArchiveEngine.compress] (พาร์ท 2/3) จริงบน background thread พร้อม
 * Foreground Notification/progress - ตัว logic การบีบอัดเองทั้งหมดอยู่ใน ArchiveEngine.kt แล้ว
 * ไฟล์นี้มีหน้าที่แค่ "ห่อ" การเรียกนั้นด้วยวงจรชีวิตของ Service เดียวกับที่
 * ArchiveOperationService.kt/FileOperationService.kt ทำอยู่แล้วสำหรับงานอื่น (ดู class doc ของ
 * ทั้งสองไฟล์นั้นสำหรับเหตุผลที่ต้องเป็น Service ไม่ใช่ coroutine ธรรมดาใน Activity/ViewModel)
 *
 * ตั้งใจแยกเป็น Service คนละตัวกับ ArchiveOperationService เดิม (ไม่ใช้ร่วมกัน) เพราะ:
 * - เส้นทางนี้ทั้งหมด (CompressOptions/CompressViewModel/CompressDialog/ArchiveEngine) ถูกออกแบบ
 *   ให้แยกจากเมนู "บีบอัด"/"แตกไฟล์" แบบเดิมโดยสิ้นเชิงมาตั้งแต่พาร์ท 1 - ดู CompressOptions.kt
 * - งานนี้รองรับการ "ยกเลิกกลางคัน" จริง (ArchiveCancelledException) ซึ่ง ArchiveOperationService
 *   เดิมไม่รองรับ การผสมสองเส้นทางเข้า Service เดียวจะทำให้ path เดิมต้องรับความซับซ้อนของการ
 *   ยกเลิกไปด้วยโดยไม่จำเป็น
 *
 * รองรับ [CompressOptions.createSeparateArchivePerItem]: ArchiveEngine เองไม่รู้จัก flag นี้ (ตาม
 * ที่ตั้งใจไว้ในพาร์ท 2 - ดู ArchiveEngine.kt) จึงวนเรียก [ArchiveEngine.compress] แยกทีละไฟล์/
 * โฟลเดอร์ต้นทางที่ระดับ Service นี้แทน คนละไฟล์ archive ต่อหนึ่งรายการต้นทาง ชื่อไฟล์แต่ละไฟล์
 * ต่อท้ายเลขอัตโนมัติเองถ้าซ้ำ (uniqueName - เหมือนที่ CompressViewModel.buildOptions() ทำกับ
 * archive รวมไฟล์เดียว) ความคืบหน้ารวม (percent ที่ broadcast ออกไป) คำนวณจาก
 * ((รายการที่เสร็จแล้ว * 100) + percent ของรายการปัจจุบัน) / จำนวนรายการทั้งหมด
 */
class CompressOperationService : Service() {

    companion object {
        const val CHANNEL_ID = "compress_operations"
        private const val NOTIFICATION_ID = 4501
        private const val NOTIFY_THROTTLE_MS = 500L
        private const val CANCEL_REQUEST_CODE = 4502
        private const val CONTENT_REQUEST_CODE = 4503

        const val ACTION_START = "com.example.filemanager.action.COMPRESS_START"
        const val ACTION_CANCEL = "com.example.filemanager.action.COMPRESS_CANCEL"

        private const val EXTRA_SOURCE_FILES = "extra_source_files"
        private const val EXTRA_OUTPUT_DIR = "extra_output_dir"
        private const val EXTRA_OUTPUT_FILE_NAME = "extra_output_file_name"
        private const val EXTRA_FORMAT = "extra_format"
        private const val EXTRA_LEVEL = "extra_level"
        private const val EXTRA_VOLUME_SIZE_BYTES = "extra_volume_size_bytes"
        private const val EXTRA_PASSWORD = "extra_password"
        private const val EXTRA_ENCRYPTION_TYPE = "extra_encryption_type"
        private const val EXTRA_DELETE_SOURCE = "extra_delete_source"
        private const val EXTRA_SEPARATE_PER_ITEM = "extra_separate_per_item"

        const val BROADCAST_PROGRESS = "com.example.filemanager.COMPRESS_OP_PROGRESS"
        const val BROADCAST_DONE = "com.example.filemanager.COMPRESS_OP_DONE"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_ARCHIVE_NAME = "extra_archive_name"
        const val EXTRA_ITEM_INDEX = "extra_item_index"
        const val EXTRA_TOTAL_ITEMS = "extra_total_items"
        const val EXTRA_SUCCESS = "extra_success"
        const val EXTRA_CANCELLED = "extra_cancelled"
        const val EXTRA_ERROR = "extra_error"
        const val EXTRA_CREATED_PATHS = "extra_created_paths"
        const val EXTRA_DELETED_PATHS = "extra_deleted_paths"

        /** true ระหว่างที่มีงานบีบอัดกำลังทำงานอยู่จริง - ผู้ใช้กด "ยกเลิก" ได้เฉพาะตอนนี้ */
        @Volatile private var cancelRequested = false

        /** เริ่มงานสร้างไฟล์ archive ตาม [options] ในพื้นหลัง (พาร์ท 3/3) */
        fun start(context: Context, options: CompressOptions) {
            cancelRequested = false
            val intent = Intent(context, CompressOperationService::class.java).apply {
                action = ACTION_START
                putStringArrayListExtra(EXTRA_SOURCE_FILES, ArrayList(options.sourceFiles.map { it.absolutePath }))
                putExtra(EXTRA_OUTPUT_DIR, options.outputDir.absolutePath)
                putExtra(EXTRA_OUTPUT_FILE_NAME, options.outputFileName)
                putExtra(EXTRA_FORMAT, options.format.name)
                putExtra(EXTRA_LEVEL, options.level.name)
                putExtra(EXTRA_VOLUME_SIZE_BYTES, options.volumeSizeBytes)
                putExtra(EXTRA_PASSWORD, options.password)
                putExtra(EXTRA_ENCRYPTION_TYPE, options.encryptionType.name)
                putExtra(EXTRA_DELETE_SOURCE, options.deleteSourceAfterCompress)
                putExtra(EXTRA_SEPARATE_PER_ITEM, options.createSeparateArchivePerItem)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        /** ขอให้ยกเลิกงานที่กำลังทำงานอยู่ (ถ้ามี) - ปุ่ม "ยกเลิก" ทั้งใน Notification และ Progress Dialog */
        fun requestCancel(context: Context) {
            cancelRequested = true
            context.startService(Intent(context, CompressOperationService::class.java).apply {
                action = ACTION_CANCEL
            })
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "การสร้างไฟล์ Archive", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            // cancelRequested ถูกตั้งไว้แล้วใน requestCancel() ก่อนเรียก startService() นี้ -
            // ไม่ต้องทำอะไรเพิ่ม แค่ไม่ให้ตกไปเริ่มงานใหม่ด้านล่าง
            return START_NOT_STICKY
        }

        val sourcePaths = intent?.getStringArrayListExtra(EXTRA_SOURCE_FILES) ?: arrayListOf()
        val outputDirPath = intent?.getStringExtra(EXTRA_OUTPUT_DIR)
        val outputFileName = intent?.getStringExtra(EXTRA_OUTPUT_FILE_NAME)
        val format = intent?.getStringExtra(EXTRA_FORMAT)?.let { runCatching { CompressFormat.valueOf(it) }.getOrNull() }
        val level = intent?.getStringExtra(EXTRA_LEVEL)?.let { runCatching { CompressionLevel.valueOf(it) }.getOrNull() }
        val volumeSizeBytes = intent?.getLongExtra(EXTRA_VOLUME_SIZE_BYTES, 0L) ?: 0L
        val password = intent?.getStringExtra(EXTRA_PASSWORD)
        val encryptionType = intent?.getStringExtra(EXTRA_ENCRYPTION_TYPE)
            ?.let { runCatching { EncryptionType.valueOf(it) }.getOrNull() }
        val deleteSource = intent?.getBooleanExtra(EXTRA_DELETE_SOURCE, false) ?: false
        val separatePerItem = intent?.getBooleanExtra(EXTRA_SEPARATE_PER_ITEM, false) ?: false

        if (sourcePaths.isEmpty() || outputDirPath == null || outputFileName == null || format == null || level == null || encryptionType == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        val options = CompressOptions(
            sourceFiles = sourcePaths.map { File(it) },
            outputDir = File(outputDirPath),
            outputFileName = outputFileName,
            format = format,
            level = level,
            volumeSizeBytes = volumeSizeBytes,
            password = password,
            encryptionType = encryptionType,
            deleteSourceAfterCompress = deleteSource,
            createSeparateArchivePerItem = separatePerItem
        )

        cancelRequested = false
        startForeground(NOTIFICATION_ID, buildNotification(options.outputFileName, 0, 0, 0).build())

        job = scope.launch {
            if (options.createSeparateArchivePerItem && options.sourceFiles.size > 1) {
                runSeparatePerItem(options)
            } else {
                runSingleArchive(options)
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    /** สร้าง archive เดียวรวมทุกไฟล์ต้นทาง (โหมดปกติ - ไม่ได้ติ๊ก "แยกไฟล์ต่อรายการ")
     *
     * Test-only visibility (private -> internal): exposes this to CompressOperationServiceTest.kt
     * without needing the full startForegroundService()/onStartCommand() path - same
     * "test-only visibility" pattern FileOperationService.runOperation() and
     * ArchiveOperationService.runUnzip() already use. Still suspend/private-in-spirit:
     * production behavior/signature unchanged, only visible in-module now. */
    internal suspend fun runSingleArchive(options: CompressOptions) {
        var lastNotifyAt = 0L
        try {
            val createdFiles = ArchiveEngine.compress(
                options = options,
                onProgress = { percent ->
                    broadcastProgress(percent, options.outputFileName, 0, 0)
                    val now = System.currentTimeMillis()
                    if (now - lastNotifyAt >= NOTIFY_THROTTLE_MS) {
                        lastNotifyAt = now
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(options.outputFileName, percent, 0, 0).build())
                    }
                },
                onCancel = { if (cancelRequested) throw ArchiveCancelledException() }
            )
            notifyMediaScannerPaths(createdFiles.map { it.absolutePath })
            val deletedSources = mutableListOf<String>()
            if (options.deleteSourceAfterCompress) {
                options.sourceFiles.forEach { if (it.deleteRecursivelyCompat()) deletedSources += it.absolutePath }
            }
            finish(options.outputFileName, success = true, cancelled = false, error = null,
                createdPaths = createdFiles.map { it.absolutePath }, deletedPaths = deletedSources)
        } catch (e: ArchiveCancelledException) {
            finish(options.outputFileName, success = false, cancelled = true, error = null)
        } catch (e: ArchiveEngineException) {
            finish(options.outputFileName, success = false, cancelled = false, error = e.message)
        } catch (e: Exception) {
            finish(options.outputFileName, success = false, cancelled = false, error = e.message ?: "เกิดข้อผิดพลาดที่ไม่คาดคิด")
        }
    }

    /**
     * วนเรียก [ArchiveEngine.compress] แยกทีละรายการต้นทาง คนละไฟล์ archive ต่อหนึ่งรายการ - ดู
     * class doc ด้านบนสำหรับเหตุผล ถ้ายกเลิกหรือ error กลางคัน archive ของรายการก่อนหน้าที่ทำสำเร็จ
     * ไปแล้วจะไม่ถูกลบทิ้ง (ต่างจาก ArchiveEngine ที่ cleanup เฉพาะ part ของรายการที่กำลังทำค้างอยู่)
     *
     * Test-only visibility (private -> internal), same reasoning as runSingleArchive() above.
     */
    internal suspend fun runSeparatePerItem(options: CompressOptions) {
        val total = options.sourceFiles.size
        var lastNotifyAt = 0L
        var lastArchiveName = options.outputFileName
        var completedCount = 0
        var cancelledMidway = false
        var failure: String? = null
        val createdPaths = mutableListOf<String>()
        val deletedPaths = mutableListOf<String>()

        for ((index, item) in options.sourceFiles.withIndex()) {
            val itemBaseName = if (item.isDirectory) item.name else item.nameWithoutExtension.ifEmpty { item.name }
            val itemFileName = uniqueName(options.outputDir, "$itemBaseName.${options.format.displayExtension}")
            val itemOptions = options.copy(
                sourceFiles = listOf(item),
                outputFileName = itemFileName,
                createSeparateArchivePerItem = false
            )
            lastArchiveName = itemFileName
            try {
                val createdFiles = ArchiveEngine.compress(
                    options = itemOptions,
                    onProgress = { percent ->
                        val overallPercent = ((index * 100) + percent) / total
                        broadcastProgress(overallPercent, itemFileName, index + 1, total)
                        val now = System.currentTimeMillis()
                        if (now - lastNotifyAt >= NOTIFY_THROTTLE_MS) {
                            lastNotifyAt = now
                            notificationManager.notify(NOTIFICATION_ID, buildNotification(itemFileName, overallPercent, index + 1, total).build())
                        }
                    },
                    onCancel = { if (cancelRequested) throw ArchiveCancelledException() }
                )
                notifyMediaScannerPaths(createdFiles.map { it.absolutePath })
                createdPaths += createdFiles.map { it.absolutePath }
                if (options.deleteSourceAfterCompress && item.deleteRecursivelyCompat()) deletedPaths += item.absolutePath
                completedCount++
            } catch (e: ArchiveCancelledException) {
                cancelledMidway = true
                break
            } catch (e: ArchiveEngineException) {
                failure = "${item.name}: ${e.message}"
                break
            } catch (e: Exception) {
                failure = "${item.name}: ${e.message ?: "เกิดข้อผิดพลาดที่ไม่คาดคิด"}"
                break
            }
        }

        val summaryName = if (total > 1) "$completedCount/$total รายการ" else lastArchiveName
        when {
            cancelledMidway -> finish(summaryName, success = false, cancelled = true, error = null,
                createdPaths = createdPaths, deletedPaths = deletedPaths)
            failure != null -> finish(summaryName, success = false, cancelled = false, error = failure,
                createdPaths = createdPaths, deletedPaths = deletedPaths)
            else -> finish(summaryName, success = true, cancelled = false, error = null,
                createdPaths = createdPaths, deletedPaths = deletedPaths)
        }
    }

    private fun finish(
        archiveName: String, success: Boolean, cancelled: Boolean, error: String?,
        createdPaths: List<String> = emptyList(), deletedPaths: List<String> = emptyList()
    ) {
        notificationManager.notify(NOTIFICATION_ID, buildNotification(archiveName, 100, 0, 0, done = true, success = success, cancelled = cancelled).build())
        broadcastDone(archiveName, success, cancelled, error, createdPaths, deletedPaths)
    }

    private fun buildNotification(
        archiveName: String,
        percent: Int,
        itemIndex: Int,
        totalItems: Int,
        done: Boolean = false,
        success: Boolean = true,
        cancelled: Boolean = false
    ): NotificationCompat.Builder {
        val itemSuffix = if (totalItems > 1) " (${itemIndex}/${totalItems})" else ""
        val title = when {
            !done -> "กำลังสร้างไฟล์ Archive$itemSuffix"
            cancelled -> "ยกเลิกการสร้างไฟล์ Archive แล้ว"
            success -> "สร้างไฟล์ Archive เสร็จแล้ว"
            else -> "สร้างไฟล์ Archive ไม่สำเร็จ"
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(if (done) archiveName else "$archiveName - $percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setAutoCancel(done)
            .setProgress(100, percent, false)
        if (!done) {
            val cancelIntent = Intent(this, CompressOperationService::class.java).apply { action = ACTION_CANCEL }
            val cancelPendingIntent = PendingIntent.getService(
                this, CANCEL_REQUEST_CODE, cancelIntent, PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "ยกเลิก", cancelPendingIntent)

            // แตะตัว notification เอง (ไม่ใช่ปุ่ม "ยกเลิก" ด้านบน) ตอนงานยังทำอยู่ - รวมถึงตอนที่
            // ผู้ใช้กด "ซ่อน" dialog ไปแล้ว - ให้เปิดแอปกลับมาพร้อมเรียก dialog กลับมาโผล่ ดู
            // MainActivity.onNewIntent()/handleReopenProgressIntent() เหมือนกับที่
            // ArchiveOperationService.kt ทำสำหรับฝั่งแตกไฟล์
            val contentIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_REOPEN_COMPRESS_PROGRESS, true)
            }
            val contentPendingIntent = PendingIntent.getActivity(
                this, CONTENT_REQUEST_CODE, contentIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.setContentIntent(contentPendingIntent)
        }
        return builder
    }

    private fun broadcastProgress(percent: Int, archiveName: String, itemIndex: Int, totalItems: Int) {
        sendBroadcast(Intent(BROADCAST_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_PERCENT, percent)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
            putExtra(EXTRA_ITEM_INDEX, itemIndex)
            putExtra(EXTRA_TOTAL_ITEMS, totalItems)
        })
    }

    private fun broadcastDone(
        archiveName: String, success: Boolean, cancelled: Boolean, error: String?,
        createdPaths: List<String> = emptyList(), deletedPaths: List<String> = emptyList()
    ) {
        sendBroadcast(Intent(BROADCAST_DONE).apply {
            setPackage(packageName)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
            putExtra(EXTRA_SUCCESS, success)
            putExtra(EXTRA_CANCELLED, cancelled)
            putExtra(EXTRA_ERROR, error)
            putStringArrayListExtra(EXTRA_CREATED_PATHS, ArrayList(createdPaths))
            putStringArrayListExtra(EXTRA_DELETED_PATHS, ArrayList(deletedPaths))
        })
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
