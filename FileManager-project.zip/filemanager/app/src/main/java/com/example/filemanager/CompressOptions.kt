package com.example.filemanager

import java.io.File

/**
 * ส่วนที่ 1/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน" (ถอดแบบมาจาก ZArchiver): Data Model ล้วน ๆ
 * ที่เก็บสเปกทั้งหมดของการสร้างไฟล์ archive หนึ่งครั้ง ไฟล์นี้ไม่มี logic การบีบอัดจริง -
 * นั่นเป็นหน้าที่ของ Engine/Service ที่จะเขียนในพาร์ทถัดไป CompressViewModel.kt เป็นตัวสร้าง/
 * ตรวจสอบค่า [CompressOptions] จากสิ่งที่ผู้ใช้เลือกในหน้า CompressDialog.kt แล้วส่งต่อให้ Engine
 *
 * หมายเหตุ: รายชื่อฟอร์แมตในไฟล์นี้ตั้งใจแยกจาก ArchiveManager.COMPRESS_FORMATS (ของเดิมที่
 * ArchiveDialogs.kt/MainActivity.kt ใช้อยู่ตอนนี้สำหรับเมนู "บีบอัด" แบบเดิม) เพราะดีไซน์ใหม่นี้
 * รองรับฟอร์แมต TAR ผสม (tar.gz, tar.bz2, tar.xz, tar.lz4, tar.zstd) เป็นตัวเลือกเดียวจบตามสเปก
 * ZArchiver ที่ขอมา การเชื่อมเข้ากับ Engine จริงจะทำในพาร์ทถัดไปโดยไม่ต้องแก้ enum เหล่านี้
 */

/** ฟอร์แมตไฟล์ archive ที่หน้า "สร้างไฟล์ Archive" รองรับ */
enum class CompressFormat(val displayExtension: String) {
    SEVEN_Z("7z"),
    ZIP("zip"),
    TAR("tar"),
    TAR_BZ2("tar.bz2"),
    TAR_GZ("tar.gz"),
    TAR_XZ("tar.xz"),
    TAR_LZ4("tar.lz4"),
    TAR_ZSTD("tar.zstd");

    /** true เฉพาะฟอร์แมตที่หน้า UI นี้เปิดให้ตั้งรหัสผ่าน/เข้ารหัสได้ (7z และ zip เท่านั้น -
     *  ฟอร์แมตตระกูล tar ไม่มีการเข้ารหัสในตัวมันเอง) */
    val supportsEncryption: Boolean
        get() = this == SEVEN_Z || this == ZIP

    companion object {
        val DEFAULT = ZIP
    }
}

/** ระดับการบีบอัด อิงมาตรฐานเดียวกับ 7-Zip/ZArchiver */
enum class CompressionLevel(val labelTh: String) {
    STORE("ไม่มีการบีบอัด"),
    FASTEST("เร็วที่สุด"),
    FAST("เร็ว"),
    NORMAL("ปกติ"),
    MAXIMUM("สูงสุด"),
    ULTRA("อัลตร้า");

    companion object {
        val DEFAULT = NORMAL
    }
}

/** วิธีเข้ารหัสไฟล์ archive - มีผลเฉพาะฟอร์แมตที่ [CompressFormat.supportsEncryption] เป็น true
 *  และมีการตั้งรหัสผ่านไว้จริงเท่านั้น */
enum class EncryptionType(val labelTh: String) {
    ZIP_CRYPTO("ข้อมูล (ZipCrypto)"),
    AES256("AES-256");

    companion object {
        val DEFAULT = AES256
    }
}

/**
 * ตัวเลือกขนาดสำหรับแยกไฟล์ archive เป็นหลายส่วน (split volume) ตามสเปก ZArchiver
 * [fixedBytes] เป็น null สำหรับ [NONE] (ไม่แยกไฟล์) และ [CUSTOM] (ผู้ใช้กรอกขนาดเอง -
 * ค่าจริงจะถูกคำนวณโดย CompressViewModel จากช่องกรอกขนาดกำหนดเอง ไม่ใช่จาก enum นี้)
 */
enum class SplitVolumeOption(val labelTh: String, val fixedBytes: Long?) {
    NONE("ไม่แยก", null),
    MB_5("5 MB", 5L * 1024 * 1024),
    MB_10("10 MB", 10L * 1024 * 1024),
    MB_24("24 MB", 24L * 1024 * 1024),
    MB_50("50 MB", 50L * 1024 * 1024),
    MB_100("100 MB", 100L * 1024 * 1024),
    CUSTOM("กำหนดเอง...", null);

    companion object {
        val DEFAULT = NONE
    }
}

/**
 * สเปกทั้งหมดของการสร้างไฟล์ archive หนึ่งครั้ง ตามที่ผู้ใช้กรอกในหน้า CompressDialog
 * ค่านี้ถูกสร้างโดย CompressViewModel.buildOptions() หลังผ่านการตรวจสอบ (validation) แล้วเท่านั้น
 * ชื่อไฟล์ปลายทาง ([outputFileName]) เป็นชื่อที่ resolve ไม่ให้ซ้ำกับไฟล์เดิมในโฟลเดอร์แล้ว
 *
 * @param volumeSizeBytes ขนาดต่อส่วนของ split volume เป็นไบต์ - 0L หมายถึง "ไม่แยกไฟล์"
 *   (ค่านี้ resolve มาจาก [SplitVolumeOption] แล้วโดย ViewModel ไม่ใช่ enum ตรง ๆ เพื่อให้ Engine
 *   ในพาร์ทถัดไปใช้ตัวเลขไบต์ได้เลยโดยไม่ต้องรู้จัก enum นี้)
 */
data class CompressOptions(
    val sourceFiles: List<File>,
    val outputDir: File,
    val outputFileName: String,
    val format: CompressFormat,
    val level: CompressionLevel,
    val volumeSizeBytes: Long,
    val password: String?,
    val encryptionType: EncryptionType,
    val deleteSourceAfterCompress: Boolean,
    val createSeparateArchivePerItem: Boolean
) {
    /** path เต็มของไฟล์ archive หลัก (ไฟล์ส่วนแรกเมื่อมีการแยก split volume) */
    val outputFile: File
        get() = File(outputDir, outputFileName)

    /** true เมื่อไฟล์นี้จะถูกเข้ารหัสจริง (ฟอร์แมตรองรับ + มีรหัสผ่านที่ไม่ว่าง) */
    val isEncrypted: Boolean
        get() = format.supportsEncryption && !password.isNullOrEmpty()

    /** true เมื่อจะมีการแยกไฟล์เป็นหลายส่วน (split volume) */
    val isSplit: Boolean
        get() = volumeSizeBytes > 0L
}
