package com.example.filemanager

import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * ส่วนที่ 3/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน": Progress Dialog ในแอปสำหรับ CompressOperationService
 * (คนละตัวกับ ArchiveProgressDialogHelper.kt เดิม ซึ่งใช้กับเมนู "บีบอัด"/"แตกไฟล์" แบบเก่าที่ยัง
 * ไม่รองรับยกเลิกกลางคัน) โครงหน้าตาเหมือนของเดิมทุกอย่าง ต่างกันแค่มีปุ่ม "ยกเลิก" เพิ่มมา ซึ่งเรียก
 * [CompressOperationService.requestCancel] ตรง ๆ - Engine (ArchiveEngine.kt) จะรับรู้ผ่าน onCancel
 * callback ที่ตรวจ flag นั้นอยู่แล้ว (ดู CompressOperationService.kt)
 *
 * ใช้ [MainActivity.startArchiveOperationWithNotificationCheck] ตัวเดิมร่วมกับฝั่ง zip/unzip เก่า
 * (ArchiveProgressDialogHelper.kt) ได้เลยโดยไม่ต้องแก้ - ฟังก์ชันนั้น generic อยู่แล้ว (แค่เช็ค/ขอ
 * สิทธิ์ POST_NOTIFICATIONS แล้วเรียก callback) ไม่ได้ผูกกับ ArchiveOperationService โดยเฉพาะ
 */

/** Rotation Safety #3: stable KornDialog id - see KornDialog.dismissStale()'s doc / the same
 * pattern used by ArchiveProgressDialogHelper.kt's ARCHIVE_PROGRESS_DIALOG_ID. */
private const val COMPRESS_PROGRESS_DIALOG_ID = "compress_progress"

internal fun MainActivity.showCompressProgressDialog() {
    if (compressProgressDialogHandle?.isShowing == true) return
    // Rotation Safety #3: see the matching comment in ArchiveProgressDialogHelper.kt's
    // showArchiveProgressDialog() - same reasoning, same fix, this dialog's own stable id.
    KornDialog.dismissStale(this, COMPRESS_PROGRESS_DIALOG_ID)
    val pad = dp(16)
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad / 2, pad, 0)
    }
    val label = TextView(this).apply { textSize = 14f }
    val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100
        isIndeterminate = false
    }
    val percentText = TextView(this).apply {
        gravity = Gravity.END
        textSize = 12f
    }
    container.addView(label, LinearLayout.LayoutParams(-1, -2))
    container.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    container.addView(percentText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

    compressProgressLabel = label
    compressProgressBar = bar
    compressProgressPercentText = percentText

    compressProgressDialogHandle = KornDialog.Builder(this, COMPRESS_PROGRESS_DIALOG_ID)
        .setTitle("กำลังสร้างไฟล์ Archive")
        .setView(container)
        .setCancelable(false)
        .setNegativeButton("ยกเลิก") { _, _ -> CompressOperationService.requestCancel(this) }
        .setNeutralButton("ซ่อน") { _, _ -> viewModel.setCompressDialogHidden(true) }
        .show()
}

internal fun MainActivity.updateCompressProgressDialog(state: MainViewModel.CompressOpUiState) {
    val itemSuffix = if (state.totalItems > 1) " (${state.currentItemIndex}/${state.totalItems})" else ""
    compressProgressLabel?.text = "กำลังสร้าง: ${state.archiveName}$itemSuffix"
    compressProgressBar?.progress = state.percent
    compressProgressPercentText?.text = "${state.percent}%"
}

internal fun MainActivity.dismissCompressProgressDialog() {
    compressProgressDialogHandle?.dismiss()
    compressProgressDialogHandle = null
    compressProgressLabel = null
    compressProgressBar = null
    compressProgressPercentText = null
}

/** Collects viewModel.compressOpState for the lifetime of the Activity and drives the dialog above. */
internal fun MainActivity.observeCompressOpState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            viewModel.compressOpState.collect { state ->
                when {
                    !state.isRunning -> dismissCompressProgressDialog()
                    state.hidden -> dismissCompressProgressDialog()
                    else -> {
                        showCompressProgressDialog()
                        updateCompressProgressDialog(state)
                    }
                }
            }
        }
    }
}
