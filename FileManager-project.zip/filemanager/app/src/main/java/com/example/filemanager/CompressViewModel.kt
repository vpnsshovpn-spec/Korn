package com.example.filemanager

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

/**
 * ส่วนที่ 2/3 ของฟีเจอร์ "สร้างไฟล์ ของฉัน": จัดการ State ทั้งหมดของหน้า CompressDialog
 * (ชื่อไฟล์, โฟลเดอร์ปลายทาง, ฟอร์แมต, ระดับการบีบอัด, รหัสผ่าน, การแยกไฟล์ ฯลฯ) และเป็นคนสร้าง
 * [CompressOptions] ที่ผ่านการตรวจสอบแล้วให้ CompressDialog.kt ส่งต่อให้ Engine ในพาร์ทถัดไป
 *
 * ไม่มี constructor argument (สร้างผ่าน `ViewModelProvider(activity)[CompressViewModel::class.java]`
 * แบบเดียวกับ MainViewModel) - ค่าตั้งต้นของแต่ละ Dialog มาจากการเรียก [init] ครั้งเดียวตอนเปิด
 */
class CompressViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CompressUiState())
    val uiState: StateFlow<CompressUiState> = _uiState.asStateFlow()

    /**
     * เรียกครั้งเดียวตอนเปิด Dialog เพื่อตั้งค่าเริ่มต้นจากไฟล์/โฟลเดอร์ที่ผู้ใช้เลือกไว้ก่อนเปิด
     * Dialog (จากหน้ารายการไฟล์). ถ้าเรียกซ้ำด้วยชุดไฟล์/โฟลเดอร์เดิม (เช่น Activity หมุนจอ) จะไม่
     * รีเซ็ตค่าที่ผู้ใช้แก้ไว้แล้วทิ้ง.
     */
    fun init(sourceFiles: List<File>, outputDir: File) {
        val current = _uiState.value
        if (current.sourceFiles == sourceFiles && current.outputDir == outputDir) return
        _uiState.value = CompressUiState(
            sourceFiles = sourceFiles,
            outputDir = outputDir,
            fileNameInput = defaultFileNameFor(sourceFiles, outputDir)
        )
    }

    private fun defaultFileNameFor(sourceFiles: List<File>, outputDir: File): String {
        val single = sourceFiles.singleOrNull()
        return when {
            single != null && single.isDirectory -> single.name
            single != null -> single.nameWithoutExtension.ifEmpty { single.name }
            sourceFiles.size > 1 -> outputDir.name.ifEmpty { "archive" }
            else -> "archive"
        }
    }

    fun setFileNameInput(value: String) {
        _uiState.update { it.copy(fileNameInput = value) }
    }

    fun setOutputDir(dir: File) {
        _uiState.update { it.copy(outputDir = dir) }
    }

    fun setFormat(format: CompressFormat) {
        _uiState.update { state ->
            // ฟอร์แมตที่ไม่รองรับการเข้ารหัสต้องล้างรหัสผ่านทิ้งด้วย ไม่งั้น buildOptions() อาจ
            // เผลอพกรหัสผ่านติดไปกับฟอร์แมตที่ Engine เข้ารหัสให้ไม่ได้ (เช่น tar เปล่า ๆ)
            if (format.supportsEncryption) {
                state.copy(format = format)
            } else {
                state.copy(format = format, password = "", isPasswordVisible = false)
            }
        }
    }

    fun setLevel(level: CompressionLevel) {
        _uiState.update { it.copy(level = level) }
    }

    fun setEncryptionType(type: EncryptionType) {
        _uiState.update { it.copy(encryptionType = type) }
    }

    fun setPassword(value: String) {
        _uiState.update { it.copy(password = value) }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun setSplitOption(option: SplitVolumeOption) {
        _uiState.update { it.copy(splitOption = option) }
    }

    fun setCustomVolumeSizeMbInput(value: String) {
        _uiState.update { it.copy(customVolumeSizeMbInput = value) }
    }

    fun setDeleteSourceAfterCompress(value: Boolean) {
        _uiState.update { it.copy(deleteSourceAfterCompress = value) }
    }

    fun setCreateSeparateArchivePerItem(value: Boolean) {
        _uiState.update { it.copy(createSeparateArchivePerItem = value) }
    }

    /** ใช้ชื่อไฟล์ที่ระบบแนะนำ (รันเลขอัตโนมัติ เช่น "file (1)") แทนชื่อที่ผู้ใช้พิมพ์ไว้ตอนชื่อซ้ำ */
    fun applySuggestedFileName() {
        val state = _uiState.value
        val suggested = state.suggestedFileName ?: return
        val nameWithoutExt = suggested.removeSuffix(".${state.format.displayExtension}")
        _uiState.update { it.copy(fileNameInput = nameWithoutExt) }
    }

    /**
     * สร้าง [CompressOptions] จากค่าปัจจุบันของ Dialog หลังผ่านการตรวจสอบแล้ว คืนค่า null ถ้า
     * ข้อมูลยังไม่ครบ/ไม่ถูกต้อง (ดู [CompressUiState.isConfirmEnabled]) - CompressDialog.kt ใช้ค่านี้
     * ปิดปุ่ม "ตกลง" อยู่แล้ว จึงไม่ควรเรียกฟังก์ชันนี้ได้ตอนข้อมูลไม่ครบในทางปฏิบัติ
     *
     * ชื่อไฟล์ที่ซ้ำกับไฟล์เดิมในโฟลเดอร์ปลายทางจะถูกรันเลขอัตโนมัติให้ ณ จุดนี้เสมอ (เช่น
     * "file (1).zip") ผู้ใช้ไม่จำเป็นต้องกดยืนยันชื่อที่แนะนำเองก่อนกด "ตกลง"
     */
    fun buildOptions(): CompressOptions? {
        val state = _uiState.value
        if (!state.isConfirmEnabled) return null
        val resolvedName = uniqueName(state.outputDir, state.fullFileName)
        return CompressOptions(
            sourceFiles = state.sourceFiles,
            outputDir = state.outputDir,
            outputFileName = resolvedName,
            format = state.format,
            level = state.level,
            volumeSizeBytes = state.volumeSizeBytes,
            password = state.password.ifEmpty { null },
            encryptionType = state.encryptionType,
            deleteSourceAfterCompress = state.deleteSourceAfterCompress,
            createSeparateArchivePerItem = state.createSeparateArchivePerItem
        )
    }
}

/**
 * State ทั้งหมดของหน้า CompressDialog ณ ขณะใดขณะหนึ่ง ทุก field ที่มาจาก dropdown/checkbox
 * เก็บเป็น enum/Boolean ตรง ๆ ส่วนช่องกรอกข้อความ (ชื่อไฟล์, รหัสผ่าน, ขนาด custom) เก็บเป็น
 * String ดิบตามที่ผู้ใช้พิมพ์ - ค่าที่ resolve แล้ว (เช่น [volumeSizeBytes], [fullFileName]) เป็น
 * computed property เพื่อไม่ให้ state สองส่วนขัดแย้งกันเอง
 */
data class CompressUiState(
    val sourceFiles: List<File> = emptyList(),
    val outputDir: File = File("/"),
    val fileNameInput: String = "",
    val format: CompressFormat = CompressFormat.DEFAULT,
    val level: CompressionLevel = CompressionLevel.DEFAULT,
    val splitOption: SplitVolumeOption = SplitVolumeOption.DEFAULT,
    val customVolumeSizeMbInput: String = "",
    val encryptionType: EncryptionType = EncryptionType.DEFAULT,
    val password: String = "",
    val isPasswordVisible: Boolean = false,
    val deleteSourceAfterCompress: Boolean = false,
    val createSeparateArchivePerItem: Boolean = false
) {
    val isSingleSource: Boolean
        get() = sourceFiles.size == 1

    /** true เมื่อฟอร์แมตปัจจุบันรองรับการเข้ารหัส (7z/zip) - ใช้ปิดการใช้งาน Dropdown/ช่องรหัสผ่านใน UI */
    val isEncryptionSupported: Boolean
        get() = format.supportsEncryption

    /** ชื่อไฟล์เต็มพร้อมนามสกุลตามฟอร์แมตปัจจุบัน (ยังไม่ผ่านการตรวจซ้ำกับไฟล์ที่มีอยู่) */
    val fullFileName: String
        get() {
            val base = fileNameInput.trim().ifEmpty { "archive" }
            return "$base.${format.displayExtension}"
        }

    /** true ถ้าชื่อไฟล์ที่จะสร้างซ้ำกับไฟล์ที่มีอยู่แล้วในโฟลเดอร์ปลายทาง */
    val isDuplicateName: Boolean
        get() = File(outputDir, fullFileName).exists()

    /** ชื่อไฟล์ที่แนะนำเมื่อชื่อซ้ำ (รันเลขอัตโนมัติ เช่น "file (1).zip") - null ถ้าไม่ซ้ำ */
    val suggestedFileName: String?
        get() = if (isDuplicateName) uniqueName(outputDir, fullFileName) else null

    /** ขนาด split volume เป็นไบต์ (0L = ไม่แยกไฟล์) แปลงจาก dropdown หรือช่องกำหนดเอง (หน่วย MB) */
    val volumeSizeBytes: Long
        get() = when (splitOption) {
            SplitVolumeOption.NONE -> 0L
            SplitVolumeOption.CUSTOM -> {
                val mb = customVolumeSizeMbInput.trim().toDoubleOrNull()
                if (mb == null || mb <= 0.0) 0L else (mb * 1024 * 1024).toLong()
            }
            else -> splitOption.fixedBytes ?: 0L
        }

    /** true เมื่อเลือก "กำหนดเอง" แต่กรอกขนาดไม่ถูกต้อง (ว่าง/ไม่ใช่ตัวเลข/≤0) */
    val isCustomVolumeSizeInvalid: Boolean
        get() = splitOption == SplitVolumeOption.CUSTOM &&
            (customVolumeSizeMbInput.trim().toDoubleOrNull()?.let { it <= 0.0 } ?: true)

    /** true เมื่อกรอกข้อมูลครบและกดปุ่ม "ตกลง" ได้ (ไม่บล็อกเรื่องชื่อซ้ำ เพราะจะรันเลขอัตโนมัติให้เอง) */
    val isConfirmEnabled: Boolean
        get() = sourceFiles.isNotEmpty() && fileNameInput.trim().isNotEmpty() && !isCustomVolumeSizeInvalid
}
