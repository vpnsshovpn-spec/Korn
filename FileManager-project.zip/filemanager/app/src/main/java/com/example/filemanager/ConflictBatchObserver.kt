package com.example.filemanager

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import java.io.File

/**
 * Rotation Safety #2: the "watch the ViewModel-held conflict batch and react to its current
 * head" loop that replaces the old local recursion in CopyMoveConflictResolver.kt/
 * ArchiveConflictResolver.kt. Split into its own file for the same reason
 * ArchiveProgressDialogHelper.kt's observeArchiveOpState() is - MainActivity.kt only wires up
 * the single onCreate() call that has to physically live there.
 *
 * Each collector re-fires whenever the batch StateFlow changes - including right after
 * Activity recreation (rotation, or a fresh Activity after the process was restarted and
 * MainViewModel's init restored a persisted batch from SavedStateHandle), because
 * repeatOnLifecycle(STARTED) re-subscribes and StateFlow always replays its latest value to a
 * new collector. That's what makes the dialog reappear automatically instead of the batch
 * silently stalling.
 *
 * showOrReplaceConflictDialog() below guards against showing a second dialog for the same
 * conflict item when this fires again for a reason other than "moved to a new conflict" (e.g.
 * STOPPED->STARTED on a screen that never actually left, or a duplicate emission) - the same
 * kind of dedup Rotation Safety #3 (progress dialog) still needs, called out in the handoff
 * status so both are recognized as the same class of fix.
 */
internal fun MainActivity.observeConflictBatches() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            launch {
                viewModel.copyMoveConflictBatch.collect { batch ->
                    if (batch == null) {
                        dismissConflictDialog()
                        return@collect
                    }
                    val current = batch.remaining.firstOrNull() ?: return@collect
                    if (batch.forcedAction != null) {
                        dismissConflictDialog()
                        applyCopyMoveResolution(batch, ConflictResolution(batch.forcedAction, applyToAll = true))
                    } else {
                        showOrReplaceConflictDialog(current, File(current).name) { resolution ->
                            applyCopyMoveResolution(batch, resolution)
                        }
                    }
                }
            }
            launch {
                viewModel.extractConflictBatch.collect { batch ->
                    if (batch == null) {
                        dismissConflictDialog()
                        return@collect
                    }
                    val current = batch.remaining.firstOrNull() ?: return@collect
                    if (batch.forcedAction != null) {
                        dismissConflictDialog()
                        applyExtractResolution(batch, ConflictResolution(batch.forcedAction, applyToAll = true))
                    } else {
                        showOrReplaceConflictDialog(current, File(current).name) { resolution ->
                            applyExtractResolution(batch, resolution)
                        }
                    }
                }
            }
        }
    }
}

/** Shows the shared conflict dialog for [key] (the conflicting file/entry's absolute path or
 * archive-relative path) unless one is already showing for that same [key] - avoids stacking a
 * second dialog when this collector re-fires for the batch's unchanged current head. */
private fun MainActivity.showOrReplaceConflictDialog(key: String, fileName: String, onResolved: (ConflictResolution) -> Unit) {
    if (conflictDialogShownForKey == key && conflictDialogHandle?.isShowing == true) return
    dismissConflictDialog()
    conflictDialogShownForKey = key
    conflictDialogHandle = showConflictDialog(fileName) { resolution ->
        conflictDialogShownForKey = null
        conflictDialogHandle = null
        onResolved(resolution)
    }
}

private fun MainActivity.dismissConflictDialog() {
    conflictDialogHandle?.dismiss()
    conflictDialogHandle = null
    conflictDialogShownForKey = null
}
