package com.example.filemanager

/**
 * The 4 choices offered when a Copy/Move/Extract destination file already exists.
 *
 * SKIP and CANCEL are deliberately distinct: SKIP leaves this one conflicting file
 * untouched and lets the rest of the batch continue; CANCEL stops the whole
 * operation immediately. They must never be merged into a single button.
 */
enum class ConflictAction {
    OVERWRITE,
    RENAME,
    SKIP,
    CANCEL
}

/**
 * The user's answer to a single conflict prompt.
 *
 * [applyToAll] is set when the user ticked "ใช้ตัวเลือกนี้กับไฟล์ที่เหลือทั้งหมด" - the
 * caller (ConflictScanner-driven loop in each service) is responsible for remembering
 * this and skipping further prompts for the rest of the batch, reusing [action] for
 * every remaining conflict. CANCEL always short-circuits the whole batch regardless
 * of [applyToAll].
 */
data class ConflictResolution(
    val action: ConflictAction,
    val applyToAll: Boolean
)
