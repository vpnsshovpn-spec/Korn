package com.example.filemanager

import java.io.File

/**
 * Finds which top-level items in [sources] would collide with something already
 * inside [destDir]. Mirrors the exact same name check FileOperationService has
 * always used internally (File(destDir, src.name)) - this just runs it ahead of
 * time, before anything is copied/moved/deleted, so the conflict dialog can ask
 * up front instead of the service silently auto-renaming mid-transfer.
 *
 * Only checks the top-level name (same granularity as the existing behavior) -
 * it does not recurse into folder contents.
 */
internal fun scanCopyMoveConflicts(sources: List<File>, destDir: File): List<File> =
    sources.filter { src -> File(destDir, src.name).existsCompat() }
