package com.example.filemanager

import android.widget.Toast
import java.io.File

/**
 * Orchestrates "scan for filename conflicts, ask the user one at a time, then start
 * the copy/move" for Copy/Move. This file only glues 3 already-separate pieces
 * together in the right order:
 *   - conflict detection:  ConflictScanner.kt   (scanCopyMoveConflicts)
 *   - the prompt itself:   ConflictDialogHelper.kt (showConflictDialog)
 *   - the actual transfer: FileOperationService.kt (unchanged transfer logic,
 *     just now told which paths to overwrite / which to leave out)
 *
 * ClipboardHelper.pasteClipboard() calls [startCopyMoveWithConflictCheck] instead of
 * calling FileOperationService.start() directly - no copy/move logic lives here.
 */
internal fun MainActivity.startCopyMoveWithConflictCheck(sources: List<File>, destDir: File, move: Boolean) {
    val conflicts = scanCopyMoveConflicts(sources, destDir)
    if (conflicts.isEmpty()) {
        FileOperationService.start(this, sources, destDir, move)
        Toast.makeText(this, if (move) "กำลังย้ายไฟล์ในพื้นหลัง…" else "กำลังคัดลอกไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
        return
    }
    resolveNextCopyMoveConflict(
        remaining = conflicts.toMutableList(),
        allSources = sources,
        destDir = destDir,
        move = move,
        overwritePaths = mutableSetOf(),
        skipPaths = mutableSetOf(),
        forcedAction = null
    )
}

/**
 * Walks [remaining] one conflicting file at a time. [forcedAction] is set once the
 * user has ticked "ใช้ตัวเลือกนี้กับไฟล์ที่เหลือทั้งหมด" on an earlier file in this same
 * batch - when set, later conflicts are resolved immediately with that same action
 * instead of showing the dialog again. RENAME needs nothing recorded (it's
 * FileOperationService's existing default whenever a path isn't in overwritePaths),
 * SKIP removes the item from the final source list, OVERWRITE is recorded so
 * FileOperationService replaces the existing destination instead of auto-renaming,
 * and CANCEL stops the whole batch immediately without starting the service at all.
 */
private fun MainActivity.resolveNextCopyMoveConflict(
    remaining: MutableList<File>,
    allSources: List<File>,
    destDir: File,
    move: Boolean,
    overwritePaths: MutableSet<String>,
    skipPaths: MutableSet<String>,
    forcedAction: ConflictAction?
) {
    if (remaining.isEmpty()) {
        val finalSources = allSources.filterNot { it.absolutePath in skipPaths }
        if (finalSources.isEmpty()) {
            Toast.makeText(this, "ไม่มีไฟล์ที่จะดำเนินการ (ข้ามทั้งหมด)", Toast.LENGTH_SHORT).show()
            return
        }
        FileOperationService.start(this, finalSources, destDir, move, overwritePaths)
        Toast.makeText(this, if (move) "กำลังย้ายไฟล์ในพื้นหลัง…" else "กำลังคัดลอกไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
        return
    }

    val current = remaining.removeAt(0)

    fun applyResolution(resolution: ConflictResolution) {
        when (resolution.action) {
            ConflictAction.OVERWRITE -> overwritePaths.add(current.absolutePath)
            ConflictAction.RENAME -> Unit
            ConflictAction.SKIP -> skipPaths.add(current.absolutePath)
            ConflictAction.CANCEL -> {
                Toast.makeText(this, "ยกเลิกการดำเนินการแล้ว", Toast.LENGTH_SHORT).show()
                return
            }
        }
        resolveNextCopyMoveConflict(
            remaining, allSources, destDir, move, overwritePaths, skipPaths,
            forcedAction = if (resolution.applyToAll) resolution.action else null
        )
    }

    if (forcedAction != null) {
        applyResolution(ConflictResolution(forcedAction, applyToAll = true))
    } else {
        showConflictDialog(current.name) { resolution -> applyResolution(resolution) }
    }
}
