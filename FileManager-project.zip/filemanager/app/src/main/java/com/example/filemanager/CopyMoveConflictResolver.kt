package com.example.filemanager

import android.widget.Toast
import java.io.File

/**
 * Orchestrates "scan for filename conflicts, ask the user one at a time, then start
 * the copy/move" for Copy/Move. This file only glues 3 already-separate pieces
 * together in the right order:
 *   - conflict detection:  ConflictScanner.kt   (scanCopyMoveConflicts)
 *   - the prompt itself:   ConflictDialogHelper.kt (showConflictDialog)
 *   - the actual transfer: FileOperationService.kt (unchanged transfer logic,
 *     just now told which paths to overwrite / which to leave out)
 *
 * ClipboardHelper.pasteClipboard() calls [startCopyMoveWithConflictCheck] instead of
 * calling FileOperationService.start() directly - no copy/move logic lives here.
 *
 * Rotation Safety #2: the batch (remaining conflicts, overwrite/skip sets, the
 * "apply to all" choice) is no longer walked via local recursion on this Activity's
 * call stack - it lives in MainViewModel.copyMoveConflictBatch (SavedStateHandle-backed,
 * survives process death, not just rotation). This file now only (a) starts a batch,
 * and (b) applies one resolution to the ViewModel-held batch and advances it. The
 * actual "watch the batch and show a dialog for its current head" loop lives in
 * ConflictBatchObserver.kt, the same split ArchiveProgressDialogHelper.kt already uses
 * for archiveOpState.
 */
internal fun MainActivity.startCopyMoveWithConflictCheck(sources: List<File>, destDir: File, move: Boolean) {
    val conflicts = scanCopyMoveConflicts(sources, destDir)
    if (conflicts.isEmpty()) {
        FileOperationService.start(this, sources, destDir, move)
        Toast.makeText(this, if (move) "กำลังย้ายไฟล์ในพื้นหลัง…" else "กำลังคัดลอกไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
        return
    }
    viewModel.startCopyMoveConflictBatch(
        MainViewModel.CopyMoveConflictBatch(
            allSourcePaths = sources.map { it.absolutePath },
            destDirPath = destDir.absolutePath,
            move = move,
            remaining = conflicts.map { it.absolutePath },
            overwritePaths = emptySet(),
            skipPaths = emptySet(),
            forcedAction = null
        )
    )
}

/**
 * Applies [resolution] to [batch]'s current head conflict (the first entry of
 * [MainViewModel.CopyMoveConflictBatch.remaining]) and pushes the advanced state back to
 * the ViewModel - either the next conflict to ask about, or (once remaining is empty)
 * finishing the batch by actually starting FileOperationService. Called from
 * ConflictBatchObserver.kt, both for a fresh dialog answer and to auto-apply an already-
 * recorded [MainViewModel.CopyMoveConflictBatch.forcedAction] without showing a dialog again.
 */
internal fun MainActivity.applyCopyMoveResolution(
    batch: MainViewModel.CopyMoveConflictBatch,
    resolution: ConflictResolution
) {
    val current = batch.remaining.firstOrNull() ?: return
    if (resolution.action == ConflictAction.CANCEL) {
        Toast.makeText(this, "ยกเลิกการดำเนินการแล้ว", Toast.LENGTH_SHORT).show()
        viewModel.clearCopyMoveConflictBatch()
        return
    }
    val nextBatch = batch.copy(
        remaining = batch.remaining.drop(1),
        overwritePaths = if (resolution.action == ConflictAction.OVERWRITE) batch.overwritePaths + current else batch.overwritePaths,
        skipPaths = if (resolution.action == ConflictAction.SKIP) batch.skipPaths + current else batch.skipPaths,
        forcedAction = if (resolution.applyToAll) resolution.action else batch.forcedAction
    )
    if (nextBatch.remaining.isEmpty()) {
        finishCopyMoveBatch(nextBatch)
    } else {
        viewModel.updateCopyMoveConflictBatch(nextBatch)
    }
}

private fun MainActivity.finishCopyMoveBatch(batch: MainViewModel.CopyMoveConflictBatch) {
    viewModel.clearCopyMoveConflictBatch()
    val finalSources = batch.allSourcePaths.filterNot { it in batch.skipPaths }.map { File(it) }
    if (finalSources.isEmpty()) {
        Toast.makeText(this, "ไม่มีไฟล์ที่จะดำเนินการ (ข้ามทั้งหมด)", Toast.LENGTH_SHORT).show()
        return
    }
    FileOperationService.start(this, finalSources, File(batch.destDirPath), batch.move, batch.overwritePaths)
    Toast.makeText(this, if (batch.move) "กำลังย้ายไฟล์ในพื้นหลัง…" else "กำลังคัดลอกไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
}
