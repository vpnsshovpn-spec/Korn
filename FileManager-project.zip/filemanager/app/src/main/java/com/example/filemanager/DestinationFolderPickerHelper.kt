package com.example.filemanager

import android.content.Context
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File

/**
 * STEP 17+ destination-folder picker UI.
 *
 * Owns the "เลือกโฟลเดอร์ปลายทาง" dialog used by move/copy/extract flows:
 * building the folder list, the favorite/sort top bar, and wiring taps to
 * navigate within the picker. Directory listing itself stays in
 * DirectoryBrowserHelper (subfolders()); MainActivity still owns the
 * current directory, sort state, bookmarks and the shared sort dialog, and
 * passes them in so this helper carries no directory/browsing state of its
 * own between calls to show().
 */
class DestinationFolderPickerHelper(
    private val context: Context,
    private val directoryBrowserHelper: DirectoryBrowserHelper,
    private val bookmarksManager: BookmarksManager,
    private val comparator: () -> Comparator<FileEntry>,
    private val dp: (Int) -> Int,
    private val showSortDialog: (onApplied: () -> Unit) -> Unit
) {

    /**
     * Shows the picker starting at [startDir]. Behavior matches the previous
     * MainActivity.chooseDestinationFolder() exactly: "⬆ .." navigation,
     * favorite-folder shortcut, in-dialog sort button, and confirming the
     * currently browsed folder via the positive button.
     */
    fun show(startDir: File, onSelected: (File) -> Unit) {
        var chooserDir = startDir

        fun sortedSubfolders(dir: File): List<File> =
            directoryBrowserHelper.subfolders(dir, comparator())

        val list = ListView(context)
        val adapter = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1)
        list.adapter = adapter

        fun refreshChooser() {
            adapter.clear()
            if (chooserDir.parentFile != null) adapter.add("⬆ ..")
            sortedSubfolders(chooserDir).forEach { adapter.add("📁 ${it.name}") }
            adapter.notifyDataSetChanged()
        }

        val topBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val favoriteButton = TextView(context).apply {
            text = "⭐ โปรดปราน"
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setTextColor(context.getColor(R.color.primary))
            isClickable = true
            isFocusable = true
            background = obtainSelectableItemBackground()
        }
        val sortButton = TextView(context).apply {
            text = "↕ เรียง"
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setTextColor(context.getColor(R.color.primary))
            isClickable = true
            isFocusable = true
            background = obtainSelectableItemBackground()
        }
        topBar.addView(favoriteButton)
        topBar.addView(sortButton)

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        container.addView(topBar, LinearLayout.LayoutParams(-1, -2))
        container.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val dialog = KornDialog.Builder(context)
            .setTitle("เลือกโฟลเดอร์ปลายทาง")
            .setView(container)
            .setPositiveButton("เลือกโฟลเดอร์นี้") { _, _ -> onSelected(chooserDir) }
            .setNegativeButton("ยกเลิก", null)
            .create()

        sortButton.setOnClickListener {
            // Same sort dialog + same comparator/SharedPreferences as the main screen;
            // it just refreshes this picker's list instead of the main file list.
            showSortDialog { refreshChooser() }
        }

        favoriteButton.setOnClickListener {
            val bookmarks = bookmarksManager.getAll()
            if (bookmarks.isEmpty()) {
                Toast.makeText(context, "ยังไม่มีรายการโปรด", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = bookmarks.map { it.name }.toTypedArray()
            KornDialog.Builder(context)
                .setTitle("ไปยังโฟลเดอร์โปรดปราน")
                .setItems(names) { _, which ->
                    val target = File(bookmarks[which].path)
                    if (target.isDirectory) {
                        chooserDir = target
                        refreshChooser()
                        dialog.setTitle("เลือกโฟลเดอร์: ${chooserDir.name.ifBlank { chooserDir.path }}")
                    } else {
                        Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        list.setOnItemClickListener { _, _, position, _ ->
            val parentOffset = if (chooserDir.parentFile != null) 1 else 0
            if (parentOffset == 1 && position == 0) {
                chooserDir.parentFile?.let { chooserDir = it }
            } else {
                val index = position - parentOffset
                sortedSubfolders(chooserDir).getOrNull(index)?.let { chooserDir = it }
            }
            refreshChooser()
            dialog.setTitle("เลือกโฟลเดอร์: ${chooserDir.name.ifBlank { chooserDir.path }}")
        }

        refreshChooser()
        dialog.show()
    }

    private fun obtainSelectableItemBackground(): android.graphics.drawable.Drawable? {
        val typedValue = TypedValue()
        context.theme.resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true)
        return ContextCompat.getDrawable(context, typedValue.resourceId)
    }
}
