package com.example.filemanager

import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * STEP 17+ directory breadcrumb UI helper.
 *
 * Owns only breadcrumb rendering/scrolling. Directory resolution and navigation
 * remain in DirectoryBrowserHelper/DirectoryNavigationHelper, while Activity
 * state and folder-opening behavior remain in MainActivity.
 */
class DirectoryBreadcrumbHelper(
    private val breadcrumbBar: LinearLayout,
    private val breadcrumbScroll: HorizontalScrollView,
    private val textPrimary: Int,
    private val textSecondary: Int,
    private val onFolderClick: (File) -> Unit
) {

    fun render(parts: List<DirectoryBrowserHelper.BreadcrumbPart>) {
        breadcrumbBar.removeAllViews()

        parts.forEachIndexed { index, part ->
            if (index > 0) {
                breadcrumbBar.addView(TextView(breadcrumbBar.context).apply {
                    text = ">"
                    textSize = 14f
                    setTextColor(breadcrumbBar.context.getColor(textSecondary))
                    setPadding(4, 0, 4, 0)
                    gravity = Gravity.CENTER_VERTICAL
                })
            }

            breadcrumbBar.addView(TextView(breadcrumbBar.context).apply {
                text = part.label
                textSize = 14f
                typeface = if (index == parts.lastIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(breadcrumbBar.context.getColor(textPrimary))
                setPadding(12, 8, 12, 8)
                isSingleLine = true
                setOnClickListener { onFolderClick(part.folder) }
                contentDescription = "ไปที่โฟลเดอร์ ${part.label}"
                isClickable = true
                isFocusable = true
            })
        }

        scrollToEnd()
    }

    fun showSpecialPath(label: String) {
        breadcrumbBar.removeAllViews()
        breadcrumbBar.addView(TextView(breadcrumbBar.context).apply {
            text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(breadcrumbBar.context.getColor(textPrimary))
            setPadding(12, 8, 12, 8)
        })
        scrollToEnd()
    }

    private fun scrollToEnd() {
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(View.FOCUS_RIGHT) }
    }
}
