package com.example.filemanager

import android.os.Environment
import java.io.File

/**
 * Directory-listing logic used by the normal file-browser screen.
 *
 * STEP 17+ starts by isolating the directory-resolution part of browsing from
 * MainActivity. This helper deliberately owns no Activity/UI state: it only
 * decides whether a directory can be reached and produces the filtered,
 * sorted FileEntry list. Navigation state, breadcrumbs, adapter updates and
 * other UI behavior remain in MainActivity so existing behavior is preserved.
 */
class DirectoryBrowserHelper {

    data class Result(
        val directory: File,
        val entries: List<FileEntry>
    )

    /**
     * Returns true when the directory can be reached either normally or through
     * the existing Shizuku compatibility layer.
     */
    fun canAccess(dir: File): Boolean =
        (dir.exists() && dir.canRead()) || dir.needsShizuku()

    /**
     * Loads one directory using the existing FileOpsCompat/Shizuku fallback,
     * hidden-file rule, root trash rule and caller-supplied sort order.
     *
     * No UI work is performed here. An unreadable/failed listing is represented
     * as an empty list, matching the existing safe behavior of the browser.
     */
    fun load(
        dir: File,
        showHidden: Boolean,
        comparator: Comparator<FileEntry>
    ): Result {
        val isRoot = isExternalStorageRoot(dir)
        val children = try {
            dir.listFilesCompat() ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }

        val entries = buildEntries(children, isRoot, showHidden, comparator)
        return Result(dir, entries)
    }

    /**
     * Builds the visible browser entries from already-resolved child files.
     * Keeping this transformation here means directory browsing owns its
     * filtering/sorting pipeline without changing how other flat views sort.
     */
    fun buildEntries(
        children: Iterable<File>,
        isRoot: Boolean,
        showHidden: Boolean,
        comparator: Comparator<FileEntry>
    ): List<FileEntry> {
        return children
            .asSequence()
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { !(isRoot && it.name == TrashManager.TRASH_FOLDER_NAME) }
            .map { FileEntry(it) }
            .sortedWith(comparator)
            .toList()
    }

    private fun isExternalStorageRoot(dir: File): Boolean {
        return try {
            dir.canonicalFile == Environment.getExternalStorageDirectory().canonicalFile
        } catch (_: Exception) {
            dir.absoluteFile == Environment.getExternalStorageDirectory().absoluteFile
        }
    }
}
