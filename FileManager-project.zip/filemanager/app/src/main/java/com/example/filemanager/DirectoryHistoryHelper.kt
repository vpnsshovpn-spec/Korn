package com.example.filemanager

import android.content.Context
import java.io.File

/**
 * STEP 17+ (next round): directory navigation history persistence.
 *
 * Owns only recent-folder and open-window persistence. MainActivity keeps
 * navigation state and UI/dialog ownership exactly as before.
 */
class DirectoryHistoryHelper(private val context: Context) {

    private companion object {
        const val RECENT_FOLDERS_PREFS = "recent_folders"
        const val OPEN_WINDOWS_PREFS = "korn_windows"
        const val PATHS_KEY = "paths"
        const val MAX_RECENT_FOLDERS = 15
        const val MAX_OPEN_WINDOWS = 12
    }

    fun rememberRecentFolder(dir: File, mode: MainActivity.Mode) {
        if (mode == MainActivity.Mode.TRASH || !dir.isDirectory) return

        val prefs = context.getSharedPreferences(RECENT_FOLDERS_PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(PATHS_KEY, "")!!.split("\n").filter { it.isNotBlank() }
        val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath })
            .take(MAX_RECENT_FOLDERS)
        prefs.edit().putString(PATHS_KEY, updated.joinToString("\n")).apply()
    }

    fun loadRecentFolders(): List<File> {
        val prefs = context.getSharedPreferences(RECENT_FOLDERS_PREFS, Context.MODE_PRIVATE)
        return prefs.getString(PATHS_KEY, "")!!.split("\n")
            .filter { it.isNotBlank() }
            .mapNotNull { File(it).takeIf { f -> f.isDirectory && f.canRead() } }
    }

    fun clearRecentHistory() {
        context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).edit().clear().apply()
        context.getSharedPreferences(RECENT_FOLDERS_PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun loadOpenWindows(): MutableList<String> {
        val raw = context.getSharedPreferences(OPEN_WINDOWS_PREFS, Context.MODE_PRIVATE)
            .getString(PATHS_KEY, "") ?: ""
        return raw.split("\n")
            .filter { it.isNotBlank() }
            .mapNotNull { path -> File(path).takeIf { it.isDirectory }?.absolutePath }
            .toMutableList()
    }

    fun saveOpenWindows(openWindows: List<String>) {
        context.getSharedPreferences(OPEN_WINDOWS_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(PATHS_KEY, openWindows.take(MAX_OPEN_WINDOWS).joinToString("\n"))
            .apply()
    }

    fun rememberOpenWindow(openWindows: MutableList<String>, dir: File) {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        openWindows.remove(path)
        openWindows.add(0, path)
        while (openWindows.size > MAX_OPEN_WINDOWS) openWindows.removeAt(openWindows.lastIndex)
        saveOpenWindows(openWindows)
    }
}
