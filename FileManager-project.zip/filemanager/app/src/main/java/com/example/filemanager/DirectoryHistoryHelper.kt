package com.example.filemanager

import android.content.Context
import java.io.File

/**
 * Persistence helpers for directory navigation history.
 *
 * This class owns only SharedPreferences-backed history data. UI state,
 * navigation mode and Activity lifecycle remain in MainActivity so existing
 * browsing behavior is preserved.
 */
class DirectoryHistoryHelper(private val context: Context) {

    fun rememberRecentFolder(dir: File, isTrashMode: Boolean) {
        if (isTrashMode || !dir.isDirectory) return

        val prefs = context.getSharedPreferences("recent_folders", Context.MODE_PRIVATE)
        val old = (prefs.getString("paths", "") ?: "")
            .split("\\n")
            .filter { it.isNotBlank() }
        val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath })
            .take(15)
        prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
    }

    fun loadRecentFolders(): List<File> {
        val prefs = context.getSharedPreferences("recent_folders", Context.MODE_PRIVATE)
        return (prefs.getString("paths", "") ?: "")
            .split("\\n")
            .filter { it.isNotBlank() }
            .mapNotNull { path ->
                File(path).takeIf { file -> file.isDirectory && file.canRead() }
            }
    }

    fun clearRecentHistory() {
        context.getSharedPreferences("recent_files", Context.MODE_PRIVATE).edit().clear().apply()
        context.getSharedPreferences("recent_folders", Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun loadOpenWindows(): List<String> {
        val raw = context.getSharedPreferences("korn_windows", Context.MODE_PRIVATE)
            .getString("paths", "") ?: ""
        return raw.split("\\n")
            .filter { it.isNotBlank() }
            .mapNotNull { path ->
                val file = File(path)
                file.takeIf { it.isDirectory }?.absolutePath
            }
    }

    fun saveOpenWindows(paths: List<String>) {
        context.getSharedPreferences("korn_windows", Context.MODE_PRIVATE)
            .edit()
            .putString("paths", paths.take(12).joinToString("\\n"))
            .apply()
    }

    fun rememberOpenWindow(dir: File, currentPaths: List<String>): List<String> {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        val updated = currentPaths.filter { it != path }.toMutableList()
        updated.add(0, path)
        while (updated.size > 12) updated.removeAt(updated.lastIndex)
        saveOpenWindows(updated)
        return updated
    }
}
