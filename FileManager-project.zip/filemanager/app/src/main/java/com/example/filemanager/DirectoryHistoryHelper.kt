package com.example.filemanager

import android.content.Context
import java.io.File
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer

/**
 * Persistence helpers for directory navigation history.
 *
 * This class owns only DataStore-backed history data. UI state, navigation mode and
 * Activity lifecycle remain in MainActivity so existing browsing behavior is preserved.
 *
 * Task 3: previously stored recent folders / open windows as a single SharedPreferences
 * string joined with "\n". That format silently corrupted (or dropped) any path
 * containing a literal backslash-n and had no room to grow (e.g. per-entry timestamps)
 * without inventing another delimiter. Now stored as a JSON string array via
 * [AppDataStore], one key per list. See [AppDataStore] for why reads/writes here stay
 * synchronous (`runBlocking` bridge) instead of suspend functions.
 */
class DirectoryHistoryHelper(private val context: Context) {

    companion object {
        private val KEY_RECENT_FOLDERS = AppDataStore.key("recent_folders_json")
        private val KEY_OPEN_WINDOWS = AppDataStore.key("open_windows_json")
    }

    suspend fun rememberRecentFolder(dir: File, isTrashMode: Boolean) {
        if (isTrashMode || !dir.isDirectory) return

        val old = AppDataStore.read(context, KEY_RECENT_FOLDERS, emptyList(), ListSerializer(String.serializer()))
        val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath }).take(15)
        AppDataStore.write(context, KEY_RECENT_FOLDERS, updated, ListSerializer(String.serializer()))
    }

    suspend fun loadRecentFolders(): List<File> {
        return AppDataStore.read(context, KEY_RECENT_FOLDERS, emptyList(), ListSerializer(String.serializer()))
            .mapNotNull { path ->
                File(path).takeIf { file -> file.isDirectory && file.canRead() }
            }
    }

    suspend fun clearRecentHistory() {
        AppDataStore.write(context, KEY_RECENT_FOLDERS, emptyList<String>(), ListSerializer(String.serializer()))
        AppDataStore.write(context, KEY_OPEN_WINDOWS, emptyList<String>(), ListSerializer(String.serializer()))
        // Also clears recently-opened *files* (FileOpenHelper.rememberRecentFile) - same
        // behavior as the old code, which cleared the "recent_files" SharedPreferences here.
        AppDataStore.write(context, RECENT_FILES_KEY, emptyList<String>(), ListSerializer(String.serializer()))
    }

    suspend fun loadOpenWindows(): List<String> {
        return AppDataStore.read(context, KEY_OPEN_WINDOWS, emptyList(), ListSerializer(String.serializer()))
            .mapNotNull { path ->
                File(path).takeIf { it.isDirectory }?.absolutePath
            }
    }

    suspend fun saveOpenWindows(paths: List<String>) {
        AppDataStore.write(context, KEY_OPEN_WINDOWS, paths.take(12), ListSerializer(String.serializer()))
    }

    suspend fun rememberOpenWindow(dir: File, currentPaths: List<String>): List<String> {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        val updated = currentPaths.filter { it != path }.toMutableList()
        updated.add(0, path)
        while (updated.size > 12) updated.removeAt(updated.lastIndex)
        saveOpenWindows(updated)
        return updated
    }
}
