package com.example.filemanager

import android.os.Environment
import java.io.File

/**
 * Pure navigation rules for the normal directory browser.
 *
 * This helper does not own Activity/UI state. It only resolves the parent
 * directory and the storage-root boundary so MainActivity keeps the existing
 * navigation behavior while the filesystem navigation rules have one place.
 */
class DirectoryNavigationHelper {

    /** Returns the canonical external-storage root when possible. */
    fun externalStorageRoot(): File = try {
        Environment.getExternalStorageDirectory().canonicalFile
    } catch (_: Exception) {
        Environment.getExternalStorageDirectory().absoluteFile
    }

    /** Returns the canonical form of a directory without throwing. */
    fun normalize(dir: File): File = try {
        dir.canonicalFile
    } catch (_: Exception) {
        dir.absoluteFile
    }

    /**
     * Returns the parent directory only when normal browsing may move upward.
     * At the external-storage root, null is returned to preserve the existing
     * MainActivity back-navigation behavior.
     */
    fun parentForBackNavigation(dir: File): File? {
        val current = normalize(dir)
        val root = externalStorageRoot()
        if (current == root) return null
        return current.parentFile
    }

    /** True when the directory is the normal external-storage root. */
    fun isExternalStorageRoot(dir: File): Boolean = normalize(dir) == externalStorageRoot()
}
