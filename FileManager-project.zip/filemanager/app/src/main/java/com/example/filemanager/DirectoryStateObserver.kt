package com.example.filemanager

import android.view.View
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Collects the ViewModel's directory listing state + one-off events for as long as the
 * Activity is at least STARTED. Called once from onCreate(). Split out of MainActivity.kt
 * (see MainActivity-Slimdown-Plan.txt ก้อน 3.5 - the highest-risk block in the slimdown plan,
 * done last and only after rounds A/B/C above built cleanly): this is the collection point
 * for viewModel.events (FileOpDone/ArchiveOpDone), which also drives the Local Search Index
 * refresh (refreshSearchIndexAfterFileChange(), see MainActivity.kt), and it reaches directly
 * into several Activity fields (swipeRefresh, adapter, supportActionBar, trashActionBar,
 * viewModel.mode) plus WindowsAndHistoryHelper.kt's rememberRecentFolder()/rememberOpenWindow().
 *
 * Side effects that still require an Activity Context (recent-folder history, open-window
 * bookkeeping, breadcrumb rendering, the storage usage bar) run here, right after a
 * *successful* (non-loading) state lands - the same points in time the old synchronous
 * loadDirectory() used to run them.
 */
internal fun MainActivity.observeDirectoryState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            launch {
                viewModel.directoryState.collect { state ->
                    swipeRefresh.isRefreshing = state.isLoading
                    if (state.isLoading) return@collect
                    // Bug fix: directoryState is a StateFlow, so it replays its last
                    // cached value to every new collector - including one started by
                    // an Activity recreate (screen rotation) while the user is in a
                    // non-NORMAL mode (trash/category/search/apps), which never updates
                    // directoryState itself. Without this guard, that stale replay
                    // silently overwrites the trash/category/search/apps view that
                    // refreshCurrentView() just rendered, making it look like rotating
                    // the screen kicks the user back to normal browsing on its own.
                    if (viewModel.mode.value != MainActivity.Mode.NORMAL) return@collect

                    trashActionBar.visibility = View.GONE
                    adapter.updateItems(state.entries, showFullPath = false)
                    supportActionBar?.subtitle = state.subtitle
                    rememberRecentFolder(state.currentDir)
                    rememberOpenWindow(state.currentDir)
                    renderBreadcrumbs(state.currentDir)
                    updateStorageBar()
                }
            }
            launch {
                viewModel.events.collect { event ->
                    when (event) {
                        is MainViewModel.UiEvent.Toast -> {
                            Toast.makeText(this@observeDirectoryState, event.message, Toast.LENGTH_SHORT).show()
                            swipeRefresh.isRefreshing = false
                        }
                        is MainViewModel.UiEvent.FileOpDone -> {
                            if (event.failures.isEmpty()) {
                                Toast.makeText(
                                    this@observeDirectoryState,
                                    "เสร็จสิ้น ${event.doneCount}/${event.totalCount} รายการ",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                KornDialog.Builder(this@observeDirectoryState)
                                    .setTitle("เสร็จสิ้น ${event.doneCount}/${event.totalCount} รายการ")
                                    .setMessage("รายการที่ไม่สำเร็จ:\n" + event.failures.joinToString("\n"))
                                    .setPositiveButton("ตกลง", null)
                                    .show()
                            }
                            // Auto-Clear Selection: FileOpDone คือจุดจบของงานคัดลอก/ย้ายจริง
                            // (paste คลิปบอร์ดที่มาจาก copySelected()/moveSelected() ซึ่งเลือกไฟล์
                            // จาก selection mode ก่อนจะ exitSelectionMode() ไปตั้งแต่ตอนกดคัดลอก/
                            // ย้ายแล้ว) - ถ้าเข้าสู่ selection mode ใหม่ระหว่างที่งานพื้นหลังยังทำอยู่
                            // (เช่นเลือกไฟล์ชุดใหม่ระหว่างรองาน paste เดิม) ให้เคลียร์ทิ้งตอนงานเสร็จ
                            // ด้วยเหมือนกัน ไม่ต้องรอผู้ใช้กด "ยกเลิก" เอง
                            if (adapter.selectionMode) exitSelectionMode()
                            if (viewModel.mode.value == MainActivity.Mode.NORMAL) loadDirectory(viewModel.currentDir.value) else refreshCurrentView()
                            // Local Search Index รอบ 2 (ข้อ 6.2): rebuild index หลัง copy/move/
                            // delete/rename ที่สำเร็จอย่างน้อย 1 รายการจริงเท่านั้น (ไม่ใช่ตอน
                            // ทุกรายการ fail หมด) — จุดรวมเดียวแทนที่จะไล่ hook ทุก helper แยกกัน
                            if (event.doneCount > 0) refreshSearchIndexAfterFileChange()
                        }
                        is MainViewModel.UiEvent.ArchiveOpDone -> {
                            val verb = if (event.isUnzip) "แตกไฟล์" else "บีบอัด"
                            if (event.success) {
                                Toast.makeText(this@observeDirectoryState, "${verb}เสร็จแล้ว: ${event.archiveName}", Toast.LENGTH_LONG).show()
                                // Auto-Clear Selection: เฉพาะตอนสำเร็จจริง - ตอนล้มเหลวคงการเลือก
                                // ไว้ให้ผู้ใช้ลองใหม่ได้โดยไม่ต้องเลือกไฟล์ซ้ำ
                                if (adapter.selectionMode) exitSelectionMode()
                            } else {
                                Toast.makeText(this@observeDirectoryState, "${verb}ไม่สำเร็จ: ${event.error}", Toast.LENGTH_LONG).show()
                            }
                            refreshCurrentView()
                            // Local Search Index รอบ 2: extract/compress สำเร็จก็นับเป็น "ไฟล์
                            // เปลี่ยน" เหมือนกัน — refresh เฉพาะตอน success == true เท่านั้น
                            if (event.success) refreshSearchIndexAfterFileChange()
                        }
                        is MainViewModel.UiEvent.CompressOpDone -> {
                            // showCreateArchiveDialog() (Part 3/3 "สร้างไฟล์ ของฉัน") is a
                            // separate, newer path from the legacy ArchiveOpDone above - see
                            // CompressOperationService.kt's class doc. Same local-search-index
                            // refresh convention as ArchiveOpDone: only on a real success.
                            when {
                                event.cancelled -> {
                                    Toast.makeText(this@observeDirectoryState, "ยกเลิกแล้ว", Toast.LENGTH_SHORT).show()
                                    refreshCurrentView()
                                }
                                event.success -> {
                                    Toast.makeText(this@observeDirectoryState, "สร้างไฟล์ Archive เสร็จแล้ว: ${event.archiveName}", Toast.LENGTH_LONG).show()
                                    // Auto-Clear Selection: บีบอัดสำเร็จแล้ว - ไฟล์ต้นทางที่เลือกไว้
                                    // ไม่มีประโยชน์ต้องค้างเป็นสถานะเลือกอยู่ต่อ
                                    if (adapter.selectionMode) exitSelectionMode()
                                    refreshCurrentView()
                                    refreshSearchIndexAfterFileChange()
                                }
                                else -> {
                                    Toast.makeText(this@observeDirectoryState, "สร้างไฟล์ Archive ไม่สำเร็จ: ${event.error}", Toast.LENGTH_LONG).show()
                                    refreshCurrentView()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
