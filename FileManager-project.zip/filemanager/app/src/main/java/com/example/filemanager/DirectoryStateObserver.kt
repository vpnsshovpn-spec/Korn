package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import com.example.filemanager.ui.selection.exitSelectionMode
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import java.io.File

/**
 * Collects the ViewModel's directory listing state + one-off events for as long as the
 * Activity is at least STARTED. Called once from onCreate(). Split out of MainActivity.kt
 * (see MainActivity-Slimdown-Plan.txt ก้อน 3.5 - the highest-risk block in the slimdown plan,
 * done last and only after rounds A/B/C above built cleanly): this is the collection point
 * for the ViewModel event flows (see observeFileOperationEvents()/observeArchiveOperationEvents()
 * below), which also drive the Local Search
 * Index refresh (refreshSearchIndexAfterFileChange(), see MainActivity.kt), and it reaches directly
 * into several Activity fields (swipeRefresh, adapter, supportActionBar, trashActionBar,
 * directoryViewModel.mode) plus WindowsAndHistoryHelper.kt's rememberRecentFolder()/rememberOpenWindow().
 *
 * Side effects that still require an Activity Context (recent-folder history, open-window
 * bookkeeping, breadcrumb rendering, the storage usage bar) run here, right after a
 * *successful* (non-loading) state lands - the same points in time the old synchronous
 * loadDirectory() used to run them.
 */
/**
 * Round 2 (MainViewModel split, step 2 of 4): copy/move completion (formerly
 * MainViewModel.UiEvent.FileOpDone, handled inline inside observeDirectoryState()'s
 * viewModel.events collector) now arrives on FileOperationViewModel.events instead - see that
 * class's doc for why it has its own small event flow. Logic is unchanged from before the
 * move, only the source flow and the event type name (FileOpDoneEvent, not
 * MainViewModel.UiEvent.FileOpDone). Wired from MainActivity.onCreate(), same as
 * observeDirectoryState().
 */
/**
 * Round 2 (MainViewModel split, step 3 of 4): archive/compress operation completion (formerly
 * MainViewModel.UiEvent.Toast/ArchiveOpDone/CompressOpDone, handled inline inside
 * observeDirectoryState()'s viewModel.events collector) now arrives on
 * archiveOperationViewModel.events instead - see that class's doc for why it has its own small
 * event flow (same "collector per ViewModel" pattern as observeFileOperationEvents() above).
 * Logic is unchanged from before the move, only the source flow and event type names
 * (ArchiveOperationViewModel.UiEvent, not MainViewModel.UiEvent). Wired from
 * MainActivity.onCreate(), same as the others.
 */
internal fun MainActivity.observeArchiveOperationEvents() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            archiveOperationViewModel.events.collect { event ->
                when (event) {
                    is ArchiveOperationViewModel.UiEvent.Toast -> {
                        Toast.makeText(this@observeArchiveOperationEvents, event.message, Toast.LENGTH_SHORT).show()
                        swipeRefresh.isRefreshing = false
                    }
                    is ArchiveOperationViewModel.UiEvent.ArchiveOpDone -> {
                        val verb = if (event.isUnzip) "แตกไฟล์" else "บีบอัด"
                        if (event.success) {
                            Toast.makeText(this@observeArchiveOperationEvents, "${verb}เสร็จแล้ว: ${event.archiveName}", Toast.LENGTH_LONG).show()
                            // Auto-Clear Selection: เฉพาะตอนสำเร็จจริง - ตอนล้มเหลวคงการเลือก
                            // ไว้ให้ผู้ใช้ลองใหม่ได้โดยไม่ต้องเลือกไฟล์ซ้ำ
                            if (adapter.selectionMode) exitSelectionMode()
                        } else {
                            Toast.makeText(this@observeArchiveOperationEvents, "${verb}ไม่สำเร็จ: ${event.error}", Toast.LENGTH_LONG).show()
                        }
                        refreshCurrentView()
                        // Archive extraction reports the exact destination. Update only that
                        // subtree on success; keep the full rebuild helper as a fallback for
                        // operations whose exact paths are unavailable.
                        if (event.success) {
                            val destination = event.destinationPath?.let { File(it) }
                            if (destination != null) {
                                refreshSearchIndexIncremental { searchIndexManager.indexSubtree(destination) }
                            } else {
                                refreshSearchIndexAfterFileChange()
                            }
                        }
                    }
                    is ArchiveOperationViewModel.UiEvent.CompressOpDone -> {
                        // showCreateArchiveDialog() (Part 3/3 "สร้างไฟล์ ของฉัน") is a
                        // separate, newer path from the legacy ArchiveOpDone above - see
                        // CompressOperationService.kt's class doc. Same local-search-index
                        // refresh convention as ArchiveOpDone: only on a real success.
                        when {
                            event.cancelled -> {
                                Toast.makeText(this@observeArchiveOperationEvents, "ยกเลิกแล้ว", Toast.LENGTH_SHORT).show()
                                refreshCurrentView()
                            }
                            event.success -> {
                                Toast.makeText(this@observeArchiveOperationEvents, "สร้างไฟล์ Archive เสร็จแล้ว: ${event.archiveName}", Toast.LENGTH_LONG).show()
                                // Auto-Clear Selection: บีบอัดสำเร็จแล้ว - ไฟล์ต้นทางที่เลือกไว้
                                // ไม่มีประโยชน์ต้องค้างเป็นสถานะเลือกอยู่ต่อ
                                if (adapter.selectionMode) exitSelectionMode()
                                refreshCurrentView()
                                if (event.createdPaths.isNotEmpty() || event.deletedPaths.isNotEmpty()) {
                                    refreshSearchIndexIncremental {
                                        event.deletedPaths.forEach { searchIndexManager.removeFromIndex(File(it)) }
                                        event.createdPaths.forEach { path ->
                                            val file = File(path)
                                            if (file.isDirectory) searchIndexManager.indexSubtree(file)
                                            else searchIndexManager.indexFile(file)
                                        }
                                    }
                                } else {
                                    refreshSearchIndexAfterFileChange()
                                }
                            }
                            else -> {
                                Toast.makeText(this@observeArchiveOperationEvents, "สร้างไฟล์ Archive ไม่สำเร็จ: ${event.error}", Toast.LENGTH_LONG).show()
                                refreshCurrentView()
                            }
                        }
                    }
                }
            }
        }
    }
}

internal fun MainActivity.observeFileOperationEvents() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            fileOperationViewModel.events.collect { event ->
                if (event.failures.isEmpty()) {
                    Toast.makeText(
                        this@observeFileOperationEvents,
                        "เสร็จสิ้น ${event.doneCount}/${event.totalCount} รายการ",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    KornDialog.Builder(this@observeFileOperationEvents)
                        .setTitle("เสร็จสิ้น ${event.doneCount}/${event.totalCount} รายการ")
                        .setMessage("รายการที่ไม่สำเร็จ:\n" + event.failures.joinToString("\n"))
                        .setPositiveButton("ตกลง", null)
                        .show()
                }
                // Auto-Clear Selection: FileOpDone คือจุดจบของงานคัดลอก/ย้ายจริง
                // (paste คลิปบอร์ดที่มาจาก copySelected()/moveSelected() ซึ่งเลือกไฟล์
                // จาก selection mode ก่อนจะ exitSelectionMode() ไปตั้งแต่ตอนกดคัดลอก/
                // ย้ายแล้ว) - ถ้าเข้าสู่ selection mode ใหม่ระหว่างที่งานพื้นหลังยังทำอยู่
                // (เช่นเลือกไฟล์ชุดใหม่ระหว่างรองาน paste เดิม) ให้เคลียร์ทิ้งตอนงานเสร็จ
                // ด้วยเหมือนกัน ไม่ต้องรอผู้ใช้กด "ยกเลิก" เอง
                if (adapter.selectionMode) exitSelectionMode()
                if (directoryViewModel.mode.value == MainActivity.Mode.NORMAL) loadDirectory(directoryViewModel.currentDir.value) else refreshCurrentView()
                // Local Search Index: background copy/move now reports exact successful
                // changes. Use incremental updates for the normal path; only fall back to a
                // full rebuild when a partial/uncertain filesystem operation could have left
                // the destination in an unknown state.
                if (event.indexNeedsFullSync) {
                    refreshSearchIndexAfterFileChange()
                } else if (event.doneCount > 0) {
                    refreshSearchIndexIncremental {
                        event.indexRemovals.forEach { searchIndexManager.removeFromIndex(File(it)) }
                        event.indexMoves.forEach { encoded ->
                            val parts = encoded.split('\u0000', limit = 2)
                            if (parts.size == 2) {
                                searchIndexManager.renameOrMoveInIndex(File(parts[0]), File(parts[1]))
                            }
                        }
                        event.indexAdds.forEach { path ->
                            val file = File(path)
                            if (file.isDirectory) searchIndexManager.indexSubtree(file)
                            else searchIndexManager.indexFile(file)
                        }
                    }
                }
            }
        }
    }
}

internal fun MainActivity.observeDirectoryState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            launch {
                directoryViewModel.directoryState.collect { state ->
                    swipeRefresh.isRefreshing = state.isLoading
                    if (state.isLoading) return@collect
                    // Bug fix: directoryState is a StateFlow, so it replays its last
                    // cached value to every new collector - including one started by
                    // an Activity recreate (screen rotation) while the user is in a
                    // non-NORMAL mode (trash/category/search/apps), which never updates
                    // directoryState itself. Without this guard, that stale replay
                    // silently overwrites the trash/category/search/apps view that
                    // refreshCurrentView() just rendered, making it look like rotating
                    // the screen kicks the user back to normal browsing on its own.
                    if (directoryViewModel.mode.value != MainActivity.Mode.NORMAL) return@collect

                    trashActionBar.visibility = View.GONE
                    adapter.updateItems(state.entries, showFullPath = false)
                    supportActionBar?.subtitle = state.subtitle
                    rememberRecentFolder(state.currentDir)
                    rememberOpenWindow(state.currentDir)
                    renderBreadcrumbs(state.currentDir)
                    updateStorageBar()
                }
            }
            launch {
                // Round 2 (MainViewModel split, step 1 of 4): loadDirectory()'s "access denied"
                // toast now comes through DirectoryViewModel's own small toastEvents flow
                // instead of MainViewModel's shared UiEvent bus - see DirectoryViewModel.kt's
                // class doc for why.
                directoryViewModel.toastEvents.collect { message ->
                    Toast.makeText(this@observeDirectoryState, message, Toast.LENGTH_SHORT).show()
                    swipeRefresh.isRefreshing = false
                }
            }
        }
    }
}
