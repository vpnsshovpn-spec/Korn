package com.example.filemanager

import com.example.filemanager.ui.directory.DirectoryBrowserHelper
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): everything to do
 * with "where is the user browsing and how is it displayed" now lives here instead of
 * MainViewModel - currentDir/lastNormalDir/mode/category filter (Round 16, SavedStateHandle-
 * backed since Round 22), sort key/ascending + showHidden + grid/view mode (Round 14), and the
 * directoryState listing itself + its loadDirectory() loader (Round 17, Task 1). This is a pure
 * move: no logic changed, only which class owns the state - see round1-fix-handoff.txt-style
 * caution for round 2 itself in refactor-instructions.txt ("ห้ามแก้ชื่อคลาส/ฟังก์ชันระหว่างย้าย").
 *
 * [toastEvents] is a small local counterpart to MainViewModel.UiEvent.Toast, needed only
 * because loadDirectory()'s "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้" toast used to be emitted through
 * MainViewModel's shared _events SharedFlow. Splitting the ViewModel means this class can't
 * reach into MainViewModel's private _events, so it gets its own minimal event flow instead of
 * introducing a ViewModel-to-ViewModel dependency. MainActivity collects both.
 */
class DirectoryViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val directoryBrowserHelper = DirectoryBrowserHelper()

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val toastEvents: SharedFlow<String> = _toastEvents

    // ---------- Settings / display state (Round 14) ----------

    private val _showHidden = MutableStateFlow(false)
    val showHidden: StateFlow<Boolean> = _showHidden
    fun setShowHidden(value: Boolean) { _showHidden.value = value }

    private val _sortKey = MutableStateFlow(MainActivity.SortKey.NAME)
    internal val sortKey: StateFlow<MainActivity.SortKey> = _sortKey
    internal fun setSortKey(value: MainActivity.SortKey) { _sortKey.value = value }

    private val _sortAscending = MutableStateFlow(true)
    val sortAscending: StateFlow<Boolean> = _sortAscending
    fun setSortAscending(value: Boolean) { _sortAscending.value = value }

    private val _isGridMode = MutableStateFlow(false)
    val isGridMode: StateFlow<Boolean> = _isGridMode
    fun setIsGridMode(value: Boolean) { _isGridMode.value = value }

    private val _fileViewMode = MutableStateFlow(FileAdapter.ViewMode.LIST)
    val fileViewMode: StateFlow<FileAdapter.ViewMode> = _fileViewMode
    fun setFileViewMode(value: FileAdapter.ViewMode) { _fileViewMode.value = value }

    // ---------- Navigation / directory state (Round 16; process-death survival added Round 22) ----------
    //
    // Round 22: this block is what "SavedStateHandle" work means in practice. A plain
    // MutableStateFlow only lives in RAM - it survives screen rotation (the ViewModel
    // instance itself is kept), but not "process death" (Android killing the whole app
    // process in the background under memory pressure, e.g. because another app needed
    // the RAM). SavedStateHandle is backed by a small Bundle that Android itself saves to
    // disk before killing the process, and restores before this ViewModel is even
    // constructed again - so every setter below now writes through to it, and every
    // initial value below reads back from it first. Scope is deliberately limited to
    // "where was the user browsing" (folder, mode, category) - this is what actually
    // matters if the app reappears from a cold start after being killed.

    private val _currentDir = MutableStateFlow(
        savedStateHandle.get<String>(KEY_CURRENT_DIR)?.let { File(it) }
            ?: android.os.Environment.getExternalStorageDirectory()
    )
    val currentDir: StateFlow<File> = _currentDir
    fun setCurrentDir(value: File) {
        _currentDir.value = value
        savedStateHandle[KEY_CURRENT_DIR] = value.absolutePath
    }

    private val _lastNormalDir = MutableStateFlow(
        savedStateHandle.get<String>(KEY_LAST_NORMAL_DIR)?.let { File(it) }
            ?: android.os.Environment.getExternalStorageDirectory()
    )
    val lastNormalDir: StateFlow<File> = _lastNormalDir
    fun setLastNormalDir(value: File) {
        _lastNormalDir.value = value
        savedStateHandle[KEY_LAST_NORMAL_DIR] = value.absolutePath
    }

    private val _mode = MutableStateFlow(
        savedStateHandle.get<String>(KEY_MODE)?.let { name ->
            runCatching { MainActivity.Mode.valueOf(name) }.getOrNull()
        } ?: MainActivity.Mode.NORMAL
    )
    val mode: StateFlow<MainActivity.Mode> = _mode
    fun setMode(value: MainActivity.Mode) {
        _mode.value = value
        savedStateHandle[KEY_MODE] = value.name
    }

    private val _currentCategoryLabel = MutableStateFlow(savedStateHandle.get<String>(KEY_CATEGORY_LABEL))
    val currentCategoryLabel: StateFlow<String?> = _currentCategoryLabel
    fun setCurrentCategoryLabel(value: String?) {
        _currentCategoryLabel.value = value
        savedStateHandle[KEY_CATEGORY_LABEL] = value
    }

    private val _currentCategoryExts = MutableStateFlow(
        savedStateHandle.get<ArrayList<String>>(KEY_CATEGORY_EXTS)?.toSet()
    )
    val currentCategoryExts: StateFlow<Set<String>?> = _currentCategoryExts
    fun setCurrentCategoryExts(value: Set<String>?) {
        _currentCategoryExts.value = value
        savedStateHandle[KEY_CATEGORY_EXTS] = value?.let { ArrayList(it) }
    }

    // ---------- Directory listing data flow (Round 17 / Task 1) ----------

    /**
     * Everything MainActivity needs to render the normal-browse file list, in one snapshot.
     * isLoading defaults to true so the very first, empty placeholder value emitted to a
     * fresh collector (before checkPermissionsAndLoad() triggers the first real load) is
     * skipped rather than treated as "loaded an empty root folder" - see observeDirectoryState().
     */
    data class DirectoryUiState(
        val currentDir: File = android.os.Environment.getExternalStorageDirectory(),
        val entries: List<FileEntry> = emptyList(),
        val subtitle: String = "",
        val isLoading: Boolean = true
    )

    private val _directoryState = MutableStateFlow(DirectoryUiState())
    val directoryState: StateFlow<DirectoryUiState> = _directoryState.asStateFlow()

    private var loadJob: Job? = null

    /**
     * Removes [file] from the currently-shown entries *immediately*, in memory, without waiting
     * for a fresh disk scan. A no-op if [file] isn't in the list currently being shown (e.g. a
     * different folder, or a search/category view where MainActivity handles its own list state).
     *
     * บั๊กเดิม: หลังลบไฟล์สำเร็จ (เช่น ย้ายเข้าถังขยะ) โค้ดเดิมเรียก refreshCurrentView() ทันที
     * ซึ่งไปเรียก loadDirectory() ที่เป็น "fire and forget" - แค่ยิง coroutine ใหม่ไปสแกน disk
     * ใหม่ทั้งโฟลเดอร์ (listFilesCompat + เรียงลำดับใหม่) แล้ว return ทันทีโดยไม่รอผลลัพธ์จริง
     * ผลคือ toast "ย้ายไปถังขยะแล้ว" ขึ้นทันที แต่ตัวลิสต์ยังโชว์ไฟล์เดิมค้างอยู่จนกว่าการสแกนใหม่
     * (ซึ่งช้ากว่าอย่างเห็นได้ชัดในโฟลเดอร์ที่มีไฟล์เยอะ) จะเสร็จแล้วอัปเดต state จริง ๆ ทำให้ดู
     * เหมือนกดลบ "สำเร็จ" ทั้งที่ไฟล์ยังไม่หายไปสักพัก
     * แก้โดยตัดไฟล์ที่ลบออกจากลิสต์ปัจจุบันทันทีแบบ optimistic (ไม่ต้องรอสแกน disk ใหม่) ให้ตรง
     * กับจังหวะที่ toast ขึ้นเป๊ะ ส่วนการสแกนแบบเต็ม (refreshCurrentView -> loadDirectory) ยังทำงาน
     * ต่อไปตามปกติเบื้องหลังเพื่อ sync กับ disk จริงในกรณีมีการเปลี่ยนแปลงอื่นที่การลบไฟล์เดียวนี้
     * ไม่ครอบคลุม (เช่น ไฟล์อื่นถูกเพิ่ม/ลบพร้อมกันจากที่อื่น)
     */
    fun removeEntryOptimistically(file: File) {
        if (_mode.value != MainActivity.Mode.NORMAL) return
        val current = _directoryState.value
        val filtered = current.entries.filterNot { it.file == file }
        if (filtered.size == current.entries.size) return
        _directoryState.value = current.copy(entries = filtered, subtitle = "${filtered.size} รายการ")
    }

    /**
     * Loads [dir]'s contents off the main thread: listFilesCompat()/Shizuku fallback,
     * the hidden-file + root-trash-folder filter, and the sort comparator all run on
     * Dispatchers.IO now (previously this all ran synchronously inside
     * MainActivity.loadDirectory(), blocking the UI thread on every navigation).
     *
     * Any in-flight load is cancelled first, so rapid navigation (e.g. mashing back,
     * or a swipe-refresh landing mid-navigation) can't let a stale result overwrite
     * a newer one - only the latest call's result is ever applied.
     *
     * currentDir/lastNormalDir/mode are updated as part of this same state update
     * (matching what the old synchronous loadDirectory() did), so MainActivity no
     * longer needs to set them itself around the call.
     */
    fun loadDirectory(dir: File) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch(Dispatchers.IO) {
            if (!directoryBrowserHelper.canAccess(dir)) {
                _toastEvents.emit("ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้")
                return@launch
            }

            _directoryState.update { it.copy(isLoading = true) }

            val comparator = directoryBrowserHelper.comparator(_sortKey.value, _sortAscending.value)
            val result = directoryBrowserHelper.load(dir, _showHidden.value, comparator)

            setMode(MainActivity.Mode.NORMAL)
            setCurrentDir(dir)
            setLastNormalDir(dir)
            _directoryState.value = DirectoryUiState(
                currentDir = dir,
                entries = result.entries,
                subtitle = "${result.entries.size} รายการ",
                isLoading = false
            )
        }
    }

    companion object {
        // Round 22 (SavedStateHandle) keys
        private const val KEY_CURRENT_DIR = "current_dir"
        private const val KEY_LAST_NORMAL_DIR = "last_normal_dir"
        private const val KEY_MODE = "mode"
        private const val KEY_CATEGORY_LABEL = "category_label"
        private const val KEY_CATEGORY_EXTS = "category_exts"
    }
}
