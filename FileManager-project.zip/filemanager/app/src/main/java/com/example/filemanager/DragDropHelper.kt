package com.example.filemanager

import com.example.filemanager.ui.selection.updateActionBars
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.renameToCompat

/**
 * Drag & drop (drag one or more selected files, drop onto a folder to move them) - extracted
 * out of MainActivity.kt (round 4 of the size-reduction plan). No logic changed, only
 * location + widening loadDirectory() and updateActionBars() from private to internal so this
 * file can call them.
 */

internal fun MainActivity.onStartFileDrag(entry: FileEntry, sourceView: View): Boolean {
    val paths = if (adapter.selectionMode && adapter.getSelectedFiles().any {
            it.absolutePath == entry.file.absolutePath
        }) {
        adapter.getSelectedFiles().map { it.absolutePath }
    } else {
        listOf(entry.file.absolutePath)
    }
    val clip = android.content.ClipData.newPlainText(
        "KORN_FILES",
        paths.joinToString("\n")
    )
    val shadow = View.DragShadowBuilder(sourceView)
    val started = sourceView.startDragAndDrop(clip, shadow, null, 0)
    if (started) {
        Toast.makeText(this, "ลากไปวางบนโฟลเดอร์เพื่อย้าย", Toast.LENGTH_SHORT).show()
    }
    return started
}

internal fun MainActivity.onDropOnFolder(folder: File, paths: List<String>): Boolean {
    if (!folder.isDirectory || paths.isEmpty()) return false
    val sources = paths.map { File(it) }.filter { it.exists() }
    if (sources.isEmpty()) return false

    lifecycleScope.launch(Dispatchers.IO) {
        var moved = 0
        var skipped = 0
        val successfulMoves = mutableListOf<Pair<File, File>>()
        for (src in sources.distinctBy { it.absolutePath }) {
            try {
                if (src.absoluteFile == folder.absoluteFile) {
                    skipped++
                    continue
                }
                if (src.isDirectory) {
                    val srcPath = src.canonicalFile.toPath()
                    val destPath = folder.canonicalFile.toPath()
                    if (destPath.startsWith(srcPath)) {
                        skipped++
                        continue
                    }
                }
                var dest = File(folder, src.name)
                if (dest.canonicalFile == src.canonicalFile) {
                    skipped++
                    continue
                }
                if (dest.exists()) dest = File(folder, uniqueName(folder, src.name, src.isDirectory))
                val ok = src.renameToCompat(dest)
                if (ok) { moved++; successfulMoves += src to dest } else skipped++
            } catch (_: Exception) {
                skipped++
            }
        }
        withContext(Dispatchers.Main) {
            exitSelectionModeIfNeededAfterDrag()
            loadDirectory(directoryViewModel.currentDir.value)
            val msg = if (skipped == 0) "ย้าย $moved รายการไปที่ ${folder.name} แล้ว"
            else "ย้ายสำเร็จ $moved รายการ (ข้าม $skipped รายการ)"
            Toast.makeText(this@onDropOnFolder, msg, Toast.LENGTH_LONG).show()
            // Local Search Index รอบ 3: รีเฟรชเฉพาะตอนย้ายสำเร็จอย่างน้อย 1 รายการจริง
            if (successfulMoves.isNotEmpty()) {
                for ((src, dest) in successfulMoves) {
                    searchIndexManager.renameOrMoveInIndex(src, dest)
                }
            }
        }
    }
    return true
}

internal fun MainActivity.exitSelectionModeIfNeededAfterDrag() {
    if (adapter.selectionMode) {
        adapter.setSelectionMode(false)
        swipeRefresh.isEnabled = true
        updateActionBars()
    }
}
