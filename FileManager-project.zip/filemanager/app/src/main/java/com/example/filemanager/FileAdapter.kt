package com.example.filemanager

import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.graphics.drawable.Drawable
import android.content.pm.PackageManager
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Round 18 (Task 2): converted from a plain RecyclerView.Adapter driven by
 * notifyDataSetChanged() on every update to a ListAdapter backed by DiffUtil
 * (see DIFF_CALLBACK below). This makes updateItems() compute a real diff and
 * animate/only-rebind the rows that actually changed, instead of redrawing
 * the whole list (and re-triggering every thumbnail/icon load) on every
 * refresh. `items` is gone - the current list now lives in ListAdapter's own
 * currentList, accessed here via getItem(position)/currentList.
 */
class FileAdapter(
    private val context: android.content.Context,
    initialItems: List<FileEntry>,
    private val onClick: (FileEntry) -> Unit,
    private val onLongClick: (FileEntry) -> Boolean,
    private val onStartDrag: (FileEntry, View) -> Boolean,
    private val onDropOnFolder: (File, List<String>) -> Boolean,
    private var showFullPath: Boolean = false
) : ListAdapter<FileEntry, FileAdapter.VH>(DIFF_CALLBACK) {

    init {
        if (initialItems.isNotEmpty()) submitList(initialItems)
    }

    companion object {
        /**
         * Task 2 requirement: identity and content are both keyed off the backing file's
         * path and lastModified timestamp. A path change (rename/move) is a different item;
         * a lastModified change (edited/replaced in place) is a content change worth
         * rebinding. Purely cosmetic fields (displayName/subtitleOverride, used only by the
         * flat trash view) intentionally aren't diffed - they only ever change together with
         * the backing file's path anyway.
         */
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<FileEntry>() {
            override fun areItemsTheSame(oldItem: FileEntry, newItem: FileEntry): Boolean =
                oldItem.file.absolutePath == newItem.file.absolutePath

            override fun areContentsTheSame(oldItem: FileEntry, newItem: FileEntry): Boolean =
                oldItem.file.absolutePath == newItem.file.absolutePath &&
                    oldItem.file.lastModified() == newItem.file.lastModified()
        }
    }

    // Bounded (round 12 fix): previously an unbounded mutableMapOf, which could grow without
    // limit in a folder with many .apk files. Now capped the same way as packageIconCache below.
    private val apkIconCache = object : LruCache<String, Drawable?>(50) {}

    /** installed-app icon cache for Android/data and Android/obb package-name folders. */
    private val packageIconCache = object : LruCache<String, Drawable?>(100) {}
    private val packageIconLoading = mutableSetOf<String>()
    private val lifecycleOwner: LifecycleOwner? = context as? LifecycleOwner

    /** Fires whenever the selection set changes, so the activity can refresh its "N selected" subtitle. */
    var onSelectionChanged: (() -> Unit)? = null

    var selectionMode: Boolean = false
        private set
    private val selected = mutableSetOf<String>()

    var isGrid: Boolean = false
        private set

    enum class ViewMode { LIST, COMPACT, GRID, DETAILS }
    var viewMode: ViewMode = ViewMode.LIST
        private set

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val gestureHandler = Handler(Looper.getMainLooper())
        var longPressTask: Runnable? = null

        /** Round 18 (Task 2): the in-flight thumbnail decode Job for whatever item is
         * currently bound to this row, if any. Cancelled before a new item is bound and
         * in onViewRecycled(), so a slow decode from a previous item can never land on
         * this row after it's been reused - fixes both flickering and a leak source
         * (an orphaned coroutine holding a reference to a recycled ImageView). */
        var thumbnailJob: Job? = null

        fun cancelThumbnailJob() {
            thumbnailJob?.cancel()
            thumbnailJob = null
        }

        fun clearGestureCallbacks() {
            longPressTask?.let(gestureHandler::removeCallbacks)
            longPressTask = null
            gestureHandler.removeCallbacksAndMessages(null)
        }

        fun gestureHandlerForBinding(): Handler = gestureHandler

        val icon: FileIconView? = view.findViewById(R.id.icon)
        val appIcon: ImageView? = view.findViewById(R.id.appIcon)
        val thumb: ImageView? = view.findViewById(R.id.thumb)
        val name: TextView = view.findViewById(R.id.name)
        val subtitle: TextView? = view.findViewById(R.id.subtitle)
        val checkbox: CheckBox? = view.findViewById(R.id.checkbox)
    }

    /**
     * [showFullPath] switches the subtitle from "N รายการ / ขนาดไฟล์" (normal folder browsing)
     * to the item's parent folder path — used for flat results like category browsing or search.
     */
    fun updateItems(newItems: List<FileEntry>, showFullPath: Boolean = this.showFullPath) {
        this.showFullPath = showFullPath
        if (selected.isNotEmpty()) {
            selected.retainAll(newItems.map { it.file.absolutePath }.toSet())
        }
        // submitList() diffs newItems against the current list on a background thread
        // (ListAdapter's default AsyncListDiffer) and dispatches only the minimal set
        // of notifyItem*() calls, instead of the old notifyDataSetChanged() rebind-all.
        submitList(newItems)
    }

    fun setGridMode(enabled: Boolean) {
        setViewMode(if (enabled) ViewMode.GRID else ViewMode.LIST)
    }

    fun setViewMode(mode: ViewMode) {
        if (viewMode == mode) return
        viewMode = mode
        isGrid = mode == ViewMode.GRID
        // View-type-only change (same items) - notifyDataSetChanged() is still correct here
        // since every row's viewType is changing, which submitList()'s diff wouldn't detect
        // (FileEntry content is unchanged; only how it's drawn is).
        notifyDataSetChanged()
    }

    fun setSelectionMode(enabled: Boolean, notify: Boolean = true) {
        if (selectionMode == enabled) {
            if (notify) notifyDataSetChanged()
            return
        }
        selectionMode = enabled
        if (!enabled) selected.clear()
        if (notify) notifyDataSetChanged()
    }

    fun toggleSelected(path: String) {
        if (!selected.add(path)) selected.remove(path)
        onSelectionChanged?.invoke()
    }

    fun selectPath(path: String, notify: Boolean = true) {
        selected.add(path)
        if (notify) notifyDataSetChanged()
        onSelectionChanged?.invoke()
    }

    fun selectAll() {
        selected.clear()
        selected.addAll(currentList.map { it.file.absolutePath })
        notifyDataSetChanged()
        onSelectionChanged?.invoke()
    }

    fun selectionCount(): Int = selected.size

    fun getSelectedFiles(): List<File> =
        currentList.filter { it.file.absolutePath in selected }.map { it.file }

    override fun getItemViewType(position: Int): Int = when (viewMode) {
        ViewMode.GRID -> 1
        ViewMode.COMPACT -> 2
        ViewMode.DETAILS -> 3
        ViewMode.LIST -> 0
    }

    override fun onViewRecycled(holder: VH) {
        holder.cancelThumbnailJob()
        holder.clearGestureCallbacks()
        holder.itemView.setOnTouchListener(null)
        super.onViewRecycled(holder)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (viewType) {
            1 -> R.layout.item_file_grid
            2 -> R.layout.item_file_compact
            3 -> R.layout.item_file_details
            else -> R.layout.item_file
        }
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        // Round 18 (Task 2): cancel any thumbnail decode still in flight for whatever item
        // this row previously held, before binding the new one, so it can never land late
        // on the wrong row (the old code relied solely on ThumbnailLoader's `tag` check).
        holder.cancelThumbnailJob()

        val entry = getItem(position)
        val isImage = !entry.isDirectory && entry.file.extension.lowercase() in FileCategories.IMAGES

        holder.name.text = entry.displayName ?: entry.file.name

        // ---- icon / thumbnail ----
        val apkIcon = if (!entry.isDirectory && entry.file.extension.equals("apk", true)) loadApkIcon(entry.file) else null
        val packageName = if (entry.isDirectory) packageNameFor(entry.file) else null
        if (isGrid && isImage) {
            holder.icon?.visibility = View.GONE
            holder.appIcon?.visibility = View.GONE
            holder.thumb?.visibility = View.VISIBLE
            holder.thumb?.let { thumb ->
                val scope = lifecycleOwner?.lifecycleScope
                if (scope != null) {
                    holder.thumbnailJob = ThumbnailLoader.load(scope, entry.file, thumb, 300)
                } else {
                    // No LifecycleOwner available (context isn't an Activity/Fragment) -
                    // fall back to a cache-only lookup rather than launching an
                    // unscoped/unmanaged coroutine that nothing would ever cancel.
                    thumb.setImageDrawable(null)
                    ThumbnailLoader.cached(entry.file)?.let { thumb.setImageBitmap(it) }
                }
            }
        } else if (apkIcon != null) {
            holder.thumb?.visibility = View.GONE
            holder.icon?.visibility = View.GONE
            holder.appIcon?.visibility = View.VISIBLE
            holder.appIcon?.setImageDrawable(apkIcon)
        } else if (packageName != null) {
            holder.thumb?.visibility = View.GONE
            // Show the folder icon immediately; swap in the app icon asynchronously if found.
            holder.icon?.visibility = View.VISIBLE
            holder.icon?.setFolderIcon(true, null)
            holder.appIcon?.visibility = View.GONE
            holder.appIcon?.tag = packageName
            loadPackageIconAsync(packageName) { drawable ->
                // Guard against the ViewHolder having been recycled for a different item
                // while this lookup was running in the background.
                if (holder.appIcon?.tag == packageName && drawable != null) {
                    holder.icon?.visibility = View.GONE
                    holder.appIcon?.visibility = View.VISIBLE
                    holder.appIcon?.setImageDrawable(drawable)
                }
            }
        } else {
            holder.thumb?.visibility = View.GONE
            holder.appIcon?.visibility = View.GONE
            holder.icon?.visibility = View.VISIBLE
            holder.icon?.let { iconView ->
                if (entry.isDirectory) {
                    iconView.setFolderIcon(true, systemFolderBadge(entry.file))
                } else {
                    iconView.setFileIconText(iconFor(entry.file))
                }
            }
        }

        // ---- subtitle ----
        holder.subtitle?.text = entry.subtitleOverride ?: run {
            if (entry.isDirectory) {
                val count = entry.file.listFiles()?.size ?: 0
                if (showFullPath) "${entry.file.parent ?: ""}  •  $count รายการ  •  ${formatDate(entry.file.lastModified())}"
                else "$count รายการ  •  ${formatDate(entry.file.lastModified())}"
            } else {
                val details = "${readableSize(entry.file.length())}  •  ${formatDate(entry.file.lastModified())}"
                if (showFullPath) "${entry.file.parent ?: ""}  •  $details" else details
            }
        }

        // ---- selection checkbox ----
        holder.checkbox?.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.checkbox?.setOnCheckedChangeListener(null)
        holder.checkbox?.isChecked = entry.file.absolutePath in selected
        holder.checkbox?.setOnClickListener { toggleSelected(entry.file.absolutePath) }

        holder.itemView.setOnClickListener {
            if (selectionMode) {
                toggleSelected(entry.file.absolutePath)
                notifyItemChanged(holder.bindingAdapterPosition)
            } else {
                onClick(entry)
            }
        }
        // Long-press selects immediately. If the finger is still down, moving
        // after the long-press threshold starts drag without requiring a second touch.
        holder.clearGestureCallbacks()
        val handler = holder.gestureHandlerForBinding()
        val touchSlop = ViewConfiguration.get(holder.itemView.context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var longPressed = false
        var dragStarted = false

        val longPressTask = Runnable {
            if (!dragStarted) {
                longPressed = true
                // Keep this row's touch gesture alive; do not rebind the RecyclerView.
                onLongClick(entry)
                holder.checkbox?.visibility = View.VISIBLE
                holder.checkbox?.setOnCheckedChangeListener(null)
                holder.checkbox?.isChecked = true
                holder.itemView.parent?.requestDisallowInterceptTouchEvent(true)
            }
        }
        holder.longPressTask = longPressTask

        holder.itemView.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    longPressed = false
                    dragStarted = false
                    handler.removeCallbacks(longPressTask)
                    handler.postDelayed(
                        longPressTask,
                        ViewConfiguration.getLongPressTimeout().toLong()
                    )
                    // Do NOT consume ACTION_DOWN. Let itemView's normal click
                    // handling receive a simple tap, while this listener still
                    // observes the same gesture and can switch to drag after
                    // long-press + movement.
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    val movedEnough = (dx * dx + dy * dy) >= touchSlop * touchSlop

                    if (longPressed && !dragStarted && movedEnough) {
                        dragStarted = true
                        handler.removeCallbacks(longPressTask)
                        view.parent?.requestDisallowInterceptTouchEvent(true)
                        onStartDrag(entry, view)
                        true
                    } else {
                        if (!longPressed && movedEnough) {
                            handler.removeCallbacks(longPressTask)
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                        }
                        longPressed || dragStarted
                    }
                }

                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressTask)
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                    // A normal tap must reach itemView.performClick()/the
                    // existing OnClickListener. Long-press/drag gestures remain
                    // consumed.
                    longPressed || dragStarted
                }

                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPressTask)
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                    false
                }

                else -> false
            }
        }

        // Any folder row is a valid drop target. The dragged payload contains absolute
        // paths separated by newlines, allowing multi-file drag after multi-select.
        if (entry.isDirectory) {
            holder.itemView.setOnDragListener { view, event ->
                when (event.action) {
                    android.view.DragEvent.ACTION_DRAG_STARTED -> {
                        event.clipDescription?.hasMimeType("text/plain") == true
                    }
                    android.view.DragEvent.ACTION_DRAG_ENTERED -> {
                        view.alpha = 0.65f
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_EXITED -> {
                        view.alpha = 1f
                        true
                    }
                    android.view.DragEvent.ACTION_DROP -> {
                        view.alpha = 1f
                        val text = event.clipData?.getItemAt(0)?.text?.toString().orEmpty()
                        val paths = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                        onDropOnFolder(entry.file, paths)
                    }
                    android.view.DragEvent.ACTION_DRAG_ENDED -> {
                        view.alpha = 1f
                        true
                    }
                    else -> true
                }
            }
        } else {
            holder.itemView.setOnDragListener(null)
            holder.itemView.alpha = 1f
        }
    }

    // getItemCount() is no longer overridden - ListAdapter derives it from currentList.size.

    private fun loadApkIcon(file: File): Drawable? {
        val path = file.absolutePath
        apkIconCache.get(path)?.let { return it }
        val pm = context.packageManager
        val icon = try {
            val info = pm.getPackageArchiveInfo(path, PackageManager.GET_META_DATA)
            info?.applicationInfo?.let { appInfo ->
                appInfo.sourceDir = path
                appInfo.publicSourceDir = path
                appInfo.loadIcon(pm)
            }
        } catch (_: Exception) { null }
        apkIconCache.put(path, icon)
        return icon
    }

    /**
     * If [file] is a direct child of an .../Android/data or .../Android/obb folder, its name
     * is a package name (e.g. com.example.app) — returns that name, else null.
     */
    private fun packageNameFor(file: File): String? {
        val parent = try { file.parentFile?.canonicalFile } catch (_: Exception) { file.parentFile } ?: return null
        val parentPath = parent.path.trimEnd('/')
        if (!(parentPath.endsWith("Android/data") || parentPath.endsWith("Android/obb"))) return null
        return file.name
    }

    /**
     * Looks up the installed app's icon for [packageName] (via QUERY_ALL_PACKAGES, already
     * held by the app - no new permission needed), off the main thread, with an in-memory
     * LRU cache. Calls back on the main thread with the drawable, or null if the package
     * isn't installed / has no icon.
     */
    private fun loadPackageIconAsync(packageName: String, onResult: (Drawable?) -> Unit) {
        packageIconCache.get(packageName)?.let { cached ->
            onResult(cached)
            return
        }
        val owner = lifecycleOwner
        if (owner == null) {
            onResult(null)
            return
        }
        if (!packageIconLoading.add(packageName)) return
        owner.lifecycleScope.launch {
            val icon = withContext(Dispatchers.IO) {
                try {
                    context.packageManager.getApplicationIcon(packageName)
                } catch (_: PackageManager.NameNotFoundException) {
                    null
                } catch (_: Exception) {
                    null
                }
            }
            packageIconLoading.remove(packageName)
            if (icon != null) packageIconCache.put(packageName, icon)
            onResult(icon)
        }
    }

    private fun formatDate(time: Long): String =
        if (time <= 0L) "—" else SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(time))

    /** Returns a small badge only for Android public system folders at storage root. */
    private fun systemFolderBadge(file: File): String? {
        if (!file.isDirectory) return null
        val root = android.os.Environment.getExternalStorageDirectory().canonicalFile
        val target = try { file.canonicalFile } catch (_: Exception) { file.absoluteFile }
        if (target.parentFile?.canonicalFile != root) return null

        return when (target.name.lowercase(Locale.ROOT)) {
            "download" -> "↓"
            "downloads" -> "↓"
            "pictures" -> "▣"
            "dcim" -> "⌾"
            "movies" -> "▶"
            "videos" -> "▶"
            "music" -> "♪"
            "documents" -> "▤"
            "ringtones" -> "♪"
            "alarms" -> "◷"
            "notifications" -> "!"
            "podcasts" -> "◉"
            "audiobooks" -> "♫"
            else -> null
        }
    }

    private fun iconFor(file: File): String {
        val ext = file.extension.lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp" -> "🖼️"
            "mp4", "mkv", "avi", "mov", "webm" -> "🎬"
            "mp3", "wav", "flac", "m4a", "ogg" -> "🎵"
            "pdf" -> "📕"
            "doc", "docx" -> "📘"
            "xls", "xlsx" -> "📗"
            "ppt", "pptx" -> "📙"
            "zip", "rar", "7z", "tar", "gz" -> "🗜️"
            "apk" -> "📦"
            "txt", "md" -> "📄"
            else -> "📄"
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
