package com.example.filemanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.DecimalFormat

class FileAdapter(
    private var items: List<FileEntry>,
    private val onClick: (FileEntry) -> Unit,
    private val onLongClick: (FileEntry) -> Boolean,
    private val onStartDrag: (FileEntry, View) -> Boolean,
    private val onDropOnFolder: (File, List<String>) -> Boolean,
    private var showFullPath: Boolean = false
) : RecyclerView.Adapter<FileAdapter.VH>() {

    /** Fires whenever the selection set changes, so the activity can refresh its "N selected" subtitle. */
    var onSelectionChanged: (() -> Unit)? = null

    var selectionMode: Boolean = false
        private set
    private val selected = mutableSetOf<String>()

    var isGrid: Boolean = false
        private set

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView? = view.findViewById(R.id.icon)
        val thumb: ImageView? = view.findViewById(R.id.thumb)
        val name: TextView = view.findViewById(R.id.name)
        val subtitle: TextView? = view.findViewById(R.id.subtitle)
        val checkbox: CheckBox? = view.findViewById(R.id.checkbox)
    }

    /**
     * [showFullPath] switches the subtitle from "N รายการ / ขนาดไฟล์" (normal folder browsing)
     * to the item's parent folder path — used for flat results like category browsing or search.
     */
    fun updateItems(newItems: List<FileEntry>, showFullPath: Boolean = this.showFullPath) {
        items = newItems
        this.showFullPath = showFullPath
        if (selected.isNotEmpty()) {
            selected.retainAll(newItems.map { it.file.absolutePath }.toSet())
        }
        notifyDataSetChanged()
    }

    fun setGridMode(enabled: Boolean) {
        if (isGrid == enabled) return
        isGrid = enabled
        notifyDataSetChanged()
    }

    fun setSelectionMode(enabled: Boolean) {
        if (selectionMode == enabled) return
        selectionMode = enabled
        if (!enabled) selected.clear()
        notifyDataSetChanged()
    }

    fun toggleSelected(path: String) {
        if (!selected.add(path)) selected.remove(path)
        onSelectionChanged?.invoke()
    }

    fun selectAll() {
        selected.clear()
        selected.addAll(items.map { it.file.absolutePath })
        notifyDataSetChanged()
        onSelectionChanged?.invoke()
    }

    fun selectionCount(): Int = selected.size

    fun getSelectedFiles(): List<File> =
        items.filter { it.file.absolutePath in selected }.map { it.file }

    override fun getItemViewType(position: Int): Int = if (isGrid) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 1) R.layout.item_file_grid else R.layout.item_file
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        val isImage = !entry.isDirectory && entry.file.extension.lowercase() in FileCategories.IMAGES

        holder.name.text = entry.displayName ?: entry.file.name

        // ---- icon / thumbnail ----
        if (isGrid && isImage) {
            holder.icon?.visibility = View.GONE
            holder.thumb?.visibility = View.VISIBLE
            holder.thumb?.let { ThumbnailLoader.load(entry.file, it, 300) }
        } else {
            holder.thumb?.visibility = View.GONE
            holder.icon?.visibility = View.VISIBLE
            holder.icon?.text = if (entry.isDirectory) "📁" else iconFor(entry.file)
        }

        // ---- subtitle ----
        holder.subtitle?.text = entry.subtitleOverride ?: run {
            if (entry.isDirectory) {
                if (showFullPath) entry.file.parent ?: "" else {
                    val count = entry.file.listFiles()?.size ?: 0
                    "$count รายการ"
                }
            } else {
                if (showFullPath) entry.file.parent ?: "" else readableSize(entry.file.length())
            }
        }

        // ---- selection checkbox ----
        holder.checkbox?.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.checkbox?.setOnCheckedChangeListener(null)
        holder.checkbox?.isChecked = entry.file.absolutePath in selected
        holder.checkbox?.setOnClickListener { toggleSelected(entry.file.absolutePath) }

        holder.itemView.setOnClickListener {
            if (selectionMode) {
                toggleSelected(entry.file.absolutePath)
                notifyItemChanged(holder.bindingAdapterPosition)
            } else {
                onClick(entry)
            }
        }
        // Keep the existing row long-press menu. Long-pressing the file icon starts drag,
        // so both the context menu and press-and-drag workflow remain available.
        holder.itemView.setOnLongClickListener {
            if (selectionMode) {
                toggleSelected(entry.file.absolutePath)
                notifyItemChanged(holder.bindingAdapterPosition)
                true
            } else {
                onLongClick(entry)
            }
        }
        holder.icon?.setOnLongClickListener {
            if (entry.isDirectory) false else onStartDrag(entry, holder.itemView)
        }
        holder.thumb?.setOnLongClickListener {
            if (entry.isDirectory) false else onStartDrag(entry, holder.itemView)
        }

        // Any folder row is a valid drop target. The dragged payload contains absolute
        // paths separated by newlines, allowing multi-file drag after multi-select.
        if (entry.isDirectory) {
            holder.itemView.setOnDragListener { view, event ->
                when (event.action) {
                    android.view.DragEvent.ACTION_DRAG_STARTED -> {
                        event.clipDescription?.hasMimeType("text/plain") == true
                    }
                    android.view.DragEvent.ACTION_DRAG_ENTERED -> {
                        view.alpha = 0.65f
                        true
                    }
                    android.view.DragEvent.ACTION_DRAG_EXITED -> {
                        view.alpha = 1f
                        true
                    }
                    android.view.DragEvent.ACTION_DROP -> {
                        view.alpha = 1f
                        val text = event.clipData?.getItemAt(0)?.text?.toString().orEmpty()
                        val paths = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                        onDropOnFolder(entry.file, paths)
                    }
                    android.view.DragEvent.ACTION_DRAG_ENDED -> {
                        view.alpha = 1f
                        true
                    }
                    else -> true
                }
            }
        } else {
            holder.itemView.setOnDragListener(null)
            holder.itemView.alpha = 1f
        }
    }

    override fun getItemCount(): Int = items.size

    private fun iconFor(file: File): String {
        val ext = file.extension.lowercase()
        return when (ext) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp" -> "🖼️"
            "mp4", "mkv", "avi", "mov", "webm" -> "🎬"
            "mp3", "wav", "flac", "m4a", "ogg" -> "🎵"
            "pdf" -> "📕"
            "doc", "docx" -> "📘"
            "xls", "xlsx" -> "📗"
            "ppt", "pptx" -> "📙"
            "zip", "rar", "7z", "tar", "gz" -> "🗜️"
            "apk" -> "📦"
            "txt", "md" -> "📄"
            else -> "📄"
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
