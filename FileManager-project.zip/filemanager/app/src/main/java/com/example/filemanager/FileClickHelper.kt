package com.example.filemanager

import android.content.Intent
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Tap / long-press dispatch for a list item, and the "open or extract an archive" flow that
 * a tap on an archive file leads into - extracted out of MainActivity.kt (round 9 of the
 * size-reduction plan / STEP 17+). These stay as extension functions on MainActivity, the
 * same pattern as TrashUiController.kt/CategoryShortcuts.kt/SelectionModeController.kt,
 * because they read/write several pieces of MainActivity's screen state (mode,
 * adapter, swipeRefresh, the pendingArchive* fields) directly, the same way they did as
 * private methods; moving them here only required widening onItemClick/onItemLongClick and
 * the three pendingArchive* fields from `private` to `internal` in MainActivity.kt so this
 * file (same module) can see them. currentDir is read via viewModel directly (round 19
 * wrapper removal). No logic or behavior was changed.
 */

internal fun MainActivity.onItemClick(entry: FileEntry) {
    if (viewModel.mode.value == MainActivity.Mode.APPS) {
        backupApplicationApk(entry)
        return
    }
    if (viewModel.mode.value == MainActivity.Mode.TRASH) {
        onTrashItemAction(entry)
        return
    }
    if (entry.isDirectory) {
        // Tapping a folder always drops back into normal browsing, even from a
        // flat category/search result list.
        loadDirectory(entry.file)
    } else if (ArchiveManager.isArchive(entry.file)) {
        showArchiveOpenOptions(entry.file)
    } else {
        openFile(entry.file)
    }
}

/**
 * Archives stay browsable inside KORN, but the user can always hand them to another
 * application through the Android chooser. Minecraft pack extensions also get a
 * dedicated Minecraft action when the OS has an app registered for them.
 */
internal fun MainActivity.showArchiveOpenOptions(file: File) {
    val items = mutableListOf("เปิดภายใน KORN")
    val isMinecraftPack = file.name.lowercase().let {
        it.endsWith(".mcpack") || it.endsWith(".mcaddon") || it.endsWith(".mcworld")
    }
    if (isMinecraftPack) items.add("เปิด/ส่งให้ Minecraft")
    items.add("แตกไฟล์…")
    items.add("เปิดด้วยแอปอื่น…")
    AlertDialog.Builder(this)
        .setTitle(file.name)
        .setItems(items.toTypedArray()) { _, which ->
            when (items[which]) {
                "เปิดภายใน KORN" -> openArchiveInsideKorn(file)
                "เปิด/ส่งให้ Minecraft" -> openFile(file)
                "แตกไฟล์…" -> extractArchiveDialog(file)
                "เปิดด้วยแอปอื่น…" -> openFile(file)
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.openArchiveInsideKorn(file: File) {
    // Keep ZIP-family/Minecraft archives on the existing browser so their
    // current in-place edit/rename/delete/add features remain unchanged.
    val zipLike = file.name.lowercase().let {
        it.endsWith(".zip") || it.endsWith(".mcpack") || it.endsWith(".mcaddon") ||
        it.endsWith(".mcworld") || it.endsWith(".apk") || it.endsWith(".apks") ||
        it.endsWith(".xapk") || it.endsWith(".mtz")
    }
    if (zipLike) {
        startActivity(Intent(this, ZipBrowserActivity::class.java).apply {
            putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, file.absolutePath)
        })
        return
    }

    val needsPassword = ArchiveManager.isPasswordCandidate(file)
    if (needsPassword) {
        val input = EditText(this).apply {
            hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("รหัสผ่าน (ถ้ามี)")
            .setView(input)
            .setPositiveButton("เปิด") { _, _ ->
                materializeAndOpen(file, input.text.toString().ifBlank { null })
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    } else {
        materializeAndOpen(file, null)
    }
}

internal fun MainActivity.materializeAndOpen(file: File, password: String?) {
    Toast.makeText(this, "กำลังอ่านไฟล์…", Toast.LENGTH_SHORT).show()
    lifecycleScope.launch {
        try {
            val tempZip = withContext(Dispatchers.IO) {
                ArchiveManager.materializeForBrowse(file, cacheDir, password)
            }
            startActivity(Intent(this@materializeAndOpen, ZipBrowserActivity::class.java).apply {
                putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, tempZip.absolutePath)
                putExtra("korn_temp_archive", true)
            })
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            if (!isFinishing && !isDestroyed) {
                Toast.makeText(this@materializeAndOpen, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}

internal fun MainActivity.extractArchiveDialog(file: File) {
    val choices = arrayOf(
        "อัตโนมัติ — สร้างโฟลเดอร์ชื่อเดียวกับไฟล์ในที่เดิม",
        "เส้นทางปัจจุบัน — แตกลงโฟลเดอร์ที่กำลังเปิดอยู่",
        "เลือกเส้นทาง… — เลือกโฟลเดอร์ปลายทางเอง"
    )

    // Selecting a radio option no longer extracts immediately - it just marks the
    // choice. Extraction only runs after the user taps "ตกลง" to confirm, so a stray
    // tap on the wrong option can't accidentally kick off extraction to the wrong place.
    var selectedChoice = 0
    AlertDialog.Builder(this)
        .setTitle("แตกไฟล์ไปยัง")
        .setSingleChoiceItems(choices, selectedChoice) { _, which -> selectedChoice = which }
        .setPositiveButton("ตกลง") { dialog, _ ->
            dialog.dismiss()
            if (selectedChoice == 2) {
                chooseDestinationFolder { destination ->
                    askArchivePasswordThenExtract(file, 2, destination)
                }
            } else {
                askArchivePasswordThenExtract(file, selectedChoice, null)
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.askArchivePasswordThenExtract(file: File, mode: Int, chosenDestination: File?) {
    pendingArchiveFile = file
    pendingArchiveMode = mode

    val finish = { password: String? ->
        pendingArchivePassword = password
        val destination = when (mode) {
            1 -> viewModel.currentDir.value
            2 -> chosenDestination
            else -> file.parentFile ?: viewModel.currentDir.value
        } ?: viewModel.currentDir.value
        startArchiveExtraction(file, destination, mode, password)
    }

    if (ArchiveManager.isPasswordCandidate(file)) {
        val input = EditText(this).apply {
            hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("รหัสผ่าน (ถ้ามี)")
            .setView(input)
            .setPositiveButton("แตกไฟล์") { _, _ ->
                finish(input.text.toString().ifBlank { null })
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    } else {
        finish(null)
    }
}

internal fun MainActivity.startArchiveExtraction(
    file: File,
    destinationRoot: File,
    mode: Int,
    password: String?
) {
    val dest = if (mode == 0) {
        val base = file.name.substringBeforeLast('.').substringBeforeLast('.')
            .ifBlank { file.nameWithoutExtension.ifBlank { "extracted" } }
        File(destinationRoot, uniqueName(destinationRoot, base, true))
    } else {
        destinationRoot
    }

    if (!dest.exists() && !dest.mkdirs()) {
        Toast.makeText(this, "ไม่สามารถสร้างโฟลเดอร์ปลายทางได้", Toast.LENGTH_LONG).show()
        return
    }

    Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
    lifecycleScope.launch(Dispatchers.IO) {
        try {
            ArchiveManager.extract(file, dest, password)
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@startArchiveExtraction,
                    "แตกไฟล์เสร็จแล้ว: ${dest.absolutePath}",
                    Toast.LENGTH_LONG
                ).show()
                refreshCurrentView()
            }
        } catch (e: Exception) {
            if (mode == 0) dest.deleteRecursively()
            withContext(Dispatchers.Main) {
                Toast.makeText(this@startArchiveExtraction, "แตกไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } finally {
            pendingArchiveFile = null
            pendingArchivePassword = null
        }
    }
}

internal fun MainActivity.onItemLongClick(entry: FileEntry): Boolean {
    if (viewModel.mode.value == MainActivity.Mode.TRASH) {
        onTrashItemAction(entry)
        return true
    }

    if (!adapter.selectionMode) {
        // Do not rebind the RecyclerView while the long-press finger is still
        // down; the adapter keeps the current touch listener alive so the
        // same gesture can immediately transition into drag.
        adapter.setSelectionMode(true, notify = false)
        swipeRefresh.isEnabled = false
        updateSelectionSubtitle()
        updateActionBars()
    }
    if (entry.file.absolutePath !in adapter.getSelectedFiles().map { it.absolutePath }) {
        adapter.selectPath(entry.file.absolutePath, notify = false)
    }
    return true
}
