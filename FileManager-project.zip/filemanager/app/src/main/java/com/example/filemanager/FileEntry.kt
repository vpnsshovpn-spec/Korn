package com.example.filemanager

import android.app.Activity
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.File
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.util.Base64

/**
 * [displayName] / [subtitleOverride] let flat "virtual" lists (currently just the trash view)
 * show a friendlier name/subtitle than the raw backing [file] without changing how normal
 * directory browsing, category scans, or search results render.
 */
data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val displayName: String? = null,
    val subtitleOverride: String? = null
)

enum class StorageMode {
    SHIZUKU,
    SAF,
    STANDARD
}

data class RepositoryFile(
    val path: String,
    val name: String,
    val isDirectory: Boolean
)

interface FileRepository {
    val storageMode: StorageMode

    suspend fun list(path: String): List<RepositoryFile>
    suspend fun read(path: String): ByteArray
    suspend fun write(path: String, data: ByteArray): Boolean
    suspend fun delete(path: String): Boolean
    suspend fun move(sourcePath: String, destinationPath: String): Boolean
}

abstract class BaseFileRepository : FileRepository

/**
 * Shizuku-backed file repository.
 *
 * This step uses Shizuku's shell process bridge for filesystem commands. It does not
 * change the existing File Manager browsing code yet; later steps can route operations
 * through the repository resolver.
 */
open class ShizukuFileHandler(
    private val permissionRequestCode: Int = DEFAULT_PERMISSION_REQUEST_CODE
) : BaseFileRepository() {

    override val storageMode: StorageMode = StorageMode.SHIZUKU

    /** Returns true only when the Shizuku Binder is alive and this app has permission. */
    fun hasPermission(): Boolean {
        return try {
            !Shizuku.isPreV11() &&
                Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: RuntimeException) {
            false
        }
    }

    /**
     * Checks Shizuku permission and opens its permission dialog when appropriate.
     * Call this from an Activity/UI layer; this method deliberately does not block.
     */
    fun requestPermission(activity: Activity): Boolean {
        if (hasPermission()) return true

        return try {
            if (Shizuku.isPreV11() || !Shizuku.pingBinder()) {
                false
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                false
            } else {
                Shizuku.requestPermission(permissionRequestCode)
                false
            }
        } catch (_: RuntimeException) {
            false
        }
    }

    /** Returns whether the Shizuku server is reachable, regardless of app permission. */
    fun isShizukuRunning(): Boolean = try {
        !Shizuku.isPreV11() && Shizuku.pingBinder()
    } catch (_: RuntimeException) {
        false
    }

    override suspend fun list(path: String): List<RepositoryFile> {
        requirePermission()

        val result = runShell(
            "ls -1Ap -- ${shellQuote(path)}"
        )

        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to list: $path" })
        }

        return result.stdout.lineSequence()
            .map(String::trimEnd)
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .map { rawName ->
                val isDirectory = rawName.endsWith("/")
                val name = rawName.removeSuffix("/")
                RepositoryFile(
                    path = File(path, name).path,
                    name = name,
                    isDirectory = isDirectory
                )
            }
            .toList()
    }

    override suspend fun read(path: String): ByteArray {
        requirePermission()

        val result = runShell("cat -- ${shellQuote(path)}")
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to read: $path" })
        }
        return result.stdoutBytes
    }

    override suspend fun write(path: String, data: ByteArray): Boolean {
        requirePermission()

        // Send the bytes through stdin as Base64 so paths/data never need to be shell-escaped.
        val process = newShellProcess(
            "base64 -d > ${shellQuote(path)}"
        )
        process.outputStream.use { stdin ->
            Base64.getEncoder().wrap(stdin).use { encoded ->
                encoded.write(data)
            }
        }

        val stdout = process.inputStream.readBytes()
        val stderr = process.errorStream.readBytes().toString(StandardCharsets.UTF_8)
        val exitCode = process.waitFor()
        if (exitCode != 0) {
            throw IOException(stderr.ifBlank { "Unable to write: $path" })
        }
        // Keep stdout consumed to avoid a pipe remaining open on some shell implementations.
        stdout.size
        return true
    }

    override suspend fun delete(path: String): Boolean {
        requirePermission()
        val result = runShell("rm -rf -- ${shellQuote(path)}")
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to delete: $path" })
        }
        return true
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean {
        requirePermission()
        val result = runShell(
            "mv -- ${shellQuote(sourcePath)} ${shellQuote(destinationPath)}"
        )
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to move: $sourcePath" })
        }
        return true
    }

    private fun requirePermission() {
        if (!hasPermission()) {
            throw SecurityException("Shizuku is not running or KORN File Manager has not been granted Shizuku permission")
        }
    }

    private fun runShell(command: String): ShellResult {
        val process = newShellProcess(command)
        val stdout = process.inputStream.readBytes()
        val stderr = process.errorStream.readBytes().toString(StandardCharsets.UTF_8)
        val exitCode = process.waitFor()
        return ShellResult(
            exitCode = exitCode,
            stdoutBytes = stdout,
            stdout = stdout.toString(StandardCharsets.UTF_8),
            stderr = stderr
        )
    }

    @Suppress("DEPRECATION")
    private fun newShellProcess(command: String): Process {
        if (!hasPermission()) {
            throw SecurityException("Shizuku permission is required")
        }

        return Shizuku.newProcess(
            arrayOf("sh", "-c", command),
            null,
            null
        )
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"

    private data class ShellResult(
        val exitCode: Int,
        val stdoutBytes: ByteArray,
        val stdout: String,
        val stderr: String
    )

    companion object {
        const val DEFAULT_PERMISSION_REQUEST_CODE = 1201
    }
}

/**
 * Backward-compatible name from Step 1. Existing callers can continue to compile while
 * the new Shizuku implementation is exposed as [ShizukuFileHandler].
 */
class ShizukuFileRepository(
    permissionRequestCode: Int = ShizukuFileHandler.DEFAULT_PERMISSION_REQUEST_CODE
) : ShizukuFileHandler(permissionRequestCode)

/** SAF/DocumentFile repository skeleton. Implementation comes in a later step. */
class SafFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.SAF

    override suspend fun list(path: String): List<RepositoryFile> =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun read(path: String): ByteArray =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun write(path: String, data: ByteArray): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun delete(path: String): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")
}

/** Standard java.io.File repository skeleton. Implementation comes in a later step. */
class StandardFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.STANDARD

    override suspend fun list(path: String): List<RepositoryFile> =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun read(path: String): ByteArray =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun write(path: String, data: ByteArray): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun delete(path: String): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")
}
