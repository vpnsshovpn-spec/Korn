package com.example.filemanager

import java.io.File

data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory
)
