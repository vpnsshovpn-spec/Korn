package com.example.filemanager

import java.io.File

/**
 * [displayName] / [subtitleOverride] let flat "virtual" lists (currently just the trash view)
 * show a friendlier name/subtitle than the raw backing [file] without changing how normal
 * directory browsing, category scans, or search results render.
 */
data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val displayName: String? = null,
    val subtitleOverride: String? = null
)

/**
 * Storage backend selected for a file operation.
 *
 * Priority is handled by the repository resolver in a later step:
 * SHIZUKU -> SAF -> STANDARD.
 */
enum class StorageMode {
    SHIZUKU,
    SAF,
    STANDARD
}

/**
 * Backend-neutral representation of a file system entry.
 *
 * [path] is intentionally a String so the interface does not depend on a
 * particular storage API. A future implementation may treat it as a normal
 * filesystem path, a SAF Uri string, or a Shizuku shell path.
 */
data class RepositoryFile(
    val path: String,
    val name: String,
    val isDirectory: Boolean
)

/**
 * Common contract for all KORN File Manager storage backends.
 *
 * Implementations are intentionally kept out of this step. The concrete
 * backends will be responsible for translating [path] to their native API.
 */
interface FileRepository {
    val storageMode: StorageMode

    suspend fun list(path: String): List<RepositoryFile>

    suspend fun read(path: String): ByteArray

    suspend fun write(path: String, data: ByteArray): Boolean

    suspend fun delete(path: String): Boolean

    suspend fun move(sourcePath: String, destinationPath: String): Boolean
}

/**
 * Common base for repository implementations. No storage behavior is added
 * yet; this only provides the shared type structure for the next step.
 */
abstract class BaseFileRepository : FileRepository

/** Shizuku/ADB Shell repository skeleton. Implementation comes later. */
class ShizukuFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.SHIZUKU

    override suspend fun list(path: String): List<RepositoryFile> =
        throw NotImplementedError("Shizuku storage implementation is not added in this step")

    override suspend fun read(path: String): ByteArray =
        throw NotImplementedError("Shizuku storage implementation is not added in this step")

    override suspend fun write(path: String, data: ByteArray): Boolean =
        throw NotImplementedError("Shizuku storage implementation is not added in this step")

    override suspend fun delete(path: String): Boolean =
        throw NotImplementedError("Shizuku storage implementation is not added in this step")

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        throw NotImplementedError("Shizuku storage implementation is not added in this step")
}

/** SAF/DocumentFile repository skeleton. Implementation comes later. */
class SafFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.SAF

    override suspend fun list(path: String): List<RepositoryFile> =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun read(path: String): ByteArray =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun write(path: String, data: ByteArray): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun delete(path: String): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        throw NotImplementedError("SAF storage implementation is not added in this step")
}

/** Standard java.io.File repository skeleton. Implementation comes later. */
class StandardFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.STANDARD

    override suspend fun list(path: String): List<RepositoryFile> =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun read(path: String): ByteArray =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun write(path: String, data: ByteArray): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun delete(path: String): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        throw NotImplementedError("Standard storage implementation is not added in this step")
}
