package com.example.filemanager

import android.app.Activity
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.File
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.lang.reflect.InvocationTargetException
import java.util.Base64

/**
 * [displayName] / [subtitleOverride] let flat "virtual" lists (currently just the trash view)
 * show a friendlier name/subtitle than the raw backing [file] without changing how normal
 * directory browsing, category scans, or search results render.
 */
data class FileEntry(
    val file: File,
    val isDirectory: Boolean = file.isDirectory,
    val displayName: String? = null,
    val subtitleOverride: String? = null
)

enum class StorageMode {
    SHIZUKU,
    SAF,
    STANDARD
}

data class RepositoryFile(
    val path: String,
    val name: String,
    val isDirectory: Boolean
)

interface FileRepository {
    val storageMode: StorageMode

    suspend fun list(path: String): List<RepositoryFile>
    suspend fun read(path: String): ByteArray
    suspend fun write(path: String, data: ByteArray): Boolean
    suspend fun delete(path: String): Boolean
    suspend fun move(sourcePath: String, destinationPath: String): Boolean
    suspend fun createDirectory(path: String): Boolean
}

abstract class BaseFileRepository : FileRepository

/**
 * Shizuku-backed file repository.
 *
 * This step uses Shizuku's shell process bridge for filesystem commands. It does not
 * change the existing File Manager browsing code yet; later steps can route operations
 * through the repository resolver.
 */
open class ShizukuFileHandler(
    private val permissionRequestCode: Int = DEFAULT_PERMISSION_REQUEST_CODE
) : BaseFileRepository() {

    override val storageMode: StorageMode = StorageMode.SHIZUKU

    /** Returns true only when the Shizuku Binder is alive and this app has permission. */
    fun hasPermission(): Boolean {
        return try {
            !Shizuku.isPreV11() &&
                Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: RuntimeException) {
            false
        }
    }

    /**
     * Checks Shizuku permission and opens its permission dialog when appropriate.
     * Call this from an Activity/UI layer; this method deliberately does not block.
     */
    fun requestPermission(activity: Activity): Boolean {
        if (hasPermission()) return true

        return try {
            if (Shizuku.isPreV11() || !Shizuku.pingBinder()) {
                false
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                false
            } else {
                Shizuku.requestPermission(permissionRequestCode)
                false
            }
        } catch (_: RuntimeException) {
            false
        }
    }

    /** Returns whether the Shizuku server is reachable, regardless of app permission. */
    fun isShizukuRunning(): Boolean = try {
        !Shizuku.isPreV11() && Shizuku.pingBinder()
    } catch (_: RuntimeException) {
        false
    }

    override suspend fun list(path: String): List<RepositoryFile> {
        requirePermission()

        val result = runShell(
            "ls -1Ap -- ${shellQuote(path)}"
        )

        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to list: $path" })
        }

        return result.stdout.lineSequence()
            .map(String::trimEnd)
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .map { rawName ->
                val isDirectory = rawName.endsWith("/")
                val name = rawName.removeSuffix("/")
                RepositoryFile(
                    path = File(path, name).path,
                    name = name,
                    isDirectory = isDirectory
                )
            }
            .toList()
    }

    override suspend fun read(path: String): ByteArray {
        requirePermission()

        val result = runShell("cat -- ${shellQuote(path)}")
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to read: $path" })
        }
        return result.stdoutBytes
    }

    override suspend fun write(path: String, data: ByteArray): Boolean {
        requirePermission()

        // Send the bytes through stdin as Base64 so paths/data never need to be shell-escaped.
        val process = newShellProcess(
            "base64 -d > ${shellQuote(path)}"
        )
        process.outputStream.use { stdin ->
            Base64.getEncoder().wrap(stdin).use { encoded ->
                encoded.write(data)
            }
        }

        val stdout = process.inputStream.readBytes()
        val stderr = process.errorStream.readBytes().toString(StandardCharsets.UTF_8)
        val exitCode = process.waitFor()
        if (exitCode != 0) {
            throw IOException(stderr.ifBlank { "Unable to write: $path" })
        }
        // Keep stdout consumed to avoid a pipe remaining open on some shell implementations.
        stdout.size
        return true
    }

    override suspend fun delete(path: String): Boolean {
        requirePermission()
        val result = runShell("rm -rf -- ${shellQuote(path)}")
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to delete: $path" })
        }
        return true
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean {
        requirePermission()
        val result = runShell(
            "mv -- ${shellQuote(sourcePath)} ${shellQuote(destinationPath)}"
        )
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to move: $sourcePath" })
        }
        return true
    }

    override suspend fun createDirectory(path: String): Boolean {
        requirePermission()
        val result = runShell("mkdir -p -- ${shellQuote(path)}")
        if (result.exitCode != 0) {
            throw IOException(result.stderr.ifBlank { "Unable to create directory: $path" })
        }
        return true
    }

    private fun requirePermission() {
        if (!hasPermission()) {
            throw SecurityException("Shizuku is not running or KORN File Manager has not been granted Shizuku permission")
        }
    }

    private fun runShell(command: String): ShellResult {
        val process = newShellProcess(command)
        val stdout = process.inputStream.readBytes()
        val stderr = process.errorStream.readBytes().toString(StandardCharsets.UTF_8)
        val exitCode = process.waitFor()
        return ShellResult(
            exitCode = exitCode,
            stdoutBytes = stdout,
            stdout = stdout.toString(StandardCharsets.UTF_8),
            stderr = stderr
        )
    }

    /**
     * Shizuku 13.1.5 keeps newProcess() private while it is being retired in favor of
     * UserService. Keep this Step-2 shell implementation isolated here so the project
     * compiles against the current API without changing the repository contract.
     *
     * Later, when the hybrid routing layer is added, this bridge can be replaced by a
     * UserService implementation without changing FileRepository.
     */
    private fun newShellProcess(command: String): Process {
        if (!hasPermission()) {
            throw SecurityException("Shizuku permission is required")
        }

        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                Array<String>::class.java
            )
            method.isAccessible = true
            method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process
        } catch (e: InvocationTargetException) {
            throw IllegalStateException(
                "Unable to start the Shizuku shell process",
                e.targetException
            )
        } catch (e: ReflectiveOperationException) {
            throw IllegalStateException(
                "Shizuku newProcess is unavailable in this API version",
                e
            )
        }
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"

    private data class ShellResult(
        val exitCode: Int,
        val stdoutBytes: ByteArray,
        val stdout: String,
        val stderr: String
    )

    companion object {
        const val DEFAULT_PERMISSION_REQUEST_CODE = 1201
    }
}

/**
 * Backward-compatible name from Step 1. Existing callers can continue to compile while
 * the new Shizuku implementation is exposed as [ShizukuFileHandler].
 */
class ShizukuFileRepository(
    permissionRequestCode: Int = ShizukuFileHandler.DEFAULT_PERMISSION_REQUEST_CODE
) : ShizukuFileHandler(permissionRequestCode)

/**
 * SAF/DocumentFile backed repository.
 *
 * The selected tree URI is persisted by the caller/context so the app can keep using
 * the user's granted folder after a restart. Paths passed to the repository are relative
 * to that selected tree, for example "" or "/" for the root and "com.example.app/file.txt"
 * for a child.
 */
open class SafFileHandler(
    private val activity: Activity,
    private val treeUriPreferenceKey: String = DEFAULT_TREE_URI_KEY
) : BaseFileRepository() {

    override val storageMode: StorageMode = StorageMode.SAF

    private val resolver = activity.contentResolver

    /** Opens Android's folder picker. Call from the UI when SAF access is needed. */
    fun requestFolderPermission() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(android.content.Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }
        activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            .edit()
            .putString(PREFS_EXPECTED_ROOT_KEY, ANDROID_DATA_PATH)
            .apply()
        activity.startActivityForResult(intent, REQUEST_TREE_PERMISSION)
    }

    /**
     * Persists a URI returned from ACTION_OPEN_DOCUMENT_TREE.
     * Call this from Activity.onActivityResult() (or the equivalent Activity Result API callback).
     */
    fun takePersistablePermission(uri: android.net.Uri): Boolean {
        return try {
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            resolver.takePersistableUriPermission(uri, flags)
            activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
                .edit()
                .putString(treeUriPreferenceKey, uri.toString())
                .apply()
            true
        } catch (_: SecurityException) {
            false
        } catch (_: UnsupportedOperationException) {
            false
        }
    }

    /** Returns the currently persisted SAF tree URI, or null when none is available. */
    fun getPersistedTreeUri(): android.net.Uri? {
        val value = activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            .getString(treeUriPreferenceKey, null)
            ?: return null
        return runCatching { android.net.Uri.parse(value) }.getOrNull()
    }

    /** Returns true when the saved URI is still present in persisted permissions. */
    fun hasPermission(): Boolean {
        val uri = getPersistedTreeUri() ?: return false
        return resolver.persistedUriPermissions.any { permission ->
            permission.uri == uri && permission.isReadPermission && permission.isWritePermission
        }
    }

    /** SAF permission covers the persisted tree and therefore its descendants. */
    fun hasPermissionForPath(path: String): Boolean {
        if (!hasPermission()) return false
        val normalized = toSafRelativePath(path) ?: return false
        val expectedRoot = activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            .getString(PREFS_EXPECTED_ROOT_KEY, null)
        if (expectedRoot == ANDROID_DATA_PATH) {
            val root = ANDROID_DATA_PATH.trim('/')
            return normalizePath(path) == root || normalizePath(path).startsWith("$root/")
        }
        return runCatching { resolveDocument(normalized) != null }.getOrDefault(false)
    }

    override suspend fun list(path: String): List<RepositoryFile> {
        val directory = requireDirectory(path)
        return directory.listFiles().mapNotNull { document ->
            val name = document.name ?: return@mapNotNull null
            RepositoryFile(
                path = childPath(path, name),
                name = name,
                isDirectory = document.isDirectory
            )
        }
    }

    override suspend fun read(path: String): ByteArray {
        val file = requireDocument(path)
        if (file.isDirectory) throw IOException("SAF item is a directory: $path")
        resolver.openInputStream(file.uri)?.use { input ->
            return input.readBytes()
        } ?: throw IOException("Unable to read SAF file: $path")
    }

    override suspend fun write(path: String, data: ByteArray): Boolean {
        val normalized = toSafRelativePath(path)
            ?: throw SecurityException("SAF permission does not cover path: $path")
        if (normalized.isEmpty()) throw IOException("Cannot write to SAF root")

        val parentPath = normalized.substringBeforeLast('/', "")
        val fileName = normalized.substringAfterLast('/')
        val parent = requireDirectory(parentPath)
        val existing = parent.findFile(fileName)
        val target = existing ?: parent.createFile(
            "application/octet-stream",
            fileName
        ) ?: throw IOException("Unable to create SAF file: $path")

        resolver.openOutputStream(target.uri, "wt")?.use { output ->
            output.write(data)
            output.flush()
        } ?: throw IOException("Unable to write SAF file: $path")

        return true
    }

    override suspend fun delete(path: String): Boolean {
        val target = requireDocument(path)
        if (!target.delete()) {
            throw IOException("Unable to delete SAF item: $path")
        }
        return true
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean {
        val source = requireDocument(sourcePath)
        val normalizedDestination = toSafRelativePath(destinationPath)
            ?: throw SecurityException("SAF permission does not cover destination: $destinationPath")
        if (normalizedDestination.isEmpty()) throw IOException("Invalid SAF destination")

        val destinationParentPath = normalizedDestination.substringBeforeLast('/', "")
        val destinationName = normalizedDestination.substringAfterLast('/')
        val destinationParent = requireDirectory(destinationParentPath)

        // DocumentFile does not provide a moveTo() API. SAF providers may expose
        // native move operations through lower-level DocumentsContract APIs, but this
        // repository keeps the implementation provider-agnostic: copy recursively,
        // then delete the original only after the copy succeeds.
        copyDocument(source, destinationParent, destinationName)
        if (!source.delete()) {
            throw IOException("SAF copy succeeded but source could not be deleted: $sourcePath")
        }
        return true
    }

    override suspend fun createDirectory(path: String): Boolean {
        val normalized = toSafRelativePath(path)
            ?: throw SecurityException("SAF permission does not cover path: $path")
        if (normalized.isEmpty()) return true
        val parentPath = normalized.substringBeforeLast('/', "")
        val name = normalized.substringAfterLast('/')
        val parent = requireDirectory(parentPath)
        if (parent.findFile(name) != null) return true
        return parent.createDirectory(name) != null
    }

    private fun requireDocument(path: String): androidx.documentfile.provider.DocumentFile {
        val document = resolveDocument(path)
            ?: throw IOException("SAF item not found: $path")
        return document
    }

    private fun requireDirectory(path: String): androidx.documentfile.provider.DocumentFile {
        val document = requireDocument(path)
        if (!document.isDirectory) throw IOException("SAF item is not a directory: $path")
        return document
    }

    private fun resolveDocument(path: String): androidx.documentfile.provider.DocumentFile? {
        val rootUri = getPersistedTreeUri() ?: throw SecurityException("SAF folder permission has not been granted")
        val root = androidx.documentfile.provider.DocumentFile.fromTreeUri(activity, rootUri)
            ?: throw IOException("Unable to open SAF tree")

        val normalized = toSafRelativePath(path)
            ?: throw SecurityException("SAF permission does not cover path: $path")
        if (normalized.isEmpty()) return root

        var current = root
        for (part in normalized.split('/').filter { it.isNotEmpty() }) {
            current = current.findFile(part) ?: return null
        }
        return current
    }

    private fun copyDocument(
        source: androidx.documentfile.provider.DocumentFile,
        destinationParent: androidx.documentfile.provider.DocumentFile,
        destinationName: String
    ) {
        if (source.isDirectory) {
            val target = destinationParent.createDirectory(destinationName)
                ?: throw IOException("Unable to create SAF directory: $destinationName")
            source.listFiles().forEach { child ->
                val childName = child.name ?: return@forEach
                copyDocument(child, target, childName)
            }
            return
        }

        val target = destinationParent.createFile(
            source.type ?: "application/octet-stream",
            destinationName
        ) ?: throw IOException("Unable to create SAF destination: $destinationName")

        resolver.openInputStream(source.uri)?.use { input ->
            resolver.openOutputStream(target.uri, "wt")?.use { output ->
                input.copyTo(output)
            } ?: throw IOException("Unable to open SAF destination: $destinationName")
        } ?: throw IOException("Unable to open SAF source: ${source.uri}")
    }

    private fun toSafRelativePath(path: String): String? {
        val normalized = normalizePath(path)
        val androidData = ANDROID_DATA_PATH.trim('/')
        val expectedRoot = activity.getSharedPreferences(PREFS_NAME, android.content.Context.MODE_PRIVATE)
            .getString(PREFS_EXPECTED_ROOT_KEY, null)
        return if (expectedRoot == ANDROID_DATA_PATH) {
            when {
                normalized == androidData -> ""
                normalized.startsWith("$androidData/") -> normalized.removePrefix("$androidData/")
                else -> null
            }
        } else {
            normalized
        }
    }

    private fun normalizePath(path: String): String =
        path.replace('\\', '/').trim('/').let { value ->
            if (value == ".") "" else value
        }

    private fun childPath(parent: String, name: String): String {
        val normalizedParent = parent.replace('\\', '/')
        val leadingSlash = normalizedParent.startsWith('/')
        val base = normalizedParent.trimEnd('/')
        val child = if (base.isEmpty()) name else "$base/$name"
        return if (leadingSlash && !child.startsWith('/')) "/$child" else child
    }

    companion object {
        const val REQUEST_TREE_PERMISSION = 1202
        const val DEFAULT_TREE_URI_KEY = "saf_tree_uri"
        const val ANDROID_DATA_PATH = "/storage/emulated/0/Android/data"
        private const val PREFS_NAME = "file_repository_preferences"
        private const val PREFS_EXPECTED_ROOT_KEY = "saf_expected_root"
    }
}

/** Backward-compatible name retained for callers that already reference SafFileRepository. */
class SafFileRepository(
    activity: Activity,
    treeUriPreferenceKey: String = SafFileHandler.DEFAULT_TREE_URI_KEY
) : SafFileHandler(activity, treeUriPreferenceKey)

/** Standard java.io.File repository used as the final fallback. */
open class StandardFileRepository : BaseFileRepository() {
    override val storageMode: StorageMode = StorageMode.STANDARD

    override suspend fun list(path: String): List<RepositoryFile> {
        val directory = File(path)
        if (!directory.isDirectory) throw IOException("Not a directory: $path")
        return directory.listFiles()?.map { file ->
            RepositoryFile(file.path, file.name, file.isDirectory)
        } ?: emptyList()
    }

    override suspend fun read(path: String): ByteArray = File(path).readBytes()

    override suspend fun write(path: String, data: ByteArray): Boolean {
        val target = File(path)
        target.parentFile?.mkdirs()
        target.writeBytes(data)
        return true
    }

    override suspend fun delete(path: String): Boolean {
        val target = File(path)
        if (!target.exists()) throw IOException("File not found: $path")
        return target.deleteRecursively()
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean {
        val source = File(sourcePath)
        val destination = File(destinationPath)
        destination.parentFile?.mkdirs()
        if (!source.renameTo(destination)) {
            throw IOException("Unable to move: $sourcePath -> $destinationPath")
        }
        return true
    }

    override suspend fun createDirectory(path: String): Boolean {
        File(path).mkdirs()
        return File(path).isDirectory
    }
}

/**
 * STEP 4: single repository facade for the UI.
 *
 * Resolution order is deliberately fixed:
 *   1) Shizuku + permission
 *   2) persisted SAF tree permission
 *   3) normal java.io.File API
 *
 * The UI can call getFiles(path) without knowing which backend is active.
 */
class HybridFileManager(
    private val activity: Activity,
    private val shizukuHandler: ShizukuFileHandler = ShizukuFileHandler(),
    private val safHandler: SafFileHandler = SafFileHandler(activity),
    private val standardHandler: StandardFileRepository = StandardFileRepository()
) : FileRepository {

    override val storageMode: StorageMode
        get() = selectHandler("").storageMode

    /** Returns the currently selected backend for the supplied path. */
    fun repositoryFor(path: String): FileRepository = selectHandler(path)

    /** UI-friendly directory listing. */
    suspend fun getFiles(path: String): List<RepositoryFile> =
        selectHandler(path).list(path)

    override suspend fun list(path: String): List<RepositoryFile> = getFiles(path)

    override suspend fun read(path: String): ByteArray = selectHandler(path).read(path)

    override suspend fun write(path: String, data: ByteArray): Boolean =
        selectHandler(path).write(path, data)

    override suspend fun delete(path: String): Boolean = selectHandler(path).delete(path)

    override suspend fun move(sourcePath: String, destinationPath: String): Boolean =
        selectHandler(sourcePath).move(sourcePath, destinationPath)

    override suspend fun createDirectory(path: String): Boolean =
        selectHandler(path).createDirectory(path)

    /** Re-evaluates permissions every time; no stale mode is cached. */
    fun refreshMode(path: String): StorageMode = selectHandler(path).storageMode

    private fun selectHandler(path: String): FileRepository {
        if (shizukuHandler.hasPermission()) return shizukuHandler
        if (safHandler.hasPermissionForPath(path)) return safHandler
        return standardHandler
    }
}
