package com.example.filemanager

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import kotlin.math.min

/**
 * Folder/file icon used by the file list. Folders keep the familiar yellow folder
 * shape, with a small semantic badge for well-known Android public folders.
 */
class FileIconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : androidx.appcompat.widget.AppCompatTextView(context, attrs, defStyleAttr) {

    private var folder = false
    private var badge: String? = null

    private val folderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.2f)
    }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }

    fun setFolderIcon(isFolder: Boolean, semanticBadge: String? = null) {
        folder = isFolder
        badge = semanticBadge
        if (isFolder) {
            text = null
            setTextColor(Color.TRANSPARENT)
        }
        invalidate()
    }

    fun setFileIconText(value: String) {
        folder = false
        badge = null
        text = value
        setTextColor(resolveTextColor())
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!folder) {
            super.onDraw(canvas)
            return
        }

        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val cx = width / 2f
        val cy = height / 2f
        val folderW = size * 0.76f
        val folderH = size * 0.58f
        val left = cx - folderW / 2f
        val top = cy - folderH / 2f + size * 0.03f
        val right = cx + folderW / 2f
        val bottom = top + folderH
        val radius = size * 0.07f

        val lightBackground = isLightBackground()
        val fill = if (lightBackground) Color.rgb(232, 171, 20) else Color.rgb(244, 194, 72)
        val stroke = if (lightBackground) Color.rgb(161, 106, 0) else Color.rgb(132, 88, 10)

        folderPaint.color = fill
        outlinePaint.color = stroke
        outlinePaint.strokeWidth = dp(1.1f)

        val path = Path().apply {
            moveTo(left + radius, top)
            lineTo(left + folderW * 0.36f, top)
            lineTo(left + folderW * 0.45f, top + folderH * 0.14f)
            lineTo(right - radius, top + folderH * 0.14f)
            quadTo(right, top + folderH * 0.14f, right, top + folderH * 0.14f + radius)
            lineTo(right, bottom - radius)
            quadTo(right, bottom, right - radius, bottom)
            lineTo(left + radius, bottom)
            quadTo(left, bottom, left, bottom - radius)
            lineTo(left, top + radius)
            quadTo(left, top, left + radius, top)
            close()
        }
        canvas.drawPath(path, folderPaint)
        canvas.drawPath(path, outlinePaint)

        badge?.let { symbol ->
            val badgeSize = size * 0.27f
            val bx = right - badgeSize * 0.62f
            val by = bottom - badgeSize * 0.62f
            val badgeRadius = badgeSize * 0.5f

            badgePaint.color = if (lightBackground) Color.WHITE else Color.rgb(35, 37, 40)
            canvas.drawCircle(bx, by, badgeRadius, badgePaint)

            badgeTextPaint.color = if (lightBackground) Color.rgb(75, 78, 82) else Color.WHITE
            badgeTextPaint.textSize = badgeSize * 0.62f
            val baseline = by - (badgeTextPaint.ascent() + badgeTextPaint.descent()) / 2f
            canvas.drawText(symbol, bx, baseline, badgeTextPaint)
        }
    }

    private fun isLightBackground(): Boolean {
        val currentContext = context
        val background = if (currentContext is android.app.Activity) {
            ThemeHelper.colors(currentContext).third
        } else {
            Color.WHITE
        }
        val r = Color.red(background) / 255f
        val g = Color.green(background) / 255f
        val b = Color.blue(background) / 255f
        return (0.2126f * r + 0.7152f * g + 0.0722f * b) > 0.72f
    }

    private fun resolveTextColor(): Int {
        val typed = android.util.TypedValue()
        return if (context.theme.resolveAttribute(android.R.attr.textColorPrimary, typed, true)) {
            if (typed.resourceId != 0) {
                try { context.getColor(typed.resourceId) } catch (_: Exception) { Color.DKGRAY }
            } else typed.data
        } else Color.DKGRAY
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
