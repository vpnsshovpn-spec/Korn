package com.example.filemanager

import android.view.Gravity
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import android.content.Intent
import android.os.Environment
import java.io.File

/**
 * A handful of small, mostly self-contained file-item actions (hide/unhide, rename, share)
 * plus the toolbar "home" button setup - extracted out of MainActivity.kt (round 10 of the
 * size-reduction plan / STEP 17+). These are extension functions on MainActivity, the same
 * pattern as TrashUiController.kt/SearchHelper.kt/FileClickHelper.kt, since each one either
 * reads a couple of pieces of MainActivity's state directly or is only ever called from
 * onCreate. No logic or behavior was changed; only toolbarHomeButton needed widening from
 * `private` to `internal` in MainActivity.kt so this file (same module) can see it.
 *
 * Note: shareFile() was already unused outside MainActivity.kt before this move (the
 * multi-select "share" action in SelectionModeController.kt has its own separate inline
 * share logic) - it is carried over as-is, not called from anywhere new.
 */

internal fun MainActivity.hideFile(file: File, hide: Boolean) {
    val newName = if (hide) {
        if (file.name.startsWith(".")) file.name else ".${file.name}"
    } else {
        file.name.trimStart('.').ifEmpty { file.name }
    }
    if (newName == file.name) {
        refreshCurrentView()
        return
    }
    val dest = File(file.parentFile, newName)
    if (file.renameTo(dest)) {
        Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
        refreshCurrentView()
    } else {
        Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.renameDialog(file: File) {
    val input = EditText(this)
    input.setText(file.name)
    AlertDialog.Builder(this)
        .setTitle("เปลี่ยนชื่อ")
        .setView(input)
        .setPositiveButton("ตกลง") { _, _ ->
            val newName = input.text.toString().trim()
            if (newName.isNotEmpty()) {
                val newFile = File(file.parentFile, newName)
                if (file.renameToCompat(newFile)) {
                    loadDirectory(currentDir)
                } else {
                    Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.shareFile(file: File) {
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
    } catch (e: Exception) {
        Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.setupToolbarHomeButton() {
    val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
    toolbarHomeButton = android.widget.ImageButton(this).apply {
        setImageResource(R.drawable.ic_home)
        background = null
        contentDescription = "หน้าแรก"
        setPadding(12, 8, 12, 8)
        setOnClickListener { loadDirectory(Environment.getExternalStorageDirectory()) }
    }
    val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
        dp(48),
        dp(48),
        Gravity.START or Gravity.CENTER_VERTICAL
    ).apply {
        marginStart = dp(56)
    }
    toolbar.addView(toolbarHomeButton, lp)
}
