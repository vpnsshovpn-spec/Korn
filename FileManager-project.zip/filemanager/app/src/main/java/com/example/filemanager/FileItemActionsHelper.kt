package com.example.filemanager

import android.view.Gravity
import android.widget.EditText
import android.widget.Toast
import android.os.Environment
import java.io.File

/**
 * A handful of small, mostly self-contained file-item actions (hide/unhide, rename)
 * plus the toolbar "home" button setup - extracted out of MainActivity.kt (round 10 of the
 * size-reduction plan / STEP 17+). These are extension functions on MainActivity, the same
 * pattern as TrashUiController.kt/SearchHelper.kt/FileClickHelper.kt, since each one either
 * reads a couple of pieces of MainActivity's state directly or is only ever called from
 * onCreate. No logic or behavior was changed; only toolbarHomeButton needed widening from
 * `private` to `internal` in MainActivity.kt so this file (same module) can see it.
 *
 * Note: shareFile() (round 10) was confirmed unused anywhere in the app (the multi-select
 * "share" action in SelectionModeController.kt has its own separate inline share logic) and
 * was deleted in round 11, per Korn's confirmation.
 *
 * UX pass (selection-mode auto-exit): renameDialog()'s success branch now exits selection
 * mode when it's called while in selection mode (single-item rename from the "เพิ่มเติม"
 * popup, or renameSelected() with exactly one item selected - the only two call sites of
 * this MainActivity.renameDialog() in the app) instead of only calling loadDirectory(). The
 * "ยกเลิก" (cancel) button already had no handler (null), so cancelling the dialog still
 * leaves the selection untouched. Failure ("เปลี่ยนชื่อไม่สำเร็จ") also still leaves the
 * selection untouched.
 */

internal fun MainActivity.hideFile(file: File, hide: Boolean) {
    val newName = if (hide) {
        if (file.name.startsWith(".")) file.name else ".${file.name}"
    } else {
        file.name.trimStart('.').ifEmpty { file.name }
    }
    if (newName == file.name) {
        refreshCurrentView()
        return
    }
    val dest = File(file.parentFile, newName)
    if (file.renameToCompat(dest)) {
        Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
        refreshCurrentView()
    } else {
        Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.renameDialog(file: File) {
    val input = EditText(this)
    input.setText(file.name)
    KornDialog.Builder(this)
        .setTitle("เปลี่ยนชื่อ")
        .setView(input)
        .setPositiveButton("ตกลง") { _, _ ->
            val newName = input.text.toString().trim()
            if (newName.isNotEmpty()) {
                val newFile = File(file.parentFile, newName)
                if (file.renameToCompat(newFile)) {
                    if (adapter.selectionMode) exitSelectionMode() else loadDirectory(viewModel.currentDir.value)
                } else {
                    Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.setupToolbarHomeButton() {
    val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
    toolbarHomeButton = android.widget.ImageButton(this).apply {
        setImageResource(R.drawable.ic_home)
        background = null
        contentDescription = "หน้าแรก"
        setPadding(12, 8, 12, 8)
        setOnClickListener { loadDirectory(Environment.getExternalStorageDirectory()) }
    }
    val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
        dp(48),
        dp(48),
        Gravity.START or Gravity.CENTER_VERTICAL
    ).apply {
        marginStart = dp(56)
    }
    toolbar.addView(toolbarHomeButton, lp)
}
