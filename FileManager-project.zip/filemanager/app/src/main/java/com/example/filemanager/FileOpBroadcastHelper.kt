package com.example.filemanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Background copy/move (FileOperationService) and archive zip/unzip (ArchiveOperationService)
 * progress broadcast receivers, plus the copy/move subtitle observer. Split out of
 * MainActivity.kt (see MainActivity-Slimdown-Plan.txt ก้อน 3.2) - both receivers only translate
 * Intent extras into viewModel calls and don't depend on any other Activity state.
 *
 * Like ShizukuIntegrationHelper.kt's listener, the receiver *fields* stay declared in
 * MainActivity for object-identity stability across registerReceiver()/unregisterReceiver() in
 * onCreate()/onDestroy(); this file only builds each receiver's body.
 */

internal fun MainActivity.buildFileOpReceiver(): BroadcastReceiver =
    object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                FileOperationService.BROADCAST_PROGRESS -> {
                    val percent = intent.getIntExtra(FileOperationService.EXTRA_PERCENT, 0)
                    val doneCount = intent.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, 0)
                    val totalCount = intent.getIntExtra(FileOperationService.EXTRA_TOTAL_COUNT, 0)
                    val move = intent.getBooleanExtra(FileOperationService.EXTRA_IS_MOVE, false)
                    viewModel.setFileOpProgress(percent, doneCount, totalCount, move)
                }
                FileOperationService.BROADCAST_DONE -> {
                    val done = intent.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, 0)
                    val total = intent.getIntExtra(FileOperationService.EXTRA_TOTAL_COUNT, 0)
                    val failures = intent.getStringArrayListExtra(FileOperationService.EXTRA_FAILED_NAMES)
                        ?: arrayListOf()
                    viewModel.setFileOpDone(done, total, failures)
                }
            }
        }
    }

internal fun MainActivity.buildArchiveOpReceiver(): BroadcastReceiver =
    object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ArchiveOperationService.BROADCAST_PROGRESS -> {
                    val percent = intent.getIntExtra(ArchiveOperationService.EXTRA_PERCENT, 0)
                    val isUnzip = intent.getBooleanExtra(ArchiveOperationService.EXTRA_IS_UNZIP, false)
                    val name = intent.getStringExtra(ArchiveOperationService.EXTRA_ARCHIVE_NAME) ?: ""
                    viewModel.setArchiveOpProgress(percent, isUnzip, name)
                }
                ArchiveOperationService.BROADCAST_DONE -> {
                    val isUnzip = intent.getBooleanExtra(ArchiveOperationService.EXTRA_IS_UNZIP, false)
                    val name = intent.getStringExtra(ArchiveOperationService.EXTRA_ARCHIVE_NAME) ?: ""
                    val success = intent.getBooleanExtra(ArchiveOperationService.EXTRA_SUCCESS, false)
                    val error = intent.getStringExtra(ArchiveOperationService.EXTRA_ERROR)
                    viewModel.setArchiveOpDone(isUnzip, name, success, error)
                }
            }
        }
    }

/**
 * Round B: renders [MainViewModel.fileOpState] (sticky - so it also reflects the correct
 * in-progress percent right after an Activity recreation/rotation, once Round C's actual
 * rotation test exercises that path). Only touches the subtitle while a copy/move is
 * actually running; once it finishes, the FileOpDone event handler in observeDirectoryState()
 * calls loadDirectory()/refreshCurrentView(), which puts the subtitle back to the normal
 * "N รายการ" text via directoryState - same as before this round, when fileOpReceiver never
 * explicitly cleared the subtitle on DONE either.
 */
internal fun MainActivity.observeFileOpState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            viewModel.fileOpState.collect { state ->
                if (state.isRunning) {
                    supportActionBar?.subtitle =
                        "${if (state.isMove) "กำลังย้าย" else "กำลังคัดลอก"}… ${state.percent}%"
                }
            }
        }
    }
}
