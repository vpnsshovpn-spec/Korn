package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.example.filemanager.shizuku.ShizukuFileService
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.serializer
import java.io.File
import com.example.filemanager.data.local.AppDataStore
import com.example.filemanager.data.repository.FileCategories
import com.example.filemanager.data.repository.needsShizuku

/**
 * File opening and recent-file orchestration extracted from MainActivity (STEP 14).
 * Existing behavior is intentionally preserved; MainActivity remains the state owner.
 */
internal fun MainActivity.rememberRecentFile(file: File) {
    if (!file.isFile) return
    // Task 3: migrated off the old "\n"-joined SharedPreferences string onto the same
    // DataStore + JSON approach as DirectoryHistoryHelper (see AppDataStore).
    lifecycleScope.launch(Dispatchers.IO) {
        val old = AppDataStore.read(this@rememberRecentFile, RECENT_FILES_KEY, emptyList(), kotlinx.serialization.builtins.ListSerializer(String.serializer()))
        val updated = (listOf(file.absolutePath) + old.filter { it != file.absolutePath }).take(30)
        AppDataStore.write(this@rememberRecentFile, RECENT_FILES_KEY, updated, kotlinx.serialization.builtins.ListSerializer(String.serializer()))
    }
}

internal val RECENT_FILES_KEY = AppDataStore.key("recent_files_json")

internal fun MainActivity.openFile(file: File) {
    rememberRecentFile(file)
    val options = arrayOf("เปิดด้วย KORN", "เปิดด้วยแอปอื่น…")
    KornDialog.Builder(this)
        .setTitle(file.name)
        .setItems(options) { _, which ->
            when (which) {
                0 -> resolveForOpen(file) { resolved, syncBackTo -> openFileInternally(resolved, syncBackTo) }
                1 -> resolveForOpen(file) { resolved, _ -> openFileExternally(resolved) }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.resolveForOpen(
    file: File,
    action: (resolved: File, syncBackTo: File?) -> Unit
) {
    if (file.canRead()) {
        action(file, null)
        return
    }
    if (!file.needsShizuku()) {
        Toast.makeText(this, "เปิดไฟล์ไม่ได้", Toast.LENGTH_SHORT).show()
        return
    }
    Toast.makeText(this, "กำลังดึงไฟล์ผ่าน Shizuku…", Toast.LENGTH_SHORT).show()
    val activity = this
    lifecycleScope.launch {
        val cache = File(File(cacheDir, "shizuku_open"), file.name)
        val ok = withContext(Dispatchers.IO) {
            cache.parentFile?.mkdirs()
            ShizukuFileService.downloadToLocal(file.absolutePath, cache)
        }
        if (ok) {
            action(cache, file)
        } else {
            Toast.makeText(activity, "เปิดไฟล์ไม่ได้ (Shizuku)", Toast.LENGTH_SHORT).show()
        }
    }
}

internal fun MainActivity.openFileInternally(file: File, syncBackTo: File? = null) {
    val ext = file.extension.lowercase()
    try {
        if (FileCategories.IMAGES.contains(ext)) {
            startActivity(Intent(this, ImageViewerActivity::class.java).apply {
                putExtra(ImageViewerActivity.EXTRA_IMAGE_PATH, file.absolutePath)
            })
            return
        }
        if (syncBackTo != null) pendingShizukuSync = file to syncBackTo
        startActivityForResult(Intent(this, TextEditActivity::class.java).apply {
            putExtra(TextEditActivity.EXTRA_FILE_PATH, file.absolutePath)
        }, MainActivity.REQUEST_TEXT_EDIT)
    } catch (e: Exception) {
        Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.openFileExternally(file: File) {
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "เปิดด้วย"))
    } catch (e: Exception) {
        Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

/**
 * "เปิด/ส่งให้ Minecraft" ใน showArchiveOpenOptions() เดิมเรียก openFile(file) ซึ่งเป็นฟังก์ชัน
 * เดียวกับที่ใช้เปิดไฟล์ทั่วไป - โผล่ dialog "เปิดด้วย KORN / เปิดด้วยแอปอื่น…" ซ้ำขึ้นมาอีกชั้น
 * (เมนูซ้อนเมนู) ทั้งที่ตั้งใจให้กดแล้วพุ่งเข้า Minecraft ไปเลย จุดนี้ยิง ACTION_VIEW แบบระบุ
 * setPackage ไปที่ Minecraft ตรงๆ ทีเดียวจบ ไม่ผ่าน dialog/chooser ใดๆ อีก
 */
internal fun MainActivity.openMinecraftPack(file: File) {
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            setPackage("com.mojang.minecraftpe")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(intent)
    } catch (e: android.content.ActivityNotFoundException) {
        Toast.makeText(this, "ไม่พบแอป Minecraft ในเครื่องนี้", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
