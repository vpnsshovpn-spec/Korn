package com.example.filemanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.filemanager.shizuku.ShizukuFileService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Runs copy/move jobs outside the Activity lifecycle so large transfers
 * survive the user switching apps or the screen turning off, with a
 * persistent notification showing progress. Files this app's own process
 * can't reach directly (e.g. another app's Android/data folder) fall back
 * to the Shizuku-backed copy — that path can't report incremental
 * progress, but the operation still completes.
 */
class FileOperationService : Service() {

    companion object {
        const val CHANNEL_ID = "file_operations"
        private const val NOTIFICATION_ID = 4201

        const val ACTION_COPY = "com.example.filemanager.action.COPY"
        const val ACTION_MOVE = "com.example.filemanager.action.MOVE"
        private const val EXTRA_SOURCES = "extra_sources"
        private const val EXTRA_DEST_DIR = "extra_dest_dir"

        const val BROADCAST_PROGRESS = "com.example.filemanager.FILE_OP_PROGRESS"
        const val BROADCAST_DONE = "com.example.filemanager.FILE_OP_DONE"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_DONE_COUNT = "extra_done_count"
        const val EXTRA_TOTAL_COUNT = "extra_total_count"
        const val EXTRA_IS_MOVE = "extra_is_move"

        fun start(context: Context, sources: List<File>, destDir: File, move: Boolean) {
            val intent = Intent(context, FileOperationService::class.java).apply {
                action = if (move) ACTION_MOVE else ACTION_COPY
                putStringArrayListExtra(EXTRA_SOURCES, ArrayList(sources.map { it.absolutePath }))
                putExtra(EXTRA_DEST_DIR, destDir.absolutePath)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "การคัดลอก/ย้ายไฟล์", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val move = intent?.action == ACTION_MOVE
        val sourcePaths = intent?.getStringArrayListExtra(EXTRA_SOURCES) ?: arrayListOf()
        val destDirPath = intent?.getStringExtra(EXTRA_DEST_DIR)
        val sources = sourcePaths.map { File(it) }
        val destDir = destDirPath?.let { File(it) }

        if (sources.isEmpty() || destDir == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(move, 0).build())

        job = scope.launch {
            runOperation(sources, destDir, move)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(move: Boolean, percent: Int): NotificationCompat.Builder {
        val title = if (move) "กำลังย้ายไฟล์…" else "กำลังคัดลอกไฟล์…"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("$percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, percent, false)
    }

    private fun runOperation(sources: List<File>, destDir: File, move: Boolean) {
        val totalBytes = sources.sumOf { sizeRecursive(it) }.coerceAtLeast(1L)
        var copiedBytes = 0L
        var lastNotifiedPercent = -1
        var successCount = 0

        for (src in sources) {
            try {
                var dest = File(destDir, src.name)
                if (dest.existsCompat()) dest = File(destDir, uniqueDestName(destDir, src.name, src.isDirectory))
                if (move && src.renameToCompat(dest)) {
                    // Same-volume rename — instant, no byte-by-byte copy needed.
                    copiedBytes = (copiedBytes + sizeRecursive(dest)).coerceAtMost(totalBytes)
                    val percent = ((copiedBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                    if (percent != lastNotifiedPercent) {
                        lastNotifiedPercent = percent
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(move, percent).build())
                        broadcastProgress(percent, successCount, sources.size, move)
                    }
                    successCount++
                    continue
                }
                copiedBytes = copyWithProgress(src, dest, copiedBytes, totalBytes) { percent ->
                    if (percent != lastNotifiedPercent) {
                        lastNotifiedPercent = percent
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(move, percent).build())
                        broadcastProgress(percent, successCount, sources.size, move)
                    }
                }
                if (move) src.deleteRecursivelyCompat()
                successCount++
            } catch (e: Exception) {
                // Skip this item, keep going with the rest.
            }
        }
        broadcastDone(successCount, sources.size, move)
    }

    private fun sizeRecursive(f: File): Long {
        val children = f.listFilesCompat()
        return if (children == null) {
            if (f.isFile || f.needsShizuku()) f.length().let { if (it > 0) it else 1L } else 0L
        } else {
            children.sumOf { sizeRecursive(it) }
        }
    }

    /** Copies [src] into [dest] (recursing into directories), reporting overall percent along the way. */
    private fun copyWithProgress(
        src: File, dest: File, startBytes: Long, totalBytes: Long, onProgress: (Int) -> Unit
    ): Long {
        var copied = startBytes
        if (src.isDirectory && !src.needsShizuku()) {
            dest.mkdirsCompat()
            val children = src.listFilesCompat() ?: emptyList()
            for (child in children) {
                copied = copyWithProgress(child, File(dest, child.name), copied, totalBytes, onProgress)
            }
        } else {
            copied = copySingleFile(src, dest, copied, totalBytes, onProgress)
        }
        return copied
    }

    private fun copySingleFile(src: File, dest: File, startBytes: Long, totalBytes: Long, onProgress: (Int) -> Unit): Long {
        var copied = startBytes
        if (src.canRead()) {
            try {
                src.inputStream().use { input ->
                    dest.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var read: Int
                        while (input.read(buffer).also { read = it } >= 0) {
                            output.write(buffer, 0, read)
                            copied += read
                            onProgress(((copied * 100) / totalBytes).toInt().coerceIn(0, 100))
                        }
                    }
                }
                scanMedia(dest)
                return copied
            } catch (e: Exception) {
                // Fall through to the Shizuku path below.
            }
        }
        // Not directly readable (e.g. another app's Android/data) — hand the whole
        // file/tree to the Shizuku remote process, which isn't restricted the way
        // this app's own process is. No incremental progress in this branch.
        if (ShizukuManager.hasPermission()) {
            val remoteOk = ShizukuFileService.copyRecursive(src.absolutePath, dest.absolutePath)
            if (!remoteOk) {
                throw IOException("Shizuku copy failed: ${src.absolutePath}")
            }
            scanMedia(dest)
            copied = (copied + src.length()).coerceAtMost(totalBytes)
            onProgress(((copied * 100) / totalBytes).toInt().coerceIn(0, 100))
            return copied
        }
        throw IOException("ไม่สามารถอ่านไฟล์และไม่มี Shizuku: ${src.name}")
    }

    /**
     * Tells MediaStore about a file this service just wrote directly to disk, so it
     * shows up immediately in other apps' media/file pickers (e.g. a web upload
     * dialog) instead of only after the next full media scan or a reboot.
     */
    private fun scanMedia(file: File) {
        try {
            android.media.MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), null, null)
        } catch (e: Exception) {
            // Best-effort only.
        }
    }

    private fun uniqueDestName(dir: File, desired: String, isDir: Boolean): String {
        val dot = desired.lastIndexOf('.')
        val base = if (!isDir && dot > 0) desired.substring(0, dot) else desired
        val ext = if (!isDir && dot > 0) desired.substring(dot) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base ($i)$ext"
            i++
        } while (File(dir, candidate).existsCompat())
        return candidate
    }

    private fun broadcastProgress(percent: Int, doneCount: Int, totalCount: Int, move: Boolean) {
        sendBroadcast(Intent(BROADCAST_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_PERCENT, percent)
            putExtra(EXTRA_DONE_COUNT, doneCount)
            putExtra(EXTRA_TOTAL_COUNT, totalCount)
            putExtra(EXTRA_IS_MOVE, move)
        })
    }

    private fun broadcastDone(doneCount: Int, totalCount: Int, move: Boolean) {
        sendBroadcast(Intent(BROADCAST_DONE).apply {
            setPackage(packageName)
            putExtra(EXTRA_DONE_COUNT, doneCount)
            putExtra(EXTRA_TOTAL_COUNT, totalCount)
            putExtra(EXTRA_IS_MOVE, move)
        })
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
