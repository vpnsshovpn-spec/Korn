package com.example.filemanager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.filemanager.shizuku.ShizukuFileService
import com.example.filemanager.shizuku.ShizukuOperationResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

/**
 * Runs copy/move jobs outside the Activity lifecycle so large transfers
 * survive the user switching apps or the screen turning off, with a
 * persistent notification showing progress. Files this app's own process
 * can't reach directly (e.g. another app's Android/data folder) fall back
 * to the Shizuku-backed copy — that path can't report incremental
 * progress, but the operation still completes.
 */
class FileOperationService : Service() {

    companion object {
        const val CHANNEL_ID = "file_operations"
        private const val NOTIFICATION_ID = 4201

        const val ACTION_COPY = "com.example.filemanager.action.COPY"
        const val ACTION_MOVE = "com.example.filemanager.action.MOVE"
        private const val EXTRA_SOURCES = "extra_sources"
        private const val EXTRA_DEST_DIR = "extra_dest_dir"
        private const val EXTRA_OVERWRITE_PATHS = "extra_overwrite_paths"

        const val BROADCAST_PROGRESS = "com.example.filemanager.FILE_OP_PROGRESS"
        const val BROADCAST_DONE = "com.example.filemanager.FILE_OP_DONE"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_DONE_COUNT = "extra_done_count"
        const val EXTRA_TOTAL_COUNT = "extra_total_count"
        const val EXTRA_IS_MOVE = "extra_is_move"
        const val EXTRA_FAILED_NAMES = "extra_failed_names"
        const val EXTRA_INDEX_MOVES = "extra_index_moves"
        const val EXTRA_INDEX_ADDS = "extra_index_adds"
        const val EXTRA_INDEX_REMOVALS = "extra_index_removals"
        const val EXTRA_INDEX_NEEDS_FULL_SYNC = "extra_index_needs_full_sync"

        /**
         * [overwritePaths] is the set of [sources] absolute paths the user already chose
         * "เขียนทับ" (Overwrite) for at a pre-existing destination name, via the
         * CopyMoveConflictResolver.kt dialog flow - anything not in this set that still
         * collides with an existing destination name falls back to the original
         * auto-rename behavior (RENAME), unchanged from before this feature existed.
         * Any source the user chose "ข้าม" (Skip) for should simply not be included in
         * [sources] at all - the caller filters those out before calling start().
         */
        fun start(context: Context, sources: List<File>, destDir: File, move: Boolean, overwritePaths: Set<String> = emptySet()) {
            val intent = Intent(context, FileOperationService::class.java).apply {
                action = if (move) ACTION_MOVE else ACTION_COPY
                putStringArrayListExtra(EXTRA_SOURCES, ArrayList(sources.map { it.absolutePath }))
                putExtra(EXTRA_DEST_DIR, destDir.absolutePath)
                putStringArrayListExtra(EXTRA_OVERWRITE_PATHS, ArrayList(overwritePaths))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "การคัดลอก/ย้ายไฟล์", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val move = intent?.action == ACTION_MOVE
        val sourcePaths = intent?.getStringArrayListExtra(EXTRA_SOURCES) ?: arrayListOf()
        val destDirPath = intent?.getStringExtra(EXTRA_DEST_DIR)
        val overwritePaths = (intent?.getStringArrayListExtra(EXTRA_OVERWRITE_PATHS) ?: arrayListOf()).toSet()
        val sources = sourcePaths.map { File(it) }
        val destDir = destDirPath?.let { File(it) }

        if (sources.isEmpty() || destDir == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(move, 0).build())

        job = scope.launch {
            runOperation(sources, destDir, move, overwritePaths)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(move: Boolean, percent: Int): NotificationCompat.Builder {
        val title = if (move) "กำลังย้ายไฟล์…" else "กำลังคัดลอกไฟล์…"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("$percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, percent, false)
    }

    // Test-only visibility: exposes the pure copy/move + index-diff logic to
    // SearchIndexServiceBroadcastTest.kt without needing a full Service lifecycle
    // or reflection. Behavior/signature for production call sites (onStartCommand)
    // is unchanged - this is the same private implementation, just visible in-module.
    internal fun runOperation(sources: List<File>, destDir: File, move: Boolean, overwritePaths: Set<String> = emptySet()) {
        val totalBytes = sources.sumOf { sizeRecursive(it) }.coerceAtLeast(1L)
        var copiedBytes = 0L
        var lastNotifiedPercent = -1
        var successCount = 0
        val failures = mutableListOf<String>()
        val indexMoves = mutableListOf<String>()
        val indexAdds = mutableListOf<String>()
        val indexRemovals = mutableListOf<String>()
        var indexNeedsFullSync = false

        for (src in sources) {
            try {
                var dest = File(destDir, src.name)
                if (dest.existsCompat()) {
                    if (src.absolutePath in overwritePaths) {
                        // User already chose "เขียนทับ" for this exact name via the
                        // conflict dialog - clear the old destination first so the
                        // transfer below always lands on a clean path, regardless of
                        // whether it's a file/folder or the old and new items differ
                        // in type. dest itself stays as the original (non-renamed) path.
                        if (!dest.deleteRecursivelyCompat()) {
                            failures.add("${src.name}: ลบไฟล์เดิมก่อนเขียนทับไม่สำเร็จ")
                            indexNeedsFullSync = true
                            continue
                        }
                        indexRemovals += dest.absolutePath
                    } else {
                        // Not a resolved overwrite - same auto-rename fallback that's
                        // always existed here (covers RENAME's chosen resolution, plus
                        // anything left unresolved for any other reason).
                        dest = File(destDir, uniqueDestName(destDir, src.name, src.isDirectory))
                    }
                }
                if (move && src.renameToCompat(dest)) {
                    // Same-volume rename — instant, no byte-by-byte copy needed.
                    copiedBytes = (copiedBytes + sizeRecursive(dest)).coerceAtMost(totalBytes)
                    val percent = ((copiedBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                    if (percent != lastNotifiedPercent) {
                        lastNotifiedPercent = percent
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(move, percent).build())
                        broadcastProgress(percent, successCount, sources.size, move)
                    }
                    successCount++
                    indexMoves += src.absolutePath + "\u0000" + dest.absolutePath
                    continue
                }
                val beforeCopyBytes = copiedBytes
                val copyResult = copyWithProgress(src, dest, copiedBytes, totalBytes) { percent ->
                    if (percent != lastNotifiedPercent) {
                        lastNotifiedPercent = percent
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(move, percent).build())
                        broadcastProgress(percent, successCount, sources.size, move)
                    }
                }
                if (copyResult.result != ShizukuOperationResult.SUCCESS) {
                    copiedBytes = beforeCopyBytes
                    failures.add("${src.name}: ${reasonText(copyResult.result)}")
                    // A failed copy can leave a partially-created destination. Rebuild the
                    // index rather than guessing which descendants were actually written.
                    indexNeedsFullSync = true
                    continue
                }
                copiedBytes = copyResult.bytes
                if (move && !src.deleteRecursivelyCompat()) {
                    // Never claim a move when source cleanup failed. The destination
                    // remains intact so the user can retry safely. The index cannot be
                    // updated safely without rescanning, so request a full sync.
                    failures.add("${src.name}: ลบต้นฉบับไม่สำเร็จหลังคัดลอก")
                    indexNeedsFullSync = true
                    continue
                }
                successCount++
                if (move) {
                    indexMoves += src.absolutePath + "\u0000" + dest.absolutePath
                } else {
                    indexAdds += dest.absolutePath
                }
            } catch (e: Exception) {
                // The operation may have changed the filesystem before throwing.
                // Do not guess the index state in that case.
                indexNeedsFullSync = true
                failures.add("${src.name}: เกิดข้อผิดพลาดที่ไม่คาดคิด")
            }
        }
        broadcastDone(
            successCount, sources.size, move, failures,
            indexMoves, indexAdds, indexRemovals, indexNeedsFullSync
        )
    }

    private fun reasonText(result: ShizukuOperationResult): String = when (result) {
        ShizukuOperationResult.PERMISSION_DENIED -> "ไม่มีสิทธิ์เข้าถึง"
        ShizukuOperationResult.NOT_FOUND -> "ไม่พบไฟล์ต้นทาง"
        ShizukuOperationResult.UNAVAILABLE -> "Shizuku ไม่พร้อมใช้งาน"
        ShizukuOperationResult.PARTIAL -> "ทำสำเร็จบางส่วน"
        ShizukuOperationResult.FAILED, ShizukuOperationResult.SUCCESS -> "ทำรายการไม่สำเร็จ"
    }

    private fun sizeRecursive(f: File): Long {
        val children = f.listFilesCompat()
        return if (children == null) {
            if (f.isFile || f.needsShizuku()) f.length().let { if (it > 0) it else 1L } else 0L
        } else {
            children.sumOf { sizeRecursive(it) }
        }
    }

    /** Copies [src] into [dest] (recursing into directories), reporting overall percent along the way. */
    private data class CopyResult(val bytes: Long, val result: ShizukuOperationResult)

    private fun copyWithProgress(
        src: File, dest: File, startBytes: Long, totalBytes: Long, onProgress: (Int) -> Unit
    ): CopyResult {
        var copied = startBytes
        if (src.isDirectory && !src.needsShizuku()) {
            if (!dest.mkdirsCompat() && !dest.isDirectory) {
                return CopyResult(copied, ShizukuOperationResult.FAILED)
            }
            val children = src.listFilesCompat() ?: return CopyResult(copied, ShizukuOperationResult.FAILED)
            for (child in children) {
                val childResult = copyWithProgress(child, File(dest, child.name), copied, totalBytes, onProgress)
                if (childResult.result != ShizukuOperationResult.SUCCESS) return CopyResult(copied, ShizukuOperationResult.PARTIAL)
                copied = childResult.bytes
            }
        } else {
            return copySingleFile(src, dest, copied, totalBytes, onProgress)
        }
        return CopyResult(copied, ShizukuOperationResult.SUCCESS)
    }

    private fun copySingleFile(src: File, dest: File, startBytes: Long, totalBytes: Long, onProgress: (Int) -> Unit): CopyResult {
        var copied = startBytes
        if (src.canRead()) {
            try {
                src.inputStream().use { input ->
                    dest.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var read: Int
                        while (input.read(buffer).also { read = it } >= 0) {
                            output.write(buffer, 0, read)
                            copied += read
                            onProgress(((copied * 100) / totalBytes).toInt().coerceIn(0, 100))
                        }
                    }
                }
                scanMedia(dest)
                return CopyResult(copied, ShizukuOperationResult.SUCCESS)
            } catch (e: Exception) {
                // Fall through to the Shizuku path below.
            }
        }
        // Not directly readable (e.g. another app's Android/data) — hand the whole
        // file/tree to the Shizuku remote process, which isn't restricted the way
        // this app's own process is. No incremental progress in this branch.
        if (!ShizukuManager.hasPermission()) {
            return CopyResult(copied, ShizukuOperationResult.PERMISSION_DENIED)
        }
        val result = ShizukuFileService.copyRecursiveResult(src.absolutePath, dest.absolutePath)
        if (result != ShizukuOperationResult.SUCCESS) {
            return CopyResult(copied, result)
        }
        scanMedia(dest)
        copied = (copied + src.length()).coerceAtMost(totalBytes)
        onProgress(((copied * 100) / totalBytes).toInt().coerceIn(0, 100))
        return CopyResult(copied, ShizukuOperationResult.SUCCESS)
    }

    /**
     * Tells MediaStore about a file this service just wrote directly to disk, so it
     * shows up immediately in other apps' media/file pickers (e.g. a web upload
     * dialog) instead of only after the next full media scan or a reboot.
     */
    private fun scanMedia(file: File) {
        try {
            android.media.MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), null, null)
        } catch (e: Exception) {
            // Best-effort only.
        }
    }

    private fun uniqueDestName(dir: File, desired: String, isDir: Boolean): String {
        val dot = desired.lastIndexOf('.')
        val base = if (!isDir && dot > 0) desired.substring(0, dot) else desired
        val ext = if (!isDir && dot > 0) desired.substring(dot) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base ($i)$ext"
            i++
        } while (File(dir, candidate).existsCompat())
        return candidate
    }

    private fun broadcastProgress(percent: Int, doneCount: Int, totalCount: Int, move: Boolean) {
        sendBroadcast(Intent(BROADCAST_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_PERCENT, percent)
            putExtra(EXTRA_DONE_COUNT, doneCount)
            putExtra(EXTRA_TOTAL_COUNT, totalCount)
            putExtra(EXTRA_IS_MOVE, move)
        })
    }

    private fun broadcastDone(
        doneCount: Int, totalCount: Int, move: Boolean, failures: List<String> = emptyList(),
        indexMoves: List<String> = emptyList(), indexAdds: List<String> = emptyList(),
        indexRemovals: List<String> = emptyList(), indexNeedsFullSync: Boolean = false
    ) {
        sendBroadcast(Intent(BROADCAST_DONE).apply {
            setPackage(packageName)
            putExtra(EXTRA_DONE_COUNT, doneCount)
            putExtra(EXTRA_TOTAL_COUNT, totalCount)
            putExtra(EXTRA_IS_MOVE, move)
            putStringArrayListExtra(EXTRA_FAILED_NAMES, ArrayList(failures))
            putStringArrayListExtra(EXTRA_INDEX_MOVES, ArrayList(indexMoves))
            putStringArrayListExtra(EXTRA_INDEX_ADDS, ArrayList(indexAdds))
            putStringArrayListExtra(EXTRA_INDEX_REMOVALS, ArrayList(indexRemovals))
            putExtra(EXTRA_INDEX_NEEDS_FULL_SYNC, indexNeedsFullSync)
        })
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
