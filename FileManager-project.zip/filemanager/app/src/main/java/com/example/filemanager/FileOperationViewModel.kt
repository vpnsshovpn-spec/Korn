package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): clipboard,
 * multi-select, copy/move progress, and the copy/move conflict-resolution batch now live here
 * instead of MainViewModel - clipboardFiles/clipboardIsCut (Round 15), selectionMode/
 * selectedPaths (Round A), fileOpState (Round B), selectionMoreMenuOpen (Rotation Safety #5),
 * trashConfirmDialogOpen (Rotation Safety #4), and copyMoveConflictBatch (Rotation Safety #2).
 * This is a pure move: no logic changed, only which class owns the state - same
 * "ห้ามแก้ชื่อคลาส/ฟังก์ชันระหว่างย้าย" caution as step 1.
 *
 * extractConflictBatch/ExtractConflictBatch and the archive/compress progress state
 * (archiveOpState/compressOpState) deliberately stay on MainViewModel - round2-instructions.txt
 * scopes this step to the 8 fields named above only; extract's conflict batch and the
 * archive/compress-specific state are out of scope for step 2.
 *
 * [events] is a small local counterpart to MainViewModel.UiEvent.FileOpDone, needed for the
 * same reason DirectoryViewModel.toastEvents exists (see that class's doc): this class can't
 * reach into MainViewModel's private _events, so copy/move completion gets its own minimal
 * event flow instead of introducing a ViewModel-to-ViewModel dependency. MainActivity collects
 * both (see DirectoryStateObserver.kt).
 */
class FileOperationViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    /** One-shot "copy/move finished" signal - mirrors MainViewModel.UiEvent.FileOpDone exactly. */
    data class FileOpDoneEvent(
        val doneCount: Int,
        val totalCount: Int,
        val failures: List<String>,
        val indexMoves: List<String> = emptyList(),
        val indexAdds: List<String> = emptyList(),
        val indexRemovals: List<String> = emptyList(),
        val indexNeedsFullSync: Boolean = false
    )

    private val _events = MutableSharedFlow<FileOpDoneEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<FileOpDoneEvent> = _events

    // ---------- Clipboard state (Round 15) ----------

    private val _clipboardFiles = MutableStateFlow<List<File>>(emptyList())
    val clipboardFiles: StateFlow<List<File>> = _clipboardFiles
    fun setClipboardFiles(value: List<File>) { _clipboardFiles.value = value }

    private val _clipboardIsCut = MutableStateFlow(false)
    val clipboardIsCut: StateFlow<Boolean> = _clipboardIsCut
    fun setClipboardIsCut(value: Boolean) { _clipboardIsCut.value = value }

    // ---------- Dialog-open flags (Rotation Safety #4/#5) ----------

    private val _trashConfirmDialogOpen = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_TRASH_CONFIRM_OPEN) ?: false
    )
    val trashConfirmDialogOpen: StateFlow<Boolean> = _trashConfirmDialogOpen
    fun setTrashConfirmDialogOpen(open: Boolean) {
        _trashConfirmDialogOpen.value = open
        savedStateHandle[KEY_TRASH_CONFIRM_OPEN] = open
    }

    private val _selectionMoreMenuOpen = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SELECTION_MORE_MENU_OPEN) ?: false
    )
    val selectionMoreMenuOpen: StateFlow<Boolean> = _selectionMoreMenuOpen
    fun setSelectionMoreMenuOpen(open: Boolean) {
        _selectionMoreMenuOpen.value = open
        savedStateHandle[KEY_SELECTION_MORE_MENU_OPEN] = open
    }

    // ---------- Multi-select state (Round A) ----------

    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode

    private val _selectedPaths = MutableStateFlow<Set<String>>(emptySet())
    val selectedPaths: StateFlow<Set<String>> = _selectedPaths

    fun setSelectionState(selectionMode: Boolean, selectedPaths: Set<String>) {
        _selectionMode.value = selectionMode
        _selectedPaths.value = selectedPaths
    }

    // ---------- Copy/Move progress state (Round B) ----------

    data class FileOpUiState(
        val isRunning: Boolean = false,
        val percent: Int = 0,
        val isMove: Boolean = false,
        val doneCount: Int = 0,
        val totalCount: Int = 0
    )

    private val _fileOpState = MutableStateFlow(FileOpUiState())
    val fileOpState: StateFlow<FileOpUiState> = _fileOpState

    fun setFileOpProgress(percent: Int, doneCount: Int, totalCount: Int, isMove: Boolean) {
        _fileOpState.value = FileOpUiState(
            isRunning = true,
            percent = percent,
            isMove = isMove,
            doneCount = doneCount,
            totalCount = totalCount
        )
    }

    fun setFileOpDone(
        doneCount: Int,
        totalCount: Int,
        failures: List<String>,
        indexMoves: List<String> = emptyList(),
        indexAdds: List<String> = emptyList(),
        indexRemovals: List<String> = emptyList(),
        indexNeedsFullSync: Boolean = false
    ) {
        _fileOpState.value = FileOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(
                FileOpDoneEvent(
                    doneCount, totalCount, failures,
                    indexMoves, indexAdds, indexRemovals, indexNeedsFullSync
                )
            )
        }
    }

    // ---------- Conflict-resolution batch state (Rotation Safety #2) ----------
    //
    // Copy/Move's half only - see class doc for why Extract's batch stays on MainViewModel.

    data class CopyMoveConflictBatch(
        val allSourcePaths: List<String>,
        val destDirPath: String,
        val move: Boolean,
        val remaining: List<String>,
        val overwritePaths: Set<String>,
        val skipPaths: Set<String>,
        val forcedAction: ConflictAction?
    )

    private fun persistCopyMoveBatch(batch: CopyMoveConflictBatch?) {
        savedStateHandle[KEY_CM_ACTIVE] = batch != null
        if (batch == null) return
        savedStateHandle[KEY_CM_ALL_SOURCES] = ArrayList(batch.allSourcePaths)
        savedStateHandle[KEY_CM_DEST_DIR] = batch.destDirPath
        savedStateHandle[KEY_CM_MOVE] = batch.move
        savedStateHandle[KEY_CM_REMAINING] = ArrayList(batch.remaining)
        savedStateHandle[KEY_CM_OVERWRITE] = ArrayList(batch.overwritePaths)
        savedStateHandle[KEY_CM_SKIP] = ArrayList(batch.skipPaths)
        savedStateHandle[KEY_CM_FORCED] = batch.forcedAction?.name
    }

    private fun restoreCopyMoveBatch(): CopyMoveConflictBatch? {
        if (savedStateHandle.get<Boolean>(KEY_CM_ACTIVE) != true) return null
        val allSources = savedStateHandle.get<ArrayList<String>>(KEY_CM_ALL_SOURCES)
        val destDir = savedStateHandle.get<String>(KEY_CM_DEST_DIR)
        if (allSources == null || destDir == null) return null
        val remaining = savedStateHandle.get<ArrayList<String>>(KEY_CM_REMAINING) ?: arrayListOf()
        if (remaining.isEmpty()) return null
        return CopyMoveConflictBatch(
            allSourcePaths = allSources,
            destDirPath = destDir,
            move = savedStateHandle.get<Boolean>(KEY_CM_MOVE) ?: false,
            remaining = remaining,
            overwritePaths = savedStateHandle.get<ArrayList<String>>(KEY_CM_OVERWRITE)?.toSet() ?: emptySet(),
            skipPaths = savedStateHandle.get<ArrayList<String>>(KEY_CM_SKIP)?.toSet() ?: emptySet(),
            forcedAction = savedStateHandle.get<String>(KEY_CM_FORCED)
                ?.let { name -> runCatching { ConflictAction.valueOf(name) }.getOrNull() }
        )
    }

    private val _copyMoveConflictBatch = MutableStateFlow(restoreCopyMoveBatch())
    val copyMoveConflictBatch: StateFlow<CopyMoveConflictBatch?> = _copyMoveConflictBatch

    /** Starts a brand-new batch (called only from startCopyMoveWithConflictCheck). */
    fun startCopyMoveConflictBatch(batch: CopyMoveConflictBatch) = updateCopyMoveConflictBatch(batch)

    /** Advances/replaces the in-progress batch, or clears it with null when finished/cancelled. */
    fun updateCopyMoveConflictBatch(batch: CopyMoveConflictBatch?) {
        _copyMoveConflictBatch.value = batch
        persistCopyMoveBatch(batch)
    }

    fun clearCopyMoveConflictBatch() = updateCopyMoveConflictBatch(null)

    companion object {
        // Rotation Safety #4/#5 (dialog-open flags, process-death-safe) keys
        private const val KEY_TRASH_CONFIRM_OPEN = "trash_confirm_dialog_open"
        private const val KEY_SELECTION_MORE_MENU_OPEN = "selection_more_menu_open"

        // Rotation Safety #2 (conflict-resolution batch persistence) keys
        private const val KEY_CM_ACTIVE = "cm_conflict_active"
        private const val KEY_CM_ALL_SOURCES = "cm_conflict_all_sources"
        private const val KEY_CM_DEST_DIR = "cm_conflict_dest_dir"
        private const val KEY_CM_MOVE = "cm_conflict_move"
        private const val KEY_CM_REMAINING = "cm_conflict_remaining"
        private const val KEY_CM_OVERWRITE = "cm_conflict_overwrite"
        private const val KEY_CM_SKIP = "cm_conflict_skip"
        private const val KEY_CM_FORCED = "cm_conflict_forced"
    }
}
