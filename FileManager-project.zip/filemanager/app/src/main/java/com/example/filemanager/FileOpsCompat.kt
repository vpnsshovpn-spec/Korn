package com.example.filemanager

import com.example.filemanager.shizuku.ShizukuFileService
import java.io.File

/**
 * Drop-in replacements for the standard [File] operations used throughout
 * the app. Each one tries the normal java.io call first — which is all
 * that's needed for ordinary storage — and only reaches for the Shizuku
 * remote service (a separate, differently-privileged process) if that
 * fails AND Shizuku is actually connected. On a device without Shizuku,
 * or for any file the app could already reach normally, behavior is
 * identical to calling the java.io method directly.
 */

fun File.listFilesCompat(): List<File>? {
    listFiles()?.let { return it.toList() }
    if (!ShizukuManager.hasPermission()) return null
    val remote = ShizukuFileService.listDir(absolutePath) ?: return null
    return remote.map { File(this, it.name) }
}

fun File.existsCompat(): Boolean {
    if (exists()) return true
    return ShizukuManager.hasPermission() && ShizukuFileService.exists(absolutePath)
}

fun File.mkdirsCompat(): Boolean {
    if (mkdirs()) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.mkdirs(absolutePath)
}

fun File.deleteCompat(): Boolean {
    if (delete()) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.delete(absolutePath)
}

fun File.deleteRecursivelyCompat(): Boolean {
    val ok = try { deleteRecursively() } catch (e: Exception) { false }
    if (ok) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.deleteRecursive(absolutePath)
}

/** Move/rename [this] to [dest]. */
fun File.renameToCompat(dest: File): Boolean {
    if (renameTo(dest)) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.renameTo(absolutePath, dest.absolutePath)
}

/** Copy [this] (file or directory) to [dest], leaving the source in place. */
fun File.copyRecursivelyCompat(dest: File, overwrite: Boolean = true): Boolean {
    val ok = try { copyRecursively(dest, overwrite) } catch (e: Exception) { false }
    if (ok) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.copyRecursive(absolutePath, dest.absolutePath)
}

fun File.createNewFileCompat(): Boolean {
    val ok = try { createNewFile() } catch (e: Exception) { false }
    if (ok) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.createNewFile(absolutePath)
}

/**
 * Whether reaching [this] needs Shizuku at all — i.e. it doesn't exist and
 * isn't readable through the app's own process, but does exist by way of
 * the remote service. Used to decide whether to show the "open via Shizuku"
 * copy-out path for reading/editing a protected file.
 */
fun File.needsShizuku(): Boolean {
    if (exists() && canRead()) return false
    return ShizukuManager.hasPermission() && ShizukuFileService.exists(absolutePath)
}
