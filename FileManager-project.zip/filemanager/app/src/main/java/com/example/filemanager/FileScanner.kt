package com.example.filemanager

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Extension groups used for the category shortcuts (images / video / music / docs / apps / archives). */
object FileCategories {
    val IMAGES = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
    val VIDEOS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")
    val MUSIC = setOf("mp3", "wav", "flac", "m4a", "ogg", "aac")
    val DOCS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv")
    val APPS = setOf("apk")
    val ARCHIVES = setOf(
        "zip", "rar", "rar5", "7z", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz",
        "lz4", "zst", "iso", "img", "dmg", "deb", "rpm", "apk", "apks", "xapk", "mtz",
        "cab", "arj", "lzh", "chm", "wim", "cpio", "egg", "alz",
        "mcpack", "mcaddon", "mcworld"
    )
}

/**
 * Recursive scanning (for category browsing + search) and zip/unzip helpers.
 * Everything here runs on a background thread from MainActivity — these functions
 * do not touch the UI themselves.
 */
object FileScanner {

    /** Recursively collects files under [root] whose extension is in [extensions]. */
    fun scanByExtensions(root: File, extensions: Set<String>, showHidden: Boolean): List<File> {
        val results = mutableListOf<File>()
        walk(root, showHidden) { f ->
            if (!f.isDirectory && f.extension.lowercase() in extensions) results.add(f)
        }
        return results
    }

    /** Recursively collects files/folders whose name contains [query] (case-insensitive). */
    fun searchByName(root: File, query: String, showHidden: Boolean): List<File> {
        val results = mutableListOf<File>()
        val q = query.lowercase()
        walk(root, showHidden) { f ->
            if (f.name.lowercase().contains(q)) results.add(f)
        }
        return results
    }

    private fun walk(dir: File, showHidden: Boolean, action: (File) -> Unit) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            // Android/data and Android/obb throw on modern Android even with MANAGE_EXTERNAL_STORAGE
            // in some OEM builds - skip them instead of letting the scan blow up.
            if (child.isDirectory && dir.name == "Android" && (child.name == "data" || child.name == "obb")) continue
            // Never let the recycle bin's own folder show up inside search/category results.
            if (child.isDirectory && child.name == TrashManager.TRASH_FOLDER_NAME) continue
            if (!showHidden && child.name.startsWith(".")) continue
            action(child)
            if (child.isDirectory && child.canRead()) {
                walk(child, showHidden, action)
            }
        }
    }

    /** Zips [source] (a single file or a whole folder) into [destZip]. */
    fun zip(source: File, destZip: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(destZip))).use { zos ->
            if (source.isDirectory) {
                zipDir(source, source.name, zos)
            } else {
                zipSingleFile(source, source.name, zos)
            }
        }
    }

    private fun zipDir(dir: File, base: String, zos: ZipOutputStream) {
        val children = dir.listFiles() ?: emptyArray()
        if (children.isEmpty()) {
            zos.putNextEntry(ZipEntry("$base/"))
            zos.closeEntry()
            return
        }
        for (child in children) {
            val entryName = "$base/${child.name}"
            if (child.isDirectory) {
                zipDir(child, entryName, zos)
            } else {
                zipSingleFile(child, entryName, zos)
            }
        }
    }

    private fun zipSingleFile(file: File, entryName: String, zos: ZipOutputStream) {
        zos.putNextEntry(ZipEntry(entryName))
        file.inputStream().use { it.copyTo(zos) }
        zos.closeEntry()
    }

    /** Extracts [zipFile] into [destDir]. Guards against zip-slip (entries escaping destDir). */
    fun unzip(zipFile: File, destDir: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            val destCanonical = destDir.canonicalPath + File.separator
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                val outCanonical = outFile.canonicalPath
                if (!outCanonical.startsWith(destCanonical)) {
                    throw SecurityException("รายการในไฟล์ ZIP ไม่ปลอดภัย: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
