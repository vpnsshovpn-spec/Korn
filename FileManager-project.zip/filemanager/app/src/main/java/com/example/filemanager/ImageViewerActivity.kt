package com.example.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import java.io.File
import kotlin.math.min

/**
 * KORN built-in image viewer.
 *
 * Opens common image files directly from the file manager instead of handing them
 * to another app. Supports large-image downsampling, pinch zoom and panning.
 */
class ImageViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_PATH = "image_path"
    }

    private lateinit var imageView: ImageView
    private lateinit var scaleDetector: ScaleGestureDetector
    private lateinit var gestureDetector: GestureDetector

    private var scale = 1f
    private var dx = 0f
    private var dy = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val path = intent.getStringExtra(EXTRA_IMAGE_PATH)
        val file = path?.let { File(it) }
        if (file == null || !file.isFile) {
            Toast.makeText(this, "ไม่พบรูปภาพ", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        supportActionBar?.title = file.name
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101010.toInt())
        }

        val title = TextView(this).apply {
            text = file.name
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(20, 12, 20, 12)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setBackgroundColor(0xFF181818.toInt())
        }

        imageView = ImageView(this).apply {
            setBackgroundColor(0xFF101010.toInt())
            scaleType = ImageView.ScaleType.MATRIX
            adjustViewBounds = true
        }

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(imageView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val bitmap = decodeSampledBitmap(file)
        if (bitmap == null) {
            Toast.makeText(this, "ไม่สามารถอ่านรูปภาพนี้ได้", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        imageView.setImageBitmap(bitmap)

        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scale = (scale * detector.scaleFactor).coerceIn(1f, 6f)
                applyMatrix()
                return true
            }
        })

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                scale = if (scale > 1.05f) 1f else 2f
                dx = 0f
                dy = 0f
                applyMatrix()
                return true
            }
        })

        imageView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            gestureDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    dragging = true
                }
                MotionEvent.ACTION_MOVE -> if (dragging && !scaleDetector.isInProgress && scale > 1f) {
                    dx += event.x - lastX
                    dy += event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    applyMatrix()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            }
            true
        }

        ViewCompat.postOnAnimation(imageView) { resetMatrix() }
    }

    private fun resetMatrix() {
        scale = 1f
        dx = 0f
        dy = 0f
        applyMatrix()
    }

    private fun applyMatrix() {
        val bitmap = imageView.drawable ?: return
        val w = bitmap.intrinsicWidth.toFloat()
        val h = bitmap.intrinsicHeight.toFloat()
        if (w <= 0f || h <= 0f || imageView.width <= 0 || imageView.height <= 0) return

        val fit = min(imageView.width / w, imageView.height / h)
        val finalScale = fit * scale
        val matrix = Matrix()
        matrix.postScale(finalScale, finalScale)
        val left = (imageView.width - w * finalScale) / 2f + dx
        val top = (imageView.height - h * finalScale) / 2f + dy
        matrix.postTranslate(left, top)
        imageView.imageMatrix = matrix
    }

    private fun decodeSampledBitmap(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val maxPixels = 4096L * 4096L
        var sample = 1
        while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > maxPixels) {
            sample *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onDestroy() {
        imageView.drawable?.let { drawable ->
            if (drawable is android.graphics.drawable.BitmapDrawable) {
                drawable.bitmap.recycle()
            }
        }
        super.onDestroy()
    }
}
