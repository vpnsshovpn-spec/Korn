package com.example.filemanager

import androidx.appcompat.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import android.os.Parcelable
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Central DialogFragment implementation used by KORN's legacy dialog call sites.
 *
 * The public Builder intentionally mirrors the small subset of KornDialog.Builder
 * used by this project, so existing behavior/callbacks can be migrated without
 * rewriting the business logic in every helper at once.  Every displayed dialog
 * is now owned by a DialogFragment and is recreated by FragmentManager on a
 * configuration change.
 */
object KornDialog {
    private val specs = ConcurrentHashMap<String, Spec>()

    class Builder(context: Context, private val stableId: String? = null) {
        private val activity: FragmentActivity = context.findFragmentActivity()
            ?: error("KornDialog requires a FragmentActivity context")
        private val spec = Spec(context)

        fun setTitle(title: CharSequence?): Builder { spec.title = title; return this }
        fun setMessage(message: CharSequence?): Builder { spec.message = message; return this }
        fun setView(view: View): Builder { spec.customView = view; return this }
        fun setCustomTitle(view: View): Builder { spec.customTitle = view; return this }
        fun setCancelable(cancelable: Boolean): Builder { spec.cancelable = cancelable; return this }

        fun setItems(items: Array<out CharSequence>, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.items = items.toList()
            spec.itemListener = listener
            return this
        }

        fun setSingleChoiceItems(
            items: Array<out CharSequence>,
            checkedItem: Int,
            listener: ((android.content.DialogInterface, Int) -> Unit)?
        ): Builder {
            spec.items = items.toList()
            spec.choiceMode = ChoiceMode.SINGLE
            spec.checkedItem = checkedItem
            spec.itemListener = listener
            return this
        }

        fun setMultiChoiceItems(
            items: Array<out CharSequence>,
            checkedItems: BooleanArray,
            listener: ((android.content.DialogInterface, Int, Boolean) -> Unit)?
        ): Builder {
            spec.items = items.toList()
            spec.choiceMode = ChoiceMode.MULTI
            spec.checkedItems = checkedItems.copyOf()
            spec.multiItemListener = listener
            return this
        }

        fun setPositiveButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.positive = ButtonSpec(text, listener)
            return this
        }

        fun setNegativeButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.negative = ButtonSpec(text, listener)
            return this
        }

        fun setNeutralButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.neutral = ButtonSpec(text, listener)
            return this
        }

        fun setOnDismissListener(listener: ((android.content.DialogInterface) -> Unit)?): Builder {
            spec.onDismiss = listener
            return this
        }

        fun create(): KornDialogHandle = showInternal(false)
        fun show(): KornDialogHandle = showInternal(true)

        private fun showInternal(immediately: Boolean): KornDialogHandle {
            // stableId (Rotation Safety #3) is only ever passed by call sites that want at most
            // one instance of this particular dialog to exist at a time (currently the archive/
            // compress progress dialogs) - everything else keeps the original random-per-call id,
            // unaffected by this change.
            val id = stableId ?: UUID.randomUUID().toString()
            specs[id] = spec
            val fragment = KornDialogFragment.newInstance(id)
            if (immediately) {
                fragment.showNow(activity.supportFragmentManager, "korn_dialog_$id")
            }
            return KornDialogHandle(activity, fragment, id, immediately)
        }
    }

    internal fun take(id: String): Spec? = specs[id]
    internal fun remove(id: String) { specs.remove(id) }

    /**
     * Rotation Safety #3: dismisses any fragment already attached under [stableId]'s tag before
     * a caller that uses a stable id (see [Builder]'s stableId param) creates a fresh one.
     *
     * Why this is needed at all: FragmentManager auto-restores a dialog fragment across a
     * configuration change using the *same* Activity instance's saved state, independently of
     * whatever MainActivity field used to hold its KornDialogHandle - that field is just a plain
     * `var` and resets to null on a brand-new Activity instance after rotation. So
     * observeArchiveOpState()/observeCompressOpState() re-collecting the current state right
     * after recreation and calling showArchiveProgressDialog()/showCompressProgressDialog()
     * again (their own local handle looking null) would otherwise build a *second*, independent
     * dialog fragment on top of the one FragmentManager already silently restored - two progress
     * dialogs stacked on screen. A stable id/tag makes that restored instance discoverable here
     * so it can be cleared first, instead of accumulating duplicates every rotation.
     */
    fun dismissStale(context: Context, stableId: String) {
        val activity = context.findFragmentActivity() ?: return
        val existing = activity.supportFragmentManager.findFragmentByTag("korn_dialog_$stableId") as? DialogFragment
        if (existing?.isAdded == true) {
            existing.dismissAllowingStateLoss()
        }
    }

    class KornDialogHandle internal constructor(
        private val activity: FragmentActivity,
        private val fragment: KornDialogFragment,
        private val id: String,
        private var shown: Boolean
    ) {
        val window: Window?
            get() = fragment.dialog?.window

        fun show() {
            if (shown) return
            if (!fragment.isAdded) {
                fragment.showNow(activity.supportFragmentManager, "korn_dialog_$id")
                shown = true
            }
        }

        fun dismiss() { fragment.dismissAllowingStateLoss() }
        fun cancel() { fragment.dismissAllowingStateLoss() }
        fun setTitle(title: CharSequence?) { fragment.setDialogTitle(title) }
        fun setView(view: View) { fragment.setDialogView(view) }
        fun setButton(whichButton: Int, text: CharSequence, listener: android.content.DialogInterface.OnClickListener?) {
            fragment.setDialogButton(whichButton, text, listener)
        }
        fun setOnShowListener(listener: ((android.content.DialogInterface) -> Unit)?) {
            fragment.setDialogOnShow(listener)
        }
        fun getButton(whichButton: Int): android.widget.Button {
            return requireNotNull(fragment.dialog as? AlertDialog) { "KORN dialog is not an AppCompat AlertDialog" }
                .getButton(whichButton)
        }
        val isShowing: Boolean get() = fragment.dialog?.isShowing == true
    }

    internal enum class ChoiceMode { NONE, SINGLE, MULTI }

    internal data class ButtonSpec(
        val text: CharSequence,
        val listener: ((android.content.DialogInterface, Int) -> Unit)?
    )

    internal class Spec(val context: Context) {
        var title: CharSequence? = null
        var message: CharSequence? = null
        var customView: View? = null
        var customTitle: View? = null
        var items: List<CharSequence>? = null
        var choiceMode: ChoiceMode = ChoiceMode.NONE
        var checkedItem: Int = -1
        var checkedItems: BooleanArray? = null
        var itemListener: ((android.content.DialogInterface, Int) -> Unit)? = null
        var multiItemListener: ((android.content.DialogInterface, Int, Boolean) -> Unit)? = null
        var positive: ButtonSpec? = null
        var negative: ButtonSpec? = null
        var neutral: ButtonSpec? = null
        var cancelable: Boolean = true
        var onDismiss: ((android.content.DialogInterface) -> Unit)? = null
        var onShow: ((android.content.DialogInterface) -> Unit)? = null
        var restoredViewState: SparseArray<Parcelable>? = null
    }

    private fun Context.findFragmentActivity(): FragmentActivity? {
        var current: Context? = this
        while (current is ContextWrapper) {
            if (current is FragmentActivity) return current
            current = current.baseContext
        }
        return current as? FragmentActivity
    }
}

/**
 * If [view] is currently attached to a ViewGroup, removes it from that parent.
 * A no-op if the view is already unparented. Must be called before handing a
 * possibly-reused View to AlertDialog.Builder (setView/setCustomTitle) or
 * View.addView() in general, since Android throws if a View already has a
 * parent when it's added to a new one.
 */
private fun detachFromParent(view: View) {
    (view.parent as? ViewGroup)?.removeView(view)
}

class KornDialogFragment : DialogFragment() {
    private var specId: String? = null
    private var spec: KornDialog.Spec? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        specId = savedInstanceState?.getString(KEY_ID) ?: arguments?.getString(KEY_ID)
        spec = specId?.let { KornDialog.take(it) }
        if (spec == null) {
            // A process-death recreation cannot recover process-local lambdas.
            // Fail closed instead of crashing the host Activity.
            dismissAllowingStateLoss()
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val s = requireNotNull(spec) { "Missing KORN dialog specification" }
        return buildAlertDialog(requireContext(), s)
    }

    private fun buildAlertDialog(context: Context, s: KornDialog.Spec): AlertDialog {
        val builder = AlertDialog.Builder(context)
        s.title?.let { builder.setTitle(it) }
        s.message?.let { builder.setMessage(it) }
        // customTitle/customView are the same View instances that were used by a
        // *previous* KornDialogFragment instance if this fragment is being created
        // by FragmentManager to restore the dialog across a configuration change
        // (KornDialog.take() intentionally does not remove the spec so that restore
        // can happen). That previous instance's dialog window may not have detached
        // the view from its decor yet at the point this runs, so always detach from
        // any existing parent before re-attaching — otherwise AlertDialog.Builder's
        // addView() throws "The specified child already has a parent".
        s.customTitle?.let {
            detachFromParent(it)
            builder.setCustomTitle(it)
        }
        s.customView?.let {
            detachFromParent(it)
            builder.setView(it)
        }

        s.items?.let { items ->
            val values = items.toTypedArray()
            when (s.choiceMode) {
                KornDialog.ChoiceMode.NONE -> builder.setItems(values) { dialog, which ->
                    s.itemListener?.invoke(dialog, which)
                }
                KornDialog.ChoiceMode.SINGLE -> builder.setSingleChoiceItems(values, s.checkedItem) { dialog, which ->
                    s.checkedItem = which
                    s.itemListener?.invoke(dialog, which)
                }
                KornDialog.ChoiceMode.MULTI -> builder.setMultiChoiceItems(
                    values,
                    s.checkedItems ?: BooleanArray(values.size)
                ) { dialog, which, checked ->
                    s.checkedItems?.let { if (which in it.indices) it[which] = checked }
                    s.multiItemListener?.invoke(dialog, which, checked)
                }
            }
        }

        s.positive?.let { button ->
            builder.setPositiveButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        s.negative?.let { button ->
            builder.setNegativeButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        s.neutral?.let { button ->
            builder.setNeutralButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        builder.setCancelable(s.cancelable)
        return builder.create()
    }

    override fun onStart() {
        super.onStart()
        spec?.restoredViewState?.let { state ->
            spec?.customView?.restoreHierarchyState(state)
            spec?.restoredViewState = null
        }
        spec?.onShow?.let { callback ->
            dialog?.setOnShowListener(null)
            dialog?.let { callback(it) }
        }
    }

    override fun onDestroyView() {
        // Runs both when the dialog is genuinely dismissed AND when its window is
        // torn down purely for a configuration change (rotation). Either way, the
        // dialog's decor ViewGroup that currently parents our reused custom view is
        // going away here, so detach proactively: it stops the view from pointing at
        // a dead window (memory leak) and guarantees the *next* fragment instance
        // (recreated by FragmentManager on rotation) can safely re-attach it in
        // buildAlertDialog() without hitting "already has a parent".
        spec?.customView?.let(::detachFromParent)
        spec?.customTitle?.let(::detachFromParent)
        super.onDestroyView()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        specId?.let { outState.putString(KEY_ID, it) }
        spec?.customView?.let { view ->
            val state = SparseArray<Parcelable>()
            view.saveHierarchyState(state)
            spec?.restoredViewState = state
        }
        super.onSaveInstanceState(outState)
    }

    override fun onDismiss(dialog: android.content.DialogInterface) {
        super.onDismiss(dialog)
        spec?.onDismiss?.invoke(dialog)
        // AndroidX's DialogFragment only forwards onDismiss() for a *real* dismissal
        // (user action / explicit dismiss/cancel), not for the transient window
        // teardown it does internally on a configuration change — so it's safe to
        // drop the spec from the static map here without breaking rotation restore.
        specId?.let(KornDialog::remove)
        // Also drop this fragment instance's own reference so the spec's captured
        // Views and listener closures (which may indirectly hold the host Activity)
        // aren't kept reachable through this fragment any longer than necessary.
        spec = null
    }

    fun setDialogTitle(title: CharSequence?) {
        currentSpec()?.title = title
        dialog?.setTitle(title)
    }

    fun setDialogView(view: View) {
        detachFromParent(view)
        currentSpec()?.customView = view
        (dialog as? AlertDialog)?.setView(view)
    }

    fun setDialogButton(
        whichButton: Int,
        text: CharSequence,
        listener: android.content.DialogInterface.OnClickListener?
    ) {
        currentSpec()?.let { s ->
            val callback: ((android.content.DialogInterface, Int) -> Unit)? =
                listener?.let { l -> { dialogInterface, which -> l.onClick(dialogInterface, which) } }
            when (whichButton) {
                android.content.DialogInterface.BUTTON_POSITIVE -> s.positive = KornDialog.ButtonSpec(text, callback)
                android.content.DialogInterface.BUTTON_NEGATIVE -> s.negative = KornDialog.ButtonSpec(text, callback)
                android.content.DialogInterface.BUTTON_NEUTRAL -> s.neutral = KornDialog.ButtonSpec(text, callback)
            }
        }
        (dialog as? AlertDialog)?.setButton(whichButton, text, listener)
    }

    fun setDialogOnShow(listener: ((android.content.DialogInterface) -> Unit)?) {
        currentSpec()?.onShow = listener
        dialog?.setOnShowListener(listener?.let { l -> android.content.DialogInterface.OnShowListener { d -> l(d) } })
    }

    private fun currentSpec(): KornDialog.Spec? {
        if (spec == null) {
            val id = specId ?: arguments?.getString(KEY_ID)
            specId = id
            spec = id?.let { KornDialog.take(it) }
        }
        return spec
    }

    companion object {
        private const val KEY_ID = "korn_dialog_id"

        fun newInstance(id: String): KornDialogFragment = KornDialogFragment().apply {
            arguments = Bundle().apply { putString(KEY_ID, id) }
        }
    }
}

typealias KornDialogHandle = KornDialog.KornDialogHandle
