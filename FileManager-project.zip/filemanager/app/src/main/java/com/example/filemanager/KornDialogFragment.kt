package com.example.filemanager

import android.app.Dialog
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import android.os.Parcelable
import android.util.SparseArray
import android.view.View
import android.view.Window
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Central DialogFragment implementation used by KORN's legacy dialog call sites.
 *
 * The public Builder intentionally mirrors the small subset of KornDialog.Builder
 * used by this project, so existing behavior/callbacks can be migrated without
 * rewriting the business logic in every helper at once.  Every displayed dialog
 * is now owned by a DialogFragment and is recreated by FragmentManager on a
 * configuration change.
 */
object KornDialog {
    private val specs = ConcurrentHashMap<String, Spec>()

    class Builder(context: Context) {
        private val activity: FragmentActivity = context.findFragmentActivity()
            ?: error("KornDialog requires a FragmentActivity context")
        private val spec = Spec(context)

        fun setTitle(title: CharSequence?): Builder { spec.title = title; return this }
        fun setMessage(message: CharSequence?): Builder { spec.message = message; return this }
        fun setView(view: View): Builder { spec.customView = view; return this }
        fun setCustomTitle(view: View): Builder { spec.customTitle = view; return this }
        fun setCancelable(cancelable: Boolean): Builder { spec.cancelable = cancelable; return this }

        fun setItems(items: Array<out CharSequence>, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.items = items.toList()
            spec.itemListener = listener
            return this
        }

        fun setSingleChoiceItems(
            items: Array<out CharSequence>,
            checkedItem: Int,
            listener: ((android.content.DialogInterface, Int) -> Unit)?
        ): Builder {
            spec.items = items.toList()
            spec.choiceMode = ChoiceMode.SINGLE
            spec.checkedItem = checkedItem
            spec.itemListener = listener
            return this
        }

        fun setMultiChoiceItems(
            items: Array<out CharSequence>,
            checkedItems: BooleanArray,
            listener: ((android.content.DialogInterface, Int, Boolean) -> Unit)?
        ): Builder {
            spec.items = items.toList()
            spec.choiceMode = ChoiceMode.MULTI
            spec.checkedItems = checkedItems.copyOf()
            spec.multiItemListener = listener
            return this
        }

        fun setPositiveButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.positive = ButtonSpec(text, listener)
            return this
        }

        fun setNegativeButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.negative = ButtonSpec(text, listener)
            return this
        }

        fun setNeutralButton(text: CharSequence, listener: ((android.content.DialogInterface, Int) -> Unit)?): Builder {
            spec.neutral = ButtonSpec(text, listener)
            return this
        }

        fun setOnDismissListener(listener: ((android.content.DialogInterface) -> Unit)?): Builder {
            spec.onDismiss = listener
            return this
        }

        fun create(): KornDialogHandle = showInternal(false)
        fun show(): KornDialogHandle = showInternal(true)

        private fun showInternal(immediately: Boolean): KornDialogHandle {
            val id = UUID.randomUUID().toString()
            specs[id] = spec
            val fragment = KornDialogFragment.newInstance(id)
            if (immediately) {
                fragment.showNow(activity.supportFragmentManager, "korn_dialog_$id")
            }
            return KornDialogHandle(activity, fragment, id, immediately)
        }
    }

    internal fun take(id: String): Spec? = specs[id]
    internal fun remove(id: String) { specs.remove(id) }

    class KornDialogHandle internal constructor(
        private val activity: FragmentActivity,
        private val fragment: KornDialogFragment,
        private val id: String,
        private var shown: Boolean
    ) {
        val window: Window?
            get() = fragment.dialog?.window

        fun show() {
            if (shown) return
            if (!fragment.isAdded) {
                fragment.showNow(activity.supportFragmentManager, "korn_dialog_$id")
                shown = true
            }
        }

        fun dismiss() { fragment.dismissAllowingStateLoss() }
        fun cancel() { fragment.dismissAllowingStateLoss() }
        fun setTitle(title: CharSequence?) { fragment.setDialogTitle(title) }
        fun setView(view: View) { fragment.setDialogView(view) }
        fun setButton(whichButton: Int, text: CharSequence, listener: android.content.DialogInterface.OnClickListener?) {
            fragment.setDialogButton(whichButton, text, listener)
        }
        fun setOnShowListener(listener: ((android.content.DialogInterface) -> Unit)?) {
            fragment.setDialogOnShow(listener)
        }
        fun getButton(whichButton: Int): android.widget.Button {
            return requireNotNull(fragment.dialog as? AlertDialog) { "KORN dialog is not an AppCompat AlertDialog" }
                .getButton(whichButton)
        }
        val isShowing: Boolean get() = fragment.dialog?.isShowing == true
    }

    internal enum class ChoiceMode { NONE, SINGLE, MULTI }

    internal data class ButtonSpec(
        val text: CharSequence,
        val listener: ((android.content.DialogInterface, Int) -> Unit)?
    )

    internal class Spec(val context: Context) {
        var title: CharSequence? = null
        var message: CharSequence? = null
        var customView: View? = null
        var customTitle: View? = null
        var items: List<CharSequence>? = null
        var choiceMode: ChoiceMode = ChoiceMode.NONE
        var checkedItem: Int = -1
        var checkedItems: BooleanArray? = null
        var itemListener: ((android.content.DialogInterface, Int) -> Unit)? = null
        var multiItemListener: ((android.content.DialogInterface, Int, Boolean) -> Unit)? = null
        var positive: ButtonSpec? = null
        var negative: ButtonSpec? = null
        var neutral: ButtonSpec? = null
        var cancelable: Boolean = true
        var onDismiss: ((android.content.DialogInterface) -> Unit)? = null
        var onShow: ((android.content.DialogInterface) -> Unit)? = null
        var restoredViewState: SparseArray<Parcelable>? = null
    }

    private fun Context.findFragmentActivity(): FragmentActivity? {
        var current: Context? = this
        while (current is ContextWrapper) {
            if (current is FragmentActivity) return current
            current = current.baseContext
        }
        return current as? FragmentActivity
    }
}

class KornDialogFragment : DialogFragment() {
    private var specId: String? = null
    private var spec: KornDialog.Spec? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        specId = savedInstanceState?.getString(KEY_ID) ?: arguments?.getString(KEY_ID)
        spec = specId?.let { KornDialog.take(it) }
        if (spec == null) {
            // A process-death recreation cannot recover process-local lambdas.
            // Fail closed instead of crashing the host Activity.
            dismissAllowingStateLoss()
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val s = requireNotNull(spec) { "Missing KORN dialog specification" }
        val builder = KornDialog.Builder(requireContext())
        s.title?.let(builder::setTitle)
        s.message?.let(builder::setMessage)
        s.customTitle?.let(builder::setCustomTitle)
        s.customView?.let(builder::setView)

        s.items?.let { items ->
            val values = items.toTypedArray()
            when (s.choiceMode) {
                KornDialog.ChoiceMode.NONE -> builder.setItems(values) { dialog, which ->
                    s.itemListener?.invoke(dialog, which)
                }
                KornDialog.ChoiceMode.SINGLE -> builder.setSingleChoiceItems(values, s.checkedItem) { dialog, which ->
                    s.checkedItem = which
                    s.itemListener?.invoke(dialog, which)
                }
                KornDialog.ChoiceMode.MULTI -> builder.setMultiChoiceItems(
                    values,
                    s.checkedItems ?: BooleanArray(values.size)
                ) { dialog, which, checked ->
                    s.checkedItems?.let { if (which in it.indices) it[which] = checked }
                    s.multiItemListener?.invoke(dialog, which, checked)
                }
            }
        }

        s.positive?.let { button ->
            builder.setPositiveButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        s.negative?.let { button ->
            builder.setNegativeButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        s.neutral?.let { button ->
            builder.setNeutralButton(button.text) { dialog, which -> button.listener?.invoke(dialog, which) }
        }
        builder.setCancelable(s.cancelable)
        return builder.create()
    }

    override fun onStart() {
        super.onStart()
        spec?.restoredViewState?.let { state ->
            spec?.customView?.restoreHierarchyState(state)
            spec?.restoredViewState = null
        }
        spec?.onShow?.let { callback ->
            dialog?.setOnShowListener(null)
            dialog?.let { callback(it) }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        specId?.let { outState.putString(KEY_ID, it) }
        spec?.customView?.let { view ->
            val state = SparseArray<Parcelable>()
            view.saveHierarchyState(state)
            spec?.restoredViewState = state
        }
        super.onSaveInstanceState(outState)
    }

    override fun onDismiss(dialog: android.content.DialogInterface) {
        super.onDismiss(dialog)
        spec?.onDismiss?.invoke(dialog)
        specId?.let(KornDialog::remove)
    }

    fun setDialogTitle(title: CharSequence?) {
        currentSpec()?.title = title
        dialog?.setTitle(title)
    }

    fun setDialogView(view: View) {
        currentSpec()?.customView = view
        (dialog as? AlertDialog)?.setView(view)
    }

    fun setDialogButton(
        whichButton: Int,
        text: CharSequence,
        listener: android.content.DialogInterface.OnClickListener?
    ) {
        currentSpec()?.let { s ->
            val callback: ((android.content.DialogInterface, Int) -> Unit)? =
                listener?.let { l -> { dialogInterface, which -> l.onClick(dialogInterface, which) } }
            when (whichButton) {
                android.content.DialogInterface.BUTTON_POSITIVE -> s.positive = KornDialog.ButtonSpec(text, callback)
                android.content.DialogInterface.BUTTON_NEGATIVE -> s.negative = KornDialog.ButtonSpec(text, callback)
                android.content.DialogInterface.BUTTON_NEUTRAL -> s.neutral = KornDialog.ButtonSpec(text, callback)
            }
        }
        (dialog as? AlertDialog)?.setButton(whichButton, text, listener)
    }

    fun setDialogOnShow(listener: ((android.content.DialogInterface) -> Unit)?) {
        currentSpec()?.onShow = listener
        dialog?.setOnShowListener(listener?.let { l -> android.content.DialogInterface.OnShowListener { d -> l(d) } })
    }

    private fun currentSpec(): KornDialog.Spec? {
        if (spec == null) {
            val id = specId ?: arguments?.getString(KEY_ID)
            specId = id
            spec = id?.let { KornDialog.take(it) }
        }
        return spec
    }

    companion object {
        private const val KEY_ID = "korn_dialog_id"

        fun newInstance(id: String): KornDialogFragment = KornDialogFragment().apply {
            arguments = Bundle().apply { putString(KEY_ID, id) }
        }
    }
}

typealias KornDialogHandle = KornDialog.KornDialogHandle
