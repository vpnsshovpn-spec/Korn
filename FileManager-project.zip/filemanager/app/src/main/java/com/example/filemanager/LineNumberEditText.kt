package com.example.filemanager

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Editable
import android.text.Layout
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.OverScroller
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.max

/**
 * EditText with a lightweight, scrolling line-number gutter.
 *
 * Performance rules:
 *  - The EditText owns scrolling; no ScrollView is used around it.
 *  - Only visible line numbers are drawn.
 *  - No requestLayout() while scrolling or drawing.
 *  - Line count is maintained incrementally instead of rescanning the whole file on every key.
 */
class LineNumberEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.MONOSPACE
        textSize = resources.displayMetrics.scaledDensity * 14f
        color = 0xff777777.toInt()
    }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xffdddddd.toInt()
        strokeWidth = resources.displayMetrics.density
    }
    private val currentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x1433aaff
        style = Paint.Style.FILL
    }
    private val tmpRect = Rect()

    private var gutterWidth = dp(64)
    private var lineCount = 1
    private var lastDigitCount = 2
    private var removedNewlineCount = 0

    // AppCompatEditText's own constructor calls setText() internally (to set up its
    // Editable buffer) BEFORE any of this subclass's property initializers or init{}
    // block have run. At that point linePaint/gutterWidth etc. are still JVM-default
    // (null/0), so the overridden setText() below must not touch them until this
    // flag is set true at the end of init{}. Without this guard the app crashes with
    // a NullPointerException the instant this view is inflated (i.e. every time the
    // text editor screen opens).
    private var isReady = false

    // Plain EditText doesn't fling on release (Android reserves the release
    // gesture for cursor placement), so drag-scrolling stops dead the instant
    // you lift your finger. This adds real momentum scrolling on top of the
    // normal touch handling, without interfering with tapping/selecting text.
    private val flingScroller = OverScroller(context)
    private val flingDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            val contentHeight = layout?.height ?: return false
            val maxScrollY = (contentHeight - height + extendedPaddingTop + extendedPaddingBottom).coerceAtLeast(0)
            if (maxScrollY <= 0) return false
            flingScroller.fling(scrollX, scrollY, 0, -velocityY.toInt(), scrollX, scrollX, 0, maxScrollY)
            postInvalidateOnAnimation()
            return true
        }
    })

    init {
        includeFontPadding = true
        setWillNotDraw(false)
        isVerticalScrollBarEnabled = true
        isHorizontalScrollBarEnabled = true
        // Long lines scroll sideways instead of wrapping onto a new visual row.
        // This guarantees one Layout line == one real source line, so the
        // gutter number is always just (line index + 1) - no separate
        // "is this a wrapped continuation row" tracking needed at all.
        setHorizontallyScrolling(true)
        overScrollMode = OVER_SCROLL_ALWAYS
        isNestedScrollingEnabled = false
        setEditorPadding()

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                removedNewlineCount = if (s == null || count == 0) {
                    0
                } else {
                    var found = 0
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') found++
                    found
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                var insertedNewlineCount = 0
                if (s != null && count > 0) {
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') insertedNewlineCount++
                }

                lineCount = max(1, lineCount - removedNewlineCount + insertedNewlineCount)
                updateGutterForLineCount(lineCount)
                postInvalidateOnAnimation()
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })

        // Everything above has now run, so it's safe for setText()/updateGutterForLineCount()
        // to touch linePaint, gutterWidth, etc. from here on.
        isReady = true
    }

    private fun setEditorPadding() {
        setPadding(gutterWidth + dp(8), paddingTop, paddingRight, paddingBottom)
    }

    private fun updateGutterForLineCount(count: Int) {
        if (!isReady) return
        val digits = max(2, count.coerceAtLeast(1).toString().length)
        if (digits == lastDigitCount) return

        lastDigitCount = digits
        val digitWidth = linePaint.measureText("0")
        // Extra room prevents clipping even for 5+ digit line numbers.
        gutterWidth = max(dp(64), (digitWidth * digits + dp(24)).toInt())
        setEditorPadding()
        // setPadding() already requests a layout when needed; avoid an extra layout pass.
        postInvalidateOnAnimation()
    }

    override fun setText(text: CharSequence?, type: BufferType?) {
        super.setText(text, type)
        // Guard against the superclass constructor calling setText() before this
        // subclass has finished initializing (see isReady's comment above).
        if (!isReady) return
        lineCount = 1
        val value = text ?: ""
        for (i in value.indices) if (value[i] == '\n') lineCount++
        updateGutterForLineCount(lineCount)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        if (!isReady) {
            super.onDraw(canvas)
            return
        }

        val textLayout = layout
        if (textLayout == null || height <= 0 || textLayout.height <= 0 || textLayout.lineCount <= 0) {
            super.onDraw(canvas)
            return
        }

        /*
         * IMPORTANT - how Android actually applies scroll to drawing:
         * View.draw() translates the canvas by (-scrollX, -scrollY) BEFORE
         * onDraw() is ever called - this is what makes any scrollable View's
         * content appear to move as scrollX/scrollY change. TextView's own
         * onDraw() therefore only adds getExtendedPaddingTop() (never
         * "- scrollY" again - the canvas already carries that shift).
         *
         * Earlier versions of this file subtracted scrollY a second time when
         * positioning the gutter's numbers/highlight, which silently doubled
         * the scroll offset for the gutter only (not the real text, which is
         * drawn by super.onDraw() the correct, single-subtraction way). That
         * mismatch is what made the gutter drift out of sync with the text
         * the further down the file you scrolled, and eventually vanish
         * completely once the (also-unfixed) clip rect scrolled off-screen.
         *
         * The rule from here on: Y coordinates for drawing = layoutTop +
         * <Layout coordinate>, with NO extra "- scrollY". Anything that must
         * stay pinned to a fixed screen position (the gutter column, its
         * divider line, the clip rect) instead adds scrollX/scrollY back, to
         * cancel out the canvas's automatic shift.
         */
        val layoutTop = getExtendedPaddingTop()
        val originX = scrollX
        val originY = scrollY
        val layoutVisibleTop = (originY - layoutTop).coerceAtLeast(0)
        val layoutVisibleBottom = (originY + height - layoutTop).coerceAtLeast(0)
        val firstLine = try {
            textLayout.getLineForVertical(layoutVisibleTop)
                .coerceIn(0, textLayout.lineCount - 1)
        } catch (_: Exception) {
            0
        }
        val lastLine = try {
            textLayout.getLineForVertical(layoutVisibleBottom)
                .coerceIn(firstLine, textLayout.lineCount - 1)
        } catch (_: Exception) {
            firstLine
        }

        val textLength = (text ?: "").length

        // Draw the active-line background, pinned to the fixed screen column
        // (gutterWidth..width) regardless of horizontal/vertical scroll.
        if (textLength > 0) {
            val currentOffset = selectionStart.coerceIn(0, textLength)
            val current = textLayout.getLineForOffset(currentOffset)
            if (current in firstLine..lastLine) {
                val top = layoutTop + textLayout.getLineTop(current)
                val bottom = layoutTop + textLayout.getLineBottom(current)
                canvas.drawRect(
                    (originX + gutterWidth).toFloat(),
                    top.toFloat(),
                    (originX + width).toFloat(),
                    bottom.toFloat(),
                    currentLinePaint
                )
            }
        }

        // Draw the actual text first. TextView positions it the correct,
        // single-subtraction way; the gutter below must match that exactly.
        super.onDraw(canvas)

        canvas.save()
        canvas.clipRect(
            originX.toFloat(), originY.toFloat(),
            (originX + gutterWidth).toFloat(), (originY + height).toFloat()
        )

        // Horizontal scrolling is enabled (no wrap), so the Layout never
        // creates extra visual rows for a long line - every Layout line is
        // exactly one real source line, and its number is just its index + 1.
        for (line in firstLine..lastLine) {
            val baseline = layoutTop + textLayout.getLineBaseline(line)
            val number = (line + 1).toString()
            linePaint.getTextBounds(number, 0, number.length, tmpRect)
            val x = originX + gutterWidth - dp(10) - tmpRect.width()
            canvas.drawText(number, x.toFloat(), baseline.toFloat(), linePaint)
        }

        canvas.drawLine(
            (originX + gutterWidth).toFloat(), originY.toFloat(),
            (originX + gutterWidth).toFloat(), (originY + height).toFloat(),
            dividerPaint
        )
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN && !flingScroller.isFinished) {
            flingScroller.forceFinished(true)
        }
        // Observe the same events for a fling gesture without consuming them;
        // normal cursor/selection handling below still gets every event.
        flingDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    override fun computeScroll() {
        if (flingScroller.computeScrollOffset()) {
            scrollTo(scrollX, flingScroller.currY)
            postInvalidateOnAnimation()
        } else {
            super.computeScroll()
        }
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        // Scrolling only needs a redraw of the lightweight gutter. Never relayout here.
        postInvalidateOnAnimation()
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        postInvalidateOnAnimation()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
