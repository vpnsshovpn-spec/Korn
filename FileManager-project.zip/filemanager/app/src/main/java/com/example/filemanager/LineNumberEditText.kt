package com.example.filemanager

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Editable
import android.text.Layout
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.max

/**
 * EditText with a lightweight, scrolling line-number gutter.
 *
 * Performance rules:
 *  - The EditText owns scrolling; no ScrollView is used around it.
 *  - Only visible line numbers are drawn.
 *  - No requestLayout() while scrolling or drawing.
 *  - Line count is maintained incrementally instead of rescanning the whole file on every key.
 */
class LineNumberEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.MONOSPACE
        textSize = resources.displayMetrics.scaledDensity * 14f
        color = 0xff777777.toInt()
    }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xffdddddd.toInt()
        strokeWidth = resources.displayMetrics.density
    }
    private val currentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x1433aaff
        style = Paint.Style.FILL
    }
    private val tmpRect = Rect()

    private var gutterWidth = dp(64)
    private var lineCount = 1
    private var lastDigitCount = 2
    private var removedNewlineCount = 0

    // AppCompatEditText's own constructor calls setText() internally (to set up its
    // Editable buffer) BEFORE any of this subclass's property initializers or init{}
    // block have run. At that point linePaint/gutterWidth etc. are still JVM-default
    // (null/0), so the overridden setText() below must not touch them until this
    // flag is set true at the end of init{}. Without this guard the app crashes with
    // a NullPointerException the instant this view is inflated (i.e. every time the
    // text editor screen opens).
    private var isReady = false

    init {
        includeFontPadding = true
        setWillNotDraw(false)
        isVerticalScrollBarEnabled = true
        overScrollMode = OVER_SCROLL_ALWAYS
        isNestedScrollingEnabled = false
        setEditorPadding()

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                removedNewlineCount = if (s == null || count == 0) {
                    0
                } else {
                    var found = 0
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') found++
                    found
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                var insertedNewlineCount = 0
                if (s != null && count > 0) {
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') insertedNewlineCount++
                }

                lineCount = max(1, lineCount - removedNewlineCount + insertedNewlineCount)
                updateGutterForLineCount(lineCount)
                postInvalidateOnAnimation()
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })

        // Everything above has now run, so it's safe for setText()/updateGutterForLineCount()
        // to touch linePaint, gutterWidth, etc. from here on.
        isReady = true
    }

    private fun setEditorPadding() {
        setPadding(gutterWidth + dp(8), paddingTop, paddingRight, paddingBottom)
    }

    private fun updateGutterForLineCount(count: Int) {
        if (!isReady) return
        val digits = max(2, count.coerceAtLeast(1).toString().length)
        if (digits == lastDigitCount) return

        lastDigitCount = digits
        val digitWidth = linePaint.measureText("0")
        // Extra room prevents clipping even for 5+ digit line numbers.
        gutterWidth = max(dp(64), (digitWidth * digits + dp(24)).toInt())
        setEditorPadding()
        // setPadding() already requests a layout when needed; avoid an extra layout pass.
        postInvalidateOnAnimation()
    }

    override fun setText(text: CharSequence?, type: BufferType?) {
        super.setText(text, type)
        // Guard against the superclass constructor calling setText() before this
        // subclass has finished initializing (see isReady's comment above).
        if (!isReady) return
        lineCount = 1
        val value = text ?: ""
        for (i in value.indices) if (value[i] == '\n') lineCount++
        updateGutterForLineCount(lineCount)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        if (!isReady) { super.onDraw(canvas); return }
        val textLayout = layout
        if (textLayout == null) {
            super.onDraw(canvas)
            return
        }

        if (height <= 0 || textLayout.height <= 0 || textLayout.lineCount <= 0) {
            super.onDraw(canvas)
            return
        }
        val viewportTop = scrollY.coerceAtLeast(0).coerceAtMost(textLayout.height)
        val viewportBottom = (scrollY + height).coerceIn(viewportTop, textLayout.height)
        val firstLine = try { textLayout.getLineForVertical(viewportTop).coerceIn(0, textLayout.lineCount - 1) } catch (_: Exception) { 0 }
        val lastLine = try { textLayout.getLineForVertical(viewportBottom).coerceIn(firstLine, textLayout.lineCount - 1) } catch (_: Exception) { firstLine }

        val textLength = text?.length ?: 0
        if (textLength > 0) {
            val current = textLayout.getLineForOffset(selectionStart.coerceIn(0, textLength))
            if (current in firstLine..lastLine) {
                // The canvas here is already translated by the View's own scroll
                // offset (that's how super.onDraw below paints the right portion
                // of a long document), so these must be plain content coordinates.
                // Subtracting scrollY again would double-offset them.
                val top = textLayout.getLineTop(current)
                val bottom = textLayout.getLineBottom(current)
                canvas.drawRect(
                    gutterWidth.toFloat(),
                    top.toFloat(),
                    width.toFloat(),
                    bottom.toFloat(),
                    currentLinePaint
                )
            }
        }

        super.onDraw(canvas)

        canvas.save()
        canvas.clipRect(0f, 0f, gutterWidth.toFloat(), height.toFloat())
        for (line in firstLine..lastLine) {
            // Same reasoning as above: no extra "- scrollY" needed here.
            val baseline = textLayout.getLineBaseline(line)
            val number = (line + 1).toString()
            linePaint.getTextBounds(number, 0, number.length, tmpRect)
            val x = gutterWidth - dp(10) - tmpRect.width()
            canvas.drawText(number, x.toFloat(), baseline.toFloat(), linePaint)
        }
        canvas.drawLine(
            gutterWidth.toFloat(), 0f,
            gutterWidth.toFloat(), height.toFloat(), dividerPaint
        )
        canvas.restore()
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        // Scrolling only needs a redraw of the lightweight gutter. Never relayout here.
        postInvalidateOnAnimation()
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        postInvalidateOnAnimation()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
