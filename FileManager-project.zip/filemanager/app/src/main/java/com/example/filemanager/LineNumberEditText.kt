package com.example.filemanager

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Editable
import android.text.Layout
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.max

/**
 * EditText with a lightweight, scrolling line-number gutter.
 *
 * Performance rules:
 *  - The EditText owns scrolling; no ScrollView is used around it.
 *  - Only visible line numbers are drawn.
 *  - No requestLayout() while scrolling or drawing.
 *  - Line count is maintained incrementally instead of rescanning the whole file on every key.
 */
class LineNumberEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.MONOSPACE
        textSize = resources.displayMetrics.scaledDensity * 14f
        color = 0xff777777.toInt()
    }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xffdddddd.toInt()
        strokeWidth = resources.displayMetrics.density
    }
    private val currentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x1433aaff
        style = Paint.Style.FILL
    }
    private val tmpRect = Rect()

    private var gutterWidth = dp(64)
    private var lineCount = 1
    private var lastDigitCount = 2
    private var removedNewlineCount = 0

    init {
        includeFontPadding = true
        setWillNotDraw(false)
        isVerticalScrollBarEnabled = true
        overScrollMode = OVER_SCROLL_ALWAYS
        isNestedScrollingEnabled = false
        setEditorPadding()

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                removedNewlineCount = if (s == null || count == 0) {
                    0
                } else {
                    var found = 0
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') found++
                    found
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                var insertedNewlineCount = 0
                if (s != null && count > 0) {
                    val end = (start + count).coerceAtMost(s.length)
                    for (i in start until end) if (s[i] == '\n') insertedNewlineCount++
                }

                lineCount = max(1, lineCount - removedNewlineCount + insertedNewlineCount)
                updateGutterForLineCount(lineCount)
                postInvalidateOnAnimation()
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun setEditorPadding() {
        setPadding(gutterWidth + dp(8), paddingTop, paddingRight, paddingBottom)
    }

    private fun updateGutterForLineCount(count: Int) {
        val digits = max(2, count.coerceAtLeast(1).toString().length)
        if (digits == lastDigitCount) return

        lastDigitCount = digits
        val digitWidth = linePaint.measureText("0")
        // Extra room prevents clipping even for 5+ digit line numbers.
        gutterWidth = max(dp(64), (digitWidth * digits + dp(24)).toInt())
        setEditorPadding()
        requestLayout()
        postInvalidateOnAnimation()
    }

    override fun setText(text: CharSequence?, type: BufferType?) {
        super.setText(text, type)
        lineCount = 1
        val value = text ?: ""
        for (i in value.indices) if (value[i] == '\n') lineCount++
        updateGutterForLineCount(lineCount)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val textLayout = layout
        if (textLayout == null) {
            super.onDraw(canvas)
            return
        }

        val viewportTop = scrollY.coerceAtLeast(0)
        val viewportBottom = (scrollY + height).coerceAtMost(textLayout.height)
        val firstLine = textLayout.getLineForVertical(viewportTop)
        val lastLine = textLayout.getLineForVertical(viewportBottom.coerceAtLeast(viewportTop))

        val textLength = text?.length ?: 0
        if (textLength > 0) {
            val current = textLayout.getLineForOffset(selectionStart.coerceIn(0, textLength))
            if (current in firstLine..lastLine) {
                val top = textLayout.getLineTop(current) - scrollY
                val bottom = textLayout.getLineBottom(current) - scrollY
                canvas.drawRect(
                    gutterWidth.toFloat(),
                    top.toFloat(),
                    width.toFloat(),
                    bottom.toFloat(),
                    currentLinePaint
                )
            }
        }

        super.onDraw(canvas)

        canvas.save()
        canvas.clipRect(0f, 0f, gutterWidth.toFloat(), height.toFloat())
        for (line in firstLine..lastLine) {
            val baseline = textLayout.getLineBaseline(line) - scrollY
            val number = (line + 1).toString()
            linePaint.getTextBounds(number, 0, number.length, tmpRect)
            val x = gutterWidth - dp(10) - tmpRect.width()
            canvas.drawText(number, x.toFloat(), baseline.toFloat(), linePaint)
        }
        canvas.drawLine(
            gutterWidth.toFloat(), 0f,
            gutterWidth.toFloat(), height.toFloat(), dividerPaint
        )
        canvas.restore()
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        // Scrolling only needs a redraw of the lightweight gutter. Never relayout here.
        postInvalidateOnAnimation()
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        postInvalidateOnAnimation()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
