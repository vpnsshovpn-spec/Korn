package com.example.filemanager

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.max

/**
 * EditText with a real, scrolling line-number gutter.
 * The numbers are drawn from the same Layout used by EditText, so wrapped lines,
 * scrolling and edits stay synchronized with the text.
 */
class LineNumberEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = androidx.appcompat.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.MONOSPACE
        textSize = resources.displayMetrics.scaledDensity * 14f
        color = 0xff777777.toInt()
    }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xffdddddd.toInt()
        strokeWidth = resources.displayMetrics.density
    }
    private val currentLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x1433aaff
        style = Paint.Style.FILL
    }
    private val tmpRect = Rect()
    private var gutterWidth = dp(52)

    init {
        includeFontPadding = true
        setWillNotDraw(false)
        // Reserve the left gutter while retaining enough room for the editor itself.
        setPadding(gutterWidth + dp(10), paddingTop, paddingRight, paddingBottom)
        addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                postInvalidate()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
    }

    override fun onDraw(canvas: Canvas) {
        val layout = layout
        if (layout != null) {
            val scrollY = scrollY
            val firstLine = layout.getLineForVertical(scrollY.coerceAtLeast(0))
            val lastLine = layout.getLineForVertical((scrollY + height).coerceAtMost(layout.height))

            // Highlight the current logical line behind the text, but only in the text area.
            val current = layout.getLineForOffset(selectionStart.coerceAtLeast(0))
            if (current in firstLine..lastLine) {
                val top = layout.getLineTop(current) - scrollY
                val bottom = layout.getLineBottom(current) - scrollY
                canvas.drawRect(gutterWidth.toFloat(), top.toFloat(), width.toFloat(), bottom.toFloat(), currentLinePaint)
            }

            super.onDraw(canvas)

            // Draw the gutter after the editor content so it remains crisp while scrolling.
            canvas.save()
            canvas.clipRect(0, 0, gutterWidth, height)
            for (line in firstLine..lastLine) {
                val baseline = layout.getLineBaseline(line) - scrollY
                val number = (line + 1).toString()
                linePaint.getTextBounds(number, 0, number.length, tmpRect)
                val x = gutterWidth - dp(8) - tmpRect.width()
                canvas.drawText(number, x.toFloat(), baseline.toFloat(), linePaint)
            }
            canvas.drawLine(gutterWidth.toFloat(), 0f, gutterWidth.toFloat(), height.toFloat(), dividerPaint)
            canvas.restore()
        } else {
            super.onDraw(canvas)
        }
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        invalidate()
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        invalidate()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
