package com.example.filemanager

import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Button
import android.graphics.Typeface
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.text.DecimalFormat
import rikka.shizuku.Shizuku
import com.example.filemanager.shizuku.ShizukuFileService

class MainActivity : AppCompatActivity() {
    internal lateinit var drawerLayout: DrawerLayout
    internal lateinit var navigationView: NavigationView

    enum class Mode { NORMAL, CATEGORY, SEARCH, TRASH, APPS }
    internal enum class SortKey { NAME, SIZE, DATE }

    internal lateinit var recyclerView: RecyclerView
    internal lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var breadcrumbBar: LinearLayout
    private lateinit var breadcrumbScroll: android.widget.HorizontalScrollView
    internal lateinit var storagePercent: TextView
    internal lateinit var bookmarksBar: android.widget.LinearLayout
    internal lateinit var categoryBar: android.widget.LinearLayout
    internal lateinit var storageText: TextView
    internal lateinit var adapter: FileAdapter
    internal lateinit var bookmarksManager: BookmarksManager
    internal lateinit var trashManager: TrashManager
    internal lateinit var selectionActionBar: LinearLayout
    internal val isSelectionActionBarInitialized: Boolean
        get() = ::selectionActionBar.isInitialized
    internal lateinit var clipboardActionBar: LinearLayout
    internal lateinit var trashActionBar: LinearLayout
    internal lateinit var selectionMoreButton: TextView
    private lateinit var clipboardPasteButton: TextView
    private lateinit var toolbarHomeButton: android.widget.ImageButton
    private val openWindows = mutableListOf<String>()

    internal var currentDir: File = Environment.getExternalStorageDirectory()
    internal var lastNormalDir: File = Environment.getExternalStorageDirectory()
    internal var clipboardFiles: List<File> = emptyList()
    internal var clipboardIsCut = false
    internal var pendingShizukuSync: Pair<File, File>? = null

    // Pending archive extraction destination: 0=auto, 1=current, 2=chosen.
    private var pendingArchiveFile: File? = null
    private var pendingArchivePassword: String? = null
    private var pendingArchiveMode: Int = 0

    internal var mode = Mode.NORMAL
    internal var showHidden = false
    internal var currentCategoryLabel: String? = null
    internal var currentCategoryExts: Set<String>? = null
    internal var lastSearchQuery: String? = null
    /** Remembers the "search inside file content" checkbox state across searches this session. */
    internal var lastSearchContentEnabled: Boolean = false

    internal var sortKey = SortKey.NAME
    internal var sortAscending = true
    internal var isGridMode = false
    internal var fileViewMode = FileAdapter.ViewMode.LIST
    internal var confirmDelete = true
    internal var themeKey = "blue"
    internal var drawerHiddenSwitch: com.google.android.material.switchmaterial.SwitchMaterial? = null

    private val STORAGE_PERMISSION_CODE = 1001
    private var awaitingStoragePermission = false
    private val settingsHelper by lazy { SettingsHelper(this) }
    private val directoryBrowserHelper by lazy { DirectoryBrowserHelper() }
    private val directoryHistoryHelper by lazy { DirectoryHistoryHelper(this) }
    private val directoryNavigationHelper by lazy { DirectoryNavigationHelper() }
    private val directoryBreadcrumbHelper by lazy {
        DirectoryBreadcrumbHelper(
            breadcrumbBar = breadcrumbBar,
            breadcrumbScroll = breadcrumbScroll,
            textPrimary = R.color.text_primary,
            textSecondary = R.color.text_secondary,
            onFolderClick = { loadDirectory(it) }
        )
    }
    private val destinationFolderPickerHelper by lazy {
        DestinationFolderPickerHelper(
            context = this,
            directoryBrowserHelper = directoryBrowserHelper,
            bookmarksManager = bookmarksManager,
            comparator = { comparator() },
            dp = { dp(it) },
            showSortDialog = ::showSortDialog
        )
    }

    internal val isMainThemeViewsInitialized: Boolean
        get() = ::drawerLayout.isInitialized && ::storageText.isInitialized &&
            ::storagePercent.isInitialized && ::categoryBar.isInitialized

    override fun onCreate(savedInstanceState: Bundle?) {
        // IMPORTANT: AppCompat must know the requested night mode BEFORE
        // super.onCreate() inflates/resolves the activity theme resources.
        // If this is done after super.onCreate(), a saved "system" preference
        // can leave the first frame using the light palette (white background)
        // while text is already resolved from the night palette (light gray).
        loadUserPreferences()
        applySavedNightMode()
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        try { Shizuku.addRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        val fileOpFilter = android.content.IntentFilter().apply {
            addAction(FileOperationService.BROADCAST_PROGRESS)
            addAction(FileOperationService.BROADCAST_DONE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fileOpReceiver, fileOpFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(fileOpReceiver, fileOpFilter)
        }

        setSupportActionBar(findViewById(R.id.toolbar))
        setupNavigationDrawer()
        setupToolbarHomeButton()
        setupToolbarSearchButton()
        supportActionBar?.title = getString(R.string.app_name)

        breadcrumbBar = findViewById(R.id.breadcrumbBar)
        breadcrumbScroll = findViewById(R.id.breadcrumbScroll)
        storagePercent = findViewById(R.id.storagePercent)
        storagePercent.setOnClickListener { startActivity(Intent(this, StorageAnalyzerActivity::class.java)) }
        recyclerView = findViewById(R.id.fileList)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        bookmarksBar = findViewById(R.id.bookmarksBar)
        categoryBar = findViewById(R.id.categoryBar)
        storageText = findViewById(R.id.storageText)
        applyThemePalette()

        selectionActionBar = findViewById(R.id.selectionActionBar)
        clipboardActionBar = findViewById(R.id.clipboardActionBar)
        trashActionBar = findViewById(R.id.trashActionBar)
        findViewById<com.google.android.material.button.MaterialButton>(R.id.emptyTrashButton).setOnClickListener { emptyTrashConfirm() }
        findViewById<android.widget.ImageButton>(R.id.trashSettingsButton).setOnClickListener { TrashSettingsSheet.newInstance { loadTrash() }.show(supportFragmentManager, "trash_settings") }
        trashActionBar.visibility = View.GONE
        selectionMoreButton = findViewById(R.id.selectionMoreButton)
        clipboardPasteButton = findViewById(R.id.clipboardPasteButton)
        findViewById<TextView>(R.id.selectionCopyButton).setOnClickListener { copySelected() }
        findViewById<TextView>(R.id.selectionCutButton).setOnClickListener { moveSelected() }
        findViewById<TextView>(R.id.selectionRenameButton).setOnClickListener { renameSelected() }
        findViewById<TextView>(R.id.selectionDeleteButton).setOnClickListener { deleteSelectedToTrash() }
        findViewById<TextView>(R.id.selectionCancelButton).setOnClickListener { exitSelectionMode() }
        selectionMoreButton.setOnClickListener { showSelectionMoreMenu() }
        clipboardPasteButton.setOnClickListener { pasteClipboard() }
        findViewById<TextView>(R.id.clipboardNewButton).setOnClickListener { newFolderDialog() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton).setOnClickListener { showAddMenu() }
        findViewById<android.widget.Button>(R.id.addBookmarkButton).setOnClickListener { addBookmark(currentDir) }
        findViewById<android.widget.Button>(R.id.manageBookmarksButton).setOnClickListener { manageBookmarksDialog() }
        findViewById<android.widget.Button>(R.id.sortFilesButton).setOnClickListener { showSortDialog() }
        findViewById<android.widget.Button>(R.id.viewModeButton).setOnClickListener { toggleGridMode() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton).setOnClickListener { showWindowsDialog() }
        findViewById<TextView>(R.id.clipboardCancelButton).setOnClickListener {
            clipboardFiles = emptyList()
            clipboardIsCut = false
            updateActionBars()
        }

        bookmarksManager = BookmarksManager(this)
        trashManager = TrashManager(this)
        loadOpenWindows()
        intent.getStringExtra("start_path")?.let { File(it).takeIf { f -> f.isDirectory }?.let { f ->
            currentDir = f
            lastNormalDir = f
        }}

        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter = FileAdapter(this, emptyList(), ::onItemClick, ::onItemLongClick, this::onStartFileDrag, this::onDropOnFolder)
        adapter.onSelectionChanged = {
            updateSelectionSubtitle()
            updateActionBars()
        }
        recyclerView.adapter = adapter
        adapter.setViewMode(fileViewMode)
        updateActionBars()

        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { refreshCurrentView() }

        setupCategoryBar()
        applyThemePalette()
        MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager)
        checkPermissionsAndLoad()
    }

    override fun onResume() {
        super.onResume()
        ensureDevelopmentBookmarksSafe()
        refreshBookmarksBar()
        updateStorageBar()
        // Catches the user coming straight back from the "Allow all files
        // access" system Settings screen opened by checkPermissionsAndLoad().
        if (awaitingStoragePermission &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            Environment.isExternalStorageManager()
        ) {
            awaitingStoragePermission = false
            loadDirectory(currentDir)
        }
    }

    // ---------- Shizuku ----------

    // Fires when the user answers the Shizuku permission dialog. It is not
    // the standard Activity permission callback — Shizuku routes it through
    // its own listener even though the signature looks similar.
    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread {
                    val granted = grantResult == PackageManager.PERMISSION_GRANTED
                    Toast.makeText(
                        this,
                        if (granted) "เชื่อมต่อ Shizuku สำเร็จ" else "ไม่ได้รับสิทธิ์จาก Shizuku",
                        Toast.LENGTH_SHORT
                    ).show()
                    onShizukuStatusChanged?.invoke()
                }
            }
        }

    // Set while the settings dialog is open so it can refresh its status
    // line after the permission listener above fires; cleared once closed.
    internal var onShizukuStatusChanged: (() -> Unit)? = null

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        try { unregisterReceiver(fileOpReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ---------- Background copy/move progress ----------

    private val fileOpReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            when (intent?.action) {
                FileOperationService.BROADCAST_PROGRESS -> {
                    val percent = intent.getIntExtra(FileOperationService.EXTRA_PERCENT, 0)
                    val move = intent.getBooleanExtra(FileOperationService.EXTRA_IS_MOVE, false)
                    supportActionBar?.subtitle = "${if (move) "กำลังย้าย" else "กำลังคัดลอก"}… $percent%"
                }
                FileOperationService.BROADCAST_DONE -> {
                    val done = intent.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, 0)
                    val total = intent.getIntExtra(FileOperationService.EXTRA_TOTAL_COUNT, 0)
                    Toast.makeText(this@MainActivity, "เสร็จสิ้น $done/$total รายการ", Toast.LENGTH_SHORT).show()
                    if (mode == Mode.NORMAL) loadDirectory(currentDir) else refreshCurrentView()
                }
            }
        }
    }

    private val storageSetupHelper by lazy { StorageSetupHelper(this) }

    private fun ensureDevelopmentBookmarksSafe() = storageSetupHelper.ensureDevelopmentBookmarksSafe()

    private fun applySavedNightMode() = settingsHelper.applySavedNightMode()

    private fun loadUserPreferences() = settingsHelper.loadUserPreferences()

    internal fun saveUserPreferences() = settingsHelper.saveUserPreferences()

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_overflow_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_about_korn -> {
                showAboutKornDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutKornDialog() = settingsHelper.showAboutKornDialog()

    private fun showSettingsDialog() = settingsHelper.showSettingsDialog()

    internal fun showSettingsDialogForStorage() = showSettingsDialog()

    internal fun applyThemePalette() = settingsHelper.applyThemePalette()

    // Shared palette accessor kept for existing helper files such as CategoryShortcuts.
    // ThemeHelper remains the single source of truth for the actual colors.
    internal fun themeColors(): Triple<Int, Int, Int> = ThemeHelper.colors(this)

    private val navigationDrawerHelper by lazy { NavigationDrawerHelper(this) }

    internal fun sortLabel(): String = navigationDrawerHelper.sortLabel()

    internal fun showSortDialog(onApplied: () -> Unit = { refreshCurrentView() }) =
        navigationDrawerHelper.showSortDialog(onApplied)

    private fun setupNavigationDrawer() = navigationDrawerHelper.setupNavigationDrawer()

    private fun setupDrawerQuickControls() = navigationDrawerHelper.setupDrawerQuickControls()

    internal fun showThemeDialog() = settingsHelper.showThemeDialog()

    internal fun getRemovableStorageDirectories(): List<File> = storageSetupHelper.getRemovableStorageDirectories()

    internal fun updateRemovableStorageDrawerItem() = storageSetupHelper.updateRemovableStorageDrawerItem()

    private fun applySort(key: SortKey, ascending: Boolean, onApplied: () -> Unit = { refreshCurrentView() }) =
        navigationDrawerHelper.applySort(key, ascending, onApplied)

    internal fun toggleGridMode() = navigationDrawerHelper.toggleGridMode()

    private fun applyFileViewMode(mode: FileAdapter.ViewMode) = navigationDrawerHelper.applyFileViewMode(mode)

    private fun showViewModeDialog() = navigationDrawerHelper.showViewModeDialog()

    // ---------- Multi-select ----------

    // (Multi-select mode: subtitle, enter/exit, action bars, "เพิ่มเติม" menu, properties
    // dialog, copy/move/rename/delete/share selected, toastNoSelection moved to
    // SelectionModeController.kt - round 8)

    // ---------- Category shortcuts (images / video / music / docs / apps / archives) ----------

    // (Category shortcuts + installed apps functions moved to CategoryShortcuts.kt - round 5)

    // ---------- Search ----------

    // (Search dialog, runSearch, highlightMatch, toolbar search button moved to SearchHelper.kt - round 6)

    internal fun refreshCurrentView() {
        when (mode) {
            Mode.NORMAL -> loadDirectory(currentDir)
            Mode.CATEGORY -> {
                val label = currentCategoryLabel
                val exts = currentCategoryExts
                if (label != null && exts != null) runCategoryScan(label, exts) else loadDirectory(lastNormalDir)
            }
            Mode.SEARCH -> lastSearchQuery?.let { runSearch(it) } ?: loadDirectory(lastNormalDir)
            Mode.TRASH -> loadTrash()
            Mode.APPS -> loadInstalledApps()
        }
    }

    // ---------- Permissions ----------

    private fun checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                awaitingStoragePermission = true
                Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
            } else {
                loadDirectory(currentDir)
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ), STORAGE_PERMISSION_CODE
                )
            } else {
                loadDirectory(currentDir)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(currentDir)
        }
    }

    // ---------- Recent folders ----------

    private fun rememberRecentFolder(dir: File) {
        directoryHistoryHelper.rememberRecentFolder(dir, mode == Mode.TRASH)
    }

    internal fun loadRecentFolders() {
        mode = Mode.SEARCH
        val paths = directoryHistoryHelper.loadRecentFolders()

        if (paths.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีโฟลเดอร์ล่าสุด", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = paths.first()
        showSpecialPath("โฟลเดอร์ล่าสุด")
        adapter.updateItems(paths.map { FileEntry(it) }, showFullPath = true)
        supportActionBar?.subtitle = "${paths.size} โฟลเดอร์"
    }

    // ---------- Clickable breadcrumb path ----------

    private fun renderBreadcrumbs(dir: File) {
        directoryBreadcrumbHelper.render(directoryBrowserHelper.breadcrumbParts(dir))
    }

    internal fun showSpecialPath(label: String) {
        directoryBreadcrumbHelper.showSpecialPath(label)
    }

    // ---------- Windows (open folder windows) ----------

    private fun loadOpenWindows() {
        openWindows.clear()
        openWindows.addAll(directoryHistoryHelper.loadOpenWindows())
    }

    private fun saveOpenWindows() {
        directoryHistoryHelper.saveOpenWindows(openWindows)
    }

    private fun rememberOpenWindow(dir: File) {
        val updated = directoryHistoryHelper.rememberOpenWindow(dir, openWindows)
        openWindows.clear()
        openWindows.addAll(updated)
    }

    private fun showWindowsDialog() {
        // Refresh stale paths before showing the grid.
        openWindows.removeAll { !File(it).isDirectory }
        if (openWindows.isEmpty()) {
            openWindows.add(currentDir.absolutePath)
            saveOpenWindows()
        }

        WindowManagerDialog(
            context = this,
            windows = openWindows,
            currentPath = currentDir.absolutePath,
            onSelectHome = { loadDirectory(Environment.getExternalStorageDirectory()) },
            onSelectWindow = { target -> if (target.isDirectory) loadDirectory(target) },
            onWindowsChanged = { saveOpenWindows() }
        ).show()
    }

    internal fun clearRecentHistory() {
        directoryHistoryHelper.clearRecentHistory()
        Toast.makeText(this, "ล้างประวัติล่าสุดแล้ว", Toast.LENGTH_SHORT).show()
    }

    internal fun openAndroidDataFolder() = storageSetupHelper.openAndroidDataFolder()

    internal fun openAndroidDataFolderSaf() = storageSetupHelper.openAndroidDataFolderSaf()

    // ---------- Storage usage bar ----------

    private fun updateStorageBar() = storageSetupHelper.updateStorageBar()

    // ---------- Sorting ----------

    internal fun comparator(): Comparator<FileEntry> =
        directoryBrowserHelper.comparator(sortKey, sortAscending)

    // ---------- Directory browsing ----------

    internal fun loadDirectory(dir: File) {
        if (!directoryBrowserHelper.canAccess(dir)) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้", Toast.LENGTH_SHORT).show()
            swipeRefresh.isRefreshing = false
            return
        }
        mode = Mode.NORMAL
        trashActionBar.visibility = View.GONE
        currentDir = dir
        lastNormalDir = dir
        rememberRecentFolder(dir)
        rememberOpenWindow(dir)
        renderBreadcrumbs(dir)

        val entries = directoryBrowserHelper
            .load(dir, showHidden, comparator())
            .entries
        adapter.updateItems(entries, showFullPath = false)
        supportActionBar?.subtitle = "${entries.size} รายการ"
        updateStorageBar()
        swipeRefresh.isRefreshing = false
    }

    private fun onItemClick(entry: FileEntry) {
        if (mode == Mode.APPS) {
            backupApplicationApk(entry)
            return
        }
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return
        }
        if (entry.isDirectory) {
            // Tapping a folder always drops back into normal browsing, even from a
            // flat category/search result list.
            loadDirectory(entry.file)
        } else if (ArchiveManager.isArchive(entry.file)) {
            showArchiveOpenOptions(entry.file)
        } else {
            openFile(entry.file)
        }
    }

    /**
     * Archives stay browsable inside KORN, but the user can always hand them to another
     * application through the Android chooser. Minecraft pack extensions also get a
     * dedicated Minecraft action when the OS has an app registered for them.
     */
    private fun showArchiveOpenOptions(file: File) {
        val items = mutableListOf("เปิดภายใน KORN")
        val isMinecraftPack = file.name.lowercase().let {
            it.endsWith(".mcpack") || it.endsWith(".mcaddon") || it.endsWith(".mcworld")
        }
        if (isMinecraftPack) items.add("เปิด/ส่งให้ Minecraft")
        items.add("แตกไฟล์…")
        items.add("เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "เปิดภายใน KORN" -> openArchiveInsideKorn(file)
                    "เปิด/ส่งให้ Minecraft" -> openFile(file)
                    "แตกไฟล์…" -> extractArchiveDialog(file)
                    "เปิดด้วยแอปอื่น…" -> openFile(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openArchiveInsideKorn(file: File) {
        // Keep ZIP-family/Minecraft archives on the existing browser so their
        // current in-place edit/rename/delete/add features remain unchanged.
        val zipLike = file.name.lowercase().let {
            it.endsWith(".zip") || it.endsWith(".mcpack") || it.endsWith(".mcaddon") ||
            it.endsWith(".mcworld") || it.endsWith(".apk") || it.endsWith(".apks") ||
            it.endsWith(".xapk") || it.endsWith(".mtz")
        }
        if (zipLike) {
            startActivity(Intent(this, ZipBrowserActivity::class.java).apply {
                putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, file.absolutePath)
            })
            return
        }

        val needsPassword = ArchiveManager.isPasswordCandidate(file)
        if (needsPassword) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("เปิด") { _, _ ->
                    materializeAndOpen(file, input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            materializeAndOpen(file, null)
        }
    }

    private fun materializeAndOpen(file: File, password: String?) {
        Toast.makeText(this, "กำลังอ่านไฟล์…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val tempZip = withContext(Dispatchers.IO) {
                    ArchiveManager.materializeForBrowse(file, cacheDir, password)
                }
                startActivity(Intent(this@MainActivity, ZipBrowserActivity::class.java).apply {
                    putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, tempZip.absolutePath)
                    putExtra("korn_temp_archive", true)
                })
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this@MainActivity, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    internal fun extractArchiveDialog(file: File) {
        val choices = arrayOf(
            "อัตโนมัติ — สร้างโฟลเดอร์ชื่อเดียวกับไฟล์ในที่เดิม",
            "เส้นทางปัจจุบัน — แตกลงโฟลเดอร์ที่กำลังเปิดอยู่",
            "เลือกเส้นทาง… — เลือกโฟลเดอร์ปลายทางเอง"
        )

        // Selecting a radio option no longer extracts immediately - it just marks the
        // choice. Extraction only runs after the user taps "ตกลง" to confirm, so a stray
        // tap on the wrong option can't accidentally kick off extraction to the wrong place.
        var selectedChoice = 0
        AlertDialog.Builder(this)
            .setTitle("แตกไฟล์ไปยัง")
            .setSingleChoiceItems(choices, selectedChoice) { _, which -> selectedChoice = which }
            .setPositiveButton("ตกลง") { dialog, _ ->
                dialog.dismiss()
                if (selectedChoice == 2) {
                    chooseDestinationFolder { destination ->
                        askArchivePasswordThenExtract(file, 2, destination)
                    }
                } else {
                    askArchivePasswordThenExtract(file, selectedChoice, null)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun askArchivePasswordThenExtract(file: File, mode: Int, chosenDestination: File?) {
        pendingArchiveFile = file
        pendingArchiveMode = mode

        val finish = { password: String? ->
            pendingArchivePassword = password
            val destination = when (mode) {
                1 -> currentDir
                2 -> chosenDestination
                else -> file.parentFile ?: currentDir
            } ?: currentDir
            startArchiveExtraction(file, destination, mode, password)
        }

        if (ArchiveManager.isPasswordCandidate(file)) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("แตกไฟล์") { _, _ ->
                    finish(input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            finish(null)
        }
    }

    private fun startArchiveExtraction(
        file: File,
        destinationRoot: File,
        mode: Int,
        password: String?
    ) {
        val dest = if (mode == 0) {
            val base = file.name.substringBeforeLast('.').substringBeforeLast('.')
                .ifBlank { file.nameWithoutExtension.ifBlank { "extracted" } }
            File(destinationRoot, uniqueName(destinationRoot, base, true))
        } else {
            destinationRoot
        }

        if (!dest.exists() && !dest.mkdirs()) {
            Toast.makeText(this, "ไม่สามารถสร้างโฟลเดอร์ปลายทางได้", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                ArchiveManager.extract(file, dest, password)
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivity,
                        "แตกไฟล์เสร็จแล้ว: ${dest.absolutePath}",
                        Toast.LENGTH_LONG
                    ).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                if (mode == 0) dest.deleteRecursively()
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "แตกไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                pendingArchiveFile = null
                pendingArchivePassword = null
            }
        }
    }

    /**
     * A lightweight filesystem folder chooser. It works with the same File-based
     * storage model used by ArchiveManager, so the selected destination can be
     * passed directly to the existing extraction/copy/move code. Sorting reuses the
     * exact same [sortKey]/[sortAscending] state, [comparator], and SharedPreferences
     * (via [applySort]/[saveUserPreferences]) as the main file list, so choosing a
     * sort order here also updates the main screen's sort order and vice versa.
     */
    internal fun chooseDestinationFolder(onSelected: (File) -> Unit) {
        val startDir = currentDir.takeIf { it.isDirectory } ?: Environment.getExternalStorageDirectory()
        destinationFolderPickerHelper.show(startDir, onSelected)
    }

    companion object {
        internal const val REQUEST_TEXT_EDIT = 4101
        internal const val REQUEST_SAF_ANDROID_DATA = 4102
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_TEXT_EDIT) {
            val pending = pendingShizukuSync
            pendingShizukuSync = null
            if (pending != null) {
                val (cache, original) = pending
                lifecycleScope.launch(Dispatchers.IO) {
                    ShizukuFileService.uploadFromLocal(cache, original.absolutePath)
                }
            }
        } else if (requestCode == REQUEST_SAF_ANDROID_DATA) {
            val treeUri = data?.data
            if (resultCode == RESULT_OK && treeUri != null) {
                val looksLikeAndroidData = treeUri.toString().contains("Android%2Fdata")
                if (!looksLikeAndroidData) {
                    Toast.makeText(
                        this,
                        "โฟลเดอร์ที่เลือกไม่ใช่ Android/data — เข้าดูได้ แต่ไม่ใช่โฟลเดอร์ที่ตั้งใจไว้",
                        Toast.LENGTH_LONG
                    ).show()
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    // Permission still works for this session even if persisting failed.
                }
                startActivity(Intent(this, SafDataBrowserActivity::class.java).apply {
                    putExtra(SafDataBrowserActivity.EXTRA_TREE_URI, treeUri.toString())
                })
            }
        }
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return
        }
        if (mode != Mode.NORMAL) {
            loadDirectory(lastNormalDir)
            return
        }
        val parent = directoryNavigationHelper.parentForBackNavigation(currentDir)
        if (parent != null) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Drag & drop ----------

    // (Drag & drop functions moved to DragDropHelper.kt - round 4)

    // ---------- Batch rename ----------

    // (Batch rename functions moved to BatchRenameHelper.kt - round 3)

    // ---------- Long-press context menu ----------

    private fun onItemLongClick(entry: FileEntry): Boolean {
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return true
        }

        if (!adapter.selectionMode) {
            // Do not rebind the RecyclerView while the long-press finger is still
            // down; the adapter keeps the current touch listener alive so the
            // same gesture can immediately transition into drag.
            adapter.setSelectionMode(true, notify = false)
            swipeRefresh.isEnabled = false
            updateSelectionSubtitle()
            updateActionBars()
        }
        if (entry.file.absolutePath !in adapter.getSelectedFiles().map { it.absolutePath }) {
            adapter.selectPath(entry.file.absolutePath, notify = false)
        }
        return true
    }

    // ---------- Hide / unhide ----------

    internal fun hideFile(file: File, hide: Boolean) {
        val newName = if (hide) {
            if (file.name.startsWith(".")) file.name else ".${file.name}"
        } else {
            file.name.trimStart('.').ifEmpty { file.name }
        }
        if (newName == file.name) {
            refreshCurrentView()
            return
        }
        val dest = File(file.parentFile, newName)
        if (file.renameTo(dest)) {
            Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            refreshCurrentView()
        } else {
            Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Multi-format archive ----------

    // (Compress/zip functions moved to ArchiveDialogs.kt - round 2)

    // (addBookmark() moved to BookmarksBar.kt - round 7)

    internal fun renameDialog(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val newFile = File(file.parentFile, newName)
                    if (file.renameToCompat(newFile)) {
                        loadDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // (Recycle bin functions moved to TrashUiController.kt - round 1)

    private fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    internal fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setupToolbarHomeButton() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbarHomeButton = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_home)
            background = null
            contentDescription = "หน้าแรก"
            setPadding(12, 8, 12, 8)
            setOnClickListener { loadDirectory(Environment.getExternalStorageDirectory()) }
        }
        val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
            dp(48),
            dp(48),
            Gravity.START or Gravity.CENTER_VERTICAL
        ).apply {
            marginStart = dp(56)
        }
        toolbar.addView(toolbarHomeButton, lp)
    }

    // (setupToolbarSearchButton moved to SearchHelper.kt - round 6)

    // ---------- Drag & drop ----------

    // (Clipboard paste + create-file/folder functions moved to ClipboardHelper.kt - STEP 15)

    // (Favorites/bookmarks bar & management moved to BookmarksBar.kt - round 7)
}
