package com.example.filemanager

import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.Button
import android.graphics.Typeface
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.text.DecimalFormat
import rikka.shizuku.Shizuku
import com.example.filemanager.shizuku.ShizukuFileService

class MainActivity : AppCompatActivity() {
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    internal enum class Mode { NORMAL, CATEGORY, SEARCH, TRASH, APPS }
    private enum class SortKey { NAME, SIZE, DATE }

    private lateinit var recyclerView: RecyclerView
    internal lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var breadcrumbBar: LinearLayout
    private lateinit var breadcrumbScroll: android.widget.HorizontalScrollView
    private lateinit var storagePercent: TextView
    private lateinit var bookmarksBar: android.widget.LinearLayout
    private lateinit var categoryBar: android.widget.LinearLayout
    private lateinit var storageBar: ProgressBar
    private lateinit var storageText: TextView
    internal lateinit var adapter: FileAdapter
    private lateinit var bookmarksManager: BookmarksManager
    internal lateinit var trashManager: TrashManager
    private lateinit var selectionActionBar: LinearLayout
    private lateinit var clipboardActionBar: LinearLayout
    internal lateinit var trashActionBar: LinearLayout
    private lateinit var selectionMoreButton: TextView
    private lateinit var clipboardPasteButton: TextView
    private lateinit var toolbarHomeButton: android.widget.ImageButton
    private val openWindows = mutableListOf<String>()

    internal var currentDir: File = Environment.getExternalStorageDirectory()
    private var lastNormalDir: File = Environment.getExternalStorageDirectory()
    private var clipboardFiles: List<File> = emptyList()
    private var clipboardIsCut = false

    // Pending archive extraction destination: 0=auto, 1=current, 2=chosen.
    private var pendingArchiveFile: File? = null
    private var pendingArchivePassword: String? = null
    private var pendingArchiveMode: Int = 0

    internal var mode = Mode.NORMAL
    private var showHidden = false
    private var currentCategoryLabel: String? = null
    private var currentCategoryExts: Set<String>? = null
    private var lastSearchQuery: String? = null
    /** Remembers the "search inside file content" checkbox state across searches this session. */
    private var lastSearchContentEnabled: Boolean = false

    private var sortKey = SortKey.NAME
    private var sortAscending = true
    private var isGridMode = false
    private var fileViewMode = FileAdapter.ViewMode.LIST
    private var confirmDelete = true
    private var themeKey = "blue"
    private var drawerHiddenSwitch: com.google.android.material.switchmaterial.SwitchMaterial? = null

    private val STORAGE_PERMISSION_CODE = 1001
    private var awaitingStoragePermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // IMPORTANT: AppCompat must know the requested night mode BEFORE
        // super.onCreate() inflates/resolves the activity theme resources.
        // If this is done after super.onCreate(), a saved "system" preference
        // can leave the first frame using the light palette (white background)
        // while text is already resolved from the night palette (light gray).
        loadUserPreferences()
        applySavedNightMode()
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        try { Shizuku.addRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        val fileOpFilter = android.content.IntentFilter().apply {
            addAction(FileOperationService.BROADCAST_PROGRESS)
            addAction(FileOperationService.BROADCAST_DONE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fileOpReceiver, fileOpFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(fileOpReceiver, fileOpFilter)
        }

        setSupportActionBar(findViewById(R.id.toolbar))
        setupNavigationDrawer()
        setupToolbarHomeButton()
        setupToolbarSearchButton()
        supportActionBar?.title = getString(R.string.app_name)

        breadcrumbBar = findViewById(R.id.breadcrumbBar)
        breadcrumbScroll = findViewById(R.id.breadcrumbScroll)
        storagePercent = findViewById(R.id.storagePercent)
        storagePercent.setOnClickListener { startActivity(Intent(this, StorageAnalyzerActivity::class.java)) }
        recyclerView = findViewById(R.id.fileList)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        bookmarksBar = findViewById(R.id.bookmarksBar)
        categoryBar = findViewById(R.id.categoryBar)
        storageBar = findViewById(R.id.storageBar)
        storageText = findViewById(R.id.storageText)
        applyThemePalette()

        selectionActionBar = findViewById(R.id.selectionActionBar)
        clipboardActionBar = findViewById(R.id.clipboardActionBar)
        trashActionBar = findViewById(R.id.trashActionBar)
        findViewById<com.google.android.material.button.MaterialButton>(R.id.emptyTrashButton).setOnClickListener { emptyTrashConfirm() }
        findViewById<android.widget.ImageButton>(R.id.trashSettingsButton).setOnClickListener { TrashSettingsSheet.newInstance { loadTrash() }.show(supportFragmentManager, "trash_settings") }
        trashActionBar.visibility = View.GONE
        selectionMoreButton = findViewById(R.id.selectionMoreButton)
        clipboardPasteButton = findViewById(R.id.clipboardPasteButton)
        findViewById<TextView>(R.id.selectionCopyButton).setOnClickListener { copySelected() }
        findViewById<TextView>(R.id.selectionCutButton).setOnClickListener { moveSelected() }
        findViewById<TextView>(R.id.selectionRenameButton).setOnClickListener { renameSelected() }
        findViewById<TextView>(R.id.selectionDeleteButton).setOnClickListener { deleteSelectedToTrash() }
        findViewById<TextView>(R.id.selectionCancelButton).setOnClickListener { exitSelectionMode() }
        selectionMoreButton.setOnClickListener { showSelectionMoreMenu() }
        clipboardPasteButton.setOnClickListener { pasteClipboard() }
        findViewById<TextView>(R.id.clipboardNewButton).setOnClickListener { newFolderDialog() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton).setOnClickListener { showAddMenu() }
        findViewById<android.widget.Button>(R.id.addBookmarkButton).setOnClickListener { addBookmark(currentDir) }
        findViewById<android.widget.Button>(R.id.manageBookmarksButton).setOnClickListener { manageBookmarksDialog() }
        findViewById<android.widget.Button>(R.id.sortFilesButton).setOnClickListener { showSortDialog() }
        findViewById<android.widget.Button>(R.id.viewModeButton).setOnClickListener { toggleGridMode() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton).setOnClickListener { showWindowsDialog() }
        findViewById<TextView>(R.id.clipboardCancelButton).setOnClickListener {
            clipboardFiles = emptyList()
            clipboardIsCut = false
            updateActionBars()
        }

        bookmarksManager = BookmarksManager(this)
        trashManager = TrashManager(this)
        loadOpenWindows()
        intent.getStringExtra("start_path")?.let { File(it).takeIf { f -> f.isDirectory }?.let { f ->
            currentDir = f
            lastNormalDir = f
        }}

        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter = FileAdapter(this, emptyList(), ::onItemClick, ::onItemLongClick, this::onStartFileDrag, this::onDropOnFolder)
        adapter.onSelectionChanged = {
            updateSelectionSubtitle()
            updateActionBars()
        }
        recyclerView.adapter = adapter
        adapter.setViewMode(fileViewMode)
        updateActionBars()

        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { refreshCurrentView() }

        setupCategoryBar()
        applyThemePalette()
        MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager)
        checkPermissionsAndLoad()
    }

    override fun onResume() {
        super.onResume()
        ensureDevelopmentBookmarksSafe()
        refreshBookmarksBar()
        updateStorageBar()
        // Catches the user coming straight back from the "Allow all files
        // access" system Settings screen opened by checkPermissionsAndLoad().
        if (awaitingStoragePermission &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            Environment.isExternalStorageManager()
        ) {
            awaitingStoragePermission = false
            loadDirectory(currentDir)
        }
    }

    // ---------- Shizuku ----------

    // Fires when the user answers the Shizuku permission dialog. It is not
    // the standard Activity permission callback — Shizuku routes it through
    // its own listener even though the signature looks similar.
    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.REQUEST_CODE) {
                runOnUiThread {
                    val granted = grantResult == PackageManager.PERMISSION_GRANTED
                    Toast.makeText(
                        this,
                        if (granted) "เชื่อมต่อ Shizuku สำเร็จ" else "ไม่ได้รับสิทธิ์จาก Shizuku",
                        Toast.LENGTH_SHORT
                    ).show()
                    onShizukuStatusChanged?.invoke()
                }
            }
        }

    // Set while the settings dialog is open so it can refresh its status
    // line after the permission listener above fires; cleared once closed.
    private var onShizukuStatusChanged: (() -> Unit)? = null

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        try { unregisterReceiver(fileOpReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ---------- Background copy/move progress ----------

    private val fileOpReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            when (intent?.action) {
                FileOperationService.BROADCAST_PROGRESS -> {
                    val percent = intent.getIntExtra(FileOperationService.EXTRA_PERCENT, 0)
                    val move = intent.getBooleanExtra(FileOperationService.EXTRA_IS_MOVE, false)
                    supportActionBar?.subtitle = "${if (move) "กำลังย้าย" else "กำลังคัดลอก"}… $percent%"
                }
                FileOperationService.BROADCAST_DONE -> {
                    val done = intent.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, 0)
                    val total = intent.getIntExtra(FileOperationService.EXTRA_TOTAL_COUNT, 0)
                    Toast.makeText(this@MainActivity, "เสร็จสิ้น $done/$total รายการ", Toast.LENGTH_SHORT).show()
                    if (mode == Mode.NORMAL) loadDirectory(currentDir) else refreshCurrentView()
                }
            }
        }
    }

    private fun ensureDevelopmentBookmarksSafe() {
        try { MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager) } catch (_: Exception) {}
    }

    private fun applySavedNightMode() {
        when (themeKey) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun loadUserPreferences() {
        val prefs = getSharedPreferences("korn_settings", MODE_PRIVATE)
        showHidden = prefs.getBoolean("show_hidden", false)
        isGridMode = prefs.getBoolean("grid_mode", false)
        fileViewMode = when (prefs.getString("view_mode", if (isGridMode) "GRID" else "LIST")) {
            "COMPACT" -> FileAdapter.ViewMode.COMPACT
            "GRID" -> FileAdapter.ViewMode.GRID
            "DETAILS" -> FileAdapter.ViewMode.DETAILS
            else -> FileAdapter.ViewMode.LIST
        }
        isGridMode = fileViewMode == FileAdapter.ViewMode.GRID
        confirmDelete = prefs.getBoolean("confirm_delete", true)
        sortKey = when (prefs.getString("sort_key", "NAME")) {
            "SIZE" -> SortKey.SIZE
            "DATE" -> SortKey.DATE
            else -> SortKey.NAME
        }
        sortAscending = prefs.getBoolean("sort_ascending", true)
        themeKey = prefs.getString("theme_key", "system") ?: "system"
    }

    private fun saveUserPreferences() {
        getSharedPreferences("korn_settings", MODE_PRIVATE).edit()
            .putBoolean("show_hidden", showHidden)
            .putBoolean("grid_mode", isGridMode)
            .putString("view_mode", fileViewMode.name)
            .putBoolean("confirm_delete", confirmDelete)
            .putString("theme_key", themeKey)
            .putString("sort_key", sortKey.name)
            .putBoolean("sort_ascending", sortAscending)
            .apply()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_overflow_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_about_korn -> {
                showAboutKornDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutKornDialog() {
        AlertDialog.Builder(this)
            .setTitle("เกี่ยวกับ KORN")
            .setMessage(
                "KORN File Manager — By KORN\n\n" +
                "แอปพลิเคชันนี้เป็นผลงานของ KORN\n" +
                "ห้ามคัดลอก ดัดแปลง แก้ไข แจกจ่าย หรือเผยแพร่ส่วนหนึ่งส่วนใดของแอปพลิเคชัน " +
                "โดยไม่ได้รับอนุญาตจาก KORN"
            )
            .setPositiveButton("ตกลง", null)
            .show()
    }

    private fun showSettingsDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val themeTitle = TextView(this).apply {
            text = "ธีม"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        }
        container.addView(themeTitle)
        val themeOptions = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val themeKeys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val themeGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.RadioGroup.VERTICAL }
        themeOptions.forEachIndexed { index, label ->
            val radio = android.widget.RadioButton(this).apply {
                text = label
                id = View.generateViewId()
                isChecked = themeKeys[index] == themeKey
            }
            themeGroup.addView(radio)
        }
        // Only remember the tapped option here; do NOT touch night mode or
        // repaint the UI while the dialog is still open. Doing that on every
        // radio tap (especially the first one, before the dialog has finished
        // laying out) is what caused the dim/washed-out flash on first open.
        var pendingThemeKey = themeKey
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = themeGroup.indexOfChild(themeGroup.findViewById(checkedId))
            pendingThemeKey = themeKeys.getOrElse(selected) { themeKey }
        }
        container.addView(themeGroup)

        val hidden = android.widget.CheckBox(this).apply {
            text = "แสดงไฟล์ที่ซ่อน"
            isChecked = showHidden
        }
        hidden.setOnCheckedChangeListener { _, checked ->
            showHidden = checked
            drawerHiddenSwitch?.setOnCheckedChangeListener(null)
            drawerHiddenSwitch?.isChecked = checked
            drawerHiddenSwitch?.setOnCheckedChangeListener { _, value ->
                if (showHidden == value) return@setOnCheckedChangeListener
                showHidden = value
                saveUserPreferences()
                refreshCurrentView()
            }
            saveUserPreferences()
            refreshCurrentView()
        }
        container.addView(hidden)

        val confirm = android.widget.CheckBox(this).apply {
            text = "ยืนยันก่อนลบ"
            isChecked = confirmDelete
        }
        confirm.setOnCheckedChangeListener { _, checked ->
            confirmDelete = checked
            saveUserPreferences()
        }
        container.addView(confirm)

        val grid = android.widget.CheckBox(this).apply {
            text = "ใช้มุมมองตาราง"
            isChecked = isGridMode
        }
        grid.setOnCheckedChangeListener { _, checked ->
            if (isGridMode != checked) toggleGridMode()
        }
        container.addView(grid)

        val shizukuTitle = TextView(this).apply {
            text = "การเข้าถึงระดับระบบ"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 16, 0, 4)
        }
        container.addView(shizukuTitle)

        val shizukuRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val shizukuStatus = TextView(this).apply {
            text = "Shizuku: ${ShizukuManager.statusLabel()}"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val shizukuButton = Button(this).apply { text = "เชื่อมต่อ" }
        shizukuRow.addView(shizukuStatus)
        shizukuRow.addView(shizukuButton)
        container.addView(shizukuRow)

        val shizukuHint = TextView(this).apply {
            text = "ใช้เข้าถึงโฟลเดอร์ Android/data โดยไม่ต้อง root — ต้องติดตั้งและเปิดแอป Shizuku ไว้ก่อน"
            textSize = 12f
            setPadding(0, 2, 0, 8)
        }
        container.addView(shizukuHint)

        fun refreshShizukuRow() {
            shizukuStatus.text = "Shizuku: ${ShizukuManager.statusLabel()}"
            shizukuButton.isEnabled = ShizukuManager.isAvailable() && !ShizukuManager.hasPermission()
        }
        refreshShizukuRow()
        onShizukuStatusChanged = { refreshShizukuRow() }

        shizukuButton.setOnClickListener {
            if (!ShizukuManager.isAvailable()) {
                Toast.makeText(
                    this,
                    "ไม่พบ Shizuku — ติดตั้งและเปิดแอปจาก shizuku.rikka.app ก่อน",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                ShizukuManager.requestPermission()
            }
        }

        val settingsDialog = AlertDialog.Builder(this)
            .setTitle("การตั้งค่า")
            .setView(container)
            .setNeutralButton("เรียงลำดับ") { _, _ -> showSortDialog() }
            .setPositiveButton("เสร็จสิ้น") { _, _ ->
                themeKey = pendingThemeKey
                saveUserPreferences()
                when (themeKey) {
                    "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
                applyThemePalette()
            }
            .setOnDismissListener { onShizukuStatusChanged = null }
            .show()

        // Prevent the dialog's own dim overlay from stacking with the
        // activity's dim on the very first show, which is what produced the
        // washed-out/dim look until the dialog was reopened once.
        settingsDialog.window?.apply {
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.5f)
        }
    }

    // Delegates to ThemeHelper so every screen in the app (text editor, zip
    // browser, storage analyzer, open-with picker) reads the exact same
    // palette as the main screen instead of each activity guessing its own.
    private fun themeColors(): Triple<Int, Int, Int> = ThemeHelper.colors(this)

    private fun applyThemePalette() {
        // setupNavigationDrawer() is called early in onCreate(), before the
        // storage/category views are initialized. Do not touch lateinit views
        // until all of them are ready; the full palette is applied again later.
        if (!::drawerLayout.isInitialized ||
            !::storageText.isInitialized ||
            !::storagePercent.isInitialized ||
            !::categoryBar.isInitialized) return
        val (primary, primaryDark, background) = themeColors()
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(primary)
        window.statusBarColor = primaryDark
        drawerLayout.setBackgroundColor(background)
        findViewById<android.widget.LinearLayout>(R.id.mainContent)?.setBackgroundColor(background)
        findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.fileList)?.setBackgroundColor(background)
        val systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val darkSurface = themeKey == "dark" || (themeKey == "system" && systemDark)
        findViewById<android.widget.HorizontalScrollView>(R.id.breadcrumbScroll)?.setBackgroundColor(
            if (darkSurface) android.graphics.Color.rgb(42, 46, 51) else android.graphics.Color.rgb(238, 241, 244)
        )
        navigationView.setBackgroundColor(if (darkSurface) android.graphics.Color.rgb(36, 39, 43) else background)
        val text = if (darkSurface) android.graphics.Color.rgb(245, 247, 249) else android.graphics.Color.rgb(32, 35, 39)
        val secondary = if (darkSurface) android.graphics.Color.rgb(190, 197, 204) else android.graphics.Color.rgb(82, 88, 96)
        storageText.setTextColor(secondary)
        storagePercent.setBackgroundColor(primary)
        storagePercent.setTextColor(android.graphics.Color.WHITE)
        val tint = android.content.res.ColorStateList.valueOf(primary)
        findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton)?.backgroundTintList = tint
        findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton)?.backgroundTintList = tint
        val toolIds = listOf(R.id.addBookmarkButton, R.id.manageBookmarksButton, R.id.sortFilesButton, R.id.viewModeButton)
        if (themeKey == "gray") {
            // Gray theme: keep the tool row clearly enabled and readable.
            // Use a neutral slate-gray distinct from the Black theme's blue-gray primary.
            val grayTool = android.graphics.Color.rgb(101, 109, 121)
            toolIds.forEach { id ->
                findViewById<android.widget.Button>(id)?.apply {
                    backgroundTintList = android.content.res.ColorStateList.valueOf(grayTool)
                    setTextColor(android.graphics.Color.WHITE)
                }
            }
        } else {
            toolIds.forEach { id ->
                findViewById<android.widget.Button>(id)?.apply {
                    backgroundTintList = android.content.res.ColorStateList.valueOf(primary)
                    setTextColor(android.graphics.Color.WHITE)
                }
            }
        }
        val category = categoryBar.takeIf { ::categoryBar.isInitialized }
        category?.let { bar -> for (i in 0 until bar.childCount) { (bar.getChildAt(i) as? TextView)?.setBackgroundColor(primary) } }
        navigationView.itemTextColor = android.content.res.ColorStateList.valueOf(text)
        navigationView.itemIconTintList = android.content.res.ColorStateList.valueOf(if (darkSurface) android.graphics.Color.rgb(220,225,230) else android.graphics.Color.rgb(72,78,86))
        // The drawer's header (logo/title strip at the top) is a separate view
        // added via app:headerLayout - it isn't part of the list items above,
        // so it needs its background set explicitly or it stays whatever
        // android:background is hardcoded to in nav_header.xml regardless of
        // the theme picked here.
        navigationView.getHeaderView(0)?.setBackgroundColor(primary)
    }

    private fun sortLabel(): String = when (sortKey) {
        SortKey.NAME -> if (sortAscending) "ชื่อ ก-ฮ" else "ชื่อ ฮ-ก"
        SortKey.SIZE -> if (sortAscending) "ขนาด น้อย-มาก" else "ขนาด มาก-น้อย"
        SortKey.DATE -> if (sortAscending) "วันที่ เก่า-ใหม่" else "วันที่ ใหม่-เก่า"
    }

    private fun showSortDialog(onApplied: () -> Unit = { refreshCurrentView() }) {
        val options = arrayOf(
            "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
            "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
            "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
        )
        val checked = when {
            sortKey == SortKey.NAME && sortAscending -> 0
            sortKey == SortKey.NAME -> 1
            sortKey == SortKey.SIZE && !sortAscending -> 2
            sortKey == SortKey.SIZE -> 3
            !sortAscending -> 4
            else -> 5
        }
        AlertDialog.Builder(this).setTitle("เรียงลำดับ").setSingleChoiceItems(options, checked) { d, which ->
            when (which) {
                0 -> applySort(SortKey.NAME, true, onApplied)
                1 -> applySort(SortKey.NAME, false, onApplied)
                2 -> applySort(SortKey.SIZE, false, onApplied)
                3 -> applySort(SortKey.SIZE, true, onApplied)
                4 -> applySort(SortKey.DATE, false, onApplied)
                5 -> applySort(SortKey.DATE, true, onApplied)
            }
            d.dismiss()
        }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun clearRecentHistory() {
        getSharedPreferences("recent_files", MODE_PRIVATE).edit().clear().apply()
        getSharedPreferences("recent_folders", MODE_PRIVATE).edit().clear().apply()
        Toast.makeText(this, "ล้างประวัติล่าสุดแล้ว", Toast.LENGTH_SHORT).show()
    }

    private fun setupNavigationDrawer() {
        // Keep the original simple 3-line hamburger icon.
        // Clicking it opens/closes the drawer; edge-swipe remains enabled by DrawerLayout.
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_hamburger)
        toolbar.setNavigationOnClickListener {
            if (drawerLayout.isDrawerOpen(Gravity.START)) {
                drawerLayout.closeDrawer(Gravity.START)
            } else {
                drawerLayout.openDrawer(Gravity.START)
            }
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home, R.id.nav_internal -> loadDirectory(Environment.getExternalStorageDirectory())
                R.id.nav_android_data -> openAndroidDataFolder()
                R.id.nav_android_data_saf -> openAndroidDataFolderSaf()
                R.id.nav_removable -> {
                    val removable = getRemovableStorageDirectories().firstOrNull()
                    if (removable != null) loadDirectory(removable)
                    else Toast.makeText(this, "ไม่พบ SD Card / USB ที่เชื่อมต่ออยู่", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_minecraft -> {
                    val d = File(Environment.getExternalStorageDirectory(), "KORN/MinecraftAddons")
                    d.mkdirs()
                    loadDirectory(d)
                }
                R.id.nav_minecraft_tools -> MinecraftAddonTools.showTools(this, currentDir)
                R.id.nav_recent -> loadRecentFolders()
                R.id.nav_clear_recent -> clearRecentHistory()
                R.id.nav_bookmarks -> manageBookmarksDialog()
                R.id.nav_trash -> loadTrash()
                R.id.nav_analyzer -> startActivity(Intent(this, StorageAnalyzerActivity::class.java))
                R.id.nav_theme -> showThemeDialog()
            }
            drawerLayout.closeDrawers()
            true
        }
        updateRemovableStorageDrawerItem()
        setupDrawerQuickControls()
        applyThemePalette()
    }

    private fun setupDrawerQuickControls() {
        val hiddenItem = navigationView.menu.findItem(R.id.nav_show_hidden)
        val switch = hiddenItem?.actionView as? com.google.android.material.switchmaterial.SwitchMaterial
        drawerHiddenSwitch = switch
        switch?.isChecked = showHidden
        switch?.setOnCheckedChangeListener { _, checked ->
            if (showHidden == checked) return@setOnCheckedChangeListener
            showHidden = checked
            saveUserPreferences()
            refreshCurrentView()
        }
    }

    private fun showThemeDialog() {
        val labels = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val keys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val checked = keys.indexOf(themeKey).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("ธีมสี").setSingleChoiceItems(labels, checked) { dialog, which ->
            themeKey = keys[which]
            saveUserPreferences()
            when (themeKey) {
                "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            applyThemePalette()
            dialog.dismiss()
        }.setNegativeButton("ยกเลิก", null).show()
    }



    private fun getRemovableStorageDirectories(): List<File> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return emptyList()
        val sm = getSystemService(StorageManager::class.java)
        return sm.storageVolumes.mapNotNull { volume ->
            if (!volume.isRemovable) return@mapNotNull null
            volume.directory?.takeIf { it.isDirectory }
        }
    }

    private fun updateRemovableStorageDrawerItem() {
        val item = navigationView.menu.findItem(R.id.nav_removable) ?: return
        val dirs = getRemovableStorageDirectories()
        item.isVisible = dirs.isNotEmpty()
        if (dirs.isNotEmpty()) {
            item.title = if (dirs.size == 1) "SD Card / USB" else "SD Card / USB (${dirs.size})"
        }
    }

    /**
     * Jumps straight to /Android/data. If Shizuku isn't connected yet, most
     * subfolders here will still look empty (Android hides them from this
     * app's own process on Android 11+) — nudge the user to connect first
     * instead of just landing them on a confusing empty screen.
     */
    private fun openAndroidDataFolder() {
        val dir = File(Environment.getExternalStorageDirectory(), "Android/data")
        if (!ShizukuManager.hasPermission()) {
            AlertDialog.Builder(this)
                .setTitle("Android/data")
                .setMessage(
                    "โฟลเดอร์นี้ถูกจำกัดสิทธิ์โดยระบบ Android — ต้องเชื่อมต่อ Shizuku ก่อน " +
                        "ไม่งั้นจะเห็นโฟลเดอร์ของแอปอื่นเป็นค่าว่างเปล่า\n\n" +
                        "ไปที่การตั้งค่า (⋮) เพื่อเชื่อมต่อ Shizuku ตอนนี้เลยไหม?"
                )
                .setPositiveButton("ไปตั้งค่า") { _, _ ->
                    loadDirectory(dir)
                    showSettingsDialog()
                }
                .setNegativeButton("เข้าโฟลเดอร์เลย") { _, _ -> loadDirectory(dir) }
                .show()
        } else {
            loadDirectory(dir)
        }
    }

    /**
     * SAF alternative to Shizuku: no extra app or ADB needed, but the grant
     * only covers the tree the user picks. If we already hold a persisted
     * permission for /Android/data from a previous grant, skip straight to
     * browsing it instead of showing the system picker again.
     */
    private fun openAndroidDataFolderSaf() {
        val existing = contentResolver.persistedUriPermissions.firstOrNull {
            it.isReadPermission && it.uri.toString().contains("Android%2Fdata")
        }
        if (existing != null) {
            startActivity(Intent(this, SafDataBrowserActivity::class.java).apply {
                putExtra(SafDataBrowserActivity.EXTRA_TREE_URI, existing.uri.toString())
            })
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Android/data (SAF)")
            .setMessage(
                "ระบบจะเปิดตัวเลือกโฟลเดอร์ — เลือกโฟลเดอร์ \"Android/data\" แล้วกด \"อนุญาต\" " +
                    "ที่มุมล่างของหน้าจอนั้น (ต้องเลือกโฟลเดอร์นี้เท่านั้น ไม่ใช่โฟลเดอร์อื่น)"
            )
            .setPositiveButton("เลือกโฟลเดอร์") { _, _ -> launchSafPicker() }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun launchSafPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            // Nudges the system picker to open directly inside Android/data
            // instead of the storage root. Not guaranteed on every OEM skin,
            // but works on stock AOSP-based pickers.
            val initialUri = android.provider.DocumentsContract.buildDocumentUri(
                "com.android.externalstorage.documents", "primary:Android/data"
            )
            putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, initialUri)
        }
        try {
            startActivityForResult(intent, REQUEST_SAF_ANDROID_DATA)
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดตัวเลือกโฟลเดอร์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }


    // ---------- Storage usage bar ----------

    private fun updateStorageBar() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = total - free
            val pct = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0
            storageBar.max = 100
            storageBar.progress = pct.coerceIn(0, 100)
            storagePercent.text = "$pct%"
            storageText.text = "ใช้ไป ${readableSize(used)} จาก ${readableSize(total)} (เหลือ ${readableSize(free)})"
        } catch (e: Exception) {
            storageText.text = ""
        }
    }

    // ---------- Sorting ----------

    private fun comparator(): Comparator<FileEntry> {
        val byField: Comparator<FileEntry> = when (sortKey) {
            SortKey.NAME -> compareBy { it.file.name.lowercase() }
            SortKey.SIZE -> compareBy { if (it.isDirectory) 0L else it.file.length() }
            SortKey.DATE -> compareBy { it.file.lastModified() }
        }
        val directional = if (sortAscending) byField else byField.reversed()
        // Folders always sort before files, regardless of the chosen field.
        return compareBy<FileEntry> { !it.isDirectory }.then(directional)
    }

    private fun applySort(key: SortKey, ascending: Boolean, onApplied: () -> Unit = { refreshCurrentView() }) {
        sortKey = key
        sortAscending = ascending
        saveUserPreferences()
        onApplied()
    }

    // ---------- Grid / list toggle ----------

    private fun toggleGridMode() {
        showViewModeDialog()
    }

    private fun applyFileViewMode(mode: FileAdapter.ViewMode) {
        fileViewMode = mode
        isGridMode = mode == FileAdapter.ViewMode.GRID
        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter.setViewMode(mode)
        saveUserPreferences()
    }

    private fun showViewModeDialog() {
        val labels = arrayOf("รายการปกติ", "รายการขนาดเล็ก", "ตาราง", "รายละเอียด: ขนาด + วันที่")
        val modes = arrayOf(FileAdapter.ViewMode.LIST, FileAdapter.ViewMode.COMPACT, FileAdapter.ViewMode.GRID, FileAdapter.ViewMode.DETAILS)
        val checked = modes.indexOf(fileViewMode).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("มุมมองไฟล์")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                applyFileViewMode(modes[which])
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Multi-select ----------

    private fun updateSelectionSubtitle() {
        supportActionBar?.subtitle = "เลือก ${adapter.selectionCount()} รายการ"
    }

    private fun enterSelectionMode() {
        adapter.setSelectionMode(true)
        swipeRefresh.isEnabled = false
        updateSelectionSubtitle()
        updateActionBars()
    }

    internal fun exitSelectionMode() {
        adapter.setSelectionMode(false)
        swipeRefresh.isEnabled = true
        updateActionBars()
        refreshCurrentView()
    }

    internal fun updateActionBars() {
        if (!::selectionActionBar.isInitialized) return
        selectionActionBar.visibility = if (adapter.selectionMode) View.VISIBLE else View.GONE
        clipboardActionBar.visibility =
            if (!adapter.selectionMode && clipboardFiles.isNotEmpty()) View.VISIBLE else View.GONE
        trashActionBar.visibility = if (!adapter.selectionMode && mode == Mode.TRASH) View.VISIBLE else View.GONE
    }

    private fun showSelectionMoreMenu() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }

        val popup = PopupMenu(this, selectionMoreButton)
        popup.menu.add("เลือกทั้งหมด").setOnMenuItemClickListener {
            adapter.selectAll()
            true
        }
        popup.menu.add("แชร์ที่เลือก").setOnMenuItemClickListener {
            shareSelected()
            true
        }

        if (files.size == 1) {
            val file = files[0]
            popup.menu.add("เปลี่ยนชื่อ").setOnMenuItemClickListener {
                renameDialog(file)
                true
            }
            popup.menu.add("รายละเอียด").setOnMenuItemClickListener {
                showPropertiesDialog(file)
                true
            }
            if (file.isDirectory) {
                popup.menu.add("เพิ่มในรายการโปรด").setOnMenuItemClickListener {
                    addBookmark(file)
                    true
                }
            }
            popup.menu.add(if (file.name.startsWith(".")) "เลิกซ่อน" else "ซ่อน")
                .setOnMenuItemClickListener {
                    hideFile(file, !file.name.startsWith("."))
                    true
                }
            popup.menu.add(if (file.isDirectory) "บีบอัด…" else "บีบอัด…")
                .setOnMenuItemClickListener {
                    showCompressFormatDialog(file)
                    true
                }
            if (!file.isDirectory && ArchiveManager.isArchive(file)) {
                popup.menu.add("แตกไฟล์…").setOnMenuItemClickListener {
                    extractArchiveDialog(file)
                    true
                }
            }
        } else {
            popup.menu.add("เปลี่ยนชื่อหลายไฟล์").setOnMenuItemClickListener {
                batchRenameDialog()
                true
            }
        }
        popup.show()
    }

    /**
     * "รายละเอียด" (Details/Properties) - shown from the selection "เพิ่มเติม" menu when
     * exactly one item is selected. Mirrors the kind of properties dialog other file
     * managers show (type, location, contents, size, modified date, permissions).
     */
    private fun showPropertiesDialog(file: File) {
        val sb = StringBuilder()
        sb.append("ชนิด: ").append(if (file.isDirectory) "แฟ้ม" else "ไฟล์").append("\n\n")
        sb.append("ที่ตั้ง: ").append(file.absolutePath).append("\n\n")

        if (file.isDirectory) {
            var fileCount = 0
            var dirCount = 0
            var totalSize = 0L
            runCatching {
                file.walkTopDown().forEach { f ->
                    if (f == file) return@forEach
                    if (f.isDirectory) dirCount++ else {
                        fileCount++
                        totalSize += f.length()
                    }
                }
            }
            sb.append("ประกอบด้วย: $fileCount ไฟล์, $dirCount โฟลเดอร์").append("\n\n")
            sb.append("ขนาด: ${readableSize(totalSize)}").append("\n\n")
        } else {
            sb.append("ขนาด: ${readableSize(file.length())}").append("\n\n")
        }

        sb.append("แก้ไขล่าสุด: ${formatDateTime(file.lastModified())}").append("\n\n")
        sb.append("อ่านได้: ${if (file.canRead()) "ใช่" else "ไม่"}").append("\n")
        sb.append("เขียนได้: ${if (file.canWrite()) "ใช่" else "ไม่"}").append("\n")
        sb.append("ซ่อน: ${if (file.name.startsWith(".")) "ใช่" else "ไม่"}")

        AlertDialog.Builder(this)
            .setTitle("คุณสมบัติ")
            .setMessage(sb.toString())
            .setPositiveButton("ปิด", null)
            .show()
    }

    private fun copySelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = false
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "คัดลอก ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun moveSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = true
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "เลือกย้าย ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun renameSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }
        if (files.size == 1) {
            renameDialog(files[0])
        } else {
            batchRenameDialog()
        }
    }

    private fun deleteSelectedToTrash() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        val action = {
            files.forEach { trashManager.moveToTrash(it) }
            exitSelectionMode()
            Toast.makeText(this, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
        }
        if (!confirmDelete) { action(); return }
        AlertDialog.Builder(this)
            .setTitle("ย้าย ${files.size} รายการไปถังขยะ?")
            .setPositiveButton("ย้ายไปถังขยะ") { _, _ -> action() }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun shareSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    internal fun toastNoSelection() {
        Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
    }

    // ---------- Category shortcuts (images / video / music / docs / apps / archives) ----------

    private fun setupCategoryBar() {
        val categories: List<Pair<String, Set<String>?>> = listOf(
            "ทั้งหมด" to null,
            "รูปภาพ" to FileCategories.IMAGES,
            "วิดีโอ" to FileCategories.VIDEOS,
            "เพลง" to FileCategories.MUSIC,
            "เอกสาร" to FileCategories.DOCS,
            "แอปพลิเคชัน" to FileCategories.APPS,
            "ไฟล์บีบอัด" to FileCategories.ARCHIVES
        )
        for ((label, exts) in categories) {
            val chip = TextView(this).apply {
                text = label
                setPadding(28, 14, 28, 14)
                setBackgroundColor(themeColors().first)
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 10
                layoutParams = lp
                setOnClickListener {
                    if (label == "แอปพลิเคชัน") {
                        loadInstalledApps()
                    } else if (exts == null) {
                        mode = Mode.NORMAL
                        loadDirectory(lastNormalDir)
                    } else {
                        runCategoryScan(label, exts)
                    }
                }
            }
            categoryBar.addView(chip)
        }
    }

    private fun runCategoryScan(label: String, exts: Set<String>) {
        mode = Mode.CATEGORY
        trashActionBar.visibility = View.GONE
        currentCategoryLabel = label
        currentCategoryExts = exts
        showSpecialPath("หมวดหมู่: $label")
        supportActionBar?.subtitle = "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        lifecycleScope.launch {
            try {
                val results = withContext(Dispatchers.IO) { FileScanner.scanByExtensions(root, exts, hidden) }
                swipeRefresh.isRefreshing = false
                if (mode != Mode.CATEGORY || currentCategoryLabel != label) return@launch
                val entries = results.map { FileEntry(it) }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun loadInstalledApps() {
        mode = Mode.APPS
        trashActionBar.visibility = View.GONE
        showSpecialPath("แอปพลิเคชันในเครื่อง")
        supportActionBar?.subtitle = "กำลังโหลดแอป…"
        lifecycleScope.launch {
            try {
                val entries = withContext(Dispatchers.IO) {
                    packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                        .mapNotNull { app ->
                            val path = app.sourceDir ?: return@mapNotNull null
                            val file = File(path)
                            if (!file.exists() || !file.isFile) return@mapNotNull null
                            val label = packageManager.getApplicationLabel(app).toString().ifBlank { app.packageName }
                            FileEntry(file, displayName = label, subtitleOverride = "${app.packageName}  •  ${readableSize(file.length())}  •  ${formatDateTime(file.lastModified())}")
                        }
                        .sortedBy { it.displayName?.lowercase() ?: it.file.name.lowercase() }
                }
                if (mode != Mode.APPS) return@launch
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} แอป"
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun backupApplicationApk(entry: FileEntry) {
        val source = entry.file
        if (!source.exists()) {
            Toast.makeText(this, "ไม่พบ APK ของแอปนี้", Toast.LENGTH_SHORT).show()
            return
        }
        val safeName = (entry.displayName ?: source.nameWithoutExtension).replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "application" }
        val dest = File(currentDir, uniqueName(currentDir, "$safeName.apk", false))
        AlertDialog.Builder(this)
            .setTitle("สำรองแอปเป็น APK")
            .setMessage("${entry.displayName ?: source.name}\n\nจะบันทึกเป็น:\n${dest.name}")
            .setPositiveButton("สำรอง") { _, _ ->
                Thread {
                    try {
                        source.copyTo(dest, overwrite = false)
                        runOnUiThread {
                            Toast.makeText(this, "สำรอง APK แล้ว: ${dest.name}", Toast.LENGTH_LONG).show()
                            loadDirectory(currentDir)
                        }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "สำรองไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Search ----------

    private fun searchDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        val input = EditText(this)
        input.hint = "ชื่อไฟล์หรือโฟลเดอร์"
        container.addView(input, LinearLayout.LayoutParams(-1, -2))

        val contentCheckbox = android.widget.CheckBox(this).apply {
            text = "ค้นหาในเนื้อหาไฟล์ด้วย"
            isChecked = lastSearchContentEnabled
        }
        container.addView(contentCheckbox, LinearLayout.LayoutParams(-1, -2))

        AlertDialog.Builder(this)
            .setTitle("ค้นหาไฟล์")
            .setView(container)
            .setPositiveButton("ค้นหา") { _, _ ->
                val q = input.text.toString().trim()
                lastSearchContentEnabled = contentCheckbox.isChecked
                if (q.isNotEmpty()) runSearch(q, contentCheckbox.isChecked)
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun runSearch(query: String, searchContent: Boolean = lastSearchContentEnabled) {
        mode = Mode.SEARCH
        trashActionBar.visibility = View.GONE
        lastSearchQuery = query
        lastSearchContentEnabled = searchContent
        showSpecialPath("ผลค้นหา: \"$query\"")
        supportActionBar?.subtitle = if (searchContent) "กำลังค้นหา (รวมเนื้อหาไฟล์)..." else "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        lifecycleScope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    FileScanner.searchByNameAndContent(root, query, hidden, searchContent)
                }
                swipeRefresh.isRefreshing = false
                if (mode != Mode.SEARCH || lastSearchQuery != query) return@launch
                val entries = results.map { match ->
                    val subtitle = if (match.line.isNotEmpty()) highlightMatch(match.line, query) else null
                    FileEntry(match.file, subtitleOverride = subtitle)
                }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } finally {
                if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
            }
        }
    }

    /** Wraps every case-insensitive occurrence of [query] inside [text] with a highlighted span. */
    private fun highlightMatch(text: String, query: String): CharSequence {
        if (query.isEmpty()) return text
        val spannable = android.text.SpannableString(text)
        var start = 0
        while (true) {
            val idx = text.indexOf(query, start, ignoreCase = true)
            if (idx < 0) break
            spannable.setSpan(
                android.text.style.BackgroundColorSpan(0xFFFFEB3B.toInt()),
                idx, idx + query.length,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable.setSpan(
                android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                idx, idx + query.length,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            start = idx + query.length
        }
        return spannable
    }

    internal fun refreshCurrentView() {
        when (mode) {
            Mode.NORMAL -> loadDirectory(currentDir)
            Mode.CATEGORY -> {
                val label = currentCategoryLabel
                val exts = currentCategoryExts
                if (label != null && exts != null) runCategoryScan(label, exts) else loadDirectory(lastNormalDir)
            }
            Mode.SEARCH -> lastSearchQuery?.let { runSearch(it) } ?: loadDirectory(lastNormalDir)
            Mode.TRASH -> loadTrash()
            Mode.APPS -> loadInstalledApps()
        }
    }

    // ---------- Permissions ----------

    private fun checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                awaitingStoragePermission = true
                Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
            } else {
                loadDirectory(currentDir)
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ), STORAGE_PERMISSION_CODE
                )
            } else {
                loadDirectory(currentDir)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(currentDir)
        }
    }

    // ---------- Recent folders ----------

    private fun rememberRecentFolder(dir: File) {
        if (mode != Mode.TRASH && dir.isDirectory) {
            val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
            val old = prefs.getString("paths", "")!!.split("\\n").filter { it.isNotBlank() }
            val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath }).take(15)
            prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
        }
    }

    private fun loadRecentFolders() {
        mode = Mode.SEARCH
        val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
        val paths = prefs.getString("paths", "")!!.split("\\n")
            .filter { it.isNotBlank() }
            .mapNotNull { File(it).takeIf { f -> f.isDirectory && f.canRead() } }

        if (paths.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีโฟลเดอร์ล่าสุด", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = paths.first()
        showSpecialPath("โฟลเดอร์ล่าสุด")
        adapter.updateItems(paths.map { FileEntry(it) }, showFullPath = true)
        supportActionBar?.subtitle = "${paths.size} โฟลเดอร์"
    }

    // ---------- Clickable breadcrumb path ----------

    private fun renderBreadcrumbs(dir: File) {
        breadcrumbBar.removeAllViews()

        val root = Environment.getExternalStorageDirectory().canonicalFile
        val target = try { dir.canonicalFile } catch (_: Exception) { dir.absoluteFile }
        val parts = mutableListOf<Pair<String, File>>()

        if (target == root || target.path.startsWith(root.path + File.separator)) {
            parts += "0" to root
            var cursor = root
            val relative = target.path.removePrefix(root.path)
                .trimStart(File.separatorChar)
            if (relative.isNotEmpty()) {
                for (name in relative.split(File.separatorChar).filter { it.isNotEmpty() }) {
                    cursor = File(cursor, name)
                    parts += name to cursor
                }
            }
        } else {
            parts += target.name.ifEmpty { target.path } to target
        }

        parts.forEachIndexed { index, (label, folder) ->
            if (index > 0) {
                breadcrumbBar.addView(TextView(this).apply {
                    text = ">"
                    textSize = 14f
                    setTextColor(getColor(R.color.text_secondary))
                    setPadding(4, 0, 4, 0)
                    gravity = Gravity.CENTER_VERTICAL
                })
            }

            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                typeface = if (index == parts.lastIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(getColor(R.color.text_primary))
                setPadding(12, 8, 12, 8)
                isSingleLine = true
                setOnClickListener { loadDirectory(folder) }
                contentDescription = "ไปที่โฟลเดอร์ $label"
                isClickable = true
                isFocusable = true
            }
            breadcrumbBar.addView(chip)
        }

        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    internal fun showSpecialPath(label: String) {
        breadcrumbBar.removeAllViews()
        breadcrumbBar.addView(TextView(this).apply {
            text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(getColor(R.color.text_primary))
            setPadding(12, 8, 12, 8)
        })
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    // ---------- Windows (open folder windows) ----------

    private fun loadOpenWindows() {
        val raw = getSharedPreferences("korn_windows", MODE_PRIVATE)
            .getString("paths", "") ?: ""
        openWindows.clear()
        raw.split("\n").filter { it.isNotBlank() }.forEach { path ->
            val f = File(path)
            if (f.isDirectory) openWindows.add(f.absolutePath)
        }
    }

    private fun saveOpenWindows() {
        getSharedPreferences("korn_windows", MODE_PRIVATE)
            .edit()
            .putString("paths", openWindows.take(12).joinToString("\n"))
            .apply()
    }

    private fun rememberOpenWindow(dir: File) {
        val path = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
        openWindows.remove(path)
        openWindows.add(0, path)
        while (openWindows.size > 12) openWindows.removeAt(openWindows.lastIndex)
        saveOpenWindows()
    }

    private fun showWindowsDialog() {
        // Refresh stale paths before showing the grid.
        openWindows.removeAll { !File(it).isDirectory }
        if (openWindows.isEmpty()) {
            openWindows.add(currentDir.absolutePath)
            saveOpenWindows()
        }

        WindowManagerDialog(
            context = this,
            windows = openWindows,
            currentPath = currentDir.absolutePath,
            onSelectHome = { loadDirectory(Environment.getExternalStorageDirectory()) },
            onSelectWindow = { target -> if (target.isDirectory) loadDirectory(target) },
            onWindowsChanged = { saveOpenWindows() }
        ).show()
    }

    // ---------- Directory browsing ----------

    internal fun loadDirectory(dir: File) {
        val accessible = (dir.exists() && dir.canRead()) || dir.needsShizuku()
        if (!accessible) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้", Toast.LENGTH_SHORT).show()
            swipeRefresh.isRefreshing = false
            return
        }
        mode = Mode.NORMAL
        trashActionBar.visibility = View.GONE
        currentDir = dir
        lastNormalDir = dir
        rememberRecentFolder(dir)
        rememberOpenWindow(dir)
        renderBreadcrumbs(dir)

        val isRoot = dir == Environment.getExternalStorageDirectory()
        val children = dir.listFilesCompat() ?: emptyList()
        val entries = children
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { !(isRoot && it.name == TrashManager.TRASH_FOLDER_NAME) }
            .map { FileEntry(it) }
            .sortedWith(comparator())
        adapter.updateItems(entries, showFullPath = false)
        supportActionBar?.subtitle = "${entries.size} รายการ"
        updateStorageBar()
        swipeRefresh.isRefreshing = false
    }

    private fun onItemClick(entry: FileEntry) {
        if (mode == Mode.APPS) {
            backupApplicationApk(entry)
            return
        }
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return
        }
        if (entry.isDirectory) {
            // Tapping a folder always drops back into normal browsing, even from a
            // flat category/search result list.
            loadDirectory(entry.file)
        } else if (ArchiveManager.isArchive(entry.file)) {
            showArchiveOpenOptions(entry.file)
        } else {
            openFile(entry.file)
        }
    }

    /**
     * Archives stay browsable inside KORN, but the user can always hand them to another
     * application through the Android chooser. Minecraft pack extensions also get a
     * dedicated Minecraft action when the OS has an app registered for them.
     */
    private fun showArchiveOpenOptions(file: File) {
        val items = mutableListOf("เปิดภายใน KORN")
        val isMinecraftPack = file.name.lowercase().let {
            it.endsWith(".mcpack") || it.endsWith(".mcaddon") || it.endsWith(".mcworld")
        }
        if (isMinecraftPack) items.add("เปิด/ส่งให้ Minecraft")
        items.add("แตกไฟล์…")
        items.add("เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "เปิดภายใน KORN" -> openArchiveInsideKorn(file)
                    "เปิด/ส่งให้ Minecraft" -> openFile(file)
                    "แตกไฟล์…" -> extractArchiveDialog(file)
                    "เปิดด้วยแอปอื่น…" -> openFile(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openArchiveInsideKorn(file: File) {
        // Keep ZIP-family/Minecraft archives on the existing browser so their
        // current in-place edit/rename/delete/add features remain unchanged.
        val zipLike = file.name.lowercase().let {
            it.endsWith(".zip") || it.endsWith(".mcpack") || it.endsWith(".mcaddon") ||
            it.endsWith(".mcworld") || it.endsWith(".apk") || it.endsWith(".apks") ||
            it.endsWith(".xapk") || it.endsWith(".mtz")
        }
        if (zipLike) {
            startActivity(Intent(this, ZipBrowserActivity::class.java).apply {
                putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, file.absolutePath)
            })
            return
        }

        val needsPassword = ArchiveManager.isPasswordCandidate(file)
        if (needsPassword) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("เปิด") { _, _ ->
                    materializeAndOpen(file, input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            materializeAndOpen(file, null)
        }
    }

    private fun materializeAndOpen(file: File, password: String?) {
        Toast.makeText(this, "กำลังอ่านไฟล์…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try {
                val tempZip = withContext(Dispatchers.IO) {
                    ArchiveManager.materializeForBrowse(file, cacheDir, password)
                }
                startActivity(Intent(this@MainActivity, ZipBrowserActivity::class.java).apply {
                    putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, tempZip.absolutePath)
                    putExtra("korn_temp_archive", true)
                })
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this@MainActivity, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    internal fun extractArchiveDialog(file: File) {
        val choices = arrayOf(
            "อัตโนมัติ — สร้างโฟลเดอร์ชื่อเดียวกับไฟล์ในที่เดิม",
            "เส้นทางปัจจุบัน — แตกลงโฟลเดอร์ที่กำลังเปิดอยู่",
            "เลือกเส้นทาง… — เลือกโฟลเดอร์ปลายทางเอง"
        )

        // Selecting a radio option no longer extracts immediately - it just marks the
        // choice. Extraction only runs after the user taps "ตกลง" to confirm, so a stray
        // tap on the wrong option can't accidentally kick off extraction to the wrong place.
        var selectedChoice = 0
        AlertDialog.Builder(this)
            .setTitle("แตกไฟล์ไปยัง")
            .setSingleChoiceItems(choices, selectedChoice) { _, which -> selectedChoice = which }
            .setPositiveButton("ตกลง") { dialog, _ ->
                dialog.dismiss()
                if (selectedChoice == 2) {
                    chooseDestinationFolder { destination ->
                        askArchivePasswordThenExtract(file, 2, destination)
                    }
                } else {
                    askArchivePasswordThenExtract(file, selectedChoice, null)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun askArchivePasswordThenExtract(file: File, mode: Int, chosenDestination: File?) {
        pendingArchiveFile = file
        pendingArchiveMode = mode

        val finish = { password: String? ->
            pendingArchivePassword = password
            val destination = when (mode) {
                1 -> currentDir
                2 -> chosenDestination
                else -> file.parentFile ?: currentDir
            } ?: currentDir
            startArchiveExtraction(file, destination, mode, password)
        }

        if (ArchiveManager.isPasswordCandidate(file)) {
            val input = EditText(this).apply {
                hint = "ถ้าไม่มีรหัสผ่านปล่อยว่างได้"
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this)
                .setTitle("รหัสผ่าน (ถ้ามี)")
                .setView(input)
                .setPositiveButton("แตกไฟล์") { _, _ ->
                    finish(input.text.toString().ifBlank { null })
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            finish(null)
        }
    }

    private fun startArchiveExtraction(
        file: File,
        destinationRoot: File,
        mode: Int,
        password: String?
    ) {
        val dest = if (mode == 0) {
            val base = file.name.substringBeforeLast('.').substringBeforeLast('.')
                .ifBlank { file.nameWithoutExtension.ifBlank { "extracted" } }
            File(destinationRoot, uniqueName(destinationRoot, base, true))
        } else {
            destinationRoot
        }

        if (!dest.exists() && !dest.mkdirs()) {
            Toast.makeText(this, "ไม่สามารถสร้างโฟลเดอร์ปลายทางได้", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(this, "กำลังแตกไฟล์…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                ArchiveManager.extract(file, dest, password)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "แตกไฟล์เสร็จแล้ว: ${dest.absolutePath}",
                        Toast.LENGTH_LONG
                    ).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                if (mode == 0) dest.deleteRecursively()
                runOnUiThread {
                    Toast.makeText(this, "แตกไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                pendingArchiveFile = null
                pendingArchivePassword = null
            }
        }.start()
    }

    /**
     * A lightweight filesystem folder chooser. It works with the same File-based
     * storage model used by ArchiveManager, so the selected destination can be
     * passed directly to the existing extraction/copy/move code. Sorting reuses the
     * exact same [sortKey]/[sortAscending] state, [comparator], and SharedPreferences
     * (via [applySort]/[saveUserPreferences]) as the main file list, so choosing a
     * sort order here also updates the main screen's sort order and vice versa.
     */
    private fun chooseDestinationFolder(onSelected: (File) -> Unit) {
        var chooserDir = currentDir.takeIf { it.isDirectory }
            ?: Environment.getExternalStorageDirectory()

        fun sortedSubfolders(dir: File): List<File> =
            (dir.listFiles()?.filter { it.isDirectory && !it.isHidden } ?: emptyList())
                .map { FileEntry(it) }
                .sortedWith(comparator())
                .map { it.file }

        val list = ListView(this)
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        list.adapter = adapter

        fun refreshChooser() {
            adapter.clear()
            if (chooserDir.parentFile != null) adapter.add("⬆ ..")
            sortedSubfolders(chooserDir).forEach { adapter.add("📁 ${it.name}") }
            adapter.notifyDataSetChanged()
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        val favoriteButton = TextView(this).apply {
            text = "⭐ โปรดปราน"
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setTextColor(getColor(R.color.primary))
            isClickable = true
            isFocusable = true
            background = obtainSelectableItemBackground()
        }
        val sortButton = TextView(this).apply {
            text = "↕ เรียง"
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setTextColor(getColor(R.color.primary))
            isClickable = true
            isFocusable = true
            background = obtainSelectableItemBackground()
        }
        topBar.addView(favoriteButton)
        topBar.addView(sortButton)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        container.addView(topBar, LinearLayout.LayoutParams(-1, -2))
        container.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val dialog = AlertDialog.Builder(this)
            .setTitle("เลือกโฟลเดอร์ปลายทาง")
            .setView(container)
            .setPositiveButton("เลือกโฟลเดอร์นี้") { _, _ -> onSelected(chooserDir) }
            .setNegativeButton("ยกเลิก", null)
            .create()

        sortButton.setOnClickListener {
            // Same sort dialog + same comparator/SharedPreferences as the main screen;
            // it just refreshes this picker's list instead of the main file list.
            showSortDialog(onApplied = { refreshChooser() })
        }

        favoriteButton.setOnClickListener {
            val bookmarks = bookmarksManager.getAll()
            if (bookmarks.isEmpty()) {
                Toast.makeText(this, "ยังไม่มีรายการโปรด", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = bookmarks.map { it.name }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("ไปยังโฟลเดอร์โปรดปราน")
                .setItems(names) { _, which ->
                    val target = File(bookmarks[which].path)
                    if (target.isDirectory) {
                        chooserDir = target
                        refreshChooser()
                        dialog.setTitle("เลือกโฟลเดอร์: ${chooserDir.name.ifBlank { chooserDir.path }}")
                    } else {
                        Toast.makeText(this, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        list.setOnItemClickListener { _, _, position, _ ->
            val parentOffset = if (chooserDir.parentFile != null) 1 else 0
            if (parentOffset == 1 && position == 0) {
                chooserDir.parentFile?.let { chooserDir = it }
            } else {
                val index = position - parentOffset
                sortedSubfolders(chooserDir).getOrNull(index)?.let { chooserDir = it }
            }
            refreshChooser()
            dialog.setTitle("เลือกโฟลเดอร์: ${chooserDir.name.ifBlank { chooserDir.path }}")
        }

        refreshChooser()
        dialog.show()
    }

    private fun obtainSelectableItemBackground(): android.graphics.drawable.Drawable? {
        val typedValue = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true)
        return androidx.core.content.ContextCompat.getDrawable(this, typedValue.resourceId)
    }

    private fun rememberRecentFile(file: File) {
        if (!file.isFile) return
        val prefs = getSharedPreferences("recent_files", MODE_PRIVATE)
        val old = prefs.getString("paths", "")!!.split("\\n").filter { it.isNotBlank() }
        val updated = (listOf(file.absolutePath) + old.filter { it != file.absolutePath }).take(30)
        prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
    }

    /**
     * Opens any regular file with a choice when KORN has a suitable internal viewer.
     * Supported internal viewers currently include text files and images. For all other
     * file types, Android's normal external-app chooser is used directly.
     */
    private var pendingShizukuSync: Pair<File, File>? = null // cache file -> original protected path

    private fun openFile(file: File) {
        rememberRecentFile(file)

        // Every regular file gets a KORN option. Text is edited normally; unknown/binary
        // formats use the universal HEX editor. Images keep their existing image viewer.
        val options = arrayOf("เปิดด้วย KORN", "เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> resolveForOpen(file) { resolved, syncBackTo -> openFileInternally(resolved, syncBackTo) }
                    1 -> resolveForOpen(file) { resolved, _ -> openFileExternally(resolved) }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
        }

    /**
     * Runs [action] with a File this app's own process can actually read.
     * If [file] is already directly readable that's immediate. If it's only
     * reachable through Shizuku (e.g. another app's Android/data folder),
     * it's copied into the app's cache first and [action] gets the cache
     * copy plus the original path (so an edit can be synced back).
     */
    private fun resolveForOpen(file: File, action: (resolved: File, syncBackTo: File?) -> Unit) {
        if (file.canRead()) {
            action(file, null)
            return
        }
        if (!file.needsShizuku()) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "กำลังดึงไฟล์ผ่าน Shizuku…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val cache = File(File(cacheDir, "shizuku_open"), file.name)
            val ok = withContext(Dispatchers.IO) {
                cache.parentFile?.mkdirs()
                ShizukuFileService.downloadToLocal(file.absolutePath, cache)
            }
            if (ok) {
                action(cache, file)
            } else {
                Toast.makeText(this@MainActivity, "เปิดไฟล์ไม่ได้ (Shizuku)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openFileInternally(file: File, syncBackTo: File? = null) {
        val ext = file.extension.lowercase()
        try {
            if (FileCategories.IMAGES.contains(ext)) {
                startActivity(Intent(this, ImageViewerActivity::class.java).apply {
                    putExtra(ImageViewerActivity.EXTRA_IMAGE_PATH, file.absolutePath)
                })
                return
            }

            // Text and every other binary/unknown file are editable. TextEditActivity
            // automatically chooses UTF-8 text mode or HEX mode.
            if (syncBackTo != null) pendingShizukuSync = file to syncBackTo
            startActivityForResult(Intent(this, TextEditActivity::class.java).apply {
                putExtra(TextEditActivity.EXTRA_FILE_PATH, file.absolutePath)
            }, REQUEST_TEXT_EDIT)
            return
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_TEXT_EDIT) {
            val pending = pendingShizukuSync
            pendingShizukuSync = null
            if (pending != null) {
                val (cache, original) = pending
                lifecycleScope.launch(Dispatchers.IO) {
                    ShizukuFileService.uploadFromLocal(cache, original.absolutePath)
                }
            }
        } else if (requestCode == REQUEST_SAF_ANDROID_DATA) {
            val treeUri = data?.data
            if (resultCode == RESULT_OK && treeUri != null) {
                val looksLikeAndroidData = treeUri.toString().contains("Android%2Fdata")
                if (!looksLikeAndroidData) {
                    Toast.makeText(
                        this,
                        "โฟลเดอร์ที่เลือกไม่ใช่ Android/data — เข้าดูได้ แต่ไม่ใช่โฟลเดอร์ที่ตั้งใจไว้",
                        Toast.LENGTH_LONG
                    ).show()
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    // Permission still works for this session even if persisting failed.
                }
                startActivity(Intent(this, SafDataBrowserActivity::class.java).apply {
                    putExtra(SafDataBrowserActivity.EXTRA_TREE_URI, treeUri.toString())
                })
            }
        }
    }

    private fun openFileExternally(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val REQUEST_TEXT_EDIT = 4101
        private const val REQUEST_SAF_ANDROID_DATA = 4102
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return
        }
        if (mode != Mode.NORMAL) {
            loadDirectory(lastNormalDir)
            return
        }
        val parent = currentDir.parentFile
        if (parent != null && currentDir != Environment.getExternalStorageDirectory()) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Drag & drop ----------

    // (Drag & drop functions moved to DragDropHelper.kt - round 4)

    // ---------- Batch rename ----------

    // (Batch rename functions moved to BatchRenameHelper.kt - round 3)

    // ---------- Long-press context menu ----------

    private fun onItemLongClick(entry: FileEntry): Boolean {
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return true
        }

        if (!adapter.selectionMode) {
            // Do not rebind the RecyclerView while the long-press finger is still
            // down; the adapter keeps the current touch listener alive so the
            // same gesture can immediately transition into drag.
            adapter.setSelectionMode(true, notify = false)
            swipeRefresh.isEnabled = false
            updateSelectionSubtitle()
            updateActionBars()
        }
        if (entry.file.absolutePath !in adapter.getSelectedFiles().map { it.absolutePath }) {
            adapter.selectPath(entry.file.absolutePath, notify = false)
        }
        return true
    }

    // ---------- Hide / unhide ----------

    private fun hideFile(file: File, hide: Boolean) {
        val newName = if (hide) {
            if (file.name.startsWith(".")) file.name else ".${file.name}"
        } else {
            file.name.trimStart('.').ifEmpty { file.name }
        }
        if (newName == file.name) {
            refreshCurrentView()
            return
        }
        val dest = File(file.parentFile, newName)
        if (file.renameTo(dest)) {
            Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            refreshCurrentView()
        } else {
            Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Multi-format archive ----------

    // (Compress/zip functions moved to ArchiveDialogs.kt - round 2)

    private fun addBookmark(dir: File) {
        val input = EditText(this)
        input.setText(dir.name)
        AlertDialog.Builder(this)
            .setTitle("เพิ่มในรายการโปรด")
            .setView(input)
            .setPositiveButton("บันทึก") { _, _ ->
                val name = input.text.toString().ifBlank { dir.name }
                bookmarksManager.add(name, dir.absolutePath)
                refreshBookmarksBar()
                Toast.makeText(this, "เพิ่มในรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameDialog(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val newFile = File(file.parentFile, newName)
                    if (file.renameToCompat(newFile)) {
                        loadDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // (Recycle bin functions moved to TrashUiController.kt - round 1)

    private fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setupToolbarHomeButton() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbarHomeButton = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_home)
            background = null
            contentDescription = "หน้าแรก"
            setPadding(12, 8, 12, 8)
            setOnClickListener { loadDirectory(Environment.getExternalStorageDirectory()) }
        }
        val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
            dp(48),
            dp(48),
            Gravity.START or Gravity.CENTER_VERTICAL
        ).apply {
            marginStart = dp(56)
        }
        toolbar.addView(toolbarHomeButton, lp)
    }

    private fun setupToolbarSearchButton() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        val button = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            background = null
            contentDescription = "ค้นหา"
            setPadding(12, 8, 12, 8)
            setOnClickListener { if (mode != Mode.TRASH && mode != Mode.APPS) searchDialog() }
        }
        val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
            dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL
        )
        toolbar.addView(button, lp)
    }

    // ---------- Drag & drop ----------

    private fun pasteClipboard() {
        val sources = clipboardFiles
        if (sources.isEmpty()) {
            Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
            return
        }
        val destDir = currentDir
        val cut = clipboardIsCut
        FileOperationService.start(this, sources, destDir, move = cut)
        clipboardFiles = emptyList()
        clipboardIsCut = false
        updateActionBars()
        Toast.makeText(this, "กำลังวางไฟล์ในพื้นหลัง…", Toast.LENGTH_SHORT).show()
    }

    private fun showAddMenu() {
        AlertDialog.Builder(this)
            .setTitle("เพิ่ม")
            .setItems(arrayOf("📄 ไฟล์", "📁 โฟลเดอร์")) { _, which ->
                when (which) {
                    0 -> newFileDialog()
                    1 -> newFolderDialog()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun newFileDialog() {
        val input = EditText(this)
        input.hint = "ชื่อไฟล์.txt"
        AlertDialog.Builder(this)
            .setTitle("สร้างไฟล์ใหม่")
            .setMessage("ใน ${currentDir.absolutePath}")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val newFile = File(currentDir, name)
                try {
                    when {
                        newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                        newFile.createNewFileCompat() -> loadDirectory(currentDir)
                        else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun newFolderDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    File(currentDir, name).mkdirsCompat()
                    loadDirectory(currentDir)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Favorites (bookmarks) bar & management ----------

    private fun isDarkThemeActive(): Boolean {
        return themeKey == "dark" || (themeKey == "system" &&
            (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES)
    }

    private fun refreshBookmarksBar() {
        bookmarksBar.removeAllViews()
        val bookmarks = bookmarksManager.getAll()
        for (bm in bookmarks) {
            val chip = TextView(this).apply {
                text = "⭐ ${bm.name}"
                setPadding(24, 12, 24, 12)
                setBackgroundColor(if (isDarkThemeActive()) android.graphics.Color.rgb(55, 62, 70) else android.graphics.Color.rgb(227, 242, 253))
                setTextColor(if (isDarkThemeActive()) android.graphics.Color.rgb(235, 240, 245) else android.graphics.Color.rgb(21, 101, 192))
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 12
                layoutParams = lp
                isClickable = true
                isFocusable = true
                isLongClickable = true
                setOnClickListener {
                    val target = File(bm.path)
                    if (target.exists()) loadDirectory(target)
                    else Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("ลบบุ๊คมาร์ก \"${bm.name}\"?")
                        .setPositiveButton("ลบ") { _, _ ->
                            bookmarksManager.remove(bm.path)
                            refreshBookmarksBar()
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                    true
                }
            }
            bookmarksBar.addView(chip)
        }
    }

    private fun manageBookmarksDialog() {
        val bookmarks = bookmarksManager.getAll().toMutableList()
        val list = ListView(this)
        val names = bookmarks.map { "⭐ ${it.name}\n${it.path}" }.toMutableList()
        val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_2, android.R.id.text1, names)
        list.adapter = listAdapter

        val dialog = AlertDialog.Builder(this)
            .setTitle("ตัวจัดการรายการโปรด")
            .setView(list)
            .setPositiveButton("＋ เพิ่มโฟลเดอร์") { _, _ ->
                chooseDestinationFolder { selected ->
                    addBookmark(selected)
                }
            }
            .setNegativeButton("ปิด", null)
            .create()

        list.setOnItemClickListener { _, _, which, _ ->
            val target = File(bookmarks.getOrNull(which)?.path ?: return@setOnItemClickListener)
            if (target.isDirectory) {
                dialog.dismiss()
                loadDirectory(target)
            } else {
                Toast.makeText(this, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
            }
        }

        list.setOnItemLongClickListener { _, _, which, _ ->
            val bookmark = bookmarks.getOrNull(which) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("ลบรายการโปรด?")
                .setMessage("${bookmark.name}\n${bookmark.path}")
                .setPositiveButton("ลบ") { _, _ ->
                    bookmarksManager.remove(bookmark.path)
                    bookmarks.removeAt(which)
                    names.removeAt(which)
                    listAdapter.notifyDataSetChanged()
                    refreshBookmarksBar()
                    Toast.makeText(this, "ลบออกจากรายการโปรดแล้ว", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
            true
        }

        dialog.show()

        if (bookmarks.isEmpty()) {
            // Keep the manager usable even when there are no saved folders yet.
            listAdapter.notifyDataSetChanged()
            Toast.makeText(this, "ยังไม่มีรายการโปรด กด «＋ เพิ่มโฟลเดอร์» เพื่อเลือกโฟลเดอร์", Toast.LENGTH_LONG).show()
        }
    }
}
