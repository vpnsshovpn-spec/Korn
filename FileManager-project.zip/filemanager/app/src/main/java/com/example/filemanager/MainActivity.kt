package com.example.filemanager

import android.content.Intent
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    // Round 13 scaffold: ViewModel wired in but not yet holding any state.
    // Future rounds will move state here in small, isolated steps (see MainViewModel.kt).
    internal val viewModel: MainViewModel by viewModels()

    internal lateinit var drawerLayout: DrawerLayout
    internal lateinit var navigationView: NavigationView

    enum class Mode { NORMAL, CATEGORY, SEARCH, TRASH, APPS }
    internal enum class SortKey { NAME, SIZE, DATE }

    internal lateinit var recyclerView: RecyclerView
    internal lateinit var swipeRefresh: SwipeRefreshLayout
    // internal (not private): widened for MainViewBindingHelper.kt (round 3.7 slimdown).
    internal lateinit var breadcrumbBar: LinearLayout
    internal lateinit var breadcrumbScroll: android.widget.HorizontalScrollView
    internal lateinit var storagePercent: TextView
    internal lateinit var bookmarksBar: android.widget.LinearLayout
    internal lateinit var categoryBar: android.widget.LinearLayout
    internal lateinit var storageText: TextView
    internal lateinit var adapter: FileAdapter
    internal lateinit var bookmarksManager: BookmarksManager
    internal lateinit var trashManager: TrashManager
    // Local Search Index รอบ 1: สร้าง index เปล่าๆ ไว้เฉยๆ ยังไม่เปลี่ยนพฤติกรรม
    // ค้นหาใดๆ ที่ผู้ใช้เห็น (ดู search-index-project-plan.txt ข้อ 5) — รอบ 2
    // ถึงจะต่อสายให้ SearchHelper/MainViewModel query จากตัวนี้แทน FileScanner
    internal lateinit var searchIndexManager: SearchIndexManager
    internal lateinit var selectionActionBar: LinearLayout
    internal val isSelectionActionBarInitialized: Boolean
        get() = ::selectionActionBar.isInitialized
    internal lateinit var clipboardActionBar: LinearLayout
    internal lateinit var trashActionBar: LinearLayout
    internal lateinit var selectionMoreButton: TextView
    // internal (not private): widened for MainViewBindingHelper.kt (round 3.7 slimdown).
    internal lateinit var clipboardPasteButton: TextView
    // internal (not private): setupToolbarHomeButton() moved to FileItemActionsHelper.kt.
    internal lateinit var toolbarHomeButton: android.widget.ImageButton
    // internal (not private): widened for WindowsAndHistoryHelper.kt (round 3.3 slimdown).
    internal val openWindows = mutableListOf<String>()

    // Top Pull-Down Drawer: all slide-animation/gesture logic lives in the controller class
    // (see TopPullDownController.kt) - this Activity only wires the two views together below.
    private lateinit var topPullDownController: TopPullDownController

    // Round 19: currentDir wrapper removed; ArchiveDialogs.kt, CategoryShortcuts.kt,
    // ClipboardHelper.kt, DragDropHelper.kt, FileClickHelper.kt, FileItemActionsHelper.kt,
    // PermissionFlowHelper.kt, NavigationDrawerHelper.kt use viewModel.currentDir directly.
    // Round 18: lastNormalDir/clipboardFiles/clipboardIsCut wrappers removed; callers use
    // viewModel.xxx.value / viewModel.setXxx() directly (ClipboardHelper.kt, CategoryShortcuts.kt,
    // SelectionModeController.kt).
    internal var pendingShizukuSync: Pair<File, File>? = null

    // Pending archive extraction destination: 0=auto, 1=current, 2=chosen.
    // internal (not private): read/written from FileClickHelper.kt's archive extraction flow.
    internal var pendingArchiveFile: File? = null
    internal var pendingArchivePassword: String? = null
    internal var pendingArchiveMode: Int = 0

    // Background Archive Operations: pending zip/unzip start held while a POST_NOTIFICATIONS
    // permission request is in flight, and the progress-dialog view refs while it's showing.
    // internal (not private): read/written from ArchiveProgressDialogHelper.kt.
    internal var pendingArchiveOperation: (() -> Unit)? = null
    internal var archiveProgressDialogHandle: KornDialog.KornDialogHandle? = null
    internal var archiveProgressLabel: android.widget.TextView? = null
    internal var archiveProgressBar: android.widget.ProgressBar? = null
    internal var archiveProgressPercentText: android.widget.TextView? = null

    // Part 3/3 "สร้างไฟล์ ของฉัน": progress-dialog view refs for CompressOperationService, mirrors
    // the archiveProgress* fields above. internal (not private): read/written from
    // CompressProgressDialogHelper.kt. Reuses pendingArchiveOperation/
    // startArchiveOperationWithNotificationCheck above - that check is generic, not tied to
    // ArchiveOperationService specifically.
    internal var compressProgressDialogHandle: KornDialog.KornDialogHandle? = null
    internal var compressProgressLabel: android.widget.TextView? = null
    internal var compressProgressBar: android.widget.ProgressBar? = null
    internal var compressProgressPercentText: android.widget.TextView? = null

    // Rotation Safety #2: the currently-showing "ไฟล์ซ้ำ" conflict dialog (Copy/Move or
    // Extract - only one batch is ever active at a time) and which conflict item it's for,
    // so ConflictBatchObserver.kt's collector can tell "same conflict, already showing" apart
    // from "moved on to the next one" and never stacks a duplicate. internal (not private):
    // read/written from ConflictBatchObserver.kt.
    internal var conflictDialogHandle: KornDialog.KornDialogHandle? = null
    internal var conflictDialogShownForKey: String? = null

    // Round 21: mode wrapper removed; CategoryShortcuts.kt, FileClickHelper.kt, SearchHelper.kt,
    // SelectionModeController.kt, TrashUiController.kt use viewModel.mode directly.
    // Round 19: showHidden wrapper removed; CategoryShortcuts.kt, NavigationDrawerHelper.kt,
    // SearchHelper.kt, SettingsHelper.kt use viewModel.showHidden directly.
    // Round 18: currentCategoryLabel/currentCategoryExts/lastSearchQuery/lastSearchContentEnabled
    // wrappers removed; CategoryShortcuts.kt and SearchHelper.kt use viewModel directly.

    // Round 20: sortKey/sortAscending/themeKey wrappers removed; BookmarksBar.kt,
    // NavigationDrawerHelper.kt, SettingsHelper.kt use viewModel directly.

    // Round 18: isGridMode/fileViewMode wrappers removed; NavigationDrawerHelper.kt and
    // SettingsHelper.kt use activity.viewModel directly.
    internal var confirmDelete = true
    internal var drawerHiddenSwitch: com.google.android.material.switchmaterial.SwitchMaterial? = null

    // internal (not private): read/written from PermissionFlowHelper.kt's checkPermissionsAndLoad().
    internal val STORAGE_PERMISSION_CODE = 1001
    internal var awaitingStoragePermission = false
    private val settingsHelper by lazy { SettingsHelper(this) }
    private val directoryBrowserHelper by lazy { DirectoryBrowserHelper() }
    // internal (not private): widened for WindowsAndHistoryHelper.kt (round 3.3 slimdown).
    internal val directoryHistoryHelper by lazy { DirectoryHistoryHelper(this) }
    private val directoryNavigationHelper by lazy { DirectoryNavigationHelper() }
    private val directoryBreadcrumbHelper by lazy {
        DirectoryBreadcrumbHelper(
            breadcrumbBar = breadcrumbBar,
            breadcrumbScroll = breadcrumbScroll,
            textPrimary = R.color.text_primary,
            textSecondary = R.color.text_secondary,
            onFolderClick = { loadDirectory(it) }
        )
    }
    private val destinationFolderPickerHelper by lazy {
        DestinationFolderPickerHelper(
            context = this,
            directoryBrowserHelper = directoryBrowserHelper,
            bookmarksManager = bookmarksManager,
            comparator = { comparator() },
            dp = { dp(it) },
            showSortDialog = ::showSortDialog
        )
    }

    internal val isMainThemeViewsInitialized: Boolean
        get() = ::drawerLayout.isInitialized && ::storageText.isInitialized &&
            ::storagePercent.isInitialized && ::categoryBar.isInitialized

    override fun onCreate(savedInstanceState: Bundle?) {
        // IMPORTANT: AppCompat must know the requested night mode BEFORE
        // super.onCreate() inflates/resolves the activity theme resources.
        // If this is done after super.onCreate(), a saved "system" preference
        // can leave the first frame using the light palette (white background)
        // while text is already resolved from the night palette (light gray).
        //
        // Round 22: this reads theme_key straight from SharedPreferences (not via
        // viewModel) because MainViewModel now needs a SavedStateHandle, which the
        // Activity's SavedStateRegistry only provides from super.onCreate() onward -
        // touching `viewModel` any earlier than that throws at runtime. The full
        // loadUserPreferences() (which does populate viewModel) now runs right after
        // super.onCreate() instead, before anything else in this method needs it.
        applySavedNightModeFromPrefs()
        super.onCreate(savedInstanceState)
        loadUserPreferences()

        setContentView(R.layout.activity_main)

        // All findViewById() + setOnClickListener() wiring lives in bindMainViews() (round 3.7
        // slimdown, see MainActivity-Slimdown-Plan.txt); must run before anything below that
        // touches those fields (setupNavigationDrawer(), applyThemePalette(), etc.)
        bindMainViews()

        try { Shizuku.addRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        val fileOpFilter = android.content.IntentFilter().apply {
            addAction(FileOperationService.BROADCAST_PROGRESS)
            addAction(FileOperationService.BROADCAST_DONE)
        }
        val archiveOpFilter = android.content.IntentFilter().apply {
            addAction(ArchiveOperationService.BROADCAST_PROGRESS)
            addAction(ArchiveOperationService.BROADCAST_DONE)
        }
        val compressOpFilter = android.content.IntentFilter().apply {
            addAction(CompressOperationService.BROADCAST_PROGRESS)
            addAction(CompressOperationService.BROADCAST_DONE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fileOpReceiver, fileOpFilter, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(archiveOpReceiver, archiveOpFilter, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(compressOpReceiver, compressOpFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(fileOpReceiver, fileOpFilter)
            registerReceiver(archiveOpReceiver, archiveOpFilter)
            registerReceiver(compressOpReceiver, compressOpFilter)
        }

        setSupportActionBar(findViewById(R.id.toolbar))
        setupNavigationDrawer()
        setupToolbarHomeButton()
        setupToolbarSearchButton()
        supportActionBar?.title = getString(R.string.app_name)
        applyThemePalette()

        bookmarksManager = BookmarksManager(this)
        trashManager = TrashManager(this)
        lifecycleScope.launch { trashManager.initialize() }
        // Local Search Index: รอบ 1 สร้าง initialize() ที่เช็คเองว่า index ว่างอยู่หรือยัง
        // แล้ว rebuild ครั้งแรกถ้าจำเป็น — fire-and-forget เหมือน trashManager ด้านบน
        // รอบ 2 (ดู search-index-project-plan.txt ข้อ 6.3) เพิ่ม 2 อย่าง: (1) attach เข้า
        // MainViewModel เพื่อให้ runSearchNow() เรียกใช้ query จาก index ได้จริง (2) แจ้ง
        // ผู้ใช้ด้วย Toast ตอนเปิดแอปครั้งแรกที่ index ยังว่างอยู่ เพราะรอบแรกที่เครื่องมี
        // ไฟล์เยอะๆ อาจใช้เวลาสักพัก (ระหว่างนั้นการค้นหาจะ fallback ไปเดินสแกนสดแทน —
        // ดู MainViewModel.runSearchNow())
        searchIndexManager = SearchIndexManager(this)
        viewModel.attachSearchIndexManager(searchIndexManager)
        lifecycleScope.launch {
            if (searchIndexManager.isEmpty()) {
                Toast.makeText(this@MainActivity, "กำลังสร้างดัชนีไฟล์ครั้งแรก...", Toast.LENGTH_LONG).show()
            }
            searchIndexManager.initialize()
        }
        loadOpenWindows()
        intent.getStringExtra("start_path")?.let { File(it).takeIf { f -> f.isDirectory }?.let { f ->
            viewModel.setCurrentDir(f)
            viewModel.setLastNormalDir(f)
        }}

        recyclerView.layoutManager = if (viewModel.isGridMode.value) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter = FileAdapter(this, viewModel, emptyList(), this::onItemClick, this::onItemLongClick, this::onStartFileDrag, this::onDropOnFolder)
        adapter.onSelectionChanged = {
            updateSelectionSubtitle()
            updateActionBars()
        }
        recyclerView.adapter = adapter
        adapter.setViewMode(viewModel.fileViewMode.value)
        updateActionBars()

        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { refreshCurrentView() }

        setupCategoryBar()
        applyThemePalette()

        // Top Pull-Down Drawer glue code (logic itself lives in TopPullDownController.kt).
        topPullDownController = TopPullDownController(
            panel = findViewById(R.id.topPullDownPanel),
            handle = findViewById(R.id.pullDownHandle)
        )
        topPullDownController.setup()

        MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager)
        observeDirectoryState()
        observeFileOpState()
        observeArchiveOpState()
        observeCompressOpState()
        observeConflictBatches()
        observeSearchState()
        checkPermissionsAndLoad(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        ensureDevelopmentBookmarksSafe()
        refreshBookmarksBar()
        updateStorageBar()
        // Catches the user coming straight back from the "Allow all files
        // access" system Settings screen opened by checkPermissionsAndLoad().
        if (awaitingStoragePermission &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            Environment.isExternalStorageManager()
        ) {
            awaitingStoragePermission = false
            loadDirectory(viewModel.currentDir.value)
        }
    }

    // ---------- Shizuku ----------

    // Fires when the user answers the Shizuku permission dialog. It is not the standard
    // Activity permission callback - Shizuku routes it through its own listener even though
    // the signature looks similar. Listener body lives in ShizukuIntegrationHelper.kt (see
    // MainActivity-Slimdown-Plan.txt ก้อน 3.1); the field stays here for object-identity
    // stability across Shizuku.addRequestPermissionResultListener()/
    // removeRequestPermissionResultListener() in onCreate()/onDestroy() below.
    private val shizukuPermissionListener = buildShizukuPermissionListener()

    // Set while the settings dialog is open so it can refresh its status
    // line after the permission listener above fires; cleared once closed.
    internal var onShizukuStatusChanged: (() -> Unit)? = null

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener) } catch (_: Throwable) {}
        try { unregisterReceiver(fileOpReceiver) } catch (_: Throwable) {}
        try { unregisterReceiver(archiveOpReceiver) } catch (_: Throwable) {}
        try { unregisterReceiver(compressOpReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ---------- Background copy/move + archive progress ----------
    // Receiver bodies + observeFileOpState() moved to FileOpBroadcastHelper.kt (see
    // MainActivity-Slimdown-Plan.txt ก้อน 3.2); fields stay here for the same object-identity
    // reason as shizukuPermissionListener above (registerReceiver()/unregisterReceiver() in
    // onCreate()/onDestroy() need a stable instance to unregister the same receiver they
    // registered). archiveOpReceiver mirrors fileOpReceiver; ArchiveOperationService.kt is
    // its sender.

    private val fileOpReceiver = buildFileOpReceiver()
    private val archiveOpReceiver = buildArchiveOpReceiver()
    private val compressOpReceiver = buildCompressOpReceiver()

    private val storageSetupHelper by lazy { StorageSetupHelper(this) }

    private fun ensureDevelopmentBookmarksSafe() = storageSetupHelper.ensureDevelopmentBookmarksSafe()

    private fun applySavedNightModeFromPrefs() = settingsHelper.applySavedNightModeFromPrefs()

    private fun loadUserPreferences() = settingsHelper.loadUserPreferences()

    internal fun saveUserPreferences() = settingsHelper.saveUserPreferences()

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_overflow_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                showSettingsDialog()
                true
            }
            R.id.action_about_korn -> {
                showAboutKornDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutKornDialog() = settingsHelper.showAboutKornDialog()

    private fun showSettingsDialog() = settingsHelper.showSettingsDialog()

    internal fun showSettingsDialogForStorage() = showSettingsDialog()

    internal fun applyThemePalette() = settingsHelper.applyThemePalette()

    // Shared palette accessor kept for existing helper files such as CategoryShortcuts.
    // ThemeHelper remains the single source of truth for the actual colors.
    internal fun themeColors(): Triple<Int, Int, Int> = ThemeHelper.colors(this)

    private val navigationDrawerHelper by lazy { NavigationDrawerHelper(this) }

    internal fun sortLabel(): String = navigationDrawerHelper.sortLabel()

    internal fun showSortDialog(onApplied: () -> Unit = { refreshCurrentView() }) =
        navigationDrawerHelper.showSortDialog(onApplied)

    private fun setupNavigationDrawer() = navigationDrawerHelper.setupNavigationDrawer()

    private fun setupDrawerQuickControls() = navigationDrawerHelper.setupDrawerQuickControls()

    internal fun showThemeDialog() = settingsHelper.showThemeDialog()

    internal fun getRemovableStorageDirectories(): List<File> = storageSetupHelper.getRemovableStorageDirectories()

    internal fun updateRemovableStorageDrawerItem() = storageSetupHelper.updateRemovableStorageDrawerItem()

    private fun applySort(key: SortKey, ascending: Boolean, onApplied: () -> Unit = { refreshCurrentView() }) =
        navigationDrawerHelper.applySort(key, ascending, onApplied)

    internal fun toggleGridMode() = navigationDrawerHelper.toggleGridMode()

    private fun applyFileViewMode(mode: FileAdapter.ViewMode) = navigationDrawerHelper.applyFileViewMode(mode)

    private fun showViewModeDialog() = navigationDrawerHelper.showViewModeDialog()

    // ---------- Multi-select ----------

    // (Multi-select mode: subtitle, enter/exit, action bars, "เพิ่มเติม" menu, properties
    // dialog, copy/move/rename/delete/share selected, toastNoSelection moved to
    // SelectionModeController.kt - round 8)

    // ---------- Category shortcuts (images / video / music / docs / apps / archives) ----------

    // (Category shortcuts + installed apps functions moved to CategoryShortcuts.kt - round 5)

    // ---------- Search ----------

    // (Search dialog, runSearch, highlightMatch, toolbar search button moved to SearchHelper.kt - round 6)

    internal fun refreshCurrentView() {
        when (viewModel.mode.value) {
            Mode.NORMAL -> loadDirectory(viewModel.currentDir.value)
            Mode.CATEGORY -> {
                val label = viewModel.currentCategoryLabel.value
                val exts = viewModel.currentCategoryExts.value
                if (label != null && exts != null) runCategoryScan(label, exts) else loadDirectory(viewModel.lastNormalDir.value)
            }
            Mode.SEARCH -> viewModel.lastSearchQuery.value?.let { runSearch(it) } ?: loadDirectory(viewModel.lastNormalDir.value)
            Mode.TRASH -> loadTrash()
            Mode.APPS -> loadInstalledApps()
        }
    }

    // ---------- Permissions ----------

    // (checkPermissionsAndLoad moved to PermissionFlowHelper.kt - round 11; still called
    // as checkPermissionsAndLoad() from onCreate, same as before, since it's an extension
    // function on MainActivity in the same module/package - same pattern as onItemClick.)

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(viewModel.currentDir.value)
        } else if (requestCode == ARCHIVE_NOTIFICATION_PERMISSION_CODE) {
            pendingArchiveOperation?.invoke()
            pendingArchiveOperation = null
        }
    }

    // ---------- Recent folders ----------

    // (rememberRecentFolder, loadRecentFolders moved to WindowsAndHistoryHelper.kt - round 3.3
    // slimdown, see MainActivity-Slimdown-Plan.txt)

    // ---------- Clickable breadcrumb path ----------

    // internal (not private): widened for DirectoryStateObserver.kt (round 3.5 slimdown).
    internal fun renderBreadcrumbs(dir: File) {
        directoryBreadcrumbHelper.render(directoryBrowserHelper.breadcrumbParts(dir))
    }

    internal fun showSpecialPath(label: String) {
        directoryBreadcrumbHelper.showSpecialPath(label)
    }

    // ---------- Windows (open folder windows) ----------

    // (loadOpenWindows, saveOpenWindows, rememberOpenWindow, showWindowsDialog,
    // clearRecentHistory moved to WindowsAndHistoryHelper.kt - round 3.3 slimdown, see
    // MainActivity-Slimdown-Plan.txt)

    internal fun openAndroidDataFolder() = storageSetupHelper.openAndroidDataFolder()

    internal fun openAndroidDataFolderSaf() = storageSetupHelper.openAndroidDataFolderSaf()

    // ---------- Storage usage bar ----------

    // internal (not private): widened for DirectoryStateObserver.kt (round 3.5 slimdown).
    internal fun updateStorageBar() = storageSetupHelper.updateStorageBar()

    // ---------- Sorting ----------

    internal fun comparator(): Comparator<FileEntry> =
        directoryBrowserHelper.comparator(viewModel.sortKey.value, viewModel.sortAscending.value)

    // ---------- Directory browsing ----------

    // Round 17: the actual listing/filtering/sorting I/O moved into
    // MainViewModel.loadDirectory(), which runs it on Dispatchers.IO and
    // publishes the result via viewModel.directoryState. MainActivity no
    // longer touches the filesystem here - it only kicks off the load and
    // reacts to the resulting state in observeDirectoryState() (wired up
    // from onCreate).
    internal fun loadDirectory(dir: File) {
        viewModel.loadDirectory(dir)
    }

    // (observeDirectoryState moved to DirectoryStateObserver.kt - round 3.5 slimdown, see
    // MainActivity-Slimdown-Plan.txt; still called as observeDirectoryState() from onCreate)

    // (onItemClick, showArchiveOpenOptions, openArchiveInsideKorn, materializeAndOpen,
    // extractArchiveDialog, askArchivePasswordThenExtract, startArchiveExtraction
    // moved to FileClickHelper.kt - round 9 / STEP 17+)

    /**
     * A lightweight filesystem folder chooser. It works with the same File-based
     * storage model used by ArchiveManager, so the selected destination can be
     * passed directly to the existing extraction/copy/move code. Sorting reuses the
     * exact same [sortKey]/[sortAscending] state, [comparator], and SharedPreferences
     * (via [applySort]/[saveUserPreferences]) as the main file list, so choosing a
     * sort order here also updates the main screen's sort order and vice versa.
     */
    internal fun chooseDestinationFolder(onSelected: (File) -> Unit) {
        val startDir = viewModel.currentDir.value.takeIf { it.isDirectory } ?: Environment.getExternalStorageDirectory()
        destinationFolderPickerHelper.show(startDir, onSelected)
    }

    /**
     * Local Search Index — เริ่มจากรอบ 2 (search-index-project-plan.txt ข้อ 6.2) hook ไว้ที่
     * จุดรวมเหตุการณ์เดียวใน observeDirectoryState() (FileOpDone/ArchiveOpDone) ก่อน
     *
     * รอบ 3: ขยาย visibility จาก private → internal เพราะพบว่า rename/hide/ลากวาง/ถังขยะ/
     * batch rename ทำงานตรงๆ ผ่าน renameToCompat()/TrashManager แล้วรีเฟรชหน้าจอเองโดยไม่
     * ผ่าน viewModel.events เลย (ไม่ได้ผ่าน FileOpDone/ArchiveOpDone) จึงไม่เคย trigger
     * ฟังก์ชันนี้มาก่อน — ตอนนี้ extension function ไฟล์อื่น (FileItemActionsHelper.kt,
     * DragDropHelper.kt, SelectionModeController.kt, BatchRenameHelper.kt,
     * TrashUiController.kt) เรียกตรงๆ ที่จุด "สำเร็จ" ของแต่ละ action เพิ่มเข้ามาด้วย
     * เรียก rebuild index ใหม่ทั้งก้อนแบบ fire-and-forget เสมอ ไม่บล็อก UI
     */
    internal fun refreshSearchIndexAfterFileChange() {
        lifecycleScope.launch {
            searchIndexManager.rebuildFullIndex(Environment.getExternalStorageDirectory(), showHidden = true)
        }
    }

    companion object {
        internal const val REQUEST_TEXT_EDIT = 4101
        internal const val REQUEST_SAF_ANDROID_DATA = 4102
    }

    // Body moved to ActivityResultHelper.kt (round 3.4 slimdown, see
    // MainActivity-Slimdown-Plan.txt); the override itself must stay here (Android requires
    // it directly on the Activity), same pattern as checkPermissionsAndLoad() called from
    // onCreate().
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        handleActivityResult(requestCode, resultCode, data)
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return
        }
        if (viewModel.mode.value != Mode.NORMAL) {
            loadDirectory(viewModel.lastNormalDir.value)
            return
        }
        val parent = directoryNavigationHelper.parentForBackNavigation(viewModel.currentDir.value)
        if (parent != null) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Drag & drop ----------

    // (Drag & drop functions moved to DragDropHelper.kt - round 4)

    // ---------- Batch rename ----------

    // (Batch rename functions moved to BatchRenameHelper.kt - round 3)

    // ---------- Long-press context menu ----------

    // (onItemLongClick moved to FileClickHelper.kt - round 9 / STEP 17+)

    // ---------- Hide / unhide ----------

    // (hideFile moved to FileItemActionsHelper.kt - round 10)

    // ---------- Multi-format archive ----------

    // (Compress/zip functions moved to ArchiveDialogs.kt - round 2)

    // (addBookmark() moved to BookmarksBar.kt - round 7)

    // (renameDialog moved to FileItemActionsHelper.kt - round 10)

    // (Recycle bin functions moved to TrashUiController.kt - round 1)

    // (shareFile moved to FileItemActionsHelper.kt in round 10; confirmed unused
    // and deleted in round 11)

    internal fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // (setupToolbarHomeButton moved to FileItemActionsHelper.kt - round 10)

    // (setupToolbarSearchButton moved to SearchHelper.kt - round 6)

    // ---------- Drag & drop ----------

    // (Clipboard paste + create-file/folder functions moved to ClipboardHelper.kt - STEP 15)

    // (Favorites/bookmarks bar & management moved to BookmarksBar.kt - round 7)
}
