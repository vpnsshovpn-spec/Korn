package com.example.filemanager

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var pathText: TextView
    private lateinit var bookmarksBar: android.widget.LinearLayout
    private lateinit var adapter: FileAdapter
    private lateinit var bookmarksManager: BookmarksManager

    private var currentDir: File = Environment.getExternalStorageDirectory()
    private var clipboardFile: File? = null
    private var clipboardIsCut = false

    private val STORAGE_PERMISSION_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.title = getString(R.string.app_name)

        pathText = findViewById(R.id.pathText)
        recyclerView = findViewById(R.id.fileList)
        bookmarksBar = findViewById(R.id.bookmarksBar)
        bookmarksManager = BookmarksManager(this)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter(emptyList(), ::onItemClick, ::onItemLongClick)
        recyclerView.adapter = adapter

        checkPermissionsAndLoad()
    }

    override fun onResume() {
        super.onResume()
        refreshBookmarksBar()
    }

    // ---------- Permissions ----------

    private fun checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
            } else {
                loadDirectory(currentDir)
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ), STORAGE_PERMISSION_CODE
                )
            } else {
                loadDirectory(currentDir)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(currentDir)
        }
    }

    // ---------- Directory browsing ----------

    private fun loadDirectory(dir: File) {
        if (!dir.exists() || !dir.canRead()) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = dir
        pathText.text = dir.absolutePath

        val children = dir.listFiles()?.toList() ?: emptyList()
        val entries = children
            .map { FileEntry(it) }
            .sortedWith(compareBy({ !it.isDirectory }, { it.file.name.lowercase() }))
        adapter.updateItems(entries)
        supportActionBar?.subtitle = "${entries.size} รายการ"
    }

    private fun onItemClick(entry: FileEntry) {
        if (entry.isDirectory) {
            loadDirectory(entry.file)
        } else {
            openFile(entry.file)
        }
    }

    private fun openFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        val parent = currentDir.parentFile
        if (parent != null && currentDir != Environment.getExternalStorageDirectory()) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Long-press context menu ----------

    private fun onItemLongClick(entry: FileEntry): Boolean {
        val options = mutableListOf("เปลี่ยนชื่อ", "คัดลอก", "ย้าย", "ลบ", "แชร์")
        if (entry.isDirectory) options.add(0, "เพิ่มเป็นบุ๊คมาร์ก")

        AlertDialog.Builder(this)
            .setTitle(entry.file.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "เพิ่มเป็นบุ๊คมาร์ก" -> addBookmark(entry.file)
                    "เปลี่ยนชื่อ" -> renameDialog(entry.file)
                    "คัดลอก" -> { clipboardFile = entry.file; clipboardIsCut = false
                        Toast.makeText(this, "คัดลอกแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show() }
                    "ย้าย" -> { clipboardFile = entry.file; clipboardIsCut = true
                        Toast.makeText(this, "เลือกย้ายแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show() }
                    "ลบ" -> deleteConfirm(entry.file)
                    "แชร์" -> shareFile(entry.file)
                }
            }
            .show()
        return true
    }

    private fun addBookmark(dir: File) {
        val input = EditText(this)
        input.setText(dir.name)
        AlertDialog.Builder(this)
            .setTitle("เพิ่มบุ๊คมาร์ก")
            .setView(input)
            .setPositiveButton("บันทึก") { _, _ ->
                val name = input.text.toString().ifBlank { dir.name }
                bookmarksManager.add(name, dir.absolutePath)
                refreshBookmarksBar()
                Toast.makeText(this, "เพิ่มบุ๊คมาร์กแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameDialog(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val newFile = File(file.parentFile, newName)
                    if (file.renameTo(newFile)) {
                        loadDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun deleteConfirm(file: File) {
        AlertDialog.Builder(this)
            .setTitle("ลบ ${file.name}?")
            .setMessage("ไม่สามารถกู้คืนได้")
            .setPositiveButton("ลบ") { _, _ ->
                val ok = if (file.isDirectory) file.deleteRecursively() else file.delete()
                if (ok) loadDirectory(currentDir)
                else Toast.makeText(this, "ลบไม่สำเร็จ", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Tap empty toolbar area long-press to paste (simple approach: use options menu instead)
    override fun onCreateOptionsMenu(menu: android.view.Menu): Boolean {
        menu.add(0, 1, 0, "วางที่นี่")
        menu.add(0, 2, 1, "จัดการบุ๊คมาร์ก")
        menu.add(0, 3, 2, "สร้างโฟลเดอร์ใหม่")
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        when (item.itemId) {
            1 -> pasteClipboard()
            2 -> manageBookmarksDialog()
            3 -> newFolderDialog()
        }
        return true
    }

    private fun pasteClipboard() {
        val src = clipboardFile ?: run {
            Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
            return
        }
        val dest = File(currentDir, src.name)
        try {
            if (clipboardIsCut) {
                if (!src.renameTo(dest)) {
                    src.copyRecursively(dest, overwrite = true)
                    src.deleteRecursively()
                }
            } else {
                src.copyRecursively(dest, overwrite = true)
            }
            clipboardFile = null
            loadDirectory(currentDir)
            Toast.makeText(this, "เสร็จสิ้น", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ทำรายการไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun newFolderDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    File(currentDir, name).mkdirs()
                    loadDirectory(currentDir)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Bookmarks bar & management ----------

    private fun refreshBookmarksBar() {
        bookmarksBar.removeAllViews()
        val bookmarks = bookmarksManager.getAll()
        for (bm in bookmarks) {
            val chip = TextView(this).apply {
                text = "⭐ ${bm.name}"
                setPadding(24, 12, 24, 12)
                setBackgroundColor(0xFFE3F2FD.toInt())
                setTextColor(0xFF1565C0.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 12
                layoutParams = lp
                setOnClickListener {
                    val target = File(bm.path)
                    if (target.exists()) loadDirectory(target)
                    else Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("ลบบุ๊คมาร์ก \"${bm.name}\"?")
                        .setPositiveButton("ลบ") { _, _ ->
                            bookmarksManager.remove(bm.path)
                            refreshBookmarksBar()
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                    true
                }
            }
            bookmarksBar.addView(chip)
        }
    }

    private fun manageBookmarksDialog() {
        val bookmarks = bookmarksManager.getAll()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีบุ๊คมาร์ก กดค้างที่โฟลเดอร์เพื่อเพิ่ม", Toast.LENGTH_LONG).show()
            return
        }
        val names = bookmarks.map { "${it.name}  (${it.path})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("บุ๊คมาร์กทั้งหมด (แตะเพื่อไป, กดค้างเพื่อลบใน bar ด้านบน)")
            .setItems(names) { _, which ->
                val target = File(bookmarks[which].path)
                if (target.exists()) loadDirectory(target)
            }
            .setNegativeButton("ปิด", null)
            .show()
    }
}
