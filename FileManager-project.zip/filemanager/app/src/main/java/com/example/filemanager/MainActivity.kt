package com.example.filemanager

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Typeface
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    private enum class Mode { NORMAL, CATEGORY, SEARCH, TRASH }
    private enum class SortKey { NAME, SIZE, DATE }

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var breadcrumbBar: LinearLayout
    private lateinit var breadcrumbScroll: android.widget.HorizontalScrollView
    private lateinit var storagePercent: TextView
    private lateinit var bookmarksBar: android.widget.LinearLayout
    private lateinit var categoryBar: android.widget.LinearLayout
    private lateinit var storageBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var adapter: FileAdapter
    private lateinit var bookmarksManager: BookmarksManager
    private lateinit var trashManager: TrashManager
    private lateinit var selectionActionBar: LinearLayout
    private lateinit var clipboardActionBar: LinearLayout
    private lateinit var selectionMoreButton: TextView
    private lateinit var clipboardPasteButton: TextView

    private var currentDir: File = Environment.getExternalStorageDirectory()
    private var lastNormalDir: File = Environment.getExternalStorageDirectory()
    private var clipboardFiles: List<File> = emptyList()
    private var clipboardIsCut = false

    private var mode = Mode.NORMAL
    private var showHidden = false
    private var currentCategoryLabel: String? = null
    private var currentCategoryExts: Set<String>? = null
    private var lastSearchQuery: String? = null

    private var sortKey = SortKey.NAME
    private var sortAscending = true
    private var isGridMode = false

    private val STORAGE_PERMISSION_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        setSupportActionBar(findViewById(R.id.toolbar))
        setupNavigationDrawer()
        supportActionBar?.title = getString(R.string.app_name)

        breadcrumbBar = findViewById(R.id.breadcrumbBar)
        breadcrumbScroll = findViewById(R.id.breadcrumbScroll)
        storagePercent = findViewById(R.id.storagePercent)
        storagePercent.setOnClickListener { startActivity(Intent(this, StorageAnalyzerActivity::class.java)) }
        recyclerView = findViewById(R.id.fileList)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        bookmarksBar = findViewById(R.id.bookmarksBar)
        categoryBar = findViewById(R.id.categoryBar)
        storageBar = findViewById(R.id.storageBar)
        storageText = findViewById(R.id.storageText)

        selectionActionBar = findViewById(R.id.selectionActionBar)
        clipboardActionBar = findViewById(R.id.clipboardActionBar)
        selectionMoreButton = findViewById(R.id.selectionMoreButton)
        clipboardPasteButton = findViewById(R.id.clipboardPasteButton)
        findViewById<TextView>(R.id.selectionCopyButton).setOnClickListener { copySelected() }
        findViewById<TextView>(R.id.selectionCutButton).setOnClickListener { moveSelected() }
        findViewById<TextView>(R.id.selectionDeleteButton).setOnClickListener { deleteSelectedToTrash() }
        findViewById<TextView>(R.id.selectionCancelButton).setOnClickListener { exitSelectionMode() }
        selectionMoreButton.setOnClickListener { showSelectionMoreMenu() }
        clipboardPasteButton.setOnClickListener { pasteClipboard() }
        findViewById<TextView>(R.id.clipboardNewButton).setOnClickListener { newFolderDialog() }
        findViewById<TextView>(R.id.clipboardCancelButton).setOnClickListener {
            clipboardFiles = emptyList()
            clipboardIsCut = false
            updateActionBars()
            invalidateOptionsMenu()
        }

        bookmarksManager = BookmarksManager(this)
        trashManager = TrashManager(this)
        intent.getStringExtra("start_path")?.let { File(it).takeIf { f -> f.isDirectory }?.let { f ->
            currentDir = f
            lastNormalDir = f
        }}

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter(emptyList(), ::onItemClick, ::onItemLongClick, ::onStartFileDrag, ::onDropOnFolder)
        adapter.onSelectionChanged = {
            updateSelectionSubtitle()
            updateActionBars()
        }
        recyclerView.adapter = adapter
        updateActionBars()

        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { refreshCurrentView() }

        setupCategoryBar()
        MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager)
        checkPermissionsAndLoad()
    }

    override fun onResume() {
        super.onResume()
        ensureDevelopmentBookmarksSafe()
        refreshBookmarksBar()
        updateStorageBar()
    }

    private fun ensureDevelopmentBookmarksSafe() {
        try { MinecraftAddonTools.ensureDevelopmentBookmarks(this, bookmarksManager) } catch (_: Exception) {}
    }

    private fun setupNavigationDrawer() {
        // Keep the original simple 3-line hamburger icon.
        // Clicking it opens/closes the drawer; edge-swipe remains enabled by DrawerLayout.
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_hamburger)
        toolbar.setNavigationOnClickListener {
            if (drawerLayout.isDrawerOpen(Gravity.START)) {
                drawerLayout.closeDrawer(Gravity.START)
            } else {
                drawerLayout.openDrawer(Gravity.START)
            }
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadDirectory(Environment.getExternalStorageDirectory())
                R.id.nav_downloads -> {
                    val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (d.isDirectory) loadDirectory(d)
                }
                R.id.nav_pictures -> {
                    val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    if (d.isDirectory) loadDirectory(d)
                }
                R.id.nav_minecraft -> {
                    val d = File(Environment.getExternalStorageDirectory(), "KORN/MinecraftAddons")
                    d.mkdirs()
                    loadDirectory(d)
                }
                R.id.nav_recent -> loadRecentFolders()
                R.id.nav_bookmarks -> manageBookmarksDialog()
                R.id.nav_search -> searchDialog()
                R.id.nav_trash -> loadTrash()
                R.id.nav_analyzer -> startActivity(Intent(this, StorageAnalyzerActivity::class.java))
                R.id.nav_theme_dark -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                R.id.nav_theme_light -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                R.id.nav_theme_system -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            drawerLayout.closeDrawers()
            true
        }
    }


    // ---------- Storage usage bar ----------

    private fun updateStorageBar() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = total - free
            val pct = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0
            storageBar.max = 100
            storageBar.progress = pct.coerceIn(0, 100)
            storagePercent.text = "$pct%"
            storageText.text = "ใช้ไป ${readableSize(used)} จาก ${readableSize(total)} (เหลือ ${readableSize(free)})"
        } catch (e: Exception) {
            storageText.text = ""
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }

    // ---------- Sorting ----------

    private fun comparator(): Comparator<FileEntry> {
        val byField: Comparator<FileEntry> = when (sortKey) {
            SortKey.NAME -> compareBy { it.file.name.lowercase() }
            SortKey.SIZE -> compareBy { if (it.isDirectory) 0L else it.file.length() }
            SortKey.DATE -> compareBy { it.file.lastModified() }
        }
        val directional = if (sortAscending) byField else byField.reversed()
        // Folders always sort before files, regardless of the chosen field.
        return compareBy<FileEntry> { !it.isDirectory }.then(directional)
    }

    private fun applySort(key: SortKey, ascending: Boolean) {
        sortKey = key
        sortAscending = ascending
        refreshCurrentView()
    }

    // ---------- Grid / list toggle ----------

    private fun toggleGridMode() {
        isGridMode = !isGridMode
        recyclerView.layoutManager = if (isGridMode) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        adapter.setGridMode(isGridMode)
        invalidateOptionsMenu()
    }

    // ---------- Multi-select ----------

    private fun updateSelectionSubtitle() {
        supportActionBar?.subtitle = "เลือก ${adapter.selectionCount()} รายการ"
    }

    private fun enterSelectionMode() {
        adapter.setSelectionMode(true)
        swipeRefresh.isEnabled = false
        invalidateOptionsMenu()
        updateSelectionSubtitle()
        updateActionBars()
    }

    private fun exitSelectionMode() {
        adapter.setSelectionMode(false)
        swipeRefresh.isEnabled = true
        invalidateOptionsMenu()
        updateActionBars()
        refreshCurrentView()
    }

    private fun updateActionBars() {
        if (!::selectionActionBar.isInitialized) return
        selectionActionBar.visibility = if (adapter.selectionMode) View.VISIBLE else View.GONE
        clipboardActionBar.visibility =
            if (!adapter.selectionMode && clipboardFiles.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showSelectionMoreMenu() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }

        val popup = PopupMenu(this, selectionMoreButton)
        popup.menu.add("เลือกทั้งหมด").setOnMenuItemClickListener {
            adapter.selectAll()
            true
        }
        popup.menu.add("แชร์ที่เลือก").setOnMenuItemClickListener {
            shareSelected()
            true
        }

        if (files.size == 1) {
            val file = files[0]
            popup.menu.add("เปลี่ยนชื่อ").setOnMenuItemClickListener {
                renameDialog(file)
                true
            }
            if (file.isDirectory) {
                popup.menu.add("เพิ่มเป็นบุ๊คมาร์ก").setOnMenuItemClickListener {
                    addBookmark(file)
                    true
                }
            }
            popup.menu.add(if (file.name.startsWith(".")) "เลิกซ่อน" else "ซ่อน")
                .setOnMenuItemClickListener {
                    hideFile(file, !file.name.startsWith("."))
                    true
                }
            popup.menu.add(if (file.isDirectory) "บีบอัดโฟลเดอร์เป็น ZIP" else "บีบอัดเป็น ZIP")
                .setOnMenuItemClickListener {
                    zipEntry(file)
                    true
                }
            if (!file.isDirectory && MinecraftAddonTools.isArchiveExtension(file.extension)) {
                popup.menu.add("แตกไฟล์ ZIP ที่นี่").setOnMenuItemClickListener {
                    unzipEntry(file)
                    true
                }
            }
        } else {
            popup.menu.add("เปลี่ยนชื่อหลายไฟล์").setOnMenuItemClickListener {
                batchRenameDialog()
                true
            }
        }
        popup.show()
    }

    private fun copySelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = false
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "คัดลอก ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun moveSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        clipboardFiles = files
        clipboardIsCut = true
        exitSelectionMode()
        updateActionBars()
        Toast.makeText(this, "เลือกย้าย ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
    }

    private fun deleteSelectedToTrash() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        AlertDialog.Builder(this)
            .setTitle("ย้าย ${files.size} รายการไปถังขยะ?")
            .setPositiveButton("ย้ายไปถังขยะ") { _, _ ->
                files.forEach { trashManager.moveToTrash(it) }
                exitSelectionMode()
                Toast.makeText(this, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun shareSelected() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) { toastNoSelection(); return }
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toastNoSelection() {
        Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
    }

    // ---------- Category shortcuts (images / video / music / docs / apps / archives) ----------

    private fun setupCategoryBar() {
        val categories: List<Pair<String, Set<String>?>> = listOf(
            "ทั้งหมด" to null,
            "รูปภาพ" to FileCategories.IMAGES,
            "วิดีโอ" to FileCategories.VIDEOS,
            "เพลง" to FileCategories.MUSIC,
            "เอกสาร" to FileCategories.DOCS,
            "แอป" to FileCategories.APPS,
            "ไฟล์บีบอัด" to FileCategories.ARCHIVES
        )
        for ((label, exts) in categories) {
            val chip = TextView(this).apply {
                text = label
                setPadding(28, 14, 28, 14)
                setBackgroundColor(0xFF1565C0.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 10
                layoutParams = lp
                setOnClickListener {
                    if (exts == null) {
                        mode = Mode.NORMAL
                        loadDirectory(lastNormalDir)
                    } else {
                        runCategoryScan(label, exts)
                    }
                }
            }
            categoryBar.addView(chip)
        }
    }

    private fun runCategoryScan(label: String, exts: Set<String>) {
        mode = Mode.CATEGORY
        currentCategoryLabel = label
        currentCategoryExts = exts
        showSpecialPath("หมวดหมู่: $label")
        supportActionBar?.subtitle = "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        Thread {
            val results = FileScanner.scanByExtensions(root, exts, hidden)
            runOnUiThread {
                swipeRefresh.isRefreshing = false
                if (mode != Mode.CATEGORY || currentCategoryLabel != label) return@runOnUiThread
                val entries = results.map { FileEntry(it) }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            }
        }.start()
    }

    // ---------- Search ----------

    private fun searchDialog() {
        val input = EditText(this)
        input.hint = "ชื่อไฟล์หรือโฟลเดอร์"
        AlertDialog.Builder(this)
            .setTitle("ค้นหาไฟล์")
            .setView(input)
            .setPositiveButton("ค้นหา") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) runSearch(q)
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun runSearch(query: String) {
        mode = Mode.SEARCH
        lastSearchQuery = query
        showSpecialPath("ผลค้นหา: \"$query\"")
        supportActionBar?.subtitle = "กำลังค้นหา..."
        val root = Environment.getExternalStorageDirectory()
        val hidden = showHidden
        Thread {
            val results = FileScanner.searchByName(root, query, hidden)
            runOnUiThread {
                swipeRefresh.isRefreshing = false
                if (mode != Mode.SEARCH || lastSearchQuery != query) return@runOnUiThread
                val entries = results.map { FileEntry(it) }.sortedWith(comparator())
                adapter.updateItems(entries, showFullPath = true)
                supportActionBar?.subtitle = "${entries.size} รายการ"
            }
        }.start()
    }

    private fun refreshCurrentView() {
        when (mode) {
            Mode.NORMAL -> loadDirectory(currentDir)
            Mode.CATEGORY -> {
                val label = currentCategoryLabel
                val exts = currentCategoryExts
                if (label != null && exts != null) runCategoryScan(label, exts) else loadDirectory(lastNormalDir)
            }
            Mode.SEARCH -> lastSearchQuery?.let { runSearch(it) } ?: loadDirectory(lastNormalDir)
            Mode.TRASH -> loadTrash()
        }
    }

    // ---------- Permissions ----------

    private fun checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
            } else {
                loadDirectory(currentDir)
            }
        } else {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ), STORAGE_PERMISSION_CODE
                )
            } else {
                loadDirectory(currentDir)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            loadDirectory(currentDir)
        }
    }

    // ---------- Recent folders ----------

    private fun rememberRecentFolder(dir: File) {
        if (mode != Mode.TRASH && dir.isDirectory) {
            val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
            val old = prefs.getString("paths", "")!!.split("\\n").filter { it.isNotBlank() }
            val updated = (listOf(dir.absolutePath) + old.filter { it != dir.absolutePath }).take(15)
            prefs.edit().putString("paths", updated.joinToString("\\n")).apply()
        }
    }

    private fun loadRecentFolders() {
        mode = Mode.SEARCH
        val prefs = getSharedPreferences("recent_folders", MODE_PRIVATE)
        val paths = prefs.getString("paths", "")!!.split("\\n")
            .filter { it.isNotBlank() }
            .mapNotNull { File(it).takeIf { f -> f.isDirectory && f.canRead() } }

        if (paths.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีโฟลเดอร์ล่าสุด", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = paths.first()
        showSpecialPath("โฟลเดอร์ล่าสุด")
        adapter.updateItems(paths.map { FileEntry(it) }, showFullPath = true)
        supportActionBar?.subtitle = "${paths.size} โฟลเดอร์"
    }

    // ---------- Clickable breadcrumb path ----------

    private fun renderBreadcrumbs(dir: File) {
        breadcrumbBar.removeAllViews()

        val root = Environment.getExternalStorageDirectory().canonicalFile
        val target = try { dir.canonicalFile } catch (_: Exception) { dir.absoluteFile }
        val parts = mutableListOf<Pair<String, File>>()

        if (target == root || target.path.startsWith(root.path + File.separator)) {
            parts += "0" to root
            var cursor = root
            val relative = target.path.removePrefix(root.path)
                .trimStart(File.separatorChar)
            if (relative.isNotEmpty()) {
                for (name in relative.split(File.separatorChar).filter { it.isNotEmpty() }) {
                    cursor = File(cursor, name)
                    parts += name to cursor
                }
            }
        } else {
            parts += target.name.ifEmpty { target.path } to target
        }

        parts.forEachIndexed { index, (label, folder) ->
            if (index > 0) {
                breadcrumbBar.addView(TextView(this).apply {
                    text = ">"
                    textSize = 14f
                    setTextColor(getColor(R.color.text_secondary))
                    setPadding(4, 0, 4, 0)
                    gravity = Gravity.CENTER_VERTICAL
                })
            }

            val chip = TextView(this).apply {
                text = label
                textSize = 14f
                typeface = if (index == parts.lastIndex) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(getColor(R.color.text_primary))
                setPadding(12, 8, 12, 8)
                isSingleLine = true
                setOnClickListener { loadDirectory(folder) }
                contentDescription = "ไปที่โฟลเดอร์ $label"
                isClickable = true
                isFocusable = true
            }
            breadcrumbBar.addView(chip)
        }

        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    private fun showSpecialPath(label: String) {
        breadcrumbBar.removeAllViews()
        breadcrumbBar.addView(TextView(this).apply {
            text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(getColor(R.color.text_primary))
            setPadding(12, 8, 12, 8)
        })
        breadcrumbScroll.post { breadcrumbScroll.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    // ---------- Directory browsing ----------

    private fun loadDirectory(dir: File) {
        if (!dir.exists() || !dir.canRead()) {
            Toast.makeText(this, "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้", Toast.LENGTH_SHORT).show()
            swipeRefresh.isRefreshing = false
            return
        }
        mode = Mode.NORMAL
        currentDir = dir
        lastNormalDir = dir
        rememberRecentFolder(dir)
        renderBreadcrumbs(dir)

        val isRoot = dir == Environment.getExternalStorageDirectory()
        val children = dir.listFiles()?.toList() ?: emptyList()
        val entries = children
            .filter { showHidden || !it.name.startsWith(".") }
            .filter { !(isRoot && it.name == TrashManager.TRASH_FOLDER_NAME) }
            .map { FileEntry(it) }
            .sortedWith(comparator())
        adapter.updateItems(entries, showFullPath = false)
        supportActionBar?.subtitle = "${entries.size} รายการ"
        updateStorageBar()
        swipeRefresh.isRefreshing = false
    }

    private fun onItemClick(entry: FileEntry) {
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return
        }
        if (entry.isDirectory) {
            // Tapping a folder always drops back into normal browsing, even from a
            // flat category/search result list.
            loadDirectory(entry.file)
        } else if (MinecraftAddonTools.isArchiveExtension(entry.file.extension)) {
            showArchiveOpenOptions(entry.file)
        } else if (FileCategories.IMAGES.contains(entry.file.extension.lowercase())) {
            val i = Intent(this, ImageViewerActivity::class.java)
            i.putExtra(ImageViewerActivity.EXTRA_IMAGE_PATH, entry.file.absolutePath)
            startActivity(i)
        } else {
            openFile(entry.file)
        }
    }

    /**
     * Archives stay browsable inside KORN, but the user can always hand them to another
     * application through the Android chooser. Minecraft pack extensions also get a
     * dedicated Minecraft action when the OS has an app registered for them.
     */
    private fun showArchiveOpenOptions(file: File) {
        val items = mutableListOf("เปิดภายใน KORN")
        val isMinecraftPack = file.extension.lowercase() in setOf("mcpack", "mcaddon", "mcworld")
        if (isMinecraftPack) items.add("เปิด/ส่งให้ Minecraft")
        items.add("เปิดด้วยแอปอื่น…")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(items.toTypedArray()) { _, which ->
                when (items[which]) {
                    "เปิดภายใน KORN" -> {
                        val i = Intent(this, ZipBrowserActivity::class.java)
                        i.putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, file.absolutePath)
                        startActivity(i)
                    }
                    "เปิด/ส่งให้ Minecraft" -> openFile(file)
                    "เปิดด้วยแอปอื่น…" -> openFile(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return
        }
        if (mode != Mode.NORMAL) {
            loadDirectory(lastNormalDir)
            return
        }
        val parent = currentDir.parentFile
        if (parent != null && currentDir != Environment.getExternalStorageDirectory()) {
            loadDirectory(parent)
        } else {
            super.onBackPressed()
        }
    }

    // ---------- Drag & drop ----------

    private fun onStartFileDrag(entry: FileEntry, sourceView: View): Boolean {
        val paths = if (adapter.selectionMode && adapter.getSelectedFiles().any {
                it.absolutePath == entry.file.absolutePath
            }) {
            adapter.getSelectedFiles().map { it.absolutePath }
        } else {
            listOf(entry.file.absolutePath)
        }
        val clip = android.content.ClipData.newPlainText(
            "KORN_FILES",
            paths.joinToString("\n")
        )
        val shadow = View.DragShadowBuilder(sourceView)
        val started = sourceView.startDragAndDrop(clip, shadow, null, 0)
        if (started) {
            Toast.makeText(this, "ลากไปวางบนโฟลเดอร์เพื่อย้าย", Toast.LENGTH_SHORT).show()
        }
        return started
    }

    private fun onDropOnFolder(folder: File, paths: List<String>): Boolean {
        if (!folder.isDirectory || paths.isEmpty()) return false
        val sources = paths.map { File(it) }.filter { it.exists() }
        if (sources.isEmpty()) return false

        Thread {
            var moved = 0
            var skipped = 0
            for (src in sources.distinctBy { it.absolutePath }) {
                try {
                    if (src.absoluteFile == folder.absoluteFile) {
                        skipped++
                        continue
                    }
                    if (src.isDirectory) {
                        val srcPath = src.canonicalFile.toPath()
                        val destPath = folder.canonicalFile.toPath()
                        if (destPath.startsWith(srcPath)) {
                            skipped++
                            continue
                        }
                    }
                    var dest = File(folder, src.name)
                    if (dest.canonicalFile == src.canonicalFile) {
                        skipped++
                        continue
                    }
                    if (dest.exists()) dest = File(folder, uniqueName(folder, src.name, src.isDirectory))
                    val ok = src.renameTo(dest)
                    if (ok) moved++ else skipped++
                } catch (_: Exception) {
                    skipped++
                }
            }
            runOnUiThread {
                exitSelectionModeIfNeededAfterDrag()
                loadDirectory(currentDir)
                val msg = if (skipped == 0) "ย้าย $moved รายการไปที่ ${folder.name} แล้ว"
                else "ย้ายสำเร็จ $moved รายการ (ข้าม $skipped รายการ)"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
        return true
    }

    private fun exitSelectionModeIfNeededAfterDrag() {
        if (adapter.selectionMode) {
            adapter.setSelectionMode(false)
            swipeRefresh.isEnabled = true
            invalidateOptionsMenu()
            updateActionBars()
        }
    }

    // ---------- Batch rename ----------

    private fun batchRenameDialog() {
        val files = adapter.getSelectedFiles()
        if (files.isEmpty()) {
            toastNoSelection()
            return
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
        }
        val patternInput = EditText(this).apply {
            hint = "ชื่อ_{n}"
            setText("ชื่อ_{n}")
            selectAll()
        }
        val startInput = EditText(this).apply {
            hint = "เลขเริ่มต้น"
            setText("1")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(patternInput)
        box.addView(startInput)

        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อหลายไฟล์ (${files.size} รายการ)")
            .setMessage("ใช้ {n} เป็นหมายเลขรันต่อ เช่น Addon_{n}")
            .setView(box)
            .setPositiveButton("เปลี่ยนชื่อ") { _, _ ->
                val pattern = patternInput.text.toString().trim()
                val start = startInput.text.toString().toIntOrNull() ?: 1
                if (pattern.isEmpty()) {
                    Toast.makeText(this, "กรุณาใส่รูปแบบชื่อ", Toast.LENGTH_SHORT).show()
                } else {
                    batchRename(files, pattern, start)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun batchRename(files: List<File>, pattern: String, start: Int) {
        Thread {
            var renamed = 0
            var skipped = 0
            val reserved = mutableSetOf<String>()
            files.forEachIndexed { index, file ->
                try {
                    var stem = pattern.replace("{n}", (start + index).toString())
                    if (!pattern.contains("{n}")) stem += "_${start + index}"
                    val dot = file.name.lastIndexOf('.')
                    val hasExtensionInPattern = stem.lastIndexOf('.') > 0
                    val newName = if (!file.isDirectory && !hasExtensionInPattern && dot > 0) {
                        stem + file.name.substring(dot)
                    } else stem
                    if (newName.isBlank() || newName == file.name ||
                        newName.contains("/") || newName.contains("\\") ||
                        newName in reserved
                    ) {
                        skipped++
                        return@forEachIndexed
                    }
                    val dest = File(file.parentFile, newName)
                    if (dest.exists() && dest.absolutePath != file.absolutePath) {
                        skipped++
                        return@forEachIndexed
                    }
                    if (file.renameTo(dest)) {
                        reserved.add(newName)
                        renamed++
                    } else skipped++
                } catch (_: Exception) {
                    skipped++
                }
            }
            runOnUiThread {
                exitSelectionMode()
                Toast.makeText(
                    this,
                    "เปลี่ยนชื่อสำเร็จ $renamed รายการ" +
                        if (skipped > 0) " (ข้าม $skipped รายการ)" else "",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    // ---------- Long-press context menu ----------

    private fun onItemLongClick(entry: FileEntry): Boolean {
        if (mode == Mode.TRASH) {
            onTrashItemAction(entry)
            return true
        }

        if (!adapter.selectionMode) {
            // Do not rebind the RecyclerView while the long-press finger is still
            // down; the adapter keeps the current touch listener alive so the
            // same gesture can immediately transition into drag.
            adapter.setSelectionMode(true, notify = false)
            swipeRefresh.isEnabled = false
            invalidateOptionsMenu()
            updateSelectionSubtitle()
            updateActionBars()
        }
        if (entry.file.absolutePath !in adapter.getSelectedFiles().map { it.absolutePath }) {
            adapter.selectPath(entry.file.absolutePath, notify = false)
        }
        return true
    }

    // ---------- Hide / unhide ----------

    private fun hideFile(file: File, hide: Boolean) {
        val newName = if (hide) {
            if (file.name.startsWith(".")) file.name else ".${file.name}"
        } else {
            file.name.trimStart('.').ifEmpty { file.name }
        }
        if (newName == file.name) {
            refreshCurrentView()
            return
        }
        val dest = File(file.parentFile, newName)
        if (file.renameTo(dest)) {
            Toast.makeText(this, if (hide) "ซ่อนไฟล์แล้ว" else "เลิกซ่อนไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            refreshCurrentView()
        } else {
            Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Zip / Unzip ----------

    private fun zipEntry(source: File) {
        val parent = source.parentFile ?: currentDir
        Toast.makeText(this, "กำลังบีบอัด...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val baseName = if (source.isDirectory) source.name else source.nameWithoutExtension.ifEmpty { source.name }
                val destName = uniqueName(parent, "$baseName.zip")
                val destZip = File(parent, destName)
                FileScanner.zip(source, destZip)
                runOnUiThread {
                    Toast.makeText(this, "บีบอัดเสร็จสิ้น: $destName", Toast.LENGTH_SHORT).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "บีบอัดไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun unzipEntry(zipFileEntry: File) {
        val parent = zipFileEntry.parentFile ?: currentDir
        Toast.makeText(this, "กำลังแตกไฟล์...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val destName = uniqueName(parent, zipFileEntry.nameWithoutExtension, isDir = true)
                val destDir = File(parent, destName)
                destDir.mkdirs()
                FileScanner.unzip(zipFileEntry, destDir)
                runOnUiThread {
                    Toast.makeText(this, "แตกไฟล์เสร็จสิ้น: $destName", Toast.LENGTH_SHORT).show()
                    refreshCurrentView()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "แตกไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    /** Returns a filename that doesn't already exist in [dir], appending " (1)", " (2)", ... if needed. */
    private fun uniqueName(dir: File, desired: String, isDir: Boolean = false): String {
        if (!File(dir, desired).exists()) return desired
        val dotIndex = desired.lastIndexOf('.')
        val base = if (!isDir && dotIndex > 0) desired.substring(0, dotIndex) else desired
        val ext = if (!isDir && dotIndex > 0) desired.substring(dotIndex) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base ($i)$ext"
            i++
        } while (File(dir, candidate).exists())
        return candidate
    }

    private fun addBookmark(dir: File) {
        val input = EditText(this)
        input.setText(dir.name)
        AlertDialog.Builder(this)
            .setTitle("เพิ่มบุ๊คมาร์ก")
            .setView(input)
            .setPositiveButton("บันทึก") { _, _ ->
                val name = input.text.toString().ifBlank { dir.name }
                bookmarksManager.add(name, dir.absolutePath)
                refreshBookmarksBar()
                Toast.makeText(this, "เพิ่มบุ๊คมาร์กแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameDialog(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val newFile = File(file.parentFile, newName)
                    if (file.renameTo(newFile)) {
                        loadDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Recycle bin (soft delete) ----------

    private fun trashConfirm(file: File) {
        AlertDialog.Builder(this)
            .setTitle("ย้าย \"${file.name}\" ไปถังขยะ?")
            .setPositiveButton("ย้ายไปถังขยะ") { _, _ ->
                if (trashManager.moveToTrash(file)) {
                    Toast.makeText(this, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
                    refreshCurrentView()
                } else {
                    Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun loadTrash() {
        mode = Mode.TRASH
        adapter.setSelectionMode(false)
        showSpecialPath("ถังขยะ")
        val trashEntries = trashManager.listEntries()
        val fileEntries = trashEntries.map { e ->
            FileEntry(
                file = e.trashedFile,
                displayName = e.trashedFile.name.replaceFirst(Regex("^\\d+_"), ""),
                subtitleOverride = "จาก: ${e.originalPath}"
            )
        }
        adapter.updateItems(fileEntries, showFullPath = false)
        supportActionBar?.subtitle = "${fileEntries.size} รายการในถังขยะ"
        swipeRefresh.isRefreshing = false
    }

    private fun onTrashItemAction(entry: FileEntry) {
        val trashEntry = trashManager.listEntries()
            .find { it.trashedFile.absolutePath == entry.file.absolutePath } ?: return
        val title = entry.displayName ?: entry.file.name
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(arrayOf("กู้คืน", "ลบถาวร")) { _, which ->
                when (which) {
                    0 -> {
                        if (trashManager.restore(trashEntry)) {
                            Toast.makeText(this, "กู้คืนแล้ว", Toast.LENGTH_SHORT).show()
                            loadTrash()
                        } else {
                            Toast.makeText(this, "กู้คืนไม่สำเร็จ (อาจไม่พบโฟลเดอร์ต้นทางแล้ว)", Toast.LENGTH_SHORT).show()
                        }
                    }
                    1 -> {
                        AlertDialog.Builder(this)
                            .setTitle("ลบถาวร \"$title\"?")
                            .setMessage("ไม่สามารถกู้คืนได้อีก")
                            .setPositiveButton("ลบถาวร") { _, _ ->
                                trashManager.deleteForever(trashEntry)
                                loadTrash()
                            }
                            .setNegativeButton("ยกเลิก", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun emptyTrashConfirm() {
        AlertDialog.Builder(this)
            .setTitle("ล้างถังขยะทั้งหมด?")
            .setMessage("ไฟล์ทั้งหมดในถังขยะจะถูกลบถาวร ไม่สามารถกู้คืนได้")
            .setPositiveButton("ล้างถังขยะ") { _, _ ->
                trashManager.emptyTrash()
                loadTrash()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Toolbar menu (rebuilt on demand: normal / selection / trash) ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean = true

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.clear()
        when {
            adapter.selectionMode -> {
                menu.add(0, 20, 0, "เลือกทั้งหมด")
                menu.add(0, 21, 1, "คัดลอกที่เลือก")
                menu.add(0, 22, 2, "ย้ายที่เลือก")
                menu.add(0, 23, 3, "ลบที่เลือก (ถังขยะ)")
                menu.add(0, 24, 4, "แชร์ที่เลือก")
                menu.add(0, 25, 5, "ยกเลิกการเลือก")
                menu.add(0, 26, 6, "เปลี่ยนชื่อหลายไฟล์")
            }
            mode == Mode.TRASH -> {
                menu.add(0, 30, 0, "ล้างถังขยะ")
            }
            else -> {
                menu.add(0, 1, 0, "วางที่นี่")
                menu.add(0, 2, 1, "จัดการบุ๊คมาร์ก")
                menu.add(0, 3, 2, "สร้างโฟลเดอร์ใหม่")
                menu.add(0, 4, 3, "ค้นหา")
                val hiddenItem = menu.add(0, 5, 4, "แสดงไฟล์ที่ซ่อน")
                hiddenItem.isCheckable = true
                hiddenItem.isChecked = showHidden

                val sortMenu = menu.addSubMenu(0, 6, 5, "เรียงลำดับ")
                sortMenu.add(0, 60, 0, "ชื่อ (ก-ฮ)")
                sortMenu.add(0, 61, 1, "ชื่อ (ฮ-ก)")
                sortMenu.add(0, 62, 2, "ขนาด (มาก-น้อย)")
                sortMenu.add(0, 63, 3, "ขนาด (น้อย-มาก)")
                sortMenu.add(0, 64, 4, "วันที่แก้ไข (ใหม่-เก่า)")
                sortMenu.add(0, 65, 5, "วันที่แก้ไข (เก่า-ใหม่)")

                menu.add(0, 7, 6, "เลือกหลายไฟล์")
                menu.add(0, 9, 7, if (isGridMode) "มุมมองรายการ" else "มุมมองตาราง")
                menu.add(0, 8, 8, "ถังขยะ")
                menu.add(0, 10, 9, "🧩 Minecraft Add-on Tools")
                menu.add(0, 11, 10, "📊 วิเคราะห์พื้นที่จัดเก็บ")
            }
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> pasteClipboard()
            2 -> manageBookmarksDialog()
            3 -> newFolderDialog()
            4 -> searchDialog()
            5 -> { showHidden = !showHidden; refreshCurrentView() }
            7 -> enterSelectionMode()
            8 -> loadTrash()
            9 -> toggleGridMode()
            10 -> MinecraftAddonTools.showTools(this, currentDir)
            11 -> startActivity(Intent(this, StorageAnalyzerActivity::class.java))
            20 -> { adapter.selectAll(); updateSelectionSubtitle() }
            21 -> copySelected()
            22 -> moveSelected()
            23 -> deleteSelectedToTrash()
            24 -> shareSelected()
            25 -> exitSelectionMode()
            26 -> {
                if (adapter.selectionCount() < 2) {
                    Toast.makeText(this, "เลือกอย่างน้อย 2 ไฟล์ก่อน", Toast.LENGTH_SHORT).show()
                } else batchRenameDialog()
            }
            30 -> emptyTrashConfirm()
            60 -> applySort(SortKey.NAME, true)
            61 -> applySort(SortKey.NAME, false)
            62 -> applySort(SortKey.SIZE, false)
            63 -> applySort(SortKey.SIZE, true)
            64 -> applySort(SortKey.DATE, false)
            65 -> applySort(SortKey.DATE, true)
        }
        return true
    }

    private fun pasteClipboard() {
        val sources = clipboardFiles
        if (sources.isEmpty()) {
            Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
            return
        }
        val destDir = currentDir
        val cut = clipboardIsCut
        Toast.makeText(this, "กำลังวางไฟล์...", Toast.LENGTH_SHORT).show()
        Thread {
            var successCount = 0
            for (src in sources) {
                try {
                    var dest = File(destDir, src.name)
                    if (dest.exists()) dest = File(destDir, uniqueName(destDir, src.name, src.isDirectory))
                    if (cut) {
                        if (!src.renameTo(dest)) {
                            src.copyRecursively(dest, overwrite = true)
                            src.deleteRecursively()
                        }
                    } else {
                        src.copyRecursively(dest, overwrite = true)
                    }
                    successCount++
                } catch (e: Exception) {
                    // Skip failed item, continue with the rest.
                }
            }
            clipboardFiles = emptyList()
            clipboardIsCut = false
            runOnUiThread {
                updateActionBars()
                invalidateOptionsMenu()
                loadDirectory(currentDir)
                Toast.makeText(this, "วางสำเร็จ $successCount รายการ", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun newFolderDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    File(currentDir, name).mkdirs()
                    loadDirectory(currentDir)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Bookmarks bar & management ----------

    private fun refreshBookmarksBar() {
        bookmarksBar.removeAllViews()
        bookmarksBar.addView(buildAddCurrentFolderChip())
        val bookmarks = bookmarksManager.getAll()
        for (bm in bookmarks) {
            val chip = TextView(this).apply {
                text = "⭐ ${bm.name}"
                setPadding(24, 12, 24, 12)
                setBackgroundColor(0xFFE3F2FD.toInt())
                setTextColor(0xFF1565C0.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 12
                layoutParams = lp
                setOnClickListener {
                    val target = File(bm.path)
                    if (target.exists()) loadDirectory(target)
                    else Toast.makeText(context, "ไม่พบโฟลเดอร์นี้แล้ว", Toast.LENGTH_SHORT).show()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("ลบบุ๊คมาร์ก \"${bm.name}\"?")
                        .setPositiveButton("ลบ") { _, _ ->
                            bookmarksManager.remove(bm.path)
                            refreshBookmarksBar()
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                    true
                }
            }
            bookmarksBar.addView(chip)
        }
    }

    /**
     * Leading chip in the bookmarks bar: one tap bookmarks whatever folder is currently open,
     * so users get a quick shortcut without long-pressing a folder row first.
     */
    private fun buildAddCurrentFolderChip(): TextView {
        return TextView(this).apply {
            text = "＋ เพิ่มโฟลเดอร์นี้"
            setPadding(24, 12, 24, 12)
            setBackgroundColor(0xFFEEEEEE.toInt())
            setTextColor(0xFF424242.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = 12
            layoutParams = lp
            setOnClickListener {
                if (mode != Mode.NORMAL) {
                    Toast.makeText(context, "กลับไปที่มุมมองโฟลเดอร์ปกติก่อนเพิ่มบุ๊คมาร์ก", Toast.LENGTH_SHORT).show()
                } else if (bookmarksManager.isBookmarked(currentDir.absolutePath)) {
                    Toast.makeText(context, "โฟลเดอร์นี้อยู่ในบุ๊คมาร์กแล้ว", Toast.LENGTH_SHORT).show()
                } else {
                    addBookmark(currentDir)
                }
            }
        }
    }

    private fun manageBookmarksDialog() {
        val bookmarks = bookmarksManager.getAll()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีบุ๊คมาร์ก กดค้างที่โฟลเดอร์เพื่อเพิ่ม", Toast.LENGTH_LONG).show()
            return
        }
        val names = bookmarks.map { "${it.name}  (${it.path})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("บุ๊คมาร์กทั้งหมด (แตะเพื่อไป, กดค้างเพื่อลบใน bar ด้านบน)")
            .setItems(names) { _, which ->
                val target = File(bookmarks[which].path)
                if (target.exists()) loadDirectory(target)
            }
            .setNegativeButton("ปิด", null)
            .show()
    }
}
