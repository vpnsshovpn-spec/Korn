package com.example.filemanager

import android.content.Intent
import android.view.View
import android.widget.TextView

/**
 * All findViewById() lookups + setOnClickListener() wiring for MainActivity's main-screen
 * views, split out of onCreate() (see MainActivity-Slimdown-Plan.txt ก้อน 3.7). Purely
 * mechanical view lookup/listener assignment - no business logic - but ordering within this
 * function matters and must match the original onCreate() order exactly, since some lines
 * depend on a field assigned earlier in the same block (e.g. trashActionBar.visibility = GONE
 * must come after trashActionBar = findViewById(...)).
 *
 * Called once from onCreate(), before setupNavigationDrawer()/applyThemePalette() and anything
 * else that touches these fields.
 */
internal fun MainActivity.bindMainViews() {
    drawerLayout = findViewById(R.id.drawerLayout)
    navigationView = findViewById(R.id.navigationView)

    breadcrumbBar = findViewById(R.id.breadcrumbBar)
    breadcrumbScroll = findViewById(R.id.breadcrumbScroll)
    storagePercent = findViewById(R.id.storagePercent)
    storagePercent.setOnClickListener { startActivity(Intent(this, StorageAnalyzerActivity::class.java)) }
    recyclerView = findViewById(R.id.fileList)
    swipeRefresh = findViewById(R.id.swipeRefresh)
    bookmarksBar = findViewById(R.id.bookmarksBar)
    categoryBar = findViewById(R.id.categoryBar)
    storageText = findViewById(R.id.storageText)

    selectionActionBar = findViewById(R.id.selectionActionBar)
    clipboardActionBar = findViewById(R.id.clipboardActionBar)
    trashActionBar = findViewById(R.id.trashActionBar)
    findViewById<com.google.android.material.button.MaterialButton>(R.id.emptyTrashButton).setOnClickListener { emptyTrashConfirm() }
    findViewById<android.widget.ImageButton>(R.id.trashSettingsButton).setOnClickListener { TrashSettingsSheet.newInstance { loadTrash() }.show(supportFragmentManager, "trash_settings") }
    trashActionBar.visibility = View.GONE
    selectionMoreButton = findViewById(R.id.selectionMoreButton)
    clipboardPasteButton = findViewById(R.id.clipboardPasteButton)
    findViewById<TextView>(R.id.selectionCopyButton).setOnClickListener { copySelected() }
    findViewById<TextView>(R.id.selectionCutButton).setOnClickListener { moveSelected() }
    findViewById<TextView>(R.id.selectionRenameButton).setOnClickListener { renameSelected() }
    findViewById<TextView>(R.id.selectionDeleteButton).setOnClickListener { deleteSelectedToTrash() }
    findViewById<TextView>(R.id.selectionCancelButton).setOnClickListener { exitSelectionMode() }
    selectionMoreButton.setOnClickListener { showSelectionMoreMenu() }
    clipboardPasteButton.setOnClickListener { pasteClipboard() }
    findViewById<TextView>(R.id.clipboardNewButton).setOnClickListener { newFolderDialog() }
    findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton).setOnClickListener { showAddMenu() }
    findViewById<android.widget.Button>(R.id.addBookmarkButton).setOnClickListener { addBookmark(viewModel.currentDir.value) }
    findViewById<android.widget.Button>(R.id.manageBookmarksButton).setOnClickListener { manageBookmarksDialog() }
    findViewById<android.widget.Button>(R.id.sortFilesButton).setOnClickListener { showSortDialog() }
    findViewById<android.widget.Button>(R.id.viewModeButton).setOnClickListener { toggleGridMode() }
    findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton).setOnClickListener { showWindowsDialog() }
    findViewById<TextView>(R.id.clipboardCancelButton).setOnClickListener {
        viewModel.setClipboardFiles(emptyList())
        viewModel.setClipboardIsCut(false)
        updateActionBars()
    }
}
