package com.example.filemanager

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Round 13 scaffolded this class empty. Round 14 moves the first group of
 * MainActivity's scattered state variables here: settings/display state
 * (showHidden, sortKey, sortAscending, isGridMode, fileViewMode, themeKey).
 *
 * These are exposed as StateFlow + setter functions. MainActivity keeps its
 * original property names (showHidden, sortKey, etc.) as thin get/set
 * wrappers around this ViewModel's StateFlow values, so every other file
 * that reads/writes `activity.showHidden` (or similar) keeps working exactly
 * as before, with no changes needed there. This is intentional: it makes
 * this round behavior-neutral even though the underlying storage moved.
 *
 * Future rounds:
 *   Round 16 - navigation/directory state (currentDir, lastNormalDir, mode, category/search state)
 *   Round 17 - unit tests + CI + cleanup
 */
class MainViewModel : ViewModel() {

    private val _showHidden = MutableStateFlow(false)
    val showHidden: StateFlow<Boolean> = _showHidden
    fun setShowHidden(value: Boolean) { _showHidden.value = value }

    private val _sortKey = MutableStateFlow(MainActivity.SortKey.NAME)
    internal val sortKey: StateFlow<MainActivity.SortKey> = _sortKey
    internal fun setSortKey(value: MainActivity.SortKey) { _sortKey.value = value }

    private val _sortAscending = MutableStateFlow(true)
    val sortAscending: StateFlow<Boolean> = _sortAscending
    fun setSortAscending(value: Boolean) { _sortAscending.value = value }

    private val _isGridMode = MutableStateFlow(false)
    val isGridMode: StateFlow<Boolean> = _isGridMode
    fun setIsGridMode(value: Boolean) { _isGridMode.value = value }

    private val _fileViewMode = MutableStateFlow(FileAdapter.ViewMode.LIST)
    val fileViewMode: StateFlow<FileAdapter.ViewMode> = _fileViewMode
    fun setFileViewMode(value: FileAdapter.ViewMode) { _fileViewMode.value = value }

    private val _themeKey = MutableStateFlow("blue")
    val themeKey: StateFlow<String> = _themeKey
    fun setThemeKey(value: String) { _themeKey.value = value }

    // Round 15: clipboard state, moved from MainActivity the same way as Round 14.
    private val _clipboardFiles = MutableStateFlow<List<java.io.File>>(emptyList())
    val clipboardFiles: StateFlow<List<java.io.File>> = _clipboardFiles
    fun setClipboardFiles(value: List<java.io.File>) { _clipboardFiles.value = value }

    private val _clipboardIsCut = MutableStateFlow(false)
    val clipboardIsCut: StateFlow<Boolean> = _clipboardIsCut
    fun setClipboardIsCut(value: Boolean) { _clipboardIsCut.value = value }
}
