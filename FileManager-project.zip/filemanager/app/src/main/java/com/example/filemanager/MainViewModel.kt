package com.example.filemanager

import androidx.lifecycle.ViewModel

/**
 * Round 13 (scaffold only): empty ViewModel wired into MainActivity.
 *
 * No state has been moved here yet. This class exists purely to verify that
 * adding the lifecycle-viewmodel-ktx dependency and binding MainActivity to
 * a ViewModel via `by viewModels()` does not break the build or the app.
 *
 * Future rounds will move MainActivity's scattered state variables into
 * StateFlow properties here, in small, isolated steps:
 *   Round 14 - settings/display state (showHidden, sortKey, sortAscending, isGridMode, fileViewMode, themeKey)
 *   Round 15 - clipboard state (clipboardFiles, clipboardIsCut)
 *   Round 16 - navigation/directory state (currentDir, lastNormalDir, mode, category/search state)
 *   Round 17 - unit tests + CI + cleanup
 */
class MainViewModel : ViewModel() {
    // Intentionally empty for Round 13.
}
