package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Holds UI state that doesn't belong to directory browsing specifically.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see round2-instructions.txt): directory
 * browsing/listing state (currentDir, lastNormalDir, mode, category filter, sort key/
 * ascending, showHidden, grid/view mode, and the directoryState listing itself + its
 * loadDirectory() loader - originally added in Round 17) has moved out to its own
 * DirectoryViewModel.
 *
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): clipboard
 * (clipboardFiles/clipboardIsCut), multi-select (selectionMode/selectedPaths), copy/move
 * progress (fileOpState) + its UiEvent.FileOpDone, the "เพิ่มเติม" menu flag
 * (selectionMoreMenuOpen), the trash-confirm dialog flag (trashConfirmDialogOpen), and the
 * copy/move conflict batch (copyMoveConflictBatch/CopyMoveConflictBatch) have moved out to
 * their own FileOperationViewModel.
 *
 * Round 2 (MainViewModel split, step 3 of 4 - see round2-next-steps-plan.txt): archive/compress
 * background-operation progress (archiveOpState/compressOpState, plus UiEvent.ArchiveOpDone/
 * CompressOpDone/Toast) and the extract conflict batch (extractConflictBatch/
 * ExtractConflictBatch) have moved out to their own ArchiveOperationViewModel.
 *
 * Round 2 (MainViewModel split, step 4 of 4 - see refactor-instructions.txt): text/content
 * search (lastSearchQuery/lastSearchContentEnabled/searchDialogOpen/searchUiState/
 * searchActive/onSearchQueryChanged/runSearchImmediate/runSearchNow) and the Local Search
 * Index attach point have moved out to their own SearchFilterViewModel - see that class
 * instead. This was the last of the 4 steps: MainViewModel now holds only themeKey.
 *
 * [savedStateHandle] is kept as an unused constructor parameter rather than removed: this is a
 * pure state-move step (no logic/signature changes beyond what's actually moving - same
 * "ห้ามแก้ชื่อคลาส/ฟังก์ชันระหว่างย้าย" caution as steps 1-3), and MainActivity's
 * `viewModel: MainViewModel by viewModels()` wiring (unchanged since Round 13) relies on this
 * constructor shape. Nothing here needs it today; a future round can drop it as a separate,
 * deliberate change if MainViewModel stays this small.
 */
class MainViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    // ---------- Settings / display state (Round 14) ----------
    //
    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): showHidden/
    // sortKey/sortAscending/isGridMode/fileViewMode moved out to DirectoryViewModel (directory-
    // browsing display settings). themeKey stays here - it's an app-wide setting, not a
    // directory-browsing one, and refactor-instructions.txt's DirectoryViewModel field list
    // deliberately excludes it.

    private val _themeKey = MutableStateFlow("blue")
    val themeKey: StateFlow<String> = _themeKey
    fun setThemeKey(value: String) { _themeKey.value = value }

    // Round 2 (MainViewModel split, step 2 of 4): clipboardFiles/clipboardIsCut (Round 15)
    // moved out to FileOperationViewModel - see that class instead.

    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): currentDir/
    // lastNormalDir/mode/currentCategoryLabel/currentCategoryExts (Round 16, SavedStateHandle-
    // backed since Round 22) moved out to DirectoryViewModel along with directoryState/
    // loadDirectory() - see that class instead.

    // Round 2 (MainViewModel split, step 2 of 4): trashConfirmDialogOpen (Rotation Safety #4's
    // other dialog) and selectionMoreMenuOpen (Rotation Safety #5) moved out to
    // FileOperationViewModel - see that class instead.

    // Round 2 (MainViewModel split, step 3 of 4): archive/compress progress state
    // (ArchiveOpUiState/archiveOpState, CompressOpUiState/compressOpState, and their setters)
    // moved to ArchiveOperationViewModel - see that class instead.

    // Round 2 (MainViewModel split, step 4 of 4 - see refactor-instructions.txt): search state
    // (lastSearchQuery/lastSearchContentEnabled/searchDialogOpen), search UI (searchUiState/
    // searchActive/clearSearchOverlay/onSearchQueryChanged/runSearchImmediate/runSearchNow),
    // and the Local Search Index attach point (attachSearchIndexManager/searchIndexManager)
    // moved to SearchFilterViewModel - see that class instead.

    // Round 2 (MainViewModel split, step 3 of 4): the extract conflict-resolution batch
    // (ExtractConflictBatch/extractConflictBatch, its SavedStateHandle persistence, and
    // pendingExtractPassword/currentExtractPassword()) moved to ArchiveOperationViewModel - see
    // that class instead. Copy/Move's counterpart moved to FileOperationViewModel back in step 2.
}
