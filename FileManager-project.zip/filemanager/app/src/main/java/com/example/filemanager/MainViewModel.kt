package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.FileScanner
import com.example.filemanager.data.search.SearchIndexManager

/**
 * Holds UI state that doesn't belong to directory browsing specifically: app-wide settings
 * (themeKey), the search dialog-open flag, and text/content search.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see round2-instructions.txt): directory
 * browsing/listing state (currentDir, lastNormalDir, mode, category filter, sort key/
 * ascending, showHidden, grid/view mode, and the directoryState listing itself + its
 * loadDirectory() loader - originally added in Round 17) has moved out to its own
 * DirectoryViewModel. This class keeps everything else Round 14-22 had already put here.
 * onSearchQueryChanged()/runSearchImmediate() below now take sortKey/sortAscending as explicit
 * parameters (same pattern as the pre-existing showHidden parameter) since that state no
 * longer lives in this ViewModel.
 *
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): clipboard
 * (clipboardFiles/clipboardIsCut), multi-select (selectionMode/selectedPaths), copy/move
 * progress (fileOpState) + its UiEvent.FileOpDone, the "เพิ่มเติม" menu flag
 * (selectionMoreMenuOpen), the trash-confirm dialog flag (trashConfirmDialogOpen), and the
 * copy/move conflict batch (copyMoveConflictBatch/CopyMoveConflictBatch) have moved out to
 * their own FileOperationViewModel.
 *
 * Round 2 (MainViewModel split, step 3 of 4 - see round2-next-steps-plan.txt): archive/compress
 * background-operation progress (archiveOpState/compressOpState, plus UiEvent.ArchiveOpDone/
 * CompressOpDone/Toast) and the extract conflict batch (extractConflictBatch/
 * ExtractConflictBatch) have moved out to their own ArchiveOperationViewModel. This class now
 * holds only themeKey, search (lastSearchQuery/lastSearchContentEnabled/searchDialogOpen/
 * searchUiState/searchActive/onSearchQueryChanged/runSearchImmediate), and the Local Search
 * Index attach point.
 */
class MainViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val directoryBrowserHelper = DirectoryBrowserHelper()

    // ---------- Local Search Index (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6) ----------

    private var searchIndexManager: SearchIndexManager? = null

    /**
     * เรียกครั้งเดียวจาก MainActivity.onCreate() ทันทีหลังสร้าง SearchIndexManager
     * MainViewModel สร้างผ่าน `by viewModels()` (no-arg constructor ตามแพทเทิร์นเดิมของ
     * โปรเจกต์) จึงรับ SearchIndexManager ผ่าน constructor ตรงๆ ไม่ได้โดยไม่เพิ่ม Factory
     * ที่โปรเจกต์นี้ไม่เคยใช้มาก่อน — attach แบบนี้แทน ไม่ผูก SearchIndexManager เป็น
     * singleton object ลอยๆ ตามที่แผนกำหนดไว้ (ข้อ 6.1)
     *
     * SearchIndexManager เก็บแค่ applicationContext ไว้ภายในตัวเอง (ดู
     * SearchIndexManager.appContext) การเก็บ reference นี้ไว้ใน ViewModel ข้าม config
     * change (เช่น หมุนจอ) จึงไม่ leak Activity — เรียกซ้ำได้ทุก onCreate เฉยๆ แค่แทนที่
     * ด้วย instance ใหม่ที่ชี้ไปที่ Room DB ไฟล์เดิม
     */
    fun attachSearchIndexManager(manager: SearchIndexManager) {
        searchIndexManager = manager
    }

    // Round 2 (MainViewModel split, step 3 of 4): UiEvent (Toast/ArchiveOpDone/CompressOpDone)
    // and the _events/events SharedFlow moved to ArchiveOperationViewModel - see that class
    // instead. This class no longer emits any one-off UI events of its own.

    // ---------- Settings / display state (Round 14) ----------
    //
    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): showHidden/
    // sortKey/sortAscending/isGridMode/fileViewMode moved out to DirectoryViewModel (directory-
    // browsing display settings). themeKey stays here - it's an app-wide setting, not a
    // directory-browsing one, and refactor-instructions.txt's DirectoryViewModel field list
    // deliberately excludes it.

    private val _themeKey = MutableStateFlow("blue")
    val themeKey: StateFlow<String> = _themeKey
    fun setThemeKey(value: String) { _themeKey.value = value }

    // Round 2 (MainViewModel split, step 2 of 4): clipboardFiles/clipboardIsCut (Round 15)
    // moved out to FileOperationViewModel - see that class instead.

    // ---------- Navigation / directory state ----------
    //
    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): currentDir/
    // lastNormalDir/mode/currentCategoryLabel/currentCategoryExts (Round 16, SavedStateHandle-
    // backed since Round 22) moved out to DirectoryViewModel along with directoryState/
    // loadDirectory() below. lastSearchQuery/lastSearchContentEnabled stay here for now - the
    // plan's SearchFilterViewModel (step 4) is where those move, not this step.

    private val _lastSearchQuery = MutableStateFlow(savedStateHandle.get<String>(KEY_SEARCH_QUERY))
    val lastSearchQuery: StateFlow<String?> = _lastSearchQuery
    fun setLastSearchQuery(value: String?) {
        _lastSearchQuery.value = value
        savedStateHandle[KEY_SEARCH_QUERY] = value
    }

    private val _lastSearchContentEnabled = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_CONTENT) ?: false
    )
    val lastSearchContentEnabled: StateFlow<Boolean> = _lastSearchContentEnabled
    fun setLastSearchContentEnabled(value: Boolean) {
        _lastSearchContentEnabled.value = value
        savedStateHandle[KEY_SEARCH_CONTENT] = value
    }

    // ---------- Dialog-open flags (Rotation Safety #4) ----------

    // Rotation Safety #4: "ค้นหาไฟล์" (SearchHelper.kt) is a plain KornDialog.Builder dialog,
    // not backed by any ViewModel-held batch the way the Rotation Safety #2 conflict dialogs
    // are. That's fine for a rotation (FragmentManager recreates the DialogFragment itself, and
    // KornDialog.take() still finds the spec in the in-memory map because the process never
    // died), but it fails silently on a real process death: KornDialogFragment.onCreate()'s
    // spec = specId?.let { KornDialog.take(it) } comes back null (the static specs map was
    // wiped along with the rest of the process), so the restored fragment just calls
    // dismissAllowingStateLoss() on itself - the dialog never reappears and nothing tells the
    // user it's gone.
    //
    // Same fix shape as Rotation Safety #2: a plain "is this dialog open" flag now lives here,
    // backed by SavedStateHandle so it survives process death too. The entry point
    // (searchDialog()) now only flips this flag to true; the actual KornDialog.Builder call
    // happens in SearchHelper.kt's observeXxxDialog() (wired from MainActivity.onCreate(), same
    // as observeConflictBatches()), which reacts to the flow the same way on a normal open, a
    // rotation, and a process-death relaunch alike - collect() always replays the latest value
    // to a fresh STARTED collector. The dialog's own setOnDismissListener flips the flag back
    // to false on every real dismissal (button tap, outside touch, back press) - never called
    // for the transient teardown a rotation causes, per KornDialogFragment.onDismiss()'s doc
    // comment, so rotation restore is unaffected.
    //
    // No extra state needs to be persisted for the search dialog's typed text/checkbox - those
    // already live in lastSearchQuery/lastSearchContentEnabled above (kept in sync on every
    // keystroke by onSearchQueryChanged()), so whenever the dialog is rebuilt it pre-fills
    // correctly regardless of why it's reappearing.
    //
    // Round 2 (MainViewModel split, step 2 of 4): trashConfirmDialogOpen (Rotation Safety #4's
    // other dialog) and selectionMoreMenuOpen (Rotation Safety #5) moved out to
    // FileOperationViewModel - see that class instead.

    private val _searchDialogOpen = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_DIALOG_OPEN) ?: false
    )
    val searchDialogOpen: StateFlow<Boolean> = _searchDialogOpen
    fun setSearchDialogOpen(open: Boolean) {
        _searchDialogOpen.value = open
        savedStateHandle[KEY_SEARCH_DIALOG_OPEN] = open
    }

    // Round 2 (MainViewModel split, step 2 of 4): multi-select state (selectionMode/
    // selectedPaths, Round A) and copy/move progress state (fileOpState, Round B) moved out to
    // FileOperationViewModel - see that class instead.

    // Round 2 (MainViewModel split, step 3 of 4): archive/compress progress state
    // (ArchiveOpUiState/archiveOpState, CompressOpUiState/compressOpState, and their setters)
    // moved to ArchiveOperationViewModel - see that class instead.

    // ---------- Search UI & Dynamic Performance ----------

    /**
     * Drives the search screen's visibility state. Loading shows the centered progress
     * wheel, Empty shows the folder+magnifier placeholder, Success renders the results into
     * the normal file list, Error surfaces a message. See SearchHelper.kt for the
     * MainActivity-side rendering of each state.
     */
    sealed class SearchUiState {
        object Loading : SearchUiState()
        object Empty : SearchUiState()
        data class Success(val entries: List<FileEntry>) : SearchUiState()
        data class Error(val message: String) : SearchUiState()
    }

    private val _searchUiState = MutableStateFlow<SearchUiState>(SearchUiState.Loading)
    val searchUiState: StateFlow<SearchUiState> = _searchUiState

    // Mode.SEARCH is reused by the unrelated "recent folders" screen (loadRecentFolders() in
    // MainActivity.kt), which never touches searchUiState. This flag is what actually tells
    // SearchHelper.kt's overlay observer "a real text search is active right now" so it
    // doesn't render a stale Loading/Empty/Success overlay on top of that screen instead.
    private val _searchActive = MutableStateFlow(false)
    val searchActive: StateFlow<Boolean> = _searchActive

    /** Called from loadRecentFolders() and anywhere else that reuses Mode.SEARCH for something else. */
    fun clearSearchOverlay() {
        searchJob?.cancel()
        _searchActive.value = false
    }

    private var searchJob: Job? = null

    /**
     * Debounced entry point for live typing in the search box: waits [SEARCH_DEBOUNCE_MS]
     * after the last keystroke, and unconditionally cancels any in-flight search job first
     * so a fast typist never has two scans racing to publish [searchUiState].
     */
    // Round 2 (MainViewModel split, step 1 of 4): sortKey/sortAscending now live on
    // DirectoryViewModel, not here - runSearchNow() needs them for its result comparator, so
    // both entry points below now take them as explicit parameters instead of reading a local
    // _sortKey/_sortAscending, the same way [showHidden] already was passed in rather than read
    // from viewModel state directly. Callers pass directoryViewModel.sortKey.value/
    // directoryViewModel.sortAscending.value (see SearchHelper.kt).
    internal fun onSearchQueryChanged(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        if (query.isBlank()) {
            _searchUiState.value = SearchUiState.Empty
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending)
        }
    }

    /** Same scan, no debounce wait - used for the dialog's "ค้นหา" button and refresh/rotation. */
    internal fun runSearchImmediate(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        searchJob = viewModelScope.launch { runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending) }
    }

    /**
     * Hybrid strategy (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6.1): searchContent == true
     * ยังเดินสแกนสดผ่าน FileScanner เหมือนเดิมเสมอ (ค้นเนื้อไฟล์ไม่ทำ index ตามที่ตกลงกัน)
     * ส่วน searchContent == false (ค้นชื่ออย่างเดียว) เปลี่ยนไป query จาก
     * [SearchIndexManager] แทนการเดินดิสก์สด "ถ้า" index ถูก build ไปแล้วอย่างน้อยหนึ่งครั้ง
     * (searchIndexManager != null && !isEmpty()) — ถ้า index ยังว่างอยู่ (เช่นเปิดแอปครั้งแรก
     * แล้ว rebuildFullIndex() ตอน initialize() ยังทำงานไม่เสร็จ) ให้ fallback ไปเดินสแกนสด
     * แบบเดิมแทนที่จะคืนผลว่างเปล่า เพื่อไม่ให้ประสบการณ์แย่ลงกว่าเดิมในช่วงสั้นๆ นั้น
     */
    private suspend fun runSearchNow(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        _searchUiState.value = SearchUiState.Loading
        try {
            val results = withContext(Dispatchers.IO) {
                val indexManager = searchIndexManager
                if (!searchContent && indexManager != null && !indexManager.isEmpty()) {
                    indexManager.search(query, showHidden).map { FileScanner.ContentMatch(it, "") }
                } else {
                    FileScanner.searchByNameAndContent(root, query, showHidden, searchContent)
                }
            }
            val comparator = directoryBrowserHelper.comparator(sortKey, sortAscending)
            val entries = results.map { match ->
                FileEntry(match.file, subtitleOverride = match.line.ifEmpty { null })
            }.sortedWith(comparator)
            _searchUiState.value = if (entries.isEmpty()) SearchUiState.Empty else SearchUiState.Success(entries)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _searchUiState.value = SearchUiState.Error(e.message ?: "เกิดข้อผิดพลาดในการค้นหา")
        }
    }

    companion object {
        private const val SEARCH_DEBOUNCE_MS = 250L
        private const val KEY_SEARCH_QUERY = "search_query"
        private const val KEY_SEARCH_CONTENT = "search_content"

        // Rotation Safety #4 (search dialog-open flag, process-death-safe) key. Round 2 (step 2
        // of 4): KEY_TRASH_CONFIRM_OPEN/KEY_SELECTION_MORE_MENU_OPEN and the Rotation Safety #2
        // copy/move (KEY_CM_*) keys moved to FileOperationViewModel.
        private const val KEY_SEARCH_DIALOG_OPEN = "search_dialog_open"
    }

    // Round 2 (MainViewModel split, step 3 of 4): the extract conflict-resolution batch
    // (ExtractConflictBatch/extractConflictBatch, its SavedStateHandle persistence, and
    // pendingExtractPassword/currentExtractPassword()) moved to ArchiveOperationViewModel - see
    // that class instead. Copy/Move's counterpart moved to FileOperationViewModel back in step 2.

    // Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): the
    // "Directory listing data flow (Round 17 / Task 1)" section (DirectoryUiState,
    // directoryState, loadDirectory()) that used to live here has moved to
    // DirectoryViewModel.kt in full, together with the currentDir/lastNormalDir/mode state it
    // reads and writes - see that file instead.
}
