package com.example.filemanager

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * Round 17 (Task 1 of the architecture upgrade): directory loading now lives here,
 * runs entirely on Dispatchers.IO via viewModelScope, and is exposed to MainActivity
 * as a single StateFlow<DirectoryUiState>. One-off UI effects (error toasts) are
 * exposed separately as a SharedFlow<UiEvent> since a StateFlow would either drop
 * a repeated identical message or resend a stale one on process/config changes.
 *
 * Earlier rounds (14/15/16) already moved simple settings/navigation fields to
 * StateFlow here; that part is untouched by this round. What changes in this round
 * is *who performs the I/O*: previously MainActivity.loadDirectory() called
 * DirectoryBrowserHelper.load() synchronously on the main thread. That listing +
 * filtering + sorting work (and any future FileScanner-based flows built on top of
 * it) now happens inside loadDirectory() below, off the main thread.
 */
class MainViewModel : ViewModel() {

    private val directoryBrowserHelper = DirectoryBrowserHelper()

    // ---------- One-off UI events (toasts, etc.) ----------

    sealed class UiEvent {
        data class Toast(val message: String) : UiEvent()

        /** Round B: one-shot "copy/move finished" signal - the toast/dialog choice and the
         * post-completion directory refresh both stay a one-off UI reaction, same as Toast. */
        data class FileOpDone(
            val doneCount: Int,
            val totalCount: Int,
            val failures: List<String>
        ) : UiEvent()
    }

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<UiEvent> = _events

    // ---------- Settings / display state (Round 14) ----------

    private val _showHidden = MutableStateFlow(false)
    val showHidden: StateFlow<Boolean> = _showHidden
    fun setShowHidden(value: Boolean) { _showHidden.value = value }

    private val _sortKey = MutableStateFlow(MainActivity.SortKey.NAME)
    internal val sortKey: StateFlow<MainActivity.SortKey> = _sortKey
    internal fun setSortKey(value: MainActivity.SortKey) { _sortKey.value = value }

    private val _sortAscending = MutableStateFlow(true)
    val sortAscending: StateFlow<Boolean> = _sortAscending
    fun setSortAscending(value: Boolean) { _sortAscending.value = value }

    private val _isGridMode = MutableStateFlow(false)
    val isGridMode: StateFlow<Boolean> = _isGridMode
    fun setIsGridMode(value: Boolean) { _isGridMode.value = value }

    private val _fileViewMode = MutableStateFlow(FileAdapter.ViewMode.LIST)
    val fileViewMode: StateFlow<FileAdapter.ViewMode> = _fileViewMode
    fun setFileViewMode(value: FileAdapter.ViewMode) { _fileViewMode.value = value }

    private val _themeKey = MutableStateFlow("blue")
    val themeKey: StateFlow<String> = _themeKey
    fun setThemeKey(value: String) { _themeKey.value = value }

    // ---------- Clipboard state (Round 15) ----------

    private val _clipboardFiles = MutableStateFlow<List<File>>(emptyList())
    val clipboardFiles: StateFlow<List<File>> = _clipboardFiles
    fun setClipboardFiles(value: List<File>) { _clipboardFiles.value = value }

    private val _clipboardIsCut = MutableStateFlow(false)
    val clipboardIsCut: StateFlow<Boolean> = _clipboardIsCut
    fun setClipboardIsCut(value: Boolean) { _clipboardIsCut.value = value }

    // ---------- Navigation / directory state (Round 16) ----------

    private val _currentDir = MutableStateFlow(android.os.Environment.getExternalStorageDirectory())
    val currentDir: StateFlow<File> = _currentDir
    fun setCurrentDir(value: File) { _currentDir.value = value }

    private val _lastNormalDir = MutableStateFlow(android.os.Environment.getExternalStorageDirectory())
    val lastNormalDir: StateFlow<File> = _lastNormalDir
    fun setLastNormalDir(value: File) { _lastNormalDir.value = value }

    private val _mode = MutableStateFlow(MainActivity.Mode.NORMAL)
    val mode: StateFlow<MainActivity.Mode> = _mode
    fun setMode(value: MainActivity.Mode) { _mode.value = value }

    private val _currentCategoryLabel = MutableStateFlow<String?>(null)
    val currentCategoryLabel: StateFlow<String?> = _currentCategoryLabel
    fun setCurrentCategoryLabel(value: String?) { _currentCategoryLabel.value = value }

    private val _currentCategoryExts = MutableStateFlow<Set<String>?>(null)
    val currentCategoryExts: StateFlow<Set<String>?> = _currentCategoryExts
    fun setCurrentCategoryExts(value: Set<String>?) { _currentCategoryExts.value = value }

    private val _lastSearchQuery = MutableStateFlow<String?>(null)
    val lastSearchQuery: StateFlow<String?> = _lastSearchQuery
    fun setLastSearchQuery(value: String?) { _lastSearchQuery.value = value }

    private val _lastSearchContentEnabled = MutableStateFlow(false)
    val lastSearchContentEnabled: StateFlow<Boolean> = _lastSearchContentEnabled
    fun setLastSearchContentEnabled(value: Boolean) { _lastSearchContentEnabled.value = value }

    // ---------- Multi-select state (Round A) ----------

    /**
     * Round A (ViewModel migration plan, round 1 of 4): multi-select state (whether
     * selection mode is on, and which absolute paths are selected) now lives here instead
     * of being owned only by FileAdapter's private fields. This is what lets the selection
     * survive an Activity recreation (rotation) once a new FileAdapter is created and
     * hydrates from these values - previously it was held only in-memory on the (destroyed)
     * Activity's old adapter instance and was lost outright on rotation.
     *
     * FileAdapter still keeps its own local `selected`/`selectionMode` fields as the
     * synchronous source it renders from, and calls [setSelectionState] as a write-through
     * after every local mutation, rather than collecting these flows continuously. That is
     * intentional, not an oversight: selection can be entered/updated from inside an
     * in-flight long-press/drag touch gesture (see FileClickHelper.onItemLongClick and the
     * `notify = false` parameters on FileAdapter.setSelectionMode()/selectPath()), and a
     * StateFlow-collector-driven notifyDataSetChanged() firing asynchronously mid-gesture
     * would rebind FileAdapter.VH's OnTouchListener (and reset its downX/downY/longPressed/
     * dragStarted tracking) while the user's finger is still down, breaking that gesture.
     * Write-through keeps FileAdapter's rendering exactly as synchronous/local as it was
     * before this round, while still giving this ViewModel a durable, single source of
     * truth for selection - Round C is where that hydrate-after-rotation path gets an
     * actual rotation test (see KORN-Next-Steps-Handoff.txt, round C in the plan).
     */
    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode

    private val _selectedPaths = MutableStateFlow<Set<String>>(emptySet())
    val selectedPaths: StateFlow<Set<String>> = _selectedPaths

    fun setSelectionState(selectionMode: Boolean, selectedPaths: Set<String>) {
        _selectionMode.value = selectionMode
        _selectedPaths.value = selectedPaths
    }

    // ---------- Copy/Move progress state (Round B) ----------

    /**
     * Round B (ViewModel migration plan, round 2 of 4): copy/move progress + completion now
     * lives here instead of FileOperationService's BroadcastReceiver callback in MainActivity
     * mutating the action bar / showing a Toast/dialog directly.
     *
     * FileOperationService itself is a Service that intentionally outlives the Activity (see
     * its own class doc: "Runs copy/move jobs outside the Activity lifecycle so large
     * transfers survive the user switching apps or the screen turning off") - it cannot hold
     * a MainViewModel reference, since a ViewModel doesn't exist independently of the
     * Activity that owns it, and the Service may still be running after that Activity (and
     * its ViewModel) is gone. So the Service keeps broadcasting BROADCAST_PROGRESS/
     * BROADCAST_DONE exactly as before (unchanged - see FileOperationService.kt). What
     * changes is MainActivity's fileOpReceiver: on receiving a broadcast it now just forwards
     * the values into this ViewModel via [setFileOpProgress]/[setFileOpDone] instead of
     * touching the UI itself. [fileOpState] is a plain StateFlow (sticky - keeps its last
     * value across Activity recreation/rotation, so a freshly created Activity immediately
     * shows the in-progress percent again instead of a blank subtitle); completion is a
     * one-off [UiEvent.FileOpDone] on [events], same reasoning as the existing Toast case.
     */
    data class FileOpUiState(
        val isRunning: Boolean = false,
        val percent: Int = 0,
        val isMove: Boolean = false,
        val doneCount: Int = 0,
        val totalCount: Int = 0
    )

    private val _fileOpState = MutableStateFlow(FileOpUiState())
    val fileOpState: StateFlow<FileOpUiState> = _fileOpState

    fun setFileOpProgress(percent: Int, doneCount: Int, totalCount: Int, isMove: Boolean) {
        _fileOpState.value = FileOpUiState(
            isRunning = true,
            percent = percent,
            isMove = isMove,
            doneCount = doneCount,
            totalCount = totalCount
        )
    }

    fun setFileOpDone(doneCount: Int, totalCount: Int, failures: List<String>) {
        _fileOpState.value = FileOpUiState(isRunning = false)
        viewModelScope.launch {
            _events.emit(UiEvent.FileOpDone(doneCount, totalCount, failures))
        }
    }

    // ---------- Directory listing data flow (Round 17 / Task 1) ----------

    /**
     * Everything MainActivity needs to render the normal-browse file list, in one snapshot.
     * isLoading defaults to true so the very first, empty placeholder value emitted to a
     * fresh collector (before checkPermissionsAndLoad() triggers the first real load) is
     * skipped rather than treated as "loaded an empty root folder" - see observeDirectoryState().
     */
    data class DirectoryUiState(
        val currentDir: File = android.os.Environment.getExternalStorageDirectory(),
        val entries: List<FileEntry> = emptyList(),
        val subtitle: String = "",
        val isLoading: Boolean = true
    )

    private val _directoryState = MutableStateFlow(DirectoryUiState())
    val directoryState: StateFlow<DirectoryUiState> = _directoryState.asStateFlow()

    private var loadJob: Job? = null

    /**
     * Loads [dir]'s contents off the main thread: listFilesCompat()/Shizuku fallback,
     * the hidden-file + root-trash-folder filter, and the sort comparator all run on
     * Dispatchers.IO now (previously this all ran synchronously inside
     * MainActivity.loadDirectory(), blocking the UI thread on every navigation).
     *
     * Any in-flight load is cancelled first, so rapid navigation (e.g. mashing back,
     * or a swipe-refresh landing mid-navigation) can't let a stale result overwrite
     * a newer one - only the latest call's result is ever applied.
     *
     * currentDir/lastNormalDir/mode are updated as part of this same state update
     * (matching what the old synchronous loadDirectory() did), so MainActivity no
     * longer needs to set them itself around the call.
     */
    fun loadDirectory(dir: File) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch(Dispatchers.IO) {
            if (!directoryBrowserHelper.canAccess(dir)) {
                _events.emit(UiEvent.Toast("ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้"))
                return@launch
            }

            _directoryState.update { it.copy(isLoading = true) }

            val comparator = directoryBrowserHelper.comparator(_sortKey.value, _sortAscending.value)
            val result = directoryBrowserHelper.load(dir, _showHidden.value, comparator)

            _mode.value = MainActivity.Mode.NORMAL
            _currentDir.value = dir
            _lastNormalDir.value = dir
            _directoryState.value = DirectoryUiState(
                currentDir = dir,
                entries = result.entries,
                subtitle = "${result.entries.size} รายการ",
                isLoading = false
            )
        }
    }
}
