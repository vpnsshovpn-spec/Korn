package com.example.filemanager

import android.content.DialogInterface
import android.content.Context
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Minecraft Bedrock-focused tools kept self-contained so they don't change the existing
 * file-manager architecture.
 */
object MinecraftAddonTools {

    fun isArchiveExtension(ext: String): Boolean =
        ext.equals("zip", true) || ext.equals("mcpack", true) ||
        ext.equals("mcaddon", true) || ext.equals("mcworld", true)

    fun ensureDevelopmentBookmarks(context: Context, manager: BookmarksManager) {
        // Disabled: Minecraft Android/data is intentionally not used by KORN.
    }
    

    fun showTools(activity: AppCompatActivity, currentDir: File) {
        val items = arrayOf(
            "📦 รวม Behavior Pack + Resource Pack → .mcaddon",
            "🚀 ส่งโฟลเดอร์ Pack ไปยัง Minecraft",
            "🆔 สร้าง UUID / แก้ manifest.json",
            "🏗️ สร้างโปรเจกต์ Add-on ใหม่",
            "📍 เปิดโฟลเดอร์ development_behavior_packs",
            "📍 เปิดโฟลเดอร์ development_resource_packs"
        )
        KornDialog.Builder(activity)
            .setTitle("Minecraft Add-on Tools")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> chooseFolder(activity, currentDir, "เลือก Behavior Pack") { behavior ->
                        chooseFolder(activity, currentDir, "เลือก Resource Pack") { resource ->
                            combineMcaddon(activity, behavior, resource, currentDir)
                        }
                    }
                    1 -> chooseFolder(activity, currentDir, "เลือกโฟลเดอร์ Pack") {
                        sendToMinecraft(activity, it)
                    }
                    2 -> chooseManifestFile(activity, currentDir)
                    3 -> createProjectDialog(activity, currentDir)
                    4 -> openDevelopment(activity, false)
                    5 -> openDevelopment(activity, true)
                }
            }
            .setNegativeButton("ปิด", null)
            .show()
    }

    private fun chooseManifestFile(activity: AppCompatActivity, dir: File) {
        val manifests = dir.walkTopDown().filter {
            it.isFile && it.name.equals("manifest.json", true)
        }.take(100).toList()
        if (manifests.isEmpty()) {
            KornDialog.Builder(activity).setTitle("ไม่พบ manifest.json")
                .setMessage("เปิดโฟลเดอร์ Add-on ที่มี manifest.json แล้วลองอีกครั้ง")
                .setPositiveButton("ตกลง", null).show()
            return
        }
        KornDialog.Builder(activity).setTitle("เลือก manifest.json")
            .setItems(manifests.map { it.absolutePath }.toTypedArray()) { _, which ->
                val i = android.content.Intent(activity, TextEditActivity::class.java)
                i.putExtra(TextEditActivity.EXTRA_FILE_PATH, manifests[which].absolutePath)
                activity.startActivity(i)
            }.show()
    }

    private fun chooseFolder(activity: AppCompatActivity, start: File, title: String, onChosen: (File) -> Unit) {
        var current = if (start.isDirectory) start else Environment.getExternalStorageDirectory()
        val root = Environment.getExternalStorageDirectory()
        val dialog = KornDialog.Builder(activity).setTitle(title).create()
        val list = ListView(activity)
        fun refresh() {
            val dirs = (current.listFiles() ?: emptyArray()).filter { it.isDirectory && !it.name.startsWith(".") }
                .sortedBy { it.name.lowercase() }
            val labels = mutableListOf<String>()
            if (current != root) labels.add("⬆️  ..")
            labels.addAll(dirs.map { "📁 ${it.name}" })
            list.adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1, labels)
            list.setOnItemClickListener { _, _, pos, _ ->
                if (current != root && pos == 0) {
                    current = current.parentFile ?: root
                    refresh()
                } else {
                    val idx = if (current != root) pos - 1 else pos
                    if (idx in dirs.indices) {
                        current = dirs[idx]
                        refresh()
                    }
                }
            }
        }
        dialog.setView(list)
        dialog.setButton(
            DialogInterface.BUTTON_POSITIVE,
            "เลือกโฟลเดอร์นี้",
            DialogInterface.OnClickListener { _, _ -> onChosen(current) }
        )
        dialog.setButton(
            DialogInterface.BUTTON_NEGATIVE,
            "ยกเลิก",
            DialogInterface.OnClickListener { _, _ -> }
        )
        refresh()
        dialog.show()
    }

    private fun combineMcaddon(activity: AppCompatActivity, behavior: File, resource: File, destination: File) {
        if (!behavior.isDirectory || !resource.isDirectory) return
        val name = "addon_${System.currentTimeMillis()}.mcaddon"
        val out = File(destination, name)
        Toast.makeText(activity, "กำลังสร้าง $name ...", Toast.LENGTH_SHORT).show()
        activity.lifecycleScope.launch(Dispatchers.IO) {
            val tempDir = File(activity.cacheDir, "mcaddon_${System.currentTimeMillis()}").apply { mkdirs() }
            try {
                val bp = File(tempDir, "${behavior.name}.mcpack")
                val rp = File(tempDir, "${resource.name}.mcpack")
                zipFolderAsPack(behavior, bp)
                zipFolderAsPack(resource, rp)
                ZipOutputStream(out.outputStream().buffered()).use { zos ->
                    listOf(bp, rp).forEach { pack ->
                        zos.putNextEntry(ZipEntry(pack.name))
                        pack.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "สร้าง .mcaddon สำเร็จ: ${out.name}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                out.delete()
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "สร้าง .mcaddon ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                tempDir.deleteRecursively()
            }
        }
    }

    private fun zipFolderAsPack(folder: File, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            addDirToZip(folder, "", zos)
        }
    }

    private fun addDirToZip(dir: File, base: String, zos: ZipOutputStream) {
        val children = dir.listFiles() ?: emptyArray()
        if (children.isEmpty()) {
            if (base.isNotEmpty()) {
                zos.putNextEntry(ZipEntry("$base/")); zos.closeEntry()
            }
            return
        }
        for (child in children) {
            val path = if (base.isEmpty()) child.name else "$base/${child.name}"
            if (child.isDirectory) addDirToZip(child, path, zos)
            else {
                zos.putNextEntry(ZipEntry(path))
                child.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    fun sendPackFromMain(activity: AppCompatActivity, pack: File) = sendToMinecraft(activity, pack)

    private fun sendToMinecraft(activity: AppCompatActivity, pack: File) {
        if (!pack.isDirectory) {
            Toast.makeText(activity, "ต้องเลือกโฟลเดอร์ Pack", Toast.LENGTH_SHORT).show()
            return
        }
        val root = Environment.getExternalStorageDirectory()
        val comMojangCandidates = listOf(
            File(root, "Android/data/com.mojang.minecraftpe/files/games/com.mojang"),
            File(root, "games/com.mojang")
        )
        val comMojang = comMojangCandidates.firstOrNull { it.exists() }
        if (comMojang == null) {
            Toast.makeText(activity, "ไม่พบโฟลเดอร์ com.mojang", Toast.LENGTH_LONG).show()
            return
        }
        val lower = pack.name.lowercase()
        val isResource = lower.contains("resource") || File(pack, "textures").exists() ||
                File(pack, "render_controllers").exists() || File(pack, "materials").exists()
        val isBehavior = lower.contains("behavior") || File(pack, "functions").exists() ||
                File(pack, "entities").exists() || File(pack, "items").exists()
        val targetName = if (isResource && !isBehavior) "development_resource_packs"
        else "development_behavior_packs"
        val targetRoot = File(comMojang, targetName)
        val target = File(targetRoot, pack.name)
        activity.lifecycleScope.launch(Dispatchers.IO) {
            try {
                targetRoot.mkdirs()
                if (target.exists()) target.deleteRecursively()
                pack.copyRecursively(target, overwrite = true)
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "ส่ง ${pack.name} → $targetName แล้ว", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(activity, "ส่งไป Minecraft ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun openDevelopment(activity: AppCompatActivity, resource: Boolean) {
        val root = Environment.getExternalStorageDirectory()
        val candidates = listOf(
            File(root, "Android/data/com.mojang.minecraftpe/files/games/com.mojang"),
            File(root, "games/com.mojang")
        )
        val base = candidates.firstOrNull { it.exists() } ?: return
        val dir = File(base, if (resource) "development_resource_packs" else "development_behavior_packs")
        if (!dir.exists()) dir.mkdirs()
        val i = android.content.Intent(activity, MainActivity::class.java)
        i.putExtra("start_path", dir.absolutePath)
        activity.startActivity(i)
    }

    private fun createProjectDialog(activity: AppCompatActivity, currentDir: File) {
        val input = EditText(activity)
        input.hint = "ชื่อโปรเจกต์ เช่น MyShaderAddon"
        KornDialog.Builder(activity)
            .setTitle("สร้าง Minecraft Add-on Project")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "MyAddon" }
                createProject(activity, currentDir, name)
            }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun createProject(activity: AppCompatActivity, parent: File, name: String) {
        val root = File(parent, name)
        val behavior = File(root, "${name}_BP")
        val resource = File(root, "${name}_RP")
        val bpUuid = UUID.randomUUID().toString()
        val rpUuid = UUID.randomUUID().toString()
        val bpModule = UUID.randomUUID().toString()
        val rpModule = UUID.randomUUID().toString()
        val manifestBp = """{
  "format_version": 2,
  "header": {
    "name": "$name Behavior Pack",
    "description": "Generated by KornManager",
    "uuid": "$bpUuid",
    "version": [1, 0, 0],
    "min_engine_version": [1, 20, 0]
  },
  "modules": [
    {"type": "data", "uuid": "$bpModule", "version": [1, 0, 0]}
  ]
}"""
        val manifestRp = """{
  "format_version": 2,
  "header": {
    "name": "$name Resource Pack",
    "description": "Generated by KornManager",
    "uuid": "$rpUuid",
    "version": [1, 0, 0],
    "min_engine_version": [1, 20, 0]
  },
  "modules": [
    {"type": "resources", "uuid": "$rpModule", "version": [1, 0, 0]}
  ]
}"""
        try {
            behavior.mkdirs(); resource.mkdirs()
            listOf("functions","entities","items","blocks","loot_tables","recipes","scripts").forEach { File(behavior,it).mkdirs() }
            listOf("textures","entity","models","animations","render_controllers","materials","particles","sounds").forEach { File(resource,it).mkdirs() }
            File(behavior, "manifest.json").writeText(manifestBp)
            File(resource, "manifest.json").writeText(manifestRp)
            // Valid 1x1 transparent PNG placeholder.
            val png = android.util.Base64.decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=",
                android.util.Base64.DEFAULT
            )
            File(behavior, "pack_icon.png").writeBytes(png)
            File(resource, "pack_icon.png").writeBytes(png)
            Toast.makeText(activity, "สร้างโปรเจกต์ $name สำเร็จ", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "สร้างโปรเจกต์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
