package com.example.filemanager

import android.os.Environment
import android.view.Gravity
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File

/**
 * Owns the main navigation drawer controls plus sorting and file-view-mode UI.
 *
 * This helper deliberately keeps MainActivity as the owner of application state.
 * It extracts the UI/persistence orchestration without changing the existing
 * navigation, sorting, or view-mode behavior.
 */
class NavigationDrawerHelper(private val activity: MainActivity) {

    fun sortLabel(): String = when (activity.viewModel.sortKey.value) {
        MainActivity.SortKey.NAME -> if (activity.viewModel.sortAscending.value) "ชื่อ ก-ฮ" else "ชื่อ ฮ-ก"
        MainActivity.SortKey.SIZE -> if (activity.viewModel.sortAscending.value) "ขนาด น้อย-มาก" else "ขนาด มาก-น้อย"
        MainActivity.SortKey.DATE -> if (activity.viewModel.sortAscending.value) "วันที่ เก่า-ใหม่" else "วันที่ ใหม่-เก่า"
    }

    fun showSortDialog(onApplied: () -> Unit = { activity.refreshCurrentView() }) {
        val options = arrayOf(
            "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
            "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
            "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
        )
        val checked = when {
            activity.viewModel.sortKey.value == MainActivity.SortKey.NAME && activity.viewModel.sortAscending.value -> 0
            activity.viewModel.sortKey.value == MainActivity.SortKey.NAME -> 1
            activity.viewModel.sortKey.value == MainActivity.SortKey.SIZE && !activity.viewModel.sortAscending.value -> 2
            activity.viewModel.sortKey.value == MainActivity.SortKey.SIZE -> 3
            !activity.viewModel.sortAscending.value -> 4
            else -> 5
        }
        AlertDialog.Builder(activity)
            .setTitle("เรียงลำดับ")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                when (which) {
                    0 -> applySort(MainActivity.SortKey.NAME, true, onApplied)
                    1 -> applySort(MainActivity.SortKey.NAME, false, onApplied)
                    2 -> applySort(MainActivity.SortKey.SIZE, false, onApplied)
                    3 -> applySort(MainActivity.SortKey.SIZE, true, onApplied)
                    4 -> applySort(MainActivity.SortKey.DATE, false, onApplied)
                    5 -> applySort(MainActivity.SortKey.DATE, true, onApplied)
                }
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    fun setupNavigationDrawer() {
        // Keep the original simple 3-line hamburger icon.
        // Clicking it opens/closes the drawer; edge-swipe remains enabled by DrawerLayout.
        val toolbar = activity.findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        toolbar.setNavigationIcon(R.drawable.ic_hamburger)
        toolbar.setNavigationOnClickListener {
            if (activity.drawerLayout.isDrawerOpen(Gravity.START)) {
                activity.drawerLayout.closeDrawer(Gravity.START)
            } else {
                activity.drawerLayout.openDrawer(Gravity.START)
            }
        }

        activity.navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home, R.id.nav_internal ->
                    activity.loadDirectory(Environment.getExternalStorageDirectory())
                R.id.nav_android_data -> activity.openAndroidDataFolder()
                R.id.nav_android_data_saf -> activity.openAndroidDataFolderSaf()
                R.id.nav_removable -> {
                    val removable = activity.getRemovableStorageDirectories().firstOrNull()
                    if (removable != null) activity.loadDirectory(removable)
                    else Toast.makeText(activity, "ไม่พบ SD Card / USB ที่เชื่อมต่ออยู่", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_minecraft -> {
                    val d = File(Environment.getExternalStorageDirectory(), "KORN/MinecraftAddons")
                    d.mkdirs()
                    activity.loadDirectory(d)
                }
                R.id.nav_minecraft_tools -> MinecraftAddonTools.showTools(activity, activity.viewModel.currentDir.value)
                R.id.nav_recent -> activity.loadRecentFolders()
                R.id.nav_clear_recent -> activity.clearRecentHistory()
                R.id.nav_bookmarks -> activity.manageBookmarksDialog()
                R.id.nav_trash -> activity.loadTrash()
                R.id.nav_analyzer -> activity.startActivity(
                    android.content.Intent(activity, StorageAnalyzerActivity::class.java)
                )
                R.id.nav_theme -> activity.showThemeDialog()
            }
            activity.drawerLayout.closeDrawers()
            true
        }
        activity.updateRemovableStorageDrawerItem()
        setupDrawerQuickControls()
        activity.applyThemePalette()
    }

    fun setupDrawerQuickControls() {
        val hiddenItem = activity.navigationView.menu.findItem(R.id.nav_show_hidden)
        val switch = hiddenItem?.actionView as? SwitchMaterial
        activity.drawerHiddenSwitch = switch
        switch?.isChecked = activity.viewModel.showHidden.value
        switch?.setOnCheckedChangeListener { _, checked ->
            if (activity.viewModel.showHidden.value == checked) return@setOnCheckedChangeListener
            activity.viewModel.setShowHidden(checked)
            activity.saveUserPreferences()
            activity.refreshCurrentView()
        }
    }

    internal fun applySort(
        key: MainActivity.SortKey,
        ascending: Boolean,
        onApplied: () -> Unit = { activity.refreshCurrentView() }
    ) {
        activity.viewModel.setSortKey(key)
        activity.viewModel.setSortAscending(ascending)
        activity.saveUserPreferences()
        onApplied()
    }

    fun toggleGridMode() = showViewModeDialog()

    fun applyFileViewMode(mode: FileAdapter.ViewMode) {
        activity.viewModel.setFileViewMode(mode)
        activity.viewModel.setIsGridMode(mode == FileAdapter.ViewMode.GRID)
        activity.recyclerView.layoutManager = if (activity.viewModel.isGridMode.value) {
            GridLayoutManager(activity, 3)
        } else {
            LinearLayoutManager(activity)
        }
        activity.adapter.setViewMode(mode)
        activity.saveUserPreferences()
    }

    fun showViewModeDialog() {
        val labels = arrayOf("รายการปกติ", "รายการขนาดเล็ก", "ตาราง", "รายละเอียด: ขนาด + วันที่")
        val modes = arrayOf(
            FileAdapter.ViewMode.LIST,
            FileAdapter.ViewMode.COMPACT,
            FileAdapter.ViewMode.GRID,
            FileAdapter.ViewMode.DETAILS
        )
        val checked = modes.indexOf(activity.viewModel.fileViewMode.value).coerceAtLeast(0)
        AlertDialog.Builder(activity)
            .setTitle("มุมมองไฟล์")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                applyFileViewMode(modes[which])
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }
}
