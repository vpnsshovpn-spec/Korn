package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.LayoutInflater
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * This activity is registered for android.intent.action.VIEW / SEND with a wildcard
 * mimeType so the app shows up in the system "Open with" chooser for any file type.
 */
class OpenWithActivity : AppCompatActivity() {

    private var incomingUri: Uri? = null
    private var incomingName: String = "unknown"
    private lateinit var bookmarksManager: BookmarksManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_open_with)
        bookmarksManager = BookmarksManager(this)
        ThemeHelper.apply(this)

        incomingUri = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }

        if (incomingUri == null) {
            Toast.makeText(this, "ไม่พบไฟล์ที่ส่งมา", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        incomingName = queryFileName(incomingUri!!) ?: "unnamed_file"

        val isMinecraftArchive =
            MinecraftAddonTools.isArchiveExtension(incomingName.substringAfterLast('.', ""))
        val internalButton = findViewById<android.widget.Button>(R.id.openInternalButton)
        internalButton.visibility = if (isMinecraftArchive) android.view.View.VISIBLE else android.view.View.GONE
        internalButton.setOnClickListener { openIncomingMinecraftArchive() }

        findViewById<TextView>(R.id.fileNameText).text = incomingName
        // Show the real, canonicalized on-disk path for file:// sources (not just the raw
        // string an external app handed us) so the user can see exactly what they're about
        // to share/open before tapping a button.
        val displayInfo = incomingUri!!.let { u ->
            if (u.scheme == "file") {
                u.path?.let { runCatching { File(it).canonicalPath }.getOrNull() } ?: u.toString()
            } else {
                u.toString()
            }
        }
        findViewById<TextView>(R.id.fileInfoText).text = displayInfo

        findViewById<android.widget.Button>(R.id.saveToButton).setOnClickListener {
            showBookmarkChooser()
        }
        findViewById<android.widget.Button>(R.id.browseButton).setOnClickListener {
            openDestinationFolderPicker()
        }
        findViewById<android.widget.Button>(R.id.openAnotherAppButton).setOnClickListener {
            val shareableUri = shareableUriFor(incomingUri!!)
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(shareableUri, mimeTypeFor(incomingUri!!))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "เปิดด้วย"))
        }
        findViewById<android.widget.Button>(R.id.shareButton).setOnClickListener {
            shareIncomingFile()
        }
        findViewById<android.widget.Button>(R.id.closeButton).setOnClickListener { finish() }
    }

    private fun openIncomingMinecraftArchive() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val source = incomingUri ?: throw IllegalArgumentException("ไม่พบ URI")
                val cacheFile = File(cacheDir, "incoming_${System.currentTimeMillis()}_${incomingName}")
                if (source.scheme == "file") {
                    val canonical = File(source.path ?: throw IllegalArgumentException("พาธไม่ถูกต้อง")).canonicalFile
                    canonical.copyTo(cacheFile, overwrite = true)
                } else {
                    contentResolver.openInputStream(source)?.use { input ->
                        cacheFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalArgumentException("อ่านไฟล์ไม่ได้")
                }
                withContext(Dispatchers.Main) {
                    val i = Intent(this@OpenWithActivity, ZipBrowserActivity::class.java)
                    i.putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, cacheFile.absolutePath)
                    startActivity(i)
                    finish()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@OpenWithActivity, "เปิด ${incomingName} ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }
    }

    /**
     * Forwards the file that was opened into this app back out through the system share
     * sheet (e.g. so a PDF someone "opened with" this app can be shared onward to LINE,
     * email, etc.) — the same "open -> share forward" flow other file managers offer.
     */
    private fun shareIncomingFile() {
        val uri = incomingUri ?: return
        try {
            val shareUri = shareableUriFor(uri)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeTypeFor(uri)
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * file:// URIs can't be handed to other apps on modern Android (FileUriExposedException),
     * so route those through our own FileProvider first. content:// URIs from the app that
     * opened us are passed through as-is.
     *
     * SECURITY: incomingUri can come straight from an external app's Intent
     * (ACTION_VIEW/ACTION_SEND on an exported activity). We never trust a file:// path from
     * outside directly: instead of handing FileProvider.getUriForFile() the raw external path
     * (which — combined with our root-path="." FileProvider config and MANAGE_EXTERNAL_STORAGE —
     * would let a third-party app get us to grant content:// read access to *any* file on the
     * device, a classic "confused deputy"), we canonicalize the path and copy the bytes into our
     * own cache dir first, then share a FileProvider Uri that points at *our* cache copy. The
     * external app never gets a grant pointing at the original path.
     */
    private fun shareableUriFor(uri: Uri): Uri {
        if (uri.scheme == "file") {
            val rawPath = uri.path ?: return uri
            val canonical = File(rawPath).canonicalFile
            val cacheFile = File(cacheDir, "share_${System.currentTimeMillis()}_${canonical.name}")
            canonical.inputStream().use { input ->
                cacheFile.outputStream().use { output -> input.copyTo(output) }
            }
            return FileProvider.getUriForFile(this, "$packageName.fileprovider", cacheFile)
        }
        return uri
    }

    private fun mimeTypeFor(uri: Uri): String {
        contentResolver.getType(uri)?.let { return it }
        val ext = incomingName.substringAfterLast('.', "")
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"
    }

    private fun queryFileName(uri: Uri): String? {
        if (uri.scheme == "file") return File(uri.path ?: "").name
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    private fun showBookmarkChooser() {
        val bookmarks = bookmarksManager.getAll()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีบุ๊คมาร์ก โปรดเพิ่มโฟลเดอร์ในแอปหลักก่อน", Toast.LENGTH_LONG).show()
            return
        }
        val names = bookmarks.map { it.name }.toTypedArray()
        KornDialog.Builder(this)
            .setTitle("บันทึกไปที่โฟลเดอร์ไหน?")
            .setItems(names) { _, which ->
                copyToFolder(File(bookmarks[which].path))
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    /**
     * Real "choose destination folder yourself" picker: lets the user navigate the
     * device's folders (starting at external storage root) and copy the incoming
     * file into whichever one they land on — same flow as RS File Explorer's
     * "คัดลอกไปที่" (copy to).
     */
    private fun openDestinationFolderPicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
            Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" ก่อน แล้วกลับมากดเลือกโฟลเดอร์ปลายทางอีกครั้ง", Toast.LENGTH_LONG).show()
            return
        }
        showFolderPickerDialog(Environment.getExternalStorageDirectory())
    }

    // Sort state for the destination-folder picker (image1/"หน้าที่ 2"). Kept separate from
    // MainActivity's own sortKey/sortAscending since this picker is a standalone dialog.
    private var pickerSortKey: PickerSortKey = PickerSortKey.NAME
    private var pickerSortAscending: Boolean = true

    private enum class PickerSortKey { NAME, SIZE, DATE }

    private fun showFolderPickerDialog(startDir: File) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_folder_picker, null)
        val pathText = dialogView.findViewById<TextView>(R.id.currentPathText)
        val listView = dialogView.findViewById<ListView>(R.id.folderListView)
        val newFolderButton = dialogView.findViewById<TextView>(R.id.newFolderInPickerButton)
        val newFileButton = dialogView.findViewById<TextView>(R.id.newFileInPickerButton)
        val sortButton = dialogView.findViewById<TextView>(R.id.sortInPickerButton)

        val dialog = KornDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        var currentDir = startDir
        val rootDir = Environment.getExternalStorageDirectory()

        // Folders sort first (and are the only navigable rows); files are listed too so the
        // user can see what's already in a folder before picking it as the destination.
        // Within that, order follows pickerSortKey/pickerSortAscending (set via the sort
        // dialog below, same options/style as the main list's "เรียงลำดับ" dialog).
        fun childrenOf(dir: File): List<File> {
            val comparator: Comparator<File> = when (pickerSortKey) {
                PickerSortKey.NAME -> compareBy { it.name.lowercase() }
                PickerSortKey.SIZE -> compareBy { it.length() }
                PickerSortKey.DATE -> compareBy { it.lastModified() }
            }
            val ordered = if (pickerSortAscending) comparator else comparator.reversed()
            return (dir.listFiles() ?: emptyArray())
                .filter { !it.name.startsWith(".") }
                .sortedWith(compareBy<File> { !it.isDirectory }.then(ordered))
        }

        fun refresh() {
            pathText.text = currentDir.absolutePath
            val children = childrenOf(currentDir)
            val showUp = currentDir != rootDir
            val labels = mutableListOf<String>()
            if (showUp) labels.add("⬆️  .. (ย้อนกลับ)")
            labels.addAll(children.map { if (it.isDirectory) "📁  ${it.name}" else "📄  ${it.name}" })

            listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
            listView.setOnItemClickListener { _, _, position, _ ->
                if (showUp && position == 0) {
                    currentDir = currentDir.parentFile ?: rootDir
                    refresh()
                    return@setOnItemClickListener
                }
                val target = children[if (showUp) position - 1 else position]
                if (target.isDirectory) {
                    currentDir = target
                    refresh()
                }
                // Tapping a file does nothing - it's shown only so the user can see the folder's contents.
            }
        }
        refresh()

        sortButton.setOnClickListener {
            val options = arrayOf(
                "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
                "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
                "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
            )
            val checked = when {
                pickerSortKey == PickerSortKey.NAME && pickerSortAscending -> 0
                pickerSortKey == PickerSortKey.NAME -> 1
                pickerSortKey == PickerSortKey.SIZE && !pickerSortAscending -> 2
                pickerSortKey == PickerSortKey.SIZE -> 3
                !pickerSortAscending -> 4
                else -> 5
            }
            KornDialog.Builder(this)
                .setTitle("เรียงลำดับ")
                .setSingleChoiceItems(options, checked) { d, which ->
                    when (which) {
                        0 -> { pickerSortKey = PickerSortKey.NAME; pickerSortAscending = true }
                        1 -> { pickerSortKey = PickerSortKey.NAME; pickerSortAscending = false }
                        2 -> { pickerSortKey = PickerSortKey.SIZE; pickerSortAscending = false }
                        3 -> { pickerSortKey = PickerSortKey.SIZE; pickerSortAscending = true }
                        4 -> { pickerSortKey = PickerSortKey.DATE; pickerSortAscending = false }
                        5 -> { pickerSortKey = PickerSortKey.DATE; pickerSortAscending = true }
                    }
                    d.dismiss()
                    refresh()
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        newFileButton.setOnClickListener {
            val input = EditText(this)
            input.hint = "ชื่อไฟล์.txt"
            KornDialog.Builder(this)
                .setTitle("สร้างไฟล์ใหม่")
                .setMessage("ใน ${currentDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newFile = File(currentDir, name)
                    try {
                        when {
                            newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                            newFile.createNewFile() -> refresh()
                            else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        newFolderButton.setOnClickListener {
            val input = EditText(this)
            KornDialog.Builder(this)
                .setTitle("สร้างโฟลเดอร์ใหม่")
                .setMessage("ใน ${currentDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newDir = File(currentDir, name)
                    when {
                        newDir.exists() -> Toast.makeText(this, "มีโฟลเดอร์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                        newDir.mkdirs() -> { currentDir = newDir; refresh() }
                        else -> Toast.makeText(this, "สร้างโฟลเดอร์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        dialogView.findViewById<android.widget.Button>(R.id.chooseFolderHereButton).setOnClickListener {
            dialog.dismiss()
            copyToFolder(currentDir)
        }
        dialogView.findViewById<android.widget.Button>(R.id.cancelFolderPickButton).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun copyToFolder(destDir: File) {
        try {
            if (!destDir.exists()) destDir.mkdirs()
            val destFile = File(destDir, incomingName)
            contentResolver.openInputStream(incomingUri!!)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "บันทึกไปที่ ${destFile.absolutePath} แล้ว", Toast.LENGTH_LONG).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
