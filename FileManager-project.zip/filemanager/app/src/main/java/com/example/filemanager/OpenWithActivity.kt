package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

/**
 * This activity is registered for android.intent.action.VIEW / SEND with mimeType "*/*"
 * so the app shows up in the system "Open with" chooser for any file type.
 */
class OpenWithActivity : AppCompatActivity() {

    private var incomingUri: Uri? = null
    private var incomingName: String = "unknown"
    private lateinit var bookmarksManager: BookmarksManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_open_with)
        bookmarksManager = BookmarksManager(this)

        incomingUri = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }

        if (incomingUri == null) {
            Toast.makeText(this, "ไม่พบไฟล์ที่ส่งมา", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        incomingName = queryFileName(incomingUri!!) ?: "unnamed_file"

        findViewById<TextView>(R.id.fileNameText).text = incomingName
        findViewById<TextView>(R.id.fileInfoText).text = incomingUri.toString()

        findViewById<android.widget.Button>(R.id.saveToButton).setOnClickListener {
            showBookmarkChooser()
        }
        findViewById<android.widget.Button>(R.id.browseButton).setOnClickListener {
            Toast.makeText(this, "เปิด My File Manager แล้วเลือกโฟลเดอร์ จากนั้นกลับมาวางไฟล์ผ่านเมนู \"วางที่นี่\" ได้ (ไฟล์ต้นฉบับยังอยู่ที่แอปเดิม)", Toast.LENGTH_LONG).show()
        }
        findViewById<android.widget.Button>(R.id.openAnotherAppButton).setOnClickListener {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(incomingUri, contentResolver.getType(incomingUri!!) ?: "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "เปิดด้วย"))
        }
        findViewById<android.widget.Button>(R.id.closeButton).setOnClickListener { finish() }
    }

    private fun queryFileName(uri: Uri): String? {
        if (uri.scheme == "file") return File(uri.path ?: "").name
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    private fun showBookmarkChooser() {
        val bookmarks = bookmarksManager.getAll()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีบุ๊คมาร์ก โปรดเพิ่มโฟลเดอร์ในแอปหลักก่อน", Toast.LENGTH_LONG).show()
            return
        }
        val names = bookmarks.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("บันทึกไปที่โฟลเดอร์ไหน?")
            .setItems(names) { _, which ->
                copyToFolder(File(bookmarks[which].path))
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun copyToFolder(destDir: File) {
        try {
            if (!destDir.exists()) destDir.mkdirs()
            val destFile = File(destDir, incomingName)
            contentResolver.openInputStream(incomingUri!!)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "บันทึกไปที่ ${destFile.absolutePath} แล้ว", Toast.LENGTH_LONG).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
