package com.example.filemanager

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast

/**
 * Storage-permission request flow, run once from onCreate() after the initial view/state
 * setup - extracted out of MainActivity.kt (round 11 of the size-reduction plan / STEP 17+).
 * This stays as an extension function on MainActivity, the same pattern as
 * FileClickHelper.kt/FileItemActionsHelper.kt, since it reads/writes a couple of pieces of
 * MainActivity's state directly (awaitingStoragePermission, STORAGE_PERMISSION_CODE) the
 * same way it did as a private method; moving it here only required widening those two from
 * `private` to `internal` in MainActivity.kt so this file (same module) can see them.
 * currentDir is read via viewModel directly (round 19 wrapper removal). No logic or
 * behavior was changed - onRequestPermissionsResult() (the callback for the pre-R permission
 * path below) stays in MainActivity.kt since it's an Activity override and can't be moved
 * out of the class body.
 */

/**
 * Round 17 bug fix: [savedInstanceState] is non-null when onCreate() is running because of
 * an Activity recreate (e.g. screen rotation) rather than a true first launch. Before this
 * fix, the "permission already granted" branches always called loadDirectory(directoryViewModel.currentDir.value),
 * which unconditionally resets mode back to NORMAL - so rotating the screen while in the
 * trash/search/category/apps screen silently kicked the user back to the normal folder view.
 * Now, on a recreate we call refreshCurrentView() instead, which re-loads whatever mode was
 * already active (trash, search with its last query, etc.) into the freshly-created adapter
 * without resetting it. A true first launch (savedInstanceState == null) keeps the exact
 * same behavior as before.
 */
internal fun MainActivity.checkPermissionsAndLoad(savedInstanceState: android.os.Bundle?) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        if (!Environment.isExternalStorageManager()) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
            awaitingStoragePermission = true
            Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" แล้วกลับมาที่แอป", Toast.LENGTH_LONG).show()
        } else if (savedInstanceState == null) {
            loadDirectory(directoryViewModel.currentDir.value)
        } else {
            refreshCurrentView()
        }
    } else {
        if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), STORAGE_PERMISSION_CODE
            )
        } else if (savedInstanceState == null) {
            loadDirectory(directoryViewModel.currentDir.value)
        } else {
            refreshCurrentView()
        }
    }
}
