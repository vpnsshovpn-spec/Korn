package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import com.example.filemanager.data.repository.listFilesCompat
import com.example.filemanager.data.repository.mkdirsCompat

/**
 * Shown instead of MainActivity when another app fires GET_CONTENT, OPEN_DOCUMENT, or PICK.
 * Lets the user browse folders and pick a single file matching the requested mime type(s),
 * then returns its Uri via setResult() - MainActivity is never touched or launched.
 *
 * UI is a floating "dialog" activity (see Theme.FileManager.Dialog in themes.xml) styled to
 * match the reference screenshot: rounded 16dp card, path bar with back/bookmark/sort icons,
 * a scrollable list of folders/files with a trailing radio indicator, and a 3-button footer.
 *
 * Design note: the reference image only shows folders, each with a radio circle. Since this
 * activity's actual job is picking a *file* (not a folder) for GET_CONTENT/OPEN_DOCUMENT, the
 * radio is wired to files that match the requested mime type - tapping a folder row navigates
 * into it, tapping a matching file row marks it as the current selection, and "เลือก" returns
 * whichever file is currently selected.
 */
class PickerActivity : AppCompatActivity() {

    private lateinit var bookmarksManager: BookmarksManager
    private lateinit var pathText: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnSelect: TextView

    private var currentDir: File = Environment.getExternalStorageDirectory()
    private var entries: List<FileEntry> = emptyList()
    private var selectedFile: File? = null
    private var sortKey = 0 // 0 = name, 1 = date, 2 = size

    private var allowedMimeTypes: List<String> = listOf("*/*")
    private var isOpenDocument = false

    private lateinit var adapter: PickerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_picker)
        sizeWindow()

        bookmarksManager = BookmarksManager(this)
        resolveMimeFilter()

        val (primary, _, _) = ThemeHelper.colors(this)

        findViewById<ImageView>(R.id.btnUp).setColorFilter(android.graphics.Color.DKGRAY)
        findViewById<ImageView>(R.id.btnBookmark).setColorFilter(primary)
        findViewById<ImageView>(R.id.btnSort).setColorFilter(primary)

        pathText = findViewById(R.id.pickerPath)
        recyclerView = findViewById(R.id.pickerList)
        btnSelect = findViewById(R.id.btnSelect)
        btnSelect.setTextColor(primary)

        adapter = PickerAdapter(primary)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        findViewById<View>(R.id.btnUp).setOnClickListener { navigateUpOrCancel() }
        findViewById<View>(R.id.btnBookmark).setOnClickListener { showBookmarksDialog() }
        findViewById<View>(R.id.btnSort).setOnClickListener { showSortMenu(it) }
        findViewById<View>(R.id.btnNewFolder).setOnClickListener { showNewFolderDialog() }
        findViewById<View>(R.id.btnCancel).setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
        btnSelect.setOnClickListener { confirmSelection() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                navigateUpOrCancel()
            }
        })

        openDirectory(currentDir)
    }

    /** Floats the activity at ~90% screen width with a transparent window so the rounded card shows. */
    private fun sizeWindow() {
        val widthPx = (resources.displayMetrics.widthPixels * 0.90).toInt()
        val heightPx = (resources.displayMetrics.heightPixels * 0.78).toInt()
        window.setLayout(widthPx, heightPx)
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }

    /** Reads the mime filter another app sent us, whether it used GET_CONTENT, OPEN_DOCUMENT, or PICK. */
    private fun resolveMimeFilter() {
        isOpenDocument = intent?.action == Intent.ACTION_OPEN_DOCUMENT
        val extraTypes = intent?.getStringArrayExtra(Intent.EXTRA_MIME_TYPES)?.toList()
        allowedMimeTypes = when {
            !extraTypes.isNullOrEmpty() -> extraTypes
            !intent?.type.isNullOrEmpty() -> listOf(intent.type!!)
            else -> listOf("*/*")
        }
    }

    private fun matchesFilter(file: File): Boolean {
        if (allowedMimeTypes.any { it == "*/*" }) return true
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: return false
        return allowedMimeTypes.any { allowed ->
            when {
                allowed == mime -> true
                allowed.endsWith("/*") -> mime.startsWith(allowed.removeSuffix("*"))
                else -> false
            }
        }
    }

    private fun openDirectory(dir: File) {
        val children = dir.listFilesCompat()
        if (children == null) {
            Toast.makeText(this, "เปิดโฟลเดอร์นี้ไม่ได้", Toast.LENGTH_SHORT).show()
            return
        }
        currentDir = dir
        selectedFile = null
        btnSelect.alpha = 0.5f

        val folders = children.filter { it.isDirectory && !it.name.startsWith(".") }
        val files = children.filter { !it.isDirectory && !it.name.startsWith(".") && matchesFilter(it) }
        val all = (folders + files).map { FileEntry(it) }

        entries = sortEntries(all)
        pathText.text = currentDir.absolutePath + "/"
        adapter.submit(entries, resetSelection = true)
    }

    private fun sortEntries(list: List<FileEntry>): List<FileEntry> {
        val comparator: Comparator<FileEntry> = when (sortKey) {
            1 -> compareBy { it.file.lastModified() }
            2 -> compareBy { if (it.isDirectory) 0L else it.file.length() }
            else -> compareBy { it.file.name.lowercase() }
        }
        // Folders always float above files, regardless of the chosen sort key.
        return list.sortedWith(compareBy<FileEntry> { !it.isDirectory }.then(comparator))
    }

    private fun navigateUpOrCancel() {
        val parent = currentDir.parentFile
        val root = Environment.getExternalStorageDirectory()
        if (parent != null && currentDir.absolutePath != root.absolutePath) {
            openDirectory(parent)
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun onRowTapped(entry: FileEntry) {
        if (entry.isDirectory) {
            openDirectory(entry.file)
        } else {
            selectedFile = entry.file
            btnSelect.alpha = 1f
            adapter.setSelected(entry.file)
        }
    }

    private fun confirmSelection() {
        val file = selectedFile
        if (file == null) {
            Toast.makeText(this, "เลือกไฟล์ก่อน", Toast.LENGTH_SHORT).show()
            return
        }
        val uri: Uri = try {
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        } catch (e: Exception) {
            Toast.makeText(this, "ส่งไฟล์นี้ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
            return
        }
        var flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (isOpenDocument) flags = flags or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        val result = Intent().setData(uri).addFlags(flags)
        setResult(RESULT_OK, result)
        finish()
    }

    private fun showSortMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 0, 0, "ชื่อ")
        popup.menu.add(0, 1, 1, "วันที่แก้ไข")
        popup.menu.add(0, 2, 2, "ขนาด")
        popup.setOnMenuItemClickListener { item ->
            sortKey = item.itemId
            entries = sortEntries(entries)
            adapter.submit(entries, resetSelection = false)
            true
        }
        popup.show()
    }

    private fun showBookmarksDialog() {
        val bookmarks = bookmarksManager.getAll()
        val names = (bookmarks.map { it.name } + "★ เพิ่มโฟลเดอร์นี้เป็นบุ๊คมาร์ค").toTypedArray()
        KornDialog.Builder(this)
            .setTitle("บุ๊คมาร์ค")
            .setItems(names) { _, which ->
                if (which == bookmarks.size) {
                    bookmarksManager.add(currentDir.name.ifEmpty { "Storage" }, currentDir.absolutePath)
                    Toast.makeText(this, "เพิ่มบุ๊คมาร์คแล้ว", Toast.LENGTH_SHORT).show()
                } else {
                    val target = File(bookmarks[which].path)
                    if (target.isDirectory) openDirectory(target)
                }
            }
            .setNegativeButton("ปิด", null)
            .show()
    }

    private fun showNewFolderDialog() {
        val input = EditText(this)
        input.hint = "ชื่อโฟลเดอร์"
        KornDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val created = File(currentDir, name)
                    if (!created.exists() && created.mkdirsCompat()) {
                        openDirectory(currentDir)
                    } else {
                        Toast.makeText(this, "สร้างโฟลเดอร์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    /** Simple RecyclerView.Adapter for the folder/file rows - kept private to this activity. */
    private inner class PickerAdapter(private val accentColor: Int) :
        RecyclerView.Adapter<PickerAdapter.Holder>() {

        private var items: List<FileEntry> = emptyList()
        private var selectedPath: String? = null

        fun submit(newItems: List<FileEntry>, resetSelection: Boolean) {
            items = newItems
            if (resetSelection) selectedPath = null
            notifyDataSetChanged()
        }

        fun setSelected(file: File) {
            selectedPath = file.absolutePath
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_picker_entry, parent, false)
            return Holder(view)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val entry = items[position]
            holder.name.text = entry.displayName ?: entry.file.name
            holder.icon.setImageResource(if (entry.isDirectory) R.drawable.ic_picker_folder else R.drawable.ic_picker_file)
            holder.icon.setColorFilter(if (entry.isDirectory) accentColor else android.graphics.Color.GRAY)
            holder.radio.isChecked = !entry.isDirectory && entry.file.absolutePath == selectedPath
            holder.radio.visibility = if (entry.isDirectory) View.INVISIBLE else View.VISIBLE
            holder.itemView.setOnClickListener { onRowTapped(entry) }
        }

        override fun getItemCount(): Int = items.size

        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.entryIcon)
            val name: TextView = view.findViewById(R.id.entryName)
            val radio: RadioButton = view.findViewById(R.id.entryRadio)
        }
    }
}
