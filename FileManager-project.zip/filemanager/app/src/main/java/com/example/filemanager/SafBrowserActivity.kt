package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat

/**
 * Browses whatever tree Uri the user granted through the system folder
 * picker (ACTION_OPEN_DOCUMENT_TREE) - this is the only way to reach
 * folders like other apps' Android/data on Android 11+, since Google
 * blocks both MANAGE_EXTERNAL_STORAGE and SAF root/Android-data access
 * at the OS level. Whether the picker even lets the user select such a
 * folder depends entirely on the device/OEM - this activity just makes
 * the most of whatever Uri comes back.
 *
 * Uses DocumentFile instead of java.io.File because a SAF tree Uri has
 * no real filesystem path the rest of the app's File-based code can use.
 */
class SafBrowserActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var pathLabel: TextView
    private lateinit var emptyLabel: TextView
    private lateinit var adapter: SafAdapter

    private lateinit var rootUri: Uri
    private lateinit var rootDoc: DocumentFile
    private val stack = mutableListOf<DocumentFile>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriString = intent.getStringExtra(EXTRA_TREE_URI)
        if (uriString == null) {
            Toast.makeText(this, "ไม่พบโฟลเดอร์ที่เลือก", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        rootUri = Uri.parse(uriString)
        val doc = DocumentFile.fromTreeUri(this, rootUri)
        if (doc == null || !doc.exists()) {
            Toast.makeText(this, "เปิดโฟลเดอร์นี้ไม่ได้ (อาจถูกระบบปิดกั้น)", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        rootDoc = doc
        stack.add(rootDoc)

        setContentView(buildView())
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        ThemeHelper.apply(this)
        adapter = SafAdapter(
            onClick = { entry -> onEntryClick(entry) },
            onLongClick = { entry -> onEntryLongClick(entry) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        loadCurrent()
    }

    override fun onSupportNavigateUp(): Boolean {
        if (!goUpOrFinish()) finish()
        return true
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (!goUpOrFinish()) super.onBackPressed()
    }

    private fun goUpOrFinish(): Boolean {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            loadCurrent()
            return true
        }
        return false
    }

    private fun buildView(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resources.getColor(R.color.background, theme))
        }
        pathLabel = TextView(this).apply {
            setPadding(24, 16, 24, 8)
            textSize = 12f
            setTextColor(resources.getColor(R.color.text_secondary, theme))
        }
        emptyLabel = TextView(this).apply {
            text = "โฟลเดอร์นี้ว่างเปล่า"
            setPadding(24, 40, 24, 40)
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(resources.getColor(R.color.text_secondary, theme))
            visibility = View.GONE
        }
        recyclerView = RecyclerView(this)
        root.addView(pathLabel)
        root.addView(emptyLabel)
        root.addView(recyclerView, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun loadCurrent() {
        val current = stack.last()
        supportActionBar?.title = current.name ?: "โฟลเดอร์"
        pathLabel.text = stack.joinToString(" / ") { it.name ?: "?" }
        emptyLabel.visibility = View.GONE
        adapter.submit(emptyList())
        lifecycleScope.launch {
            val children = withContext(Dispatchers.IO) {
                try {
                    current.listFiles().toList().sortedWith(
                        compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name ?: "" }
                    )
                } catch (e: Exception) {
                    null
                }
            }
            if (children == null) {
                Toast.makeText(this@SafBrowserActivity, "อ่านโฟลเดอร์นี้ไม่ได้", Toast.LENGTH_SHORT).show()
                emptyLabel.text = "อ่านโฟลเดอร์นี้ไม่ได้"
                emptyLabel.visibility = View.VISIBLE
                return@launch
            }
            adapter.submit(children)
            emptyLabel.visibility = if (children.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun onEntryClick(entry: DocumentFile) {
        if (entry.isDirectory) {
            stack.add(entry)
            loadCurrent()
        } else {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(entry.uri, entry.type ?: "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "เปิดไฟล์นี้ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun onEntryLongClick(entry: DocumentFile): Boolean {
        val options = mutableListOf("แชร์")
        if (entry.canWrite()) options.add("ลบ")
        AlertDialog.Builder(this)
            .setTitle(entry.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "แชร์" -> {
                        try {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = entry.type ?: "*/*"
                                putExtra(Intent.EXTRA_STREAM, entry.uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
                        } catch (e: Exception) {
                            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    "ลบ" -> {
                        AlertDialog.Builder(this)
                            .setTitle("ลบ \"${entry.name}\"?")
                            .setMessage(if (entry.isDirectory) "ลบทั้งโฟลเดอร์และไฟล์ข้างในทั้งหมด ไม่สามารถกู้คืนได้" else "ไม่สามารถกู้คืนได้")
                            .setPositiveButton("ลบ") { _, _ ->
                                lifecycleScope.launch {
                                    val ok = withContext(Dispatchers.IO) {
                                        try { entry.delete() } catch (e: Exception) { false }
                                    }
                                    Toast.makeText(
                                        this@SafBrowserActivity,
                                        if (ok) "ลบแล้ว" else "ลบไม่สำเร็จ",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    if (ok) loadCurrent()
                                }
                            }
                            .setNegativeButton("ยกเลิก", null)
                            .show()
                    }
                }
            }
            .show()
        return true
    }

    companion object {
        const val EXTRA_TREE_URI = "tree_uri"
    }
}

private class SafAdapter(
    private val onClick: (DocumentFile) -> Unit,
    private val onLongClick: (DocumentFile) -> Boolean
) : RecyclerView.Adapter<SafAdapter.VH>() {

    private var items: List<DocumentFile> = emptyList()
    private val sizeFormat = DecimalFormat("#,##0.#")

    fun submit(newItems: List<DocumentFile>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val row = LinearLayout(parent.context).apply {
            orientation = LinearLayout.HORIZONTAL
            val density = parent.context.resources.displayMetrics.density
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())
            layoutParams = RecyclerView.LayoutParams(-1, -2)
        }
        val icon = TextView(parent.context).apply {
            textSize = 20f
            val density = parent.context.resources.displayMetrics.density
            layoutParams = LinearLayout.LayoutParams((32 * density).toInt(), -2)
        }
        val textColumn = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
                val density = parent.context.resources.displayMetrics.density
                marginStart = (12 * density).toInt()
            }
        }
        val name = TextView(parent.context).apply { textSize = 15f }
        val subtitle = TextView(parent.context).apply {
            textSize = 12f
            setTextColor(parent.context.resources.getColor(R.color.text_secondary, parent.context.theme))
        }
        textColumn.addView(name)
        textColumn.addView(subtitle)
        row.addView(icon)
        row.addView(textColumn)
        return VH(row, name, subtitle, icon)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        holder.name.text = entry.name ?: "?"
        holder.icon.text = if (entry.isDirectory) "\uD83D\uDCC1" else "\uD83D\uDCC4"
        holder.subtitle.text = if (entry.isDirectory) {
            "โฟลเดอร์"
        } else {
            "${sizeFormat.format(entry.length() / 1024.0)} KB"
        }
        holder.itemView.setOnClickListener { onClick(entry) }
        holder.itemView.setOnLongClickListener { onLongClick(entry) }
    }

    override fun getItemCount(): Int = items.size

    class VH(view: View, val name: TextView, val subtitle: TextView, val icon: TextView) :
        RecyclerView.ViewHolder(view)
}
