package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Alternative to the Shizuku path for reaching /Android/data: instead of a
 * privileged remote process, this uses Android's own Storage Access
 * Framework (SAF) — the user picks the Android/data folder once in the
 * system document picker and grants this app a persistable Uri permission
 * to it. No extra app, no ADB/root needed, but the grant only covers the
 * tree the user picked (not arbitrary paths), and everything here works
 * through [DocumentFile]/content Uris rather than plain java.io.File.
 */
class SafDataBrowserActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var pathText: TextView
    private lateinit var emptyText: TextView
    private lateinit var adapter: SafEntryAdapter

    private lateinit var rootDoc: DocumentFile
    private val backStack = ArrayDeque<DocumentFile>()
    private var currentDoc: DocumentFile? = null
    private var entries: List<DocumentFile> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saf_browser)

        val treeUriString = intent.getStringExtra(EXTRA_TREE_URI)
        val treeUri = treeUriString?.let { Uri.parse(it) }
        val root = treeUri?.let { DocumentFile.fromTreeUri(this, it) }
        if (root == null || !root.exists() || !root.isDirectory) {
            Toast.makeText(this, "ไม่พบสิทธิ์เข้าถึงโฟลเดอร์นี้", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        rootDoc = root
        currentDoc = root

        val toolbar = findViewById<Toolbar>(R.id.safToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Android/data (SAF)"
        ThemeHelper.apply(this, toolbar)

        pathText = findViewById(R.id.safPathText)
        emptyText = findViewById(R.id.safEmptyText)
        listView = findViewById(R.id.safEntryList)
        adapter = SafEntryAdapter()
        listView.adapter = adapter

        swipeRefresh = findViewById(R.id.safSwipeRefresh)
        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { load() }

        listView.setOnItemClickListener { _, _, position, _ ->
            val doc = entries.getOrNull(position) ?: return@setOnItemClickListener
            if (doc.isDirectory) {
                backStack.addLast(currentDoc!!)
                currentDoc = doc
                load()
            } else {
                openDocument(doc)
            }
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            val doc = entries.getOrNull(position) ?: return@setOnItemLongClickListener true
            showEntryMenu(doc)
            true
        }

        load()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedCompat()
        return true
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        onBackPressedCompat()
    }

    private fun onBackPressedCompat() {
        if (backStack.isNotEmpty()) {
            currentDoc = backStack.removeLast()
            load()
        } else {
            finish()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.saf_browser_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> { onBackPressedCompat(); return true }
            R.id.saf_new_folder -> newFolderDialog()
            R.id.saf_refresh -> load()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun load() {
        val dir = currentDoc ?: return
        pathText.text = dir.name ?: "/"
        swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val children = withContext(Dispatchers.IO) {
                try {
                    dir.listFiles()
                        .filter { it.name != null }
                        .sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { it.name?.lowercase() })
                } catch (e: Exception) {
                    emptyList()
                }
            }
            entries = children
            adapter.notifyDataSetChanged()
            emptyText.visibility = if (children.isEmpty()) View.VISIBLE else View.GONE
            swipeRefresh.isRefreshing = false
        }
    }

    private fun openDocument(doc: DocumentFile) {
        val options = arrayOf("เปิดด้วยแอปอื่น…", "คัดลอกออกไปที่พื้นที่จัดเก็บปกติ")
        KornDialog.Builder(this)
            .setTitle(doc.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openExternally(doc)
                    1 -> copyOut(doc)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openExternally(doc: DocumentFile) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc.uri, doc.type ?: "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /** Copies a SAF document down into this app's own KORN/FromAndroidData folder. */
    private fun copyOut(doc: DocumentFile) {
        Toast.makeText(this, "กำลังคัดลอกออก…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val destDir = File(
                android.os.Environment.getExternalStorageDirectory(), "KORN/FromAndroidData"
            )
            val ok = withContext(Dispatchers.IO) {
                try {
                    destDir.mkdirs()
                    val dest = File(destDir, doc.name ?: "file")
                    contentResolver.openInputStream(doc.uri)?.use { input ->
                        dest.outputStream().use { output -> input.copyTo(output) }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            Toast.makeText(
                this@SafDataBrowserActivity,
                if (ok) "คัดลอกไปที่ KORN/FromAndroidData แล้ว" else "คัดลอกไม่สำเร็จ",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun showEntryMenu(doc: DocumentFile) {
        val options = mutableListOf("เปลี่ยนชื่อ", "ลบ")
        if (!doc.isDirectory) options.add(0, "คัดลอกออกไปที่พื้นที่จัดเก็บปกติ")
        KornDialog.Builder(this)
            .setTitle(doc.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "เปลี่ยนชื่อ" -> renameDialog(doc)
                    "ลบ" -> confirmDelete(doc)
                    "คัดลอกออกไปที่พื้นที่จัดเก็บปกติ" -> copyOut(doc)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameDialog(doc: DocumentFile) {
        val input = EditText(this).apply { setText(doc.name) }
        KornDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val ok = try { doc.renameTo(newName) } catch (e: Exception) { false }
                    if (ok) load() else Toast.makeText(this, "เปลี่ยนชื่อไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun confirmDelete(doc: DocumentFile) {
        KornDialog.Builder(this)
            .setTitle("ลบ ${doc.name}?")
            .setMessage("การลบผ่านช่องทางนี้ลบถาวรทันที ไม่ผ่านถังขยะ")
            .setPositiveButton("ลบ") { _, _ ->
                val ok = try { doc.delete() } catch (e: Exception) { false }
                if (ok) load() else Toast.makeText(this, "ลบไม่สำเร็จ", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun newFolderDialog() {
        val dir = currentDoc ?: return
        val input = EditText(this)
        KornDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    dir.createDirectory(name)
                    load()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        return DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }

    private inner class SafEntryAdapter : BaseAdapter() {
        override fun getCount() = entries.size
        override fun getItem(position: Int) = entries[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(this@SafDataBrowserActivity)
                .inflate(R.layout.item_file_compact, parent, false)
            val doc = entries[position]
            val icon = view.findViewById<FileIconView>(R.id.icon)
            val name = view.findViewById<TextView>(R.id.name)
            val subtitle = view.findViewById<TextView>(R.id.subtitle)
            val df = SimpleDateFormat("d MMM yyyy HH:mm", Locale("th"))

            name.text = doc.name ?: "?"
            if (doc.isDirectory) {
                icon.setFolderIcon(true)
                subtitle.text = df.format(Date(doc.lastModified()))
            } else {
                val ext = (doc.name ?: "").substringAfterLast('.', "")
                icon.setFileIconText(if (ext.isNotEmpty()) ext.take(4).uppercase() else "?")
                subtitle.text = "${readableSize(doc.length())} • ${df.format(Date(doc.lastModified()))}"
            }
            return view
        }
    }

    companion object {
        const val EXTRA_TREE_URI = "extra_tree_uri"
    }
}
