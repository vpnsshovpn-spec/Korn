package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.data.repository.FileScanner
import com.example.filemanager.data.search.SearchIndexManager

/**
 * Round 2 (MainViewModel split, step 4 of 4 - see refactor-instructions.txt): text/content
 * search (SearchUiState, onSearchQueryChanged()/runSearchImmediate()/runSearchNow(),
 * lastSearchQuery/lastSearchContentEnabled, the search dialog-open flag) and the Local Search
 * Index attach point now live here instead of MainViewModel - same pure-move, no-logic-change
 * caution as steps 1-3 ("ห้ามแก้ชื่อคลาส/ฟังก์ชันระหว่างย้าย"). This is the last of the 4 steps:
 * MainViewModel now holds only themeKey.
 *
 * No UiEvent/events flow here (unlike DirectoryViewModel.toastEvents or
 * ArchiveOperationViewModel.events): none of the moved search code ever emitted a one-off event
 * through MainViewModel's old shared _events - runSearchNow() reports everything, including its
 * failure case, through [searchUiState] itself, so there's nothing to replicate.
 */
class SearchFilterViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    private val directoryBrowserHelper = DirectoryBrowserHelper()

    // ---------- Local Search Index (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6) ----------

    private var searchIndexManager: SearchIndexManager? = null

    /**
     * เรียกครั้งเดียวจาก MainActivity.onCreate() ทันทีหลังสร้าง SearchIndexManager
     * SearchFilterViewModel สร้างผ่าน `by viewModels()` (no-arg constructor ตามแพทเทิร์นเดิมของ
     * โปรเจกต์) จึงรับ SearchIndexManager ผ่าน constructor ตรงๆ ไม่ได้โดยไม่เพิ่ม Factory
     * ที่โปรเจกต์นี้ไม่เคยใช้มาก่อน — attach แบบนี้แทน ไม่ผูก SearchIndexManager เป็น
     * singleton object ลอยๆ ตามที่แผนกำหนดไว้ (ข้อ 6.1)
     *
     * SearchIndexManager เก็บแค่ applicationContext ไว้ภายในตัวเอง (ดู
     * SearchIndexManager.appContext) การเก็บ reference นี้ไว้ใน ViewModel ข้าม config
     * change (เช่น หมุนจอ) จึงไม่ leak Activity — เรียกซ้ำได้ทุก onCreate เฉยๆ แค่แทนที่
     * ด้วย instance ใหม่ที่ชี้ไปที่ Room DB ไฟล์เดิม
     */
    fun attachSearchIndexManager(manager: SearchIndexManager) {
        searchIndexManager = manager
    }

    // ---------- Text/content search query + options ----------

    private val _lastSearchQuery = MutableStateFlow(savedStateHandle.get<String>(KEY_SEARCH_QUERY))
    val lastSearchQuery: StateFlow<String?> = _lastSearchQuery
    fun setLastSearchQuery(value: String?) {
        _lastSearchQuery.value = value
        savedStateHandle[KEY_SEARCH_QUERY] = value
    }

    private val _lastSearchContentEnabled = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_CONTENT) ?: false
    )
    val lastSearchContentEnabled: StateFlow<Boolean> = _lastSearchContentEnabled
    fun setLastSearchContentEnabled(value: Boolean) {
        _lastSearchContentEnabled.value = value
        savedStateHandle[KEY_SEARCH_CONTENT] = value
    }

    // ---------- Dialog-open flag (Rotation Safety #4) ----------

    // Rotation Safety #4: "ค้นหาไฟล์" (SearchHelper.kt) is a plain KornDialog.Builder dialog,
    // not backed by any ViewModel-held batch the way the Rotation Safety #2 conflict dialogs
    // are. That's fine for a rotation (FragmentManager recreates the DialogFragment itself, and
    // KornDialog.take() still finds the spec in the in-memory map because the process never
    // died), but it fails silently on a real process death: KornDialogFragment.onCreate()'s
    // spec = specId?.let { KornDialog.take(it) } comes back null (the static specs map was
    // wiped along with the rest of the process), so the restored fragment just calls
    // dismissAllowingStateLoss() on itself - the dialog never reappears and nothing tells the
    // user it's gone.
    //
    // Same fix shape as Rotation Safety #2: a plain "is this dialog open" flag lives here,
    // backed by SavedStateHandle so it survives process death too. The entry point
    // (searchDialog()) only flips this flag to true; the actual KornDialog.Builder call
    // happens in SearchHelper.kt's observeSearchDialogOpenState(), which reacts to the flow the
    // same way on a normal open, a rotation, and a process-death relaunch alike - collect()
    // always replays the latest value to a fresh STARTED collector. The dialog's own
    // setOnDismissListener flips the flag back to false on every real dismissal (button tap,
    // outside touch, back press) - never called for the transient teardown a rotation causes,
    // per KornDialogFragment.onDismiss()'s doc comment, so rotation restore is unaffected.
    //
    // No extra state needs to be persisted for the search dialog's typed text/checkbox - those
    // already live in lastSearchQuery/lastSearchContentEnabled above (kept in sync on every
    // keystroke by onSearchQueryChanged()), so whenever the dialog is rebuilt it pre-fills
    // correctly regardless of why it's reappearing.

    private val _searchDialogOpen = MutableStateFlow(
        savedStateHandle.get<Boolean>(KEY_SEARCH_DIALOG_OPEN) ?: false
    )
    val searchDialogOpen: StateFlow<Boolean> = _searchDialogOpen
    fun setSearchDialogOpen(open: Boolean) {
        _searchDialogOpen.value = open
        savedStateHandle[KEY_SEARCH_DIALOG_OPEN] = open
    }

    // ---------- Search UI & Dynamic Performance ----------

    /**
     * Drives the search screen's visibility state. Loading shows the centered progress
     * wheel, Empty shows the folder+magnifier placeholder, Success renders the results into
     * the normal file list, Error surfaces a message. See SearchHelper.kt for the
     * MainActivity-side rendering of each state.
     */
    sealed class SearchUiState {
        object Loading : SearchUiState()
        object Empty : SearchUiState()
        data class Success(val entries: List<FileEntry>) : SearchUiState()
        data class Error(val message: String) : SearchUiState()
    }

    private val _searchUiState = MutableStateFlow<SearchUiState>(SearchUiState.Loading)
    val searchUiState: StateFlow<SearchUiState> = _searchUiState

    // Mode.SEARCH is reused by the unrelated "recent folders" screen (loadRecentFolders() in
    // WindowsAndHistoryHelper.kt), which never touches searchUiState. This flag is what actually
    // tells SearchHelper.kt's overlay observer "a real text search is active right now" so it
    // doesn't render a stale Loading/Empty/Success overlay on top of that screen instead.
    private val _searchActive = MutableStateFlow(false)
    val searchActive: StateFlow<Boolean> = _searchActive

    /** Called from loadRecentFolders() and anywhere else that reuses Mode.SEARCH for something else. */
    fun clearSearchOverlay() {
        searchJob?.cancel()
        _searchActive.value = false
    }

    private var searchJob: Job? = null

    /**
     * Debounced entry point for live typing in the search box: waits [SEARCH_DEBOUNCE_MS]
     * after the last keystroke, and unconditionally cancels any in-flight search job first
     * so a fast typist never has two scans racing to publish [searchUiState].
     */
    // sortKey/sortAscending live on DirectoryViewModel (moved there in step 1), not here -
    // runSearchNow() needs them for its result comparator, so both entry points below take them
    // as explicit parameters instead of reading local state, the same way [showHidden] already
    // was passed in. Callers pass directoryViewModel.sortKey.value/
    // directoryViewModel.sortAscending.value (see SearchHelper.kt).
    internal fun onSearchQueryChanged(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        if (query.isBlank()) {
            _searchUiState.value = SearchUiState.Empty
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending)
        }
    }

    /** Same scan, no debounce wait - used for the dialog's "ค้นหา" button and refresh/rotation. */
    internal fun runSearchImmediate(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        searchJob?.cancel()
        _searchActive.value = true
        setLastSearchQuery(query)
        setLastSearchContentEnabled(searchContent)
        searchJob = viewModelScope.launch { runSearchNow(query, searchContent, root, showHidden, sortKey, sortAscending) }
    }

    /**
     * Hybrid strategy (รอบ 2 — ดู search-index-project-plan.txt ข้อ 6.1): searchContent == true
     * ยังเดินสแกนสดผ่าน FileScanner เหมือนเดิมเสมอ (ค้นเนื้อไฟล์ไม่ทำ index ตามที่ตกลงกัน)
     * ส่วน searchContent == false (ค้นชื่ออย่างเดียว) เปลี่ยนไป query จาก
     * [SearchIndexManager] แทนการเดินดิสก์สด "ถ้า" index ถูก build ไปแล้วอย่างน้อยหนึ่งครั้ง
     * (searchIndexManager != null && !isEmpty()) — ถ้า index ยังว่างอยู่ (เช่นเปิดแอปครั้งแรก
     * แล้ว rebuildFullIndex() ตอน initialize() ยังทำงานไม่เสร็จ) ให้ fallback ไปเดินสแกนสด
     * แบบเดิมแทนที่จะคืนผลว่างเปล่า เพื่อไม่ให้ประสบการณ์แย่ลงกว่าเดิมในช่วงสั้นๆ นั้น
     */
    private suspend fun runSearchNow(
        query: String,
        searchContent: Boolean,
        root: File,
        showHidden: Boolean,
        sortKey: MainActivity.SortKey,
        sortAscending: Boolean
    ) {
        _searchUiState.value = SearchUiState.Loading
        try {
            val results = withContext(Dispatchers.IO) {
                val indexManager = searchIndexManager
                if (!searchContent && indexManager != null && !indexManager.isEmpty()) {
                    indexManager.search(query, showHidden).map { FileScanner.ContentMatch(it, "") }
                } else {
                    FileScanner.searchByNameAndContent(root, query, showHidden, searchContent)
                }
            }
            val comparator = directoryBrowserHelper.comparator(sortKey, sortAscending)
            val entries = results.map { match ->
                FileEntry(match.file, subtitleOverride = match.line.ifEmpty { null })
            }.sortedWith(comparator)
            _searchUiState.value = if (entries.isEmpty()) SearchUiState.Empty else SearchUiState.Success(entries)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _searchUiState.value = SearchUiState.Error(e.message ?: "เกิดข้อผิดพลาดในการค้นหา")
        }
    }

    companion object {
        private const val SEARCH_DEBOUNCE_MS = 250L
        private const val KEY_SEARCH_QUERY = "search_query"
        private const val KEY_SEARCH_CONTENT = "search_content"
        private const val KEY_SEARCH_DIALOG_OPEN = "search_dialog_open"
    }
}
