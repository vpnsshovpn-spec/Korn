package com.example.filemanager

import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * File/content search: the search dialog, the search run + result rendering, the match
 * highlighter, and the toolbar search button that opens the dialog - extracted out of
 * MainActivity.kt (round 6 of the size-reduction plan). No logic changed, only location +
 * widening dp() from private to internal so this file can call it. lastSearchQuery/
 * lastSearchContentEnabled are read via viewModel directly (round 18 wrapper removal).
 */

internal fun MainActivity.searchDialog() {
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = (16 * resources.displayMetrics.density).toInt()
        setPadding(pad, pad / 2, pad, 0)
    }
    val input = EditText(this)
    input.hint = "ชื่อไฟล์หรือโฟลเดอร์"
    container.addView(input, LinearLayout.LayoutParams(-1, -2))

    val contentCheckbox = android.widget.CheckBox(this).apply {
        text = "ค้นหาในเนื้อหาไฟล์ด้วย"
        isChecked = viewModel.lastSearchContentEnabled.value
    }
    container.addView(contentCheckbox, LinearLayout.LayoutParams(-1, -2))

    AlertDialog.Builder(this)
        .setTitle("ค้นหาไฟล์")
        .setView(container)
        .setPositiveButton("ค้นหา") { _, _ ->
            val q = input.text.toString().trim()
            val contentChecked = contentCheckbox.isChecked
            if (q.isNotEmpty()) {
                // Round 17 bug fix: submitting the exact same query (same text, same
                // "search file content" toggle) while its results are already on screen
                // used to re-scan the whole storage from scratch for nothing. Skip only
                // that exact case; a genuinely new search, or a refresh triggered by
                // rotation/pull-to-refresh (which call runSearch() directly, not this
                // dialog), still run normally.
                val isSameAsCurrentSearch = mode == MainActivity.Mode.SEARCH &&
                    q == viewModel.lastSearchQuery.value && contentChecked == viewModel.lastSearchContentEnabled.value
                viewModel.setLastSearchContentEnabled(contentChecked)
                if (!isSameAsCurrentSearch) {
                    runSearch(q, contentChecked)
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.runSearch(query: String, searchContent: Boolean = viewModel.lastSearchContentEnabled.value) {
    mode = MainActivity.Mode.SEARCH
    trashActionBar.visibility = View.GONE
    viewModel.setLastSearchQuery(query)
    viewModel.setLastSearchContentEnabled(searchContent)
    showSpecialPath("ผลค้นหา: \"$query\"")
    supportActionBar?.subtitle = if (searchContent) "กำลังค้นหา (รวมเนื้อหาไฟล์)..." else "กำลังค้นหา..."
    val root = Environment.getExternalStorageDirectory()
    val hidden = showHidden
    lifecycleScope.launch {
        try {
            val results = withContext(Dispatchers.IO) {
                FileScanner.searchByNameAndContent(root, query, hidden, searchContent)
            }
            swipeRefresh.isRefreshing = false
            if (mode != MainActivity.Mode.SEARCH || viewModel.lastSearchQuery.value != query) return@launch
            val entries = results.map { match ->
                val subtitle = if (match.line.isNotEmpty()) highlightMatch(match.line, query) else null
                FileEntry(match.file, subtitleOverride = subtitle)
            }.sortedWith(comparator())
            adapter.updateItems(entries, showFullPath = true)
            supportActionBar?.subtitle = "${entries.size} รายการ"
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } finally {
            if (!isFinishing && !isDestroyed) swipeRefresh.isRefreshing = false
        }
    }
}

/** Wraps every case-insensitive occurrence of [query] inside [text] with a highlighted span. */
internal fun MainActivity.highlightMatch(text: String, query: String): CharSequence {
    if (query.isEmpty()) return text
    val spannable = android.text.SpannableString(text)
    var start = 0
    while (true) {
        val idx = text.indexOf(query, start, ignoreCase = true)
        if (idx < 0) break
        spannable.setSpan(
            android.text.style.BackgroundColorSpan(0xFFFFEB3B.toInt()),
            idx, idx + query.length,
            android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannable.setSpan(
            android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
            idx, idx + query.length,
            android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        start = idx + query.length
    }
    return spannable
}

internal fun MainActivity.setupToolbarSearchButton() {
    val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
    val button = android.widget.ImageButton(this).apply {
        setImageResource(R.drawable.ic_search)
        background = null
        contentDescription = "ค้นหา"
        setPadding(12, 8, 12, 8)
        setOnClickListener { if (mode != MainActivity.Mode.TRASH && mode != MainActivity.Mode.APPS) searchDialog() }
    }
    val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
        dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL
    )
    toolbar.addView(button, lp)
}
