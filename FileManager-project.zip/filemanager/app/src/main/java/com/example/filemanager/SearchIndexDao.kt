package com.example.filemanager

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/** Local Search Index DAO. Full rebuild APIs remain available as a correctness fallback. */
@Dao
interface SearchIndexDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<SearchIndexEntity>)

    @Query("DELETE FROM search_index")
    suspend fun deleteAll()

    @Query("DELETE FROM search_index WHERE path = :path")
    suspend fun deleteByPath(path: String)

    /** Deletes one path and every indexed descendant below it. [escapedPrefix] must escape \, %, _. */
    @Query("DELETE FROM search_index WHERE path = :path OR path LIKE :escapedPrefix || '/%' ESCAPE '\\'")
    suspend fun deleteByPathOrPrefix(path: String, escapedPrefix: String)

    /**
     * Renames/moves a file or directory and all indexed descendants in one SQL update.
     * The path column is rewritten for the target row and every descendant. The
     * name/nameLowercase/extension columns are only rewritten for the exact target row
     * (path = :oldPath) - descendants keep their own file name, only their path prefix
     * changes. Returns the number of rows updated, so callers can tell whether [oldPath]
     * (and any descendants) were actually present in the index beforehand.
     */
    @Query(
        """
        UPDATE search_index SET
            path = :newPath || substr(path, length(:oldPath) + 1),
            name = CASE WHEN path = :oldPath THEN :newName ELSE name END,
            nameLowercase = CASE WHEN path = :oldPath THEN :newNameLowercase ELSE nameLowercase END,
            extension = CASE WHEN path = :oldPath THEN :newExtension ELSE extension END
        WHERE path = :oldPath OR path LIKE :escapedOldPath || '/%' ESCAPE '\'
        """
    )
    suspend fun renamePathPrefix(
        oldPath: String,
        newPath: String,
        escapedOldPath: String,
        newName: String,
        newNameLowercase: String,
        newExtension: String
    ): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOne(entity: SearchIndexEntity)

    @Query("SELECT * FROM search_index WHERE nameLowercase LIKE '%' || :queryLowercase || '%' ORDER BY name ASC")
    suspend fun searchByName(queryLowercase: String): List<SearchIndexEntity>

    @Query("SELECT COUNT(*) FROM search_index")
    suspend fun count(): Int
}
