package com.example.filemanager

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/**
 * Local Search Index — รอบ 1. ดู [SearchIndexEntity] สำหรับความหมายของแต่ละคอลัมน์
 * และ [SearchIndexManager] สำหรับผู้เรียกใช้ (caller) ตัวจริงของ DAO นี้
 */
@Dao
interface SearchIndexDao {

    /** เขียนทับทั้งก้อน — ถ้า path ซ้ำ (rebuild ใหม่) ให้แทนที่แถวเดิมด้วยแถวใหม่ */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<SearchIndexEntity>)

    @Query("DELETE FROM search_index")
    suspend fun deleteAll()

    /** ใช้เตรียมไว้สำหรับรอบ 2: ค้นหาด้วยชื่อ (LIKE แบบไม่สนตัวพิมพ์ผ่าน nameLowercase ที่คำนวณไว้ล่วงหน้า) */
    @Query("SELECT * FROM search_index WHERE nameLowercase LIKE '%' || :queryLowercase || '%' ORDER BY name ASC")
    suspend fun searchByName(queryLowercase: String): List<SearchIndexEntity>

    /** เอาไว้เช็คว่า index ว่างอยู่หรือยัง (ยังไม่เคย build ครั้งแรก) */
    @Query("SELECT COUNT(*) FROM search_index")
    suspend fun count(): Int
}
