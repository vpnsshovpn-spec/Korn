package com.example.filemanager

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Local Search Index — รอบ 1.
 *
 * เก็บไฟล์ .db ไว้ที่ context.getExternalFilesDir(null) ก่อน (ถ้าใช้ไม่ได้ค่อย
 * fallback ไป internal filesDir) — เลือกแบบเดียวกับ [TrashManager.trashDir] เพื่อ
 * ความสม่ำเสมอของโปรเจกต์ (ดู TrashManager.kt: app-specific external storage ไม่
 * ต้องขอ permission และถูกล้างอัตโนมัติตอนถอนแอปเหมือนกัน)
 */
@Database(entities = [SearchIndexEntity::class], version = 1, exportSchema = false)
abstract class SearchIndexDatabase : RoomDatabase() {

    abstract fun searchIndexDao(): SearchIndexDao

    companion object {
        private const val DB_NAME = "search_index.db"

        @Volatile
        private var instance: SearchIndexDatabase? = null

        fun getInstance(context: Context): SearchIndexDatabase {
            return instance ?: synchronized(this) {
                instance ?: build(context).also { instance = it }
            }
        }

        private fun build(context: Context): SearchIndexDatabase {
            val dbDir = context.applicationContext.getExternalFilesDir(null)
                ?: context.applicationContext.filesDir
            if (!dbDir.exists()) dbDir.mkdirs()
            return Room.databaseBuilder(
                context.applicationContext,
                SearchIndexDatabase::class.java,
                java.io.File(dbDir, DB_NAME).absolutePath
            )
                // รอบ 1 เก็บแค่ index เปล่าๆ ที่ rebuild ใหม่ทั้งก้อนได้เสมอ (deleteAll แล้ว
                // insertAll ใหม่) ไม่มีข้อมูลผู้ใช้ที่ต้อง migrate — fallbackToDestructiveMigration
                // จึงปลอดภัยกว่าการเขียน Migration เปล่าทุกครั้งที่ schema เปลี่ยนในอนาคต
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
