package com.example.filemanager

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Local Search Index. Normal file changes use incremental updates; full rebuild remains
 * available for first build, manual sync and stale-index recovery.
 */
class SearchIndexManager(
    context: Context,
    // Test-only: lets unit tests inject an in-memory Room DAO instead of the real
    // singleton database, so tests don't share state with each other or touch disk.
    // Production call sites never pass this; behavior for them is unchanged.
    daoOverride: SearchIndexDao? = null
) {

    private val appContext = context.applicationContext
    private val dao: SearchIndexDao by lazy { daoOverride ?: SearchIndexDatabase.getInstance(appContext).searchIndexDao() }
    private val updateMutex = Mutex()

    companion object {
        private const val PREFS = "korn_settings"
        private const val LAST_FULL_SYNC = "search_index_last_full_sync"
        const val STALE_THRESHOLD_MS = 24L * 60L * 60L * 1000L
    }

    suspend fun initialize() {
        val now = System.currentTimeMillis()
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastSync = prefs.getLong(LAST_FULL_SYNC, 0L)
        if (isEmpty() || lastSync <= 0L || now - lastSync > STALE_THRESHOLD_MS) {
            rebuildFullIndex(android.os.Environment.getExternalStorageDirectory(), showHidden = true)
        }
    }

    suspend fun isEmpty(): Boolean = withContext(Dispatchers.IO) { dao.count() == 0 }

    suspend fun rebuildFullIndex(root: File, showHidden: Boolean) = updateMutex.withLock {
        withContext(Dispatchers.IO) {
            val entities = mutableListOf<SearchIndexEntity>()
            walkForIndex(root, showHidden, entities)
            dao.deleteAll()
            if (entities.isNotEmpty()) dao.insertAll(entities)
            appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(LAST_FULL_SYNC, System.currentTimeMillis()).apply()
        }
    }

    suspend fun indexFile(file: File) = updateMutex.withLock {
        withContext(Dispatchers.IO) {
            if (!file.exists()) return@withContext
            if (shouldSkip(file)) {
                dao.deleteByPathOrPrefix(file.absolutePath, escapeLike(file.absolutePath))
                return@withContext
            }
            dao.upsertOne(toEntity(file))
        }
    }

    suspend fun removeFromIndex(file: File) = updateMutex.withLock {
        withContext(Dispatchers.IO) {
            dao.deleteByPathOrPrefix(file.absolutePath, escapeLike(file.absolutePath))
        }
    }

    suspend fun renameOrMoveInIndex(oldFile: File, newFile: File) = updateMutex.withLock {
        withContext(Dispatchers.IO) {
            val oldPath = oldFile.absolutePath
            val newPath = newFile.absolutePath
            if (oldPath == newPath) return@withContext
            val rowsUpdated = dao.renamePathPrefix(
                oldPath, newPath, escapeLike(oldPath),
                newFile.name, newFile.name.lowercase(), newFile.extension.lowercase()
            )
            // Perf fix: only walk+reindex the destination when the SQL rename above touched
            // zero rows - i.e. oldPath (and everything under it) was never in the index to
            // begin with, so there's nothing to self-heal via a full walk on every rename/move.
            // When rowsUpdated > 0, the SQL update already renamed every indexed descendant;
            // walking the destination again on disk was pure redundant I/O for that case
            // (and the expensive one, since it re-scans the whole moved/renamed folder).
            if (rowsUpdated == 0 && newFile.isDirectory && newFile.exists() && !shouldSkip(newFile)) {
                val children = mutableListOf<SearchIndexEntity>()
                walkForIndex(newFile, true, children)
                if (children.isNotEmpty()) dao.insertAll(children)
                dao.upsertOne(toEntity(newFile))
            }
        }
    }

    suspend fun indexSubtree(root: File, showHidden: Boolean = true) = updateMutex.withLock {
        withContext(Dispatchers.IO) {
            if (!root.exists() || !root.isDirectory || shouldSkip(root)) return@withContext
            dao.upsertOne(toEntity(root))
            val entities = mutableListOf<SearchIndexEntity>()
            walkForIndex(root, showHidden, entities)
            if (entities.isNotEmpty()) dao.insertAll(entities)
        }
    }

    suspend fun fullSync(root: File = android.os.Environment.getExternalStorageDirectory()) =
        rebuildFullIndex(root, showHidden = true)

    suspend fun search(query: String, showHidden: Boolean): List<File> = withContext(Dispatchers.IO) {
        dao.searchByName(query.lowercase())
            .asSequence()
            .filter { showHidden || !containsHiddenSegment(it.path) }
            .map { File(it.path) }
            .toList()
    }

    private fun containsHiddenSegment(path: String): Boolean =
        path.split(File.separatorChar).any { it.isNotEmpty() && it.startsWith(".") }

    private fun toEntity(file: File) = SearchIndexEntity(
        path = file.absolutePath,
        name = file.name,
        nameLowercase = file.name.lowercase(),
        extension = file.extension.lowercase(),
        sizeBytes = if (file.isDirectory) 0L else file.length(),
        lastModified = file.lastModified(),
        isDirectory = file.isDirectory
    )

    private fun shouldSkip(file: File): Boolean {
        val name = file.name
        val parentName = file.parentFile?.name
        return (parentName == "Android" && (name == "data" || name == "obb")) ||
            name == TrashManager.TRASH_FOLDER_NAME
    }

    private fun walkForIndex(dir: File, showHidden: Boolean, out: MutableList<SearchIndexEntity>) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory && dir.name == "Android" && (child.name == "data" || child.name == "obb")) continue
            if (child.isDirectory && child.name == TrashManager.TRASH_FOLDER_NAME) continue
            if (!showHidden && child.name.startsWith(".")) continue
            out.add(toEntity(child))
            if (child.isDirectory && child.canRead()) walkForIndex(child, showHidden, out)
        }
    }

    /** SQLite LIKE escaping for literal filesystem paths. */
    private fun escapeLike(value: String): String =
        value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
