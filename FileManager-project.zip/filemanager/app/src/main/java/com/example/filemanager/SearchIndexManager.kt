package com.example.filemanager

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Local Search Index — รอบ 1 (ดู search-index-project-plan.txt).
 *
 * สร้างตามแพทเทิร์นเดียวกับ [TrashManager]: class รับ Context ใน constructor,
 * มี suspend fun initialize() เรียกจาก MainActivity.onCreate() ผ่าน
 * lifecycleScope.launch { }.
 *
 * รอบนี้เป็น "ชั้น Index แบบแยกตัว" เท่านั้น — [initialize] แค่ตรวจว่า index ว่าง
 * อยู่หรือยัง แล้ว rebuild ครั้งแรกถ้ายังไม่เคยมี ไม่มีจุดใดในโค้ดพฤติกรรมค้นหา
 * เดิม (SearchHelper.kt / MainViewModel.kt) ถูกแก้ให้มาเรียกใช้ [search] ในรอบนี้
 * — ตามข้อ 5.4 ของแผน ("ห้ามแก้ SearchHelper.kt / MainViewModel.kt ส่วนค้นหาในรอบนี้")
 * รอบ 2 ถึงจะต่อสายเข้าใช้งานจริง
 */
class SearchIndexManager(context: Context) {

    private val appContext = context.applicationContext
    private val dao: SearchIndexDao by lazy { SearchIndexDatabase.getInstance(appContext).searchIndexDao() }

    /** เรียกจาก MainActivity.onCreate() — สร้าง index ครั้งแรกถ้ายังว่างอยู่ (ยังไม่เคย build) */
    suspend fun initialize() {
        if (isEmpty()) {
            rebuildFullIndex(android.os.Environment.getExternalStorageDirectory(), showHidden = true)
        }
    }

    /** เช็คว่ายังไม่เคย build index เลย (ตารางว่างอยู่) */
    suspend fun isEmpty(): Boolean = withContext(Dispatchers.IO) {
        dao.count() == 0
    }

    /**
     * เดินไฟล์ทั้งหมดใต้ [root] ใหม่ทั้งก้อนแล้วเขียนทับลง DB (deleteAll แล้ว insertAll
     * ใหม่ทั้งหมด — รอบ 1 ยังไม่ทำ diff/incremental ตามแผน). รียูสกฎ skip เดียวกับ
     * FileScanner.walk(): ข้าม Android/data, Android/obb, โฟลเดอร์ trash ของ TrashManager,
     * และเคารพ [showHidden].
     *
     * [showHidden] ตอนเรียกจาก [initialize] ตั้งเป็น true เสมอ เพราะ index รอบ 1 นี้เป็น
     * "คลังกลาง" ที่ยังไม่ผูกกับ toggle แสดง/ซ่อนไฟล์ซ่อนของผู้ใช้ในหน้าจอค้นหา (ค่า
     * showHidden ที่มีผลต่อผลลัพธ์ที่ผู้ใช้เห็นจริงจะถูกจัดการตอน query ในรอบ 2 แทน
     * ไม่ใช่ตอน build index — index กว้างที่สุดไว้ก่อนแล้วไป filter ตอน query ทีหลัง)
     */
    suspend fun rebuildFullIndex(root: File, showHidden: Boolean) = withContext(Dispatchers.IO) {
        val entities = mutableListOf<SearchIndexEntity>()
        walkForIndex(root, showHidden, entities)
        dao.deleteAll()
        dao.insertAll(entities)
    }

    /** query จาก DAO คืนเป็น List<File> เพื่อให้เรียกใช้แทน FileScanner.searchByName ได้ตรงๆ ในรอบ 2 */
    suspend fun search(query: String): List<File> = withContext(Dispatchers.IO) {
        dao.searchByName(query.lowercase()).map { File(it.path) }
    }

    private fun walkForIndex(dir: File, showHidden: Boolean, out: MutableList<SearchIndexEntity>) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            // Android/data และ Android/obb throw บน Android รุ่นใหม่แม้มี MANAGE_EXTERNAL_STORAGE
            // ในบาง OEM build — ข้ามไปเหมือน FileScanner.walk()
            if (child.isDirectory && dir.name == "Android" && (child.name == "data" || child.name == "obb")) continue
            // อย่าให้โฟลเดอร์ถังขยะของ TrashManager ถูก index เข้ามาด้วย
            if (child.isDirectory && child.name == TrashManager.TRASH_FOLDER_NAME) continue
            if (!showHidden && child.name.startsWith(".")) continue

            out.add(
                SearchIndexEntity(
                    path = child.absolutePath,
                    name = child.name,
                    nameLowercase = child.name.lowercase(),
                    extension = child.extension.lowercase(),
                    sizeBytes = if (child.isDirectory) 0L else child.length(),
                    lastModified = child.lastModified(),
                    isDirectory = child.isDirectory
                )
            )
            if (child.isDirectory && child.canRead()) {
                walkForIndex(child, showHidden, out)
            }
        }
    }
}
