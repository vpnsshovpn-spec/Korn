package com.example.filemanager

import android.content.Intent
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Multi-select mode (selection subtitle, enter/exit selection, action bar visibility,
 * the "เพิ่มเติม" popup menu, properties dialog, and copy/move/rename/delete/share for the
 * current selection) - extracted out of MainActivity.kt (round 8 of the size-reduction plan).
 * No logic changed, only location + widening the following members from private to internal
 * so this file can reach them: selectionActionBar, clipboardActionBar, selectionMoreButton,
 * clipboardFiles, clipboardIsCut, confirmDelete, hideFile(), renameDialog().
 * No bound-reference (::) call sites for these functions, so no this:: fix was needed
 * (unlike round 4).
 */

internal fun MainActivity.updateSelectionSubtitle() {
    supportActionBar?.subtitle = "เลือก ${adapter.selectionCount()} รายการ"
}

internal fun MainActivity.enterSelectionMode() {
    adapter.setSelectionMode(true)
    swipeRefresh.isEnabled = false
    updateSelectionSubtitle()
    updateActionBars()
}

internal fun MainActivity.exitSelectionMode() {
    adapter.setSelectionMode(false)
    swipeRefresh.isEnabled = true
    updateActionBars()
    refreshCurrentView()
}

internal fun MainActivity.updateActionBars() {
    if (!isSelectionActionBarInitialized) return
    selectionActionBar.visibility = if (adapter.selectionMode) View.VISIBLE else View.GONE
    clipboardActionBar.visibility =
        if (!adapter.selectionMode && viewModel.clipboardFiles.value.isNotEmpty()) View.VISIBLE else View.GONE
    trashActionBar.visibility = if (!adapter.selectionMode && viewModel.mode.value == MainActivity.Mode.TRASH) View.VISIBLE else View.GONE
}

internal fun MainActivity.showSelectionMoreMenu() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }

    val popup = PopupMenu(this, selectionMoreButton)
    popup.menu.add("เลือกทั้งหมด").setOnMenuItemClickListener {
        adapter.selectAll()
        true
    }
    popup.menu.add("แชร์ที่เลือก").setOnMenuItemClickListener {
        shareSelected()
        true
    }

    if (files.size == 1) {
        val file = files[0]
        popup.menu.add("เปลี่ยนชื่อ").setOnMenuItemClickListener {
            renameDialog(file)
            true
        }
        popup.menu.add("รายละเอียด").setOnMenuItemClickListener {
            showPropertiesDialog(file)
            true
        }
        if (file.isDirectory) {
            popup.menu.add("เพิ่มในรายการโปรด").setOnMenuItemClickListener {
                addBookmark(file)
                true
            }
        }
        popup.menu.add(if (file.name.startsWith(".")) "เลิกซ่อน" else "ซ่อน")
            .setOnMenuItemClickListener {
                hideFile(file, !file.name.startsWith("."))
                true
            }
        popup.menu.add(if (file.isDirectory) "บีบอัด…" else "บีบอัด…")
            .setOnMenuItemClickListener {
                showCompressFormatDialog(file)
                true
            }
        if (!file.isDirectory && ArchiveManager.isArchive(file)) {
            popup.menu.add("แตกไฟล์…").setOnMenuItemClickListener {
                extractArchiveDialog(file)
                true
            }
        }
    } else {
        popup.menu.add("เปลี่ยนชื่อหลายไฟล์").setOnMenuItemClickListener {
            batchRenameDialog()
            true
        }
    }
    popup.show()
}

/**
 * "รายละเอียด" (Details/Properties) - shown from the selection "เพิ่มเติม" menu when
 * exactly one item is selected. Mirrors the kind of properties dialog other file
 * managers show (type, location, contents, size, modified date, permissions).
 */
internal fun MainActivity.showPropertiesDialog(file: File) {
    val sb = StringBuilder()
    sb.append("ชนิด: ").append(if (file.isDirectory) "แฟ้ม" else "ไฟล์").append("\n\n")
    sb.append("ที่ตั้ง: ").append(file.absolutePath).append("\n\n")

    if (file.isDirectory) {
        var fileCount = 0
        var dirCount = 0
        var totalSize = 0L
        runCatching {
            file.walkTopDown().forEach { f ->
                if (f == file) return@forEach
                if (f.isDirectory) dirCount++ else {
                    fileCount++
                    totalSize += f.length()
                }
            }
        }
        sb.append("ประกอบด้วย: $fileCount ไฟล์, $dirCount โฟลเดอร์").append("\n\n")
        sb.append("ขนาด: ${readableSize(totalSize)}").append("\n\n")
    } else {
        sb.append("ขนาด: ${readableSize(file.length())}").append("\n\n")
    }

    sb.append("แก้ไขล่าสุด: ${formatDateTime(file.lastModified())}").append("\n\n")
    sb.append("อ่านได้: ${if (file.canRead()) "ใช่" else "ไม่"}").append("\n")
    sb.append("เขียนได้: ${if (file.canWrite()) "ใช่" else "ไม่"}").append("\n")
    sb.append("ซ่อน: ${if (file.name.startsWith(".")) "ใช่" else "ไม่"}")

    KornDialog.Builder(this)
        .setTitle("คุณสมบัติ")
        .setMessage(sb.toString())
        .setPositiveButton("ปิด", null)
        .show()
}

internal fun MainActivity.copySelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    viewModel.setClipboardFiles(files)
    viewModel.setClipboardIsCut(false)
    exitSelectionMode()
    updateActionBars()
    Toast.makeText(this, "คัดลอก ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
}

internal fun MainActivity.moveSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    viewModel.setClipboardFiles(files)
    viewModel.setClipboardIsCut(true)
    exitSelectionMode()
    updateActionBars()
    Toast.makeText(this, "เลือกย้าย ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
}

internal fun MainActivity.renameSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }
    if (files.size == 1) {
        renameDialog(files[0])
    } else {
        batchRenameDialog()
    }
}

internal fun MainActivity.deleteSelectedToTrash() {
    val activity = this
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    val action = {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                files.forEach { trashManager.moveToTrash(it) }
            }
            exitSelectionMode()
            Toast.makeText(activity, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
        }
    }
    if (!confirmDelete) { action(); return }
    KornDialog.Builder(this)
        .setTitle("ย้าย ${files.size} รายการไปถังขยะ?")
        .setPositiveButton("ย้ายไปถังขยะ") { _, _ -> action() }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.shareSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    try {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
    } catch (e: Exception) {
        Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.toastNoSelection() {
    Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
}
