package com.example.filemanager

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate

/**
 * Owns KORN's user preferences, settings/about dialogs, and main-screen theme palette.
 *
 * MainActivity remains responsible for screen navigation and state usage, while this
 * helper owns the settings UI and persistence details. Existing behavior is preserved;
 * this round primarily reduces MainActivity's size without changing the feature design.
 */
class SettingsHelper(private val activity: MainActivity) {

    /**
     * Round 22 fix: MainActivity.onCreate() must set AppCompat's night mode BEFORE calling
     * super.onCreate() (see the comment on that call site), which means it happens before the
     * Activity's SavedStateRegistry is available - and MainViewModel now needs that registry to
     * construct its SavedStateHandle. Touching `activity.viewModel` (even just reading a value)
     * this early throws "You can consumeRestoredStateForKey only after super.onCreate of
     * corresponding component". This variant reads theme_key directly from SharedPreferences
     * instead, so night mode can still be set pre-super.onCreate() without waking the ViewModel.
     * [applySavedNightMode] (below) still reads from the ViewModel for every other caller
     * (e.g. after the user changes the theme in the Settings dialog), where touching the
     * ViewModel is safe since the Activity is already long past onCreate().
     */
    fun applySavedNightModeFromPrefs() {
        val prefs = activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE)
        when (prefs.getString("theme_key", "system")) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    fun applySavedNightMode() {
        when (activity.viewModel.themeKey.value) {
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    fun loadUserPreferences() {
        val prefs = activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE)
        activity.viewModel.setShowHidden(prefs.getBoolean("show_hidden", false))
        activity.viewModel.setIsGridMode(prefs.getBoolean("grid_mode", false))
        activity.viewModel.setFileViewMode(when (prefs.getString("view_mode", if (activity.viewModel.isGridMode.value) "GRID" else "LIST")) {
            "COMPACT" -> FileAdapter.ViewMode.COMPACT
            "GRID" -> FileAdapter.ViewMode.GRID
            "DETAILS" -> FileAdapter.ViewMode.DETAILS
            else -> FileAdapter.ViewMode.LIST
        })
        activity.viewModel.setIsGridMode(activity.viewModel.fileViewMode.value == FileAdapter.ViewMode.GRID)
        activity.confirmDelete = prefs.getBoolean("confirm_delete", true)
        activity.viewModel.setSortKey(when (prefs.getString("sort_key", "NAME")) {
            "SIZE" -> MainActivity.SortKey.SIZE
            "DATE" -> MainActivity.SortKey.DATE
            else -> MainActivity.SortKey.NAME
        })
        activity.viewModel.setSortAscending(prefs.getBoolean("sort_ascending", true))
        activity.viewModel.setThemeKey(prefs.getString("theme_key", "system") ?: "system")
    }

    fun saveUserPreferences() {
        activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE).edit()
            .putBoolean("show_hidden", activity.viewModel.showHidden.value)
            .putBoolean("grid_mode", activity.viewModel.isGridMode.value)
            .putString("view_mode", activity.viewModel.fileViewMode.value.name)
            .putBoolean("confirm_delete", activity.confirmDelete)
            .putString("theme_key", activity.viewModel.themeKey.value)
            .putString("sort_key", activity.viewModel.sortKey.value.name)
            .putBoolean("sort_ascending", activity.viewModel.sortAscending.value)
            .apply()
    }

    fun showAboutKornDialog() {
        KornDialog.Builder(activity)
            .setTitle("เกี่ยวกับ KORN")
            .setMessage(
                "KORN File Manager — By KORN\n\n" +
                    "แอปพลิเคชันนี้เป็นผลงานของ KORN\n" +
                    "ห้ามคัดลอก ดัดแปลง แก้ไข แจกจ่าย หรือเผยแพร่ส่วนหนึ่งส่วนใดของแอปพลิเคชัน " +
                    "โดยไม่ได้รับอนุญาตจาก KORN"
            )
            .setPositiveButton("ตกลง", null)
            .show()
    }

    fun showSettingsDialog() {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }
        val themeTitle = TextView(activity).apply {
            text = "ธีม"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        }
        container.addView(themeTitle)

        val themeOptions = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val themeKeys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val themeGroup = RadioGroup(activity).apply { orientation = RadioGroup.VERTICAL }
        themeOptions.forEachIndexed { index, label ->
            val radio = RadioButton(activity).apply {
                text = label
                id = View.generateViewId()
                isChecked = themeKeys[index] == activity.viewModel.themeKey.value
            }
            themeGroup.addView(radio)
        }
        var pendingThemeKey = activity.viewModel.themeKey.value
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = themeGroup.indexOfChild(themeGroup.findViewById(checkedId))
            pendingThemeKey = themeKeys.getOrElse(selected) { activity.viewModel.themeKey.value }
        }
        container.addView(themeGroup)

        val hidden = CheckBox(activity).apply {
            text = "แสดงไฟล์ที่ซ่อน"
            isChecked = activity.viewModel.showHidden.value
        }
        hidden.setOnCheckedChangeListener { _, checked ->
            activity.viewModel.setShowHidden(checked)
            activity.drawerHiddenSwitch?.setOnCheckedChangeListener(null)
            activity.drawerHiddenSwitch?.isChecked = checked
            activity.drawerHiddenSwitch?.setOnCheckedChangeListener { _, value ->
                if (activity.viewModel.showHidden.value == value) return@setOnCheckedChangeListener
                activity.viewModel.setShowHidden(value)
                saveUserPreferences()
                activity.refreshCurrentView()
            }
            saveUserPreferences()
            activity.refreshCurrentView()
        }
        container.addView(hidden)

        val confirm = CheckBox(activity).apply {
            text = "ยืนยันก่อนลบ"
            isChecked = activity.confirmDelete
        }
        confirm.setOnCheckedChangeListener { _, checked ->
            activity.confirmDelete = checked
            saveUserPreferences()
        }
        container.addView(confirm)

        val grid = CheckBox(activity).apply {
            text = "ใช้มุมมองตาราง"
            isChecked = activity.viewModel.isGridMode.value
        }
        grid.setOnCheckedChangeListener { _, checked ->
            if (activity.viewModel.isGridMode.value != checked) activity.toggleGridMode()
        }
        container.addView(grid)

        val syncIndexButton = Button(activity).apply {
            text = "ซิงค์ดัชนีค้นหาใหม่"
            setOnClickListener {
                activity.syncSearchIndexNow()
            }
        }
        container.addView(syncIndexButton)

        val shizukuTitle = TextView(activity).apply {
            text = "การเข้าถึงระดับระบบ"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 16, 0, 4)
        }
        container.addView(shizukuTitle)

        val shizukuRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val shizukuStatus = TextView(activity).apply {
            text = "Shizuku: ${ShizukuManager.statusLabel()}"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val shizukuButton = Button(activity).apply { text = "เชื่อมต่อ" }
        shizukuRow.addView(shizukuStatus)
        shizukuRow.addView(shizukuButton)
        container.addView(shizukuRow)

        val shizukuHint = TextView(activity).apply {
            text = "ใช้เข้าถึงโฟลเดอร์ Android/data โดยไม่ต้อง root — ต้องติดตั้งและเปิดแอป Shizuku ไว้ก่อน"
            textSize = 12f
            setPadding(0, 2, 0, 8)
        }
        container.addView(shizukuHint)

        fun refreshShizukuRow() {
            shizukuStatus.text = "Shizuku: ${ShizukuManager.statusLabel()}"
            shizukuButton.isEnabled = ShizukuManager.isAvailable() && !ShizukuManager.hasPermission()
        }
        refreshShizukuRow()
        activity.onShizukuStatusChanged = { refreshShizukuRow() }

        shizukuButton.setOnClickListener {
            if (!ShizukuManager.isAvailable()) {
                Toast.makeText(
                    activity,
                    "ไม่พบ Shizuku — ติดตั้งและเปิดแอปจาก shizuku.rikka.app ก่อน",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                ShizukuManager.requestPermission()
            }
        }

        val settingsDialog = KornDialog.Builder(activity)
            .setTitle("การตั้งค่า")
            .setView(container)
            .setNeutralButton("เรียงลำดับ") { _, _ -> activity.showSortDialog() }
            .setPositiveButton("เสร็จสิ้น") { _, _ ->
                activity.viewModel.setThemeKey(pendingThemeKey)
                saveUserPreferences()
                applySavedNightMode()
                applyThemePalette()
            }
            .setOnDismissListener { activity.onShizukuStatusChanged = null }
            .show()

        settingsDialog.window?.apply {
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.5f)
        }
    }

    fun applyThemePalette() {
        if (!activity.isMainThemeViewsInitialized) return

        val (primary, primaryDark, background) = ThemeHelper.colors(activity)
        activity.findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(primary)
        activity.window.statusBarColor = primaryDark
        activity.drawerLayout.setBackgroundColor(background)
        activity.findViewById<LinearLayout>(R.id.mainContent)?.setBackgroundColor(background)
        activity.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.fileList)?.setBackgroundColor(background)

        val systemDark = (activity.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val darkSurface = activity.viewModel.themeKey.value == "dark" || (activity.viewModel.themeKey.value == "system" && systemDark)
        activity.findViewById<android.widget.HorizontalScrollView>(R.id.breadcrumbScroll)?.setBackgroundColor(
            if (darkSurface) Color.rgb(42, 46, 51) else Color.rgb(238, 241, 244)
        )
        activity.navigationView.setBackgroundColor(if (darkSurface) Color.rgb(36, 39, 43) else background)
        val text = if (darkSurface) Color.rgb(245, 247, 249) else Color.rgb(32, 35, 39)
        val secondary = if (darkSurface) Color.rgb(190, 197, 204) else Color.rgb(82, 88, 96)
        activity.storageText.setTextColor(secondary)
        activity.storagePercent.setBackgroundColor(primary)
        activity.storagePercent.setTextColor(Color.WHITE)
        val tint = ColorStateList.valueOf(primary)
        activity.findViewById<com.google.android.material.button.MaterialButton>(R.id.addButton)?.backgroundTintList = tint
        activity.findViewById<com.google.android.material.button.MaterialButton>(R.id.windowsButton)?.backgroundTintList = tint

        val toolIds = listOf(R.id.addBookmarkButton, R.id.manageBookmarksButton, R.id.sortFilesButton, R.id.viewModeButton)
        val toolColor = if (activity.viewModel.themeKey.value == "gray") Color.rgb(101, 109, 121) else primary
        toolIds.forEach { id ->
            activity.findViewById<Button>(id)?.apply {
                backgroundTintList = ColorStateList.valueOf(toolColor)
                setTextColor(Color.WHITE)
            }
        }

        // Bottom action bars (multi-select "คัดลอก/ย้าย/เปลี่ยนชื่อ/ลบ/..." and clipboard
        // "วาง/สร้างโฟลเดอร์/ยกเลิก") - background used to be a hardcoded
        // android:background="@color/primary" in activity_main.xml, a static values/colors.xml
        // resource that only tracks light/dark (values-night), so it never followed the
        // in-app theme picker below (green/red/gray/dark/light/system - ThemeHelper.colors()).
        // setBackgroundColor() here uses the same solid opaque `primary` Int this whole
        // function already computes from ThemeHelper.colors() for every other view, so it's
        // always a fully-opaque color (Color.rgb()/Color.argb(255,...) style values only,
        // no alpha channel anywhere in ThemeHelper - see that file), matching every other
        // themed surface in the app. Guarded the same way toolIds/categoryBar above are,
        // since this same function also runs once from onCreate before these views may exist
        // on a slow first frame.
        if (activity.isSelectionActionBarInitialized) {
            activity.selectionActionBar.setBackgroundColor(primary)
        }
        activity.clipboardActionBar.setBackgroundColor(primary)

        // ปุ่ม "ล้างถังขยะ" ในหน้า trashActionBar - เดิมไม่ถูกแตะเลยในฟังก์ชันนี้ MaterialButton
        // ที่ไม่ได้ตั้ง app:backgroundTint ไว้ใน XML จะ fallback ไปใช้ ?attr/colorPrimary ของธีม
        // ตอน inflate ครั้งเดียว (ค่า static @color/primary จาก themes.xml) แล้วไม่อัปเดตอีกเลยตอน
        // ผู้ใช้เปลี่ยนธีมในแอป (ไม่ใช่ Activity recreate/Config change) จึงค้างเป็น #2196F3 เสมอ -
        // ผูกกับ ThemeHelper.colors() แบบเดียวกับ toolIds ด้านบนแทน
        activity.findViewById<com.google.android.material.button.MaterialButton>(R.id.emptyTrashButton)?.apply {
            backgroundTintList = ColorStateList.valueOf(primary)
            setTextColor(Color.WHITE)
        }

        activity.categoryBar.takeIf { activity.isMainThemeViewsInitialized }?.let { bar ->
            for (i in 0 until bar.childCount) {
                (bar.getChildAt(i) as? TextView)?.setBackgroundColor(primary)
            }
        }
        activity.navigationView.itemTextColor = ColorStateList.valueOf(text)
        activity.navigationView.itemIconTintList = ColorStateList.valueOf(
            if (darkSurface) Color.rgb(220, 225, 230) else Color.rgb(72, 78, 86)
        )
        activity.navigationView.getHeaderView(0)?.setBackgroundColor(primary)

        // Pull-down drawer's drag-handle strip: same theme color as everything else, but light/
        // translucent instead of solid, so it stays a subtle "pull tab" rather than a dark bar.
        activity.findViewById<LinearLayout>(R.id.pullDownHandleStrip)?.setBackgroundColor(
            Color.argb(40, Color.red(primary), Color.green(primary), Color.blue(primary))
        )
    }

    fun showThemeDialog() {
        val labels = arrayOf("🔵 น้ำเงิน", "🟢 เขียว", "🔴 แดง", "⚪ เทา", "🌑 ดำเข้ม", "☀️ ขาว", "📱 ตามระบบ")
        val keys = arrayOf("blue", "green", "red", "gray", "dark", "light", "system")
        val checked = keys.indexOf(activity.viewModel.themeKey.value).coerceAtLeast(0)
        KornDialog.Builder(activity)
            .setTitle("สีธีม")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                activity.viewModel.setThemeKey(keys[which])
                saveUserPreferences()
                applySavedNightMode()
                applyThemePalette()
                dialog.dismiss()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }
}
