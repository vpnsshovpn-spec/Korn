package com.example.filemanager

import android.content.pm.PackageManager
import android.widget.Toast
import rikka.shizuku.Shizuku

/**
 * Shizuku permission-result listener construction, split out of MainActivity.kt (see
 * MainActivity-Slimdown-Plan.txt ก้อน 3.1). The listener *field* itself stays declared in
 * MainActivity because Shizuku.addRequestPermissionResultListener()/
 * removeRequestPermissionResultListener() (called from onCreate()/onDestroy()) need a single
 * stable object identity to correctly pair add/remove - an extension property can't provide
 * that (no backing field), so this file only builds the listener body; MainActivity holds it
 * in a regular `private val`.
 */
internal fun MainActivity.buildShizukuPermissionListener(): Shizuku.OnRequestPermissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == ShizukuManager.REQUEST_CODE) {
            runOnUiThread {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                Toast.makeText(
                    this,
                    if (granted) "เชื่อมต่อ Shizuku สำเร็จ" else "ไม่ได้รับสิทธิ์จาก Shizuku",
                    Toast.LENGTH_SHORT
                ).show()
                onShizukuStatusChanged?.invoke()
            }
        }
    }
