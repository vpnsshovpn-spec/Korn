package com.example.filemanager

import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.DecimalFormat

/**
 * Lightweight storage analyzer inspired by common file explorers.
 * It scans the top-level storage folders and calculates recursive sizes.
 * Android/data and Android/obb are skipped where OEM builds deny access.
 */
class StorageAnalyzerActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildView())
        supportActionBar?.title = "วิเคราะห์พื้นที่จัดเก็บ"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        analyze()
    }

    private fun buildView(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resources.getColor(R.color.background, theme))
        }
        summary = TextView(this).apply {
            setPadding(24, 20, 24, 12)
            textSize = 15f
            setTextColor(resources.getColor(R.color.text_primary, theme))
        }
        val hint = TextView(this).apply {
            text = "คำนวณขนาดโฟลเดอร์แบบละเอียด อาจใช้เวลาสักครู่"
            setPadding(24, 0, 24, 16)
            textSize = 12f
            setTextColor(resources.getColor(R.color.text_secondary, theme))
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(list)
        }
        root.addView(summary)
        root.addView(hint)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun analyze() {
        summary.text = "กำลังวิเคราะห์…"
        Thread {
            val root = Environment.getExternalStorageDirectory()
            val children = root.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
            val rows = children.map { file ->
                AnalyzerRow(file, directorySize(file))
            }.sortedByDescending { it.bytes }

            val total = rootTotal(root)
            val free = try {
                android.os.StatFs(root.path).availableBytes
            } catch (_: Exception) { 0L }

            runOnUiThread {
                summary.text = "พื้นที่ใช้งานในรายการ: ${readable(total)}  •  ว่าง: ${readable(free)}"
                list.removeAllViews()
                if (rows.isEmpty()) {
                    TextView(this).apply {
                        text = "ไม่พบโฟลเดอร์หรือไฟล์ที่อ่านได้"
                        setPadding(24, 24, 24, 24)
                        setTextColor(resources.getColor(R.color.text_secondary, theme))
                    }.also { list.addView(it) }
                } else {
                    val max = rows.firstOrNull()?.bytes?.coerceAtLeast(1L) ?: 1L
                    rows.forEach { row -> addRow(row, max) }
                }
            }
        }.start()
    }

    private data class AnalyzerRow(val file: File, val bytes: Long)

    private fun addRow(row: AnalyzerRow, max: Long) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 12, 24, 12)
            background = resolveSelectableBackground()
        }
        val line = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = TextView(this).apply {
            text = if (row.file.isDirectory) "📁 ${row.file.name}" else "📄 ${row.file.name}"
            textSize = 16f
            setTextColor(resources.getColor(R.color.text_primary, theme))
        }
        val size = TextView(this).apply {
            text = readable(row.bytes)
            textSize = 13f
            setTextColor(resources.getColor(R.color.text_secondary, theme))
            gravity = Gravity.END
        }
        line.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(size)
        box.addView(line)

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = ((row.bytes.toDouble() / max.toDouble()) * 1000).toInt().coerceIn(0, 1000)
        }
        box.addView(bar, LinearLayout.LayoutParams(-1, 6).apply { topMargin = 8 })
        list.addView(box)
    }

    private fun resolveSelectableBackground(): android.graphics.drawable.Drawable? =
        android.util.TypedValue().let { value ->
            theme.resolveAttribute(android.R.attr.selectableItemBackground, value, true)
            androidx.appcompat.content.res.AppCompatResources.getDrawable(this, value.resourceId)
        }

    private fun rootTotal(root: File): Long =
        root.listFiles()?.sumOf { directorySize(it) } ?: 0L

    private fun directorySize(file: File): Long {
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        if (file.parentFile?.name == "Android" && (file.name == "data" || file.name == "obb")) return 0L
        var total = 0L
        try {
            file.listFiles()?.forEach { child ->
                if (child.isDirectory && file.name == "Android" &&
                    (child.name == "data" || child.name == "obb")) return@forEach
                total += directorySize(child)
            }
        } catch (_: Exception) {}
        return total
    }

    private fun readable(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val group = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, group.toDouble()))} ${units[group]}"
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
