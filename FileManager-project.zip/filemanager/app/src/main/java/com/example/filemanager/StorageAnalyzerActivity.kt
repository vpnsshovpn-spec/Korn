package com.example.filemanager

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import com.example.filemanager.ui.dialogs.KornDialog
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import java.io.File
import java.text.DecimalFormat

/**
 * Lightweight storage analyzer inspired by common file explorers.
 * It scans the top-level storage folders and calculates recursive sizes.
 * Android/data and Android/obb are skipped where OEM builds deny access.
 */
class StorageAnalyzerActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildView())
        supportActionBar?.title = "วิเคราะห์พื้นที่จัดเก็บ"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        ThemeHelper.apply(this)
        analyze()
    }

    private fun buildView(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(resources.getColor(R.color.background, theme))
        }
        summary = TextView(this).apply {
            setPadding(24, 20, 24, 12)
            textSize = 15f
            setTextColor(resources.getColor(R.color.text_primary, theme))
        }
        val hint = TextView(this).apply {
            text = "คำนวณขนาดโฟลเดอร์แบบละเอียด อาจใช้เวลาสักครู่"
            setPadding(24, 0, 24, 16)
            textSize = 12f
            setTextColor(resources.getColor(R.color.text_secondary, theme))
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = android.widget.ScrollView(this).apply {
            addView(list)
        }
        root.addView(summary)
        root.addView(hint)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun analyze() {
        summary.text = "กำลังวิเคราะห์…"
        unreadableCount = 0
        lifecycleScope.launch {
            try {
                val job = coroutineContext[kotlinx.coroutines.Job]
                val result = withContext(Dispatchers.IO) {
                    val root = Environment.getExternalStorageDirectory()
                    val children = root.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
                    val rows = children.map { file ->
                        AnalyzerRow(file, directorySize(file, job))
                    }.sortedByDescending { it.bytes }
                    val total = rootTotal(root, job)
                    val free = try {
                        android.os.StatFs(root.path).availableBytes
                    } catch (_: Exception) { 0L }
                    Triple(rows, total, free)
                }

                summary.text = "พื้นที่ใช้งานในรายการ: ${readable(result.second)}  •  ว่าง: ${readable(result.third)}" +
                    if (unreadableCount > 0) "  •  อ่านไม่ได้ $unreadableCount โฟลเดอร์ (ขนาดอาจไม่ครบ)" else ""
                list.removeAllViews()
                if (result.first.isEmpty()) {
                    TextView(this@StorageAnalyzerActivity).apply {
                        text = "ไม่พบโฟลเดอร์หรือไฟล์ที่อ่านได้"
                        setPadding(24, 24, 24, 24)
                        setTextColor(resources.getColor(R.color.text_secondary, theme))
                    }.also { list.addView(it) }
                } else {
                    val max = result.first.firstOrNull()?.bytes?.coerceAtLeast(1L) ?: 1L
                    result.first.forEach { row -> addRow(row, max) }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!isFinishing && !isDestroyed) {
                    summary.text = "วิเคราะห์ไม่สำเร็จ: ${e.message ?: "ไม่ทราบสาเหตุ"}"
                }
            }
        }
    }

    private data class AnalyzerRow(val file: File, val bytes: Long)

    private fun addRow(row: AnalyzerRow, max: Long) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 12, 24, 12)
            background = resolveSelectableBackground()
        }
        val line = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = TextView(this).apply {
            text = if (row.file.isDirectory) "📁 ${row.file.name}" else "📄 ${row.file.name}"
            textSize = 16f
            setTextColor(resources.getColor(R.color.text_primary, theme))
        }
        val size = TextView(this).apply {
            text = readable(row.bytes)
            textSize = 13f
            setTextColor(resources.getColor(R.color.text_secondary, theme))
            gravity = Gravity.END
        }
        line.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(size)
        box.addView(line)
        box.setOnClickListener { showFileActions(row.file) }

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = 1000
            progress = ((row.bytes.toDouble() / max.toDouble()) * 1000).toInt().coerceIn(0, 1000)
        }
        box.addView(bar, LinearLayout.LayoutParams(-1, 6).apply { topMargin = 8 })
        list.addView(box)
    }


    private fun showFileActions(file: File) {
        val actions = if (file.isDirectory) {
            arrayOf("เปิดโฟลเดอร์", "ลบไปถังขยะ")
        } else {
            val edit = isEditableText(file)
            if (edit) arrayOf("เปิดไฟล์", "แก้ไขไฟล์", "ลบไปถังขยะ")
            else arrayOf("เปิดไฟล์", "ลบไปถังขยะ")
        }

        KornDialog.Builder(this)
            .setTitle(file.name)
            .setItems(actions) { _, which ->
                when {
                    file.isDirectory && which == 0 -> openDirectory(file)
                    file.isDirectory && which == 1 -> moveToTrash(file)
                    !file.isDirectory && isEditableText(file) && which == 0 -> openFile(file)
                    !file.isDirectory && isEditableText(file) && which == 1 -> editFile(file)
                    !file.isDirectory && isEditableText(file) && which == 2 -> moveToTrash(file)
                    !file.isDirectory && !isEditableText(file) && which == 0 -> openFile(file)
                    else -> moveToTrash(file)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun openDirectory(file: File) {
        startActivity(Intent(this, MainActivity::class.java).apply {
            putExtra("start_path", file.absolutePath)
        })
    }

    private fun isEditableText(file: File): Boolean {
        if (!file.isFile || file.length() > 10L * 1024L * 1024L) return false
        return file.extension.lowercase() in setOf(
            "txt", "json", "xml", "mcmeta", "lang", "properties", "ini",
            "cfg", "conf", "js", "ts", "kt", "java", "py", "md", "csv",
            "log", "yml", "yaml"
        )
    }

    private fun editFile(file: File) {
        startActivity(Intent(this, TextEditActivity::class.java).apply {
            putExtra("file_path", file.absolutePath)
        })
    }

    private fun openFile(file: File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, contentResolver.getType(uri) ?: "*/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "เปิดด้วย"))
        } catch (e: Exception) {
            Toast.makeText(this, "ไม่พบแอปที่เปิดไฟล์นี้ได้", Toast.LENGTH_SHORT).show()
        }
    }

    private fun moveToTrash(file: File) {
        KornDialog.Builder(this)
            .setTitle("ย้ายไปถังขยะ?")
            .setMessage(file.name)
            .setPositiveButton("ย้าย") { _, _ ->
                lifecycleScope.launch {
                    try {
                        val ok = withContext(Dispatchers.IO) { TrashManager(this@StorageAnalyzerActivity).moveToTrash(file) }
                        if (ok) {
                            Toast.makeText(this@StorageAnalyzerActivity, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
                            analyze()
                        } else {
                            Toast.makeText(this@StorageAnalyzerActivity, "ลบไม่สำเร็จ", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@StorageAnalyzerActivity, "ลบไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun resolveSelectableBackground(): android.graphics.drawable.Drawable? =
        android.util.TypedValue().let { value ->
            theme.resolveAttribute(android.R.attr.selectableItemBackground, value, true)
            androidx.appcompat.content.res.AppCompatResources.getDrawable(this, value.resourceId)
        }

    // Set once per analyze() run; counts folders we couldn't fully read (permission denied,
    // I/O error) so the summary can say the total may be incomplete instead of silently
    // showing a misleading "0 B" for something that actually has content.
    private var unreadableCount = 0

    private fun rootTotal(root: File, job: kotlinx.coroutines.Job?): Long =
        root.listFiles()?.sumOf { directorySize(it, job) } ?: 0L

    private fun directorySize(file: File, job: kotlinx.coroutines.Job?): Long {
        // Cooperative cancellation: this loop is pure CPU/disk work with no suspension
        // points, so without this check a cancelled scan would keep running to completion
        // in the background instead of stopping when the user leaves the screen.
        if (job?.isActive == false) throw kotlinx.coroutines.CancellationException("Analyze cancelled")
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        if (file.parentFile?.name == "Android" && (file.name == "data" || file.name == "obb")) return 0L
        var total = 0L
        val children = try {
            file.listFiles()
        } catch (_: Exception) {
            unreadableCount++
            null
        }
        if (children == null) {
            unreadableCount++
        } else {
            for (child in children) {
                if (child.isDirectory && file.name == "Android" &&
                    (child.name == "data" || child.name == "obb")) continue
                total += directorySize(child, job)
            }
        }
        return total
    }

    private fun readable(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val group = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, group.toDouble()))} ${units[group]}"
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
