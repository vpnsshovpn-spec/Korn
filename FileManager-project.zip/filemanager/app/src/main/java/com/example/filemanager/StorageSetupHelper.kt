package com.example.filemanager

import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Owns storage-related setup and Android/data access orchestration.
 *
 * MainActivity remains the owner of application state and lifecycle callbacks.
 * This helper only extracts the existing storage/Shizuku/SAF UI logic without
 * changing the underlying behavior.
 */
class StorageSetupHelper(private val activity: MainActivity) {

    fun ensureDevelopmentBookmarksSafe() {
        try {
            MinecraftAddonTools.ensureDevelopmentBookmarks(activity, activity.bookmarksManager)
        } catch (_: Exception) {
            // Preserve the existing best-effort behavior.
        }
    }

    fun getRemovableStorageDirectories(): List<File> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return emptyList()
        val sm = activity.getSystemService(StorageManager::class.java)
        return sm.storageVolumes.mapNotNull { volume ->
            if (!volume.isRemovable) return@mapNotNull null
            volume.directory?.takeIf { it.isDirectory }
        }
    }

    fun updateRemovableStorageDrawerItem() {
        val item = activity.navigationView.menu.findItem(R.id.nav_removable) ?: return
        val dirs = getRemovableStorageDirectories()
        item.isVisible = dirs.isNotEmpty()
        if (dirs.isNotEmpty()) {
            item.title = if (dirs.size == 1) "SD Card / USB" else "SD Card / USB (${dirs.size})"
        }
    }

    /** Opens /Android/data using the existing Shizuku-aware flow. */
    fun openAndroidDataFolder() {
        val dir = File(Environment.getExternalStorageDirectory(), "Android/data")
        if (!ShizukuManager.hasPermission()) {
            KornDialog.Builder(activity)
                .setTitle("Android/data")
                .setMessage(
                    "โฟลเดอร์นี้ถูกจำกัดสิทธิ์โดยระบบ Android — ต้องเชื่อมต่อ Shizuku ก่อน " +
                        "ไม่งั้นจะเห็นโฟลเดอร์ของแอปอื่นเป็นค่าว่างเปล่า\n\n" +
                        "ไปที่การตั้งค่า (⋮) เพื่อเชื่อมต่อ Shizuku ตอนนี้เลยไหม?"
                )
                .setPositiveButton("ไปตั้งค่า") { _, _ ->
                    activity.loadDirectory(dir)
                    activity.showSettingsDialogForStorage()
                }
                .setNegativeButton("เข้าโฟลเดอร์เลย") { _, _ -> activity.loadDirectory(dir) }
                .show()
        } else {
            activity.loadDirectory(dir)
        }
    }

    /** Opens the existing SAF flow for Android/data. */
    fun openAndroidDataFolderSaf() {
        val existing = activity.contentResolver.persistedUriPermissions.firstOrNull {
            it.isReadPermission && it.uri.toString().contains("Android%2Fdata")
        }
        if (existing != null) {
            activity.startActivity(Intent(activity, SafDataBrowserActivity::class.java).apply {
                putExtra(SafDataBrowserActivity.EXTRA_TREE_URI, existing.uri.toString())
            })
            return
        }
        KornDialog.Builder(activity)
            .setTitle("Android/data (SAF)")
            .setMessage(
                "ระบบจะเปิดตัวเลือกโฟลเดอร์ — เลือกโฟลเดอร์ \"Android/data\" แล้วกด \"อนุญาต\" " +
                    "ที่มุมล่างของหน้าจอนั้น (ต้องเลือกโฟลเดอร์นี้เท่านั้น ไม่ใช่โฟลเดอร์อื่น)"
            )
            .setPositiveButton("เลือกโฟลเดอร์") { _, _ -> launchSafPicker() }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun launchSafPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            val initialUri = android.provider.DocumentsContract.buildDocumentUri(
                "com.android.externalstorage.documents", "primary:Android/data"
            )
            putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, initialUri)
        }
        try {
            activity.startActivityForResult(intent, MainActivity.REQUEST_SAF_ANDROID_DATA)
        } catch (e: Exception) {
            Toast.makeText(activity, "เปิดตัวเลือกโฟลเดอร์ไม่ได้: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun updateStorageBar() {
        val storageBar = activity.findViewById<ProgressBar>(R.id.storageBar)
        val storagePercent = activity.findViewById<TextView>(R.id.storagePercent)
        val storageText = activity.findViewById<TextView>(R.id.storageText)
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().path)
            val total = stat.totalBytes
            val free = stat.availableBytes
            val used = total - free
            val pct = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0
            storageBar.max = 100
            storageBar.progress = pct.coerceIn(0, 100)
            storagePercent.text = "$pct%"
            storageText.text = "ใช้ไป ${readableSize(used)} จาก ${readableSize(total)} (เหลือ ${readableSize(free)})"
        } catch (_: Exception) {
            storageText.text = ""
        }
    }
}
