package com.example.filemanager

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.regex.Pattern
import java.util.regex.PatternSyntaxException

/** Universal text/HEX editor. File I/O is kept off the UI thread; rendering/highlighting is deferred. */
class TextEditActivity : AppCompatActivity() {
    private lateinit var editText: EditText
    private lateinit var toolbar: Toolbar
    private lateinit var btnToggleEdit: android.view.View
    private lateinit var iconToggleEdit: android.widget.ImageView
    private lateinit var labelToggleEdit: android.widget.TextView
    private lateinit var btnOpen: android.view.View
    private lateinit var btnNewFile: android.view.View
    private lateinit var btnUndoChanges: android.view.View
    private lateinit var btnSaveFile: android.view.View
    private lateinit var btnMoreActions: android.widget.ImageButton
    private var isEditLocked = true
    // Snapshot taken the moment editing is unlocked, so "ยกเลิก" can discard
    // whatever was typed during this edit session and go back to it.
    private var lockedSnapshot: String = ""
    private lateinit var zipFile: File
    private lateinit var entryPath: String
    private var directFile: File? = null
    private var isManifest = false
    private var binaryMode = false
    private var originalSize = 0L
    private var loading = true

    private val highlightHandler = Handler(Looper.getMainLooper())
    private val highlightRunnable = Runnable { if (!isFinishing && !isDestroyed) highlight() }
    private var applyingHighlight = false
    private val largeFileHighlightLimit = 100_000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_edit)
        toolbar = findViewById(R.id.textEditToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        editText = findViewById(R.id.textEditContent)
        // LineNumberEditText's own init{} already enables horizontal (no-wrap)
        // scrolling - do not override it back to wrap mode here.

        btnToggleEdit = findViewById(R.id.btnToggleEdit)
        iconToggleEdit = findViewById(R.id.iconToggleEdit)
        labelToggleEdit = findViewById(R.id.labelToggleEdit)
        btnOpen = findViewById(R.id.btnOpen)
        btnNewFile = findViewById(R.id.btnNewFile)
        btnUndoChanges = findViewById(R.id.btnUndoChanges)
        btnSaveFile = findViewById(R.id.btnSaveFile)
        btnMoreActions = findViewById(R.id.btnMoreActions)

        btnToggleEdit.setOnClickListener { toggleEditLock() }
        btnOpen.setOnClickListener { onOpenTapped() }
        btnNewFile.setOnClickListener { onNewFileTapped() }
        btnUndoChanges.setOnClickListener { onUndoTapped() }
        btnSaveFile.setOnClickListener { saveAndClose() }
        btnMoreActions.setOnClickListener { toolbar.showOverflowMenu() }

        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH) ?: ""
        val filePath = intent.getStringExtra(EXTRA_FILE_PATH)
        if (filePath.isNullOrEmpty() && (zipPath == null || entryPath.isEmpty())) {
            Toast.makeText(this, "ไม่พบไฟล์", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Do not read, decode, HEX-expand, or highlight on the main thread.
        Thread {
            try {
                val result: Pair<ByteArray, String> = if (!filePath.isNullOrEmpty()) {
                    val file = File(filePath)
                    if (!file.isFile) throw IllegalArgumentException("ไม่พบไฟล์")
                    Pair(file.readBytes(), file.name)
                } else {
                    val z = File(zipPath!!)
                    if (!z.isFile) throw IllegalArgumentException("ไม่พบไฟล์ ZIP")
                    val bytes = ZipFileSystem.readEntryBytes(z, entryPath)
                    bytes to entryPath.substringAfterLast('/')
                }
                val bytes = result.first
                val name = result.second
                runOnUiThread { finishLoading(bytes, name, filePath, zipPath) }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        Toast.makeText(this, "อ่านไฟล์ไม่สำเร็จ: ${e.message ?: "ไม่ทราบสาเหตุ"}", Toast.LENGTH_LONG).show()
                        finish()
                    }
                }
            }
        }.start()

        editText.addTextChangedListener(editorWatcher)
    }

    private fun finishLoading(bytes: ByteArray, name: String, filePath: String?, zipPath: String?) {
        if (isFinishing || isDestroyed) return
        try {
            directFile = filePath?.let(::File)
            if (zipPath != null) zipFile = File(zipPath)
            originalSize = bytes.size.toLong()
            supportActionBar?.title = name
            loadBytes(bytes, name)
            loading = false
            updateToolbarSubtitle()
            setEditingLocked(true)
            // First paint the editor. Highlighting is deliberately deferred.
            if (!binaryMode) scheduleHighlight()
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดไฟล์ไม่สำเร็จ: ${e.message ?: "ไม่ทราบสาเหตุ"}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun loadBytes(bytes: ByteArray, name: String) {
        val decoded = decodeText(bytes)
        binaryMode = decoded == null
        isManifest = !binaryMode && name.equals("manifest.json", true)
        if (binaryMode) {
            editText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            // Keep HEX generation bounded. Very large binary files are still inspectable,
            // but do not allocate an enormous expanded String on the UI thread.
            if (bytes.size > MAX_HEX_BYTES) {
                throw IllegalArgumentException("ไฟล์ไบนารีมีขนาดใหญ่เกินไปสำหรับ HEX Editor (${MAX_HEX_BYTES / 1024 / 1024} MB)")
            }
            editText.setText(bytesToHex(bytes))
            editText.setSelection(0)
            supportActionBar?.subtitle = "HEX • ${bytes.size} bytes"
        } else {
            editText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            editText.setText(decoded)
            editText.setSelection(0)
            supportActionBar?.subtitle = "ข้อความ • ${bytes.size} bytes"
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, MENU_SAVE, 0, "บันทึก")
        menu.add(0, MENU_SEARCH, 1, "ค้นหา")
        menu.add(0, MENU_REPLACE, 2, "ค้นหาและแทนที่")
        if (!binaryMode) menu.add(0, MENU_GOTO_LINE, 3, "ไปบรรทัด")
        if (!binaryMode && isManifest) menu.add(0, MENU_UUID, 3, "🆔 สร้าง UUID 3 ชุด")
        if (!binaryMode && isJsonFile()) menu.add(0, MENU_FORMAT_JSON, 4, "จัดรูปแบบ JSON")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(MENU_SAVE)?.title = if (binaryMode) "บันทึก HEX" else "บันทึก"
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        android.R.id.home -> { onOpenTapped(); true }
        MENU_SAVE -> { saveAndClose(); true }
        MENU_SEARCH -> { showFindDialog(); true }
        MENU_REPLACE -> { showFindReplaceDialog(); true }
        MENU_GOTO_LINE -> { showGotoLineDialog(); true }
        MENU_UUID -> { generateManifestUuids(); true }
        MENU_FORMAT_JSON -> { formatJson(); true }
        else -> super.onOptionsItemSelected(item)
    }

    @Deprecated("Deprecated in Java", ReplaceWith("onOpenTapped()"))
    override fun onBackPressed() {
        onOpenTapped()
    }

    private fun saveAndClose() {
        val content = editText.text.toString()
        Toast.makeText(this, "กำลังบันทึก...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val bytes = if (binaryMode) hexToBytes(content) else {
                    if (isManifest) validateJsonOrThrow(content)
                    content.toByteArray(StandardCharsets.UTF_8)
                }
                val direct = directFile
                if (direct != null) {
                    val temp = File(direct.parentFile, ".${direct.name}.korn_tmp")
                    temp.outputStream().use { it.write(bytes) }
                    if (!temp.renameTo(direct)) {
                        if (!direct.delete() || !temp.renameTo(direct)) throw java.io.IOException("ไม่สามารถแทนที่ไฟล์ต้นฉบับได้")
                    }
                } else {
                    val tempFile = File(cacheDir, "edit_${System.currentTimeMillis()}.tmp")
                    tempFile.outputStream().use { it.write(bytes) }
                    ZipFileSystem.replaceEntryContent(zipFile, entryPath, tempFile)
                    tempFile.delete()
                }
                runOnUiThread {
                    Toast.makeText(this, if (direct != null) "บันทึกไฟล์แล้ว" else "บันทึกลงไฟล์ ZIP แล้ว", Toast.LENGTH_SHORT).show()
                    setResult(RESULT_OK); finish()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    /**
     * Editing starts locked (see finishLoading) so a stray tap on the text
     * can't put the cursor in and type/change anything by accident. The user
     * must explicitly tap "แก้ไข" to unlock it.
     */
    private fun setEditingLocked(locked: Boolean) {
        isEditLocked = locked
        editText.isFocusable = !locked
        editText.isFocusableInTouchMode = !locked
        editText.isCursorVisible = !locked
        editText.isLongClickable = !locked

        if (locked) {
            editText.clearFocus()
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(editText.windowToken, 0)
            btnToggleEdit.setBackgroundResource(0)
            labelToggleEdit.text = "แก้ไข"
        } else {
            lockedSnapshot = editText.text?.toString().orEmpty()
            editText.requestFocus()
            editText.setSelection(editText.text?.length?.coerceAtLeast(0) ?: 0)
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(editText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            btnToggleEdit.setBackgroundResource(R.drawable.bg_toolbar_toggle_active)
            labelToggleEdit.text = "กำลังแก้ไข"
        }
    }

    private fun toggleEditLock() {
        if (isEditLocked) {
            setEditingLocked(false)
        } else {
            // Locking back up is just "I'm done for now" - keep whatever was typed.
            setEditingLocked(true)
        }
    }

    private fun hasUnsavedChanges(): Boolean =
        !isEditLocked && editText.text?.toString() != lockedSnapshot

    private fun onOpenTapped() {
        if (hasUnsavedChanges()) {
            AlertDialog.Builder(this)
                .setTitle("ยังไม่ได้บันทึก")
                .setMessage("มีการแก้ไขที่ยังไม่ได้บันทึก ต้องการออกโดยไม่บันทึกใช่ไหม?")
                .setPositiveButton("ออกโดยไม่บันทึก") { _, _ -> finish() }
                .setNegativeButton("ยกเลิก", null)
                .show()
        } else {
            finish()
        }
    }

    private fun onNewFileTapped() {
        AlertDialog.Builder(this)
            .setTitle("เริ่มไฟล์ใหม่")
            .setMessage("ล้างข้อความทั้งหมดในตัวแก้ไขนี้และเริ่มพิมพ์ใหม่? การกระทำนี้จะไม่กระทบไฟล์เดิมจนกว่าจะกด \"บันทึก\"")
            .setPositiveButton("ล้างและเริ่มใหม่") { _, _ ->
                setEditingLocked(false)
                editText.setText("")
                lockedSnapshot = ""
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun onUndoTapped() {
        if (isEditLocked || editText.text?.toString() == lockedSnapshot) {
            Toast.makeText(this, "ยังไม่มีการแก้ไขที่จะยกเลิก", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("ยกเลิกการแก้ไข")
            .setMessage("ย้อนข้อความกลับไปก่อนหน้าที่จะเริ่มแก้ไขรอบนี้?")
            .setPositiveButton("ยกเลิกการแก้ไข") { _, _ ->
                editText.setText(lockedSnapshot)
                editText.setSelection(lockedSnapshot.length.coerceAtLeast(0))
                Toast.makeText(this, "ย้อนกลับแล้ว", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ไม่", null)
            .show()
    }


        val input = EditText(this); input.hint = if (binaryMode) "ค้นหา HEX เช่น FF 0D 0A" else "ข้อความที่ต้องการค้นหา"
        AlertDialog.Builder(this).setTitle("ค้นหา").setView(input)
            .setPositiveButton("ค้นหา") { _, _ ->
                val query = input.text.toString(); if (query.isBlank()) return@setPositiveButton
                val haystack = editText.text.toString(); val start = editText.selectionEnd.coerceAtLeast(0).coerceAtMost(haystack.length)
                val index = haystack.indexOf(query, start, ignoreCase = !binaryMode).let { if (it >= 0) it else haystack.indexOf(query, 0, ignoreCase = !binaryMode) }
                if (index >= 0) { editText.requestFocus(); editText.setSelection(index, (index + query.length).coerceAtMost(haystack.length)) }
                else Toast.makeText(this, "ไม่พบข้อมูล", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun showFindReplaceDialog() {
        if (binaryMode) {
            Toast.makeText(this, "ค้นหาและแทนที่ใช้กับไฟล์ข้อความเท่านั้น", Toast.LENGTH_SHORT).show()
            return
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val findInput = EditText(this).apply {
            hint = "ค้นหาคำหรือรูปแบบ"
            setSingleLine(true)
        }
        val replaceInput = EditText(this).apply {
            hint = "แทนที่ด้วย"
            setSingleLine(true)
        }
        val caseSensitive = android.widget.CheckBox(this).apply {
            text = "ตรงตามพิมพ์ใหญ่-เล็ก"
        }
        val wholeWord = android.widget.CheckBox(this).apply {
            text = "เฉพาะคำที่ตรงกันเท่านั้น"
        }
        val regex = android.widget.CheckBox(this).apply {
            text = "Regex (การจับคู่รูปแบบ)"
        }

        container.addView(findInput)
        container.addView(replaceInput)
        container.addView(caseSensitive)
        container.addView(wholeWord)
        container.addView(regex)

        val dialog = AlertDialog.Builder(this)
            .setTitle("ค้นหาและแทนที่")
            .setView(container)
            .setNegativeButton("ปิด", null)
            .setNeutralButton("ค้นหา", null)
            .setPositiveButton("แทนที่ทั้งหมด", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val query = findInput.text.toString()
                if (query.isEmpty()) {
                    findInput.error = "กรุณาใส่คำที่ต้องการค้นหา"
                    return@setOnClickListener
                }
                try {
                    val matcher = buildFindPattern(
                        query,
                        caseSensitive.isChecked,
                        wholeWord.isChecked,
                        regex.isChecked
                    ).matcher(editText.text)
                    val start = editText.selectionEnd.coerceAtLeast(0).coerceAtMost(editText.length())
                    val match = if (matcher.find(start)) matcher else {
                        val again = buildFindPattern(
                            query,
                            caseSensitive.isChecked,
                            wholeWord.isChecked,
                            regex.isChecked
                        ).matcher(editText.text)
                        if (again.find()) again else null
                    }
                    if (match != null) {
                        editText.requestFocus()
                        editText.setSelection(match.start(), match.end())
                        Toast.makeText(this, "พบข้อมูล", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "ไม่พบข้อมูล", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: PatternSyntaxException) {
                    findInput.error = "Regex ไม่ถูกต้อง: ${e.description}"
                }
            }

            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val query = findInput.text.toString()
                if (query.isEmpty()) {
                    findInput.error = "กรุณาใส่คำที่ต้องการค้นหา"
                    return@setOnClickListener
                }
                try {
                    val pattern = buildFindPattern(
                        query,
                        caseSensitive.isChecked,
                        wholeWord.isChecked,
                        regex.isChecked
                    )
                    val source = editText.text.toString()
                    val matcher = pattern.matcher(source)
                    val replacement = if (regex.isChecked) {
                        replaceInput.text.toString()
                    } else {
                        MatcherQuote.quoteReplacement(replaceInput.text.toString())
                    }

                    val result = StringBuffer(source.length)
                    var count = 0
                    while (matcher.find()) {
                        matcher.appendReplacement(result, replacement)
                        count++
                    }
                    matcher.appendTail(result)

                    if (count == 0) {
                        Toast.makeText(this, "ไม่พบข้อมูลที่ตรงกัน", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }

                    val oldSelectionStart = editText.selectionStart
                    editText.setText(result.toString())
                    editText.setSelection(oldSelectionStart.coerceIn(0, editText.length()))
                    Toast.makeText(this, "แทนที่ทั้งหมด $count จุด", Toast.LENGTH_SHORT).show()
                } catch (e: PatternSyntaxException) {
                    findInput.error = "Regex ไม่ถูกต้อง: ${e.description}"
                } catch (e: IllegalArgumentException) {
                    replaceInput.error = "รูปแบบข้อความแทนที่ไม่ถูกต้อง"
                }
            }
        }

        dialog.show()
    }

    private fun buildFindPattern(
        query: String,
        caseSensitive: Boolean,
        wholeWord: Boolean,
        useRegex: Boolean
    ): Pattern {
        var expression = if (useRegex) query else Pattern.quote(query)
        if (wholeWord) {
            expression = "(?<![\\\\p{L}\\\\p{N}_])(?:$expression)(?![\\\\p{L}\\\\p{N}_])"
        }
        val flags = if (caseSensitive) Pattern.UNICODE_CASE else {
            Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
        }
        return Pattern.compile(expression, flags)
    }

    // Small helper so literal replacement text is never interpreted as $1, $2, etc.
    private object MatcherQuote {
        fun quoteReplacement(value: String): String =
            value.replace("\\\\", "\\\\\\\\").replace("$", "\\\\$")
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun showGotoLineDialog() {
        val input = EditText(this); input.inputType = android.text.InputType.TYPE_CLASS_NUMBER; input.hint = "หมายเลขบรรทัด"
        AlertDialog.Builder(this).setTitle("ไปบรรทัด").setView(input)
            .setPositiveButton("ไป") { _, _ ->
                val line = input.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: return@setPositiveButton
                val text = editText.text.toString(); var position = 0
                repeat(line - 1) { val next = text.indexOf('\n', position); if (next < 0) return@repeat; position = next + 1 }
                editText.setSelection(position.coerceAtMost(text.length)); editText.requestFocus()
            }.setNegativeButton("ยกเลิก", null).show()
    }

    private fun validateJsonOrThrow(text: String) { if (text.trim().startsWith("[")) JSONArray(text.trim()) else JSONObject(text.trim()) }
    private fun isJsonFile(): Boolean = entryPath.substringAfterLast('/').substringAfterLast('.', "").equals("json", true) || directFile?.extension.equals("json", true)

    private fun formatJson() {
        try { val text = editText.text.toString(); val formatted = if (text.trimStart().startsWith("[")) JSONArray(text).toString(2) else JSONObject(text).toString(2); editText.setText(formatted); editText.setSelection(0) }
        catch (e: Exception) { Toast.makeText(this, "JSON ไม่ถูกต้อง: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun generateManifestUuids() {
        try {
            val obj = JSONObject(editText.text.toString()); val header = obj.optJSONObject("header") ?: JSONObject().also { obj.put("header", it) }; header.put("uuid", UUID.randomUUID().toString())
            val modules = obj.optJSONArray("modules") ?: JSONArray().also { obj.put("modules", it) }; val module = if (modules.length() > 0) modules.optJSONObject(0) ?: JSONObject() else JSONObject(); if (modules.length() == 0) modules.put(module); module.put("uuid", UUID.randomUUID().toString())
            val dependencies = obj.optJSONArray("dependencies") ?: JSONArray().also { obj.put("dependencies", it) }; val dep = if (dependencies.length() > 0) dependencies.optJSONObject(0) ?: JSONObject() else JSONObject(); if (dependencies.length() == 0) dependencies.put(dep); dep.put("uuid", UUID.randomUUID().toString())
            editText.setText(obj.toString(2)); Toast.makeText(this, "สร้าง UUID ใหม่ 3 ชุดแล้ว", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "manifest.json ไม่ใช่ JSON ที่ถูกต้อง: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private val editorWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(s: Editable?) { if (!loading) { updateToolbarSubtitle(); if (!binaryMode && !applyingHighlight) scheduleHighlight() } }
    }

    private fun scheduleHighlight() { highlightHandler.removeCallbacks(highlightRunnable); highlightHandler.postDelayed(highlightRunnable, 600L) }
    private fun updateToolbarSubtitle() { supportActionBar?.subtitle = "${if (binaryMode) "HEX" else "ข้อความ"} • ${editText.text?.length ?: 0} ตัวอักษร • เดิม ${originalSize} bytes" }

    private fun highlight() {
        if (binaryMode || applyingHighlight || loading || isFinishing || isDestroyed) return
        val editable = editText.text ?: return
        if (editable.length > largeFileHighlightLimit) return
        applyingHighlight = true
        try {
            editable.getSpans(0, editable.length, ForegroundColorSpan::class.java).forEach(editable::removeSpan)
            val text = editable.toString()
            val ext = (entryPath.substringAfterLast('/').substringAfterLast('.', directFile?.extension ?: "")).lowercase()
            val codeLike = isManifest || isJsonFile() || ext in setOf("xml","js","ts","kt","kts","java","gradle","css","html","py","yml","yaml","mcfunction")
            if (!codeLike) return
            Regex("\\\"(?:\\\\.|[^\\\"\\\\])*\\\"").findAll(text).forEach {
                val after = text.substring(it.range.last + 1).dropWhile(Char::isWhitespace)
                editable.setSpan(ForegroundColorSpan(if (after.startsWith(":")) Color.rgb(30,90,180) else Color.rgb(150,60,20)), it.range.first, it.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            Regex("\\b\\d+(?:\\.\\d+)?\\b").findAll(text).forEach { editable.setSpan(ForegroundColorSpan(Color.rgb(120,70,160)), it.range.first, it.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        } catch (_: Exception) {
            editable.getSpans(0, editable.length, ForegroundColorSpan::class.java).forEach(editable::removeSpan)
        } finally { applyingHighlight = false }
    }

    private fun decodeText(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return ""
        if (bytes.any { it.toInt() == 0 }) return null
        val candidates = mutableListOf<Charset>()
        when {
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() -> candidates.add(StandardCharsets.UTF_8)
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() -> candidates.add(StandardCharsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() -> candidates.add(StandardCharsets.UTF_16BE)
        }
        candidates.add(StandardCharsets.UTF_8)
        try { candidates.add(Charset.forName("windows-874")) } catch (_: Exception) {}
        try { candidates.add(Charset.forName("TIS-620")) } catch (_: Exception) {}
        for (charset in candidates.distinct()) {
            try {
                val decoder = charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                val text = decoder.decode(ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
                val sample = text.take(8192); var controls = 0
                for (c in sample) if (c < ' ' && c != '\n' && c != '\r' && c != '\t') controls++
                if (sample.isEmpty() || controls.toDouble() / sample.length < 0.02) return text
            } catch (_: CharacterCodingException) {}
        }
        return null
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val out = StringBuilder(bytes.size * 3 + bytes.size / 16)
        for (index in bytes.indices) { if (index > 0) out.append(if (index % 16 == 0) '\n' else ' '); out.append("%02X".format(bytes[index].toInt() and 0xff)) }
        return out.toString()
    }

    private fun hexToBytes(text: String): ByteArray {
        val clean = text.replace(Regex("[^0-9A-Fa-f]"), "")
        if (clean.length % 2 != 0) throw IllegalArgumentException("HEX ต้องมีจำนวนหลักเป็นเลขคู่")
        val result = ByteArray(clean.length / 2)
        var i = 0
        while (i < clean.length) { result[i / 2] = clean.substring(i, i + 2).toInt(16).toByte(); i += 2 }
        return result
    }

    override fun onDestroy() { highlightHandler.removeCallbacks(highlightRunnable); super.onDestroy() }

    companion object {
        const val EXTRA_ZIP_PATH = "zip_path"
        const val EXTRA_ENTRY_PATH = "entry_path"
        const val EXTRA_FILE_PATH = "file_path"
        private const val MENU_SAVE = 1
        private const val MENU_SEARCH = 2
        private const val MENU_REPLACE = 3
        private const val MENU_GOTO_LINE = 4
        private const val MENU_UUID = 5
        private const val MENU_FORMAT_JSON = 6
        private const val MAX_HEX_BYTES = 2 * 1024 * 1024
    }
}
