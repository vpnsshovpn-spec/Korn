package com.example.filemanager

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.UUID

/**
 * Universal in-app editor.
 *
 * Text files are opened as UTF-8 and can be edited normally. Unknown/binary files are opened
 * as a HEX editor, so every regular file can still be inspected and edited without pretending
 * that an image/APK/ZIP is text. ZIP entries are written back through ZipFileSystem.
 */
class TextEditActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var toolbar: Toolbar
    private lateinit var zipFile: File
    private lateinit var entryPath: String
    private var directFile: File? = null
    private var isManifest = false
    private var binaryMode = false
    private var originalSize = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_edit)

        toolbar = findViewById(R.id.textEditToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        editText = findViewById(R.id.textEditContent)
        editText.setHorizontallyScrolling(false)
        // Never let a pending full-document syntax pass interrupt a scroll/fling.
        // Scrolling must never trigger document-wide syntax processing.
        // Highlighting is scheduled only after editing/loading has settled.

        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH) ?: ""
        val filePath = intent.getStringExtra(EXTRA_FILE_PATH)

        try {
            if (!filePath.isNullOrEmpty()) {
                directFile = File(filePath)
                if (!directFile!!.isFile) throw IllegalArgumentException("ไม่พบไฟล์")
                val bytes = directFile!!.readBytes()
                originalSize = bytes.size.toLong()
                supportActionBar?.title = directFile!!.name
                loadBytes(bytes, directFile!!.name)
            } else {
                if (zipPath == null || entryPath.isEmpty()) throw IllegalArgumentException("ไม่พบไฟล์")
                zipFile = File(zipPath)
                if (!zipFile.isFile) throw IllegalArgumentException("ไม่พบไฟล์ ZIP")
                supportActionBar?.title = entryPath.substringAfterLast('/')
                val bytes = ZipFileSystem.readEntryBytes(zipFile, entryPath)
                originalSize = bytes.size.toLong()
                loadBytes(bytes, entryPath.substringAfterLast('/'))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "อ่านไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        editText.addTextChangedListener(editorWatcher)
        updateToolbarSubtitle()
    }

    private fun loadBytes(bytes: ByteArray, name: String) {
        binaryMode = !looksLikeText(bytes)
        isManifest = !binaryMode && name.equals("manifest.json", true)

        if (binaryMode) {
            editText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            editText.setText(bytesToHex(bytes))
            editText.setSelection(0)
            supportActionBar?.subtitle = "HEX • ${bytes.size} bytes"
        } else {
            editText.inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            editText.setText(String(bytes, StandardCharsets.UTF_8))
            editText.setSelection(0)
            // Do not highlight while the Activity is still being created. A large
            // document must first become visible and usable; highlighting is optional.
            editText.post {
                if (!isFinishing && !isDestroyed) scheduleHighlight()
            }
            supportActionBar?.subtitle = "ข้อความ • ${bytes.size} bytes"
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, MENU_SAVE, 0, "บันทึก")
        menu.add(0, MENU_SEARCH, 1, "ค้นหา")
        if (!binaryMode) menu.add(0, MENU_GOTO_LINE, 2, "ไปบรรทัด")
        if (!binaryMode && isManifest) menu.add(0, MENU_UUID, 3, "🆔 สร้าง UUID 3 ชุด")
        if (!binaryMode && isJsonFile()) menu.add(0, MENU_FORMAT_JSON, 4, "จัดรูปแบบ JSON")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(MENU_SAVE)?.title = if (binaryMode) "บันทึก HEX" else "บันทึก"
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> { finish(); true }
            MENU_SAVE -> { saveAndClose(); true }
            MENU_SEARCH -> { showFindDialog(); true }
            MENU_GOTO_LINE -> { showGotoLineDialog(); true }
            MENU_UUID -> { generateManifestUuids(); true }
            MENU_FORMAT_JSON -> { formatJson(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun saveAndClose() {
        val content = editText.text.toString()
        Toast.makeText(this, "กำลังบันทึก...", Toast.LENGTH_SHORT).show()

        Thread {
            try {
                val bytes = if (binaryMode) {
                    hexToBytes(content)
                } else {
                    if (isManifest) validateJsonOrThrow(content)
                    content.toByteArray(StandardCharsets.UTF_8)
                }

                val direct = directFile
                if (direct != null) {
                    val temp = File(direct!!.parentFile, ".${direct!!.name}.korn_tmp")
                    temp.outputStream().use { it.write(bytes) }
                    if (!temp.renameTo(direct!!)) {
                        if (!direct!!.delete() || !temp.renameTo(direct!!)) {
                            throw java.io.IOException("ไม่สามารถแทนที่ไฟล์ต้นฉบับได้")
                        }
                    }
                } else {
                    val tempFile = File(cacheDir, "edit_${System.currentTimeMillis()}.tmp")
                    tempFile.outputStream().use { it.write(bytes) }
                    ZipFileSystem.replaceEntryContent(zipFile, entryPath, tempFile)
                    tempFile.delete()
                }

                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (direct != null) "บันทึกไฟล์แล้ว" else "บันทึกลงไฟล์ ZIP แล้ว",
                        Toast.LENGTH_SHORT
                    ).show()
                    setResult(RESULT_OK)
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showFindDialog() {
        val input = EditText(this)
        input.hint = if (binaryMode) "ค้นหา HEX เช่น FF 0D 0A" else "ข้อความที่ต้องการค้นหา"
        AlertDialog.Builder(this)
            .setTitle("ค้นหา")
            .setView(input)
            .setPositiveButton("ค้นหา") { _, _ ->
                val query = input.text.toString()
                if (query.isBlank()) return@setPositiveButton
                val haystack = editText.text.toString()
                val start = (editText.selectionEnd.coerceAtLeast(0)).coerceAtMost(haystack.length)
                val index = haystack.indexOf(query, start, ignoreCase = !binaryMode)
                    .let { if (it >= 0) it else haystack.indexOf(query, 0, ignoreCase = !binaryMode) }
                if (index >= 0) {
                    editText.requestFocus()
                    editText.setSelection(index, (index + query.length).coerceAtMost(haystack.length))
                } else {
                    Toast.makeText(this, "ไม่พบข้อมูล", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun showGotoLineDialog() {
        val input = EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        input.hint = "หมายเลขบรรทัด"
        AlertDialog.Builder(this)
            .setTitle("ไปบรรทัด")
            .setView(input)
            .setPositiveButton("ไป") { _, _ ->
                val line = input.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: return@setPositiveButton
                val text = editText.text.toString()
                var position = 0
                repeat(line - 1) {
                    val next = text.indexOf('\n', position)
                    if (next < 0) return@repeat
                    position = next + 1
                }
                editText.setSelection(position.coerceAtMost(text.length))
                editText.requestFocus()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun validateJsonOrThrow(text: String) {
        val trimmed = text.trim()
        if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed)
    }

    private fun isJsonFile(): Boolean =
        entryPath.substringAfterLast('/').substringAfterLast('.', "").equals("json", true) ||
            directFile?.extension.equals("json", true)

    private fun formatJson() {
        try {
            val text = editText.text.toString()
            val formatted = if (text.trimStart().startsWith("[")) {
                JSONArray(text).toString(2)
            } else {
                JSONObject(text).toString(2)
            }
            editText.setText(formatted)
            editText.setSelection(0)
        } catch (e: Exception) {
            Toast.makeText(this, "JSON ไม่ถูกต้อง: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun generateManifestUuids() {
        try {
            val obj = JSONObject(editText.text.toString())
            val header = obj.optJSONObject("header") ?: JSONObject().also { obj.put("header", it) }
            header.put("uuid", UUID.randomUUID().toString())

            val modules = obj.optJSONArray("modules") ?: JSONArray().also { obj.put("modules", it) }
            val module = if (modules.length() > 0) modules.optJSONObject(0) ?: JSONObject() else JSONObject()
            if (modules.length() == 0) modules.put(module)
            module.put("uuid", UUID.randomUUID().toString())

            val dependencies = obj.optJSONArray("dependencies") ?: JSONArray().also { obj.put("dependencies", it) }
            val dep = if (dependencies.length() > 0) dependencies.optJSONObject(0) ?: JSONObject() else JSONObject()
            if (dependencies.length() == 0) dependencies.put(dep)
            dep.put("uuid", UUID.randomUUID().toString())

            editText.setText(obj.toString(2))
            Toast.makeText(this, "สร้าง UUID ใหม่ 3 ชุดแล้ว", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "manifest.json ไม่ใช่ JSON ที่ถูกต้อง: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private var applyingHighlight = false
    private val highlightHandler = Handler(Looper.getMainLooper())
    private val highlightRunnable = Runnable { highlight() }
    private val largeFileHighlightLimit = 100_000

    private val editorWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(s: Editable?) {
            updateToolbarSubtitle()
            if (!binaryMode && !applyingHighlight) scheduleHighlight()
        }
    }

    private fun scheduleHighlight(immediate: Boolean = false) {
        highlightHandler.removeCallbacks(highlightRunnable)
        if (immediate) {
            highlightHandler.post(highlightRunnable)
        } else {
            // Debounce syntax work while the user is typing. This keeps scrolling/cursor
            // movement independent from regex processing of the entire document.
            highlightHandler.postDelayed(highlightRunnable, 300L)
        }
    }

    private fun updateToolbarSubtitle() {
        val chars = editText.text?.length ?: 0
        val mode = if (binaryMode) "HEX" else "ข้อความ"
        supportActionBar?.subtitle = "$mode • $chars ตัวอักษร • เดิม ${originalSize} bytes"
    }

    /** Lightweight syntax highlighting for JSON/XML/code-like text without replacing the EditText on every keystroke. */
    private fun highlight() {
        if (binaryMode || applyingHighlight || !::editText.isInitialized) return
        val editable = try { editText.text } catch (_: Throwable) { return } ?: return
        try {
            highlightInternal(editable)
        } catch (_: Throwable) {
            // Syntax highlighting must never be allowed to crash the editor.
            applyingHighlight = false
        }
    }

    private fun highlightInternal(editable: Editable) {
        if (editable.length > largeFileHighlightLimit) {
            // For very large documents, plain text editing is substantially smoother than
            // repeatedly applying thousands of spans. Existing spans are removed once and
            // the editor remains fully editable/searchable/savable.
            applyingHighlight = true
            try {
                editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
                    .forEach { editable.removeSpan(it) }
            } finally {
                applyingHighlight = false
            }
            return
        }
        applyingHighlight = true
        try {
            val spans = editable.getSpans(0, editable.length, ForegroundColorSpan::class.java)
            spans.forEach { editable.removeSpan(it) }

            val text = editable.toString()
            val codeLike = isManifest || isJsonFile() ||
                entryPath.substringAfterLast('/').let {
                    val ext = it.substringAfterLast('.', "").lowercase()
                    ext in setOf("xml", "js", "ts", "kt", "kts", "java", "gradle", "css", "html", "py", "yml", "yaml", "mcfunction")
                }
            if (!codeLike) return

            Regex("\"(?:\\\\.|[^\"\\\\])*\"").findAll(text).forEach {
                val after = text.drop(it.range.last + 1).dropWhile { c -> c.isWhitespace() }
                val color = if (after.startsWith(":")) Color.rgb(30, 90, 180) else Color.rgb(150, 60, 20)
                editable.setSpan(
                    ForegroundColorSpan(color),
                    it.range.first, it.range.last + 1,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            Regex("""\b\d+(?:\.\d+)?\b""").findAll(text).forEach {
                editable.setSpan(
                    ForegroundColorSpan(Color.rgb(120, 70, 160)),
                    it.range.first, it.range.last + 1,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        } finally {
            applyingHighlight = false
        }
    }

    private fun looksLikeText(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return true
        // A NUL byte is a strong binary signal for common Android/PC binary formats.
        if (bytes.any { it.toInt() == 0 }) return false
        try {
            val decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            decoder.decode(ByteBuffer.wrap(bytes))
        } catch (_: CharacterCodingException) {
            return false
        }

        var controls = 0
        val sample = bytes.take(minOf(bytes.size, 8192))
        for (b in sample) {
            val c = b.toInt() and 0xff
            if (c < 0x09 || (c in 0x0E..0x1F)) controls++
        }
        return controls.toDouble() / sample.size < 0.02
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val out = StringBuilder(bytes.size * 3 + bytes.size / 16 * 12)
        bytes.forEachIndexed { index, b ->
            if (index > 0) {
                if (index % 16 == 0) out.append('\n') else out.append(' ')
            }
            out.append(String.format("%02X", b.toInt() and 0xff))
        }
        return out.toString()
    }

    private fun hexToBytes(text: String): ByteArray {
        val clean = text.replace(Regex("[^0-9A-Fa-f]"), "")
        if (clean.length % 2 != 0) throw IllegalArgumentException("HEX ต้องมีจำนวนหลักเป็นเลขคู่")
        val result = ByteArray(clean.length / 2)
        var i = 0
        while (i < clean.length) {
            val value = clean.substring(i, i + 2).toIntOrNull(16)
                ?: throw IllegalArgumentException("HEX ไม่ถูกต้อง")
            result[i / 2] = value.toByte()
            i += 2
        }
        return result
    }

    override fun onDestroy() {
        highlightHandler.removeCallbacks(highlightRunnable)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ZIP_PATH = "zip_path"
        const val EXTRA_ENTRY_PATH = "entry_path"
        const val EXTRA_FILE_PATH = "file_path"

        private const val MENU_SAVE = 1
        private const val MENU_SEARCH = 2
        private const val MENU_GOTO_LINE = 3
        private const val MENU_UUID = 4
        private const val MENU_FORMAT_JSON = 5
    }
}
