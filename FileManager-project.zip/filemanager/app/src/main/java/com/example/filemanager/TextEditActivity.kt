package com.example.filemanager

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.graphics.Color
import java.util.UUID
import org.json.JSONObject
import org.json.JSONArray
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.io.File

/**
 * Edits a single text entry that lives inside a zip. The entry's bytes are read into memory,
 * shown in a plain EditText, and on Save written back into the zip via
 * [ZipFileSystem.replaceEntryContent] — the rest of the archive's entries are never touched.
 */
class TextEditActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var zipFile: File
    private lateinit var entryPath: String
    private var directFile: File? = null
    private var isManifest = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_edit)

        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH) ?: ""
        val filePath = intent.getStringExtra(EXTRA_FILE_PATH)

        val toolbar = findViewById<Toolbar>(R.id.textEditToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        editText = findViewById(R.id.textEditContent)

        try {
            if (!filePath.isNullOrEmpty()) {
                directFile = File(filePath)
                if (!directFile!!.isFile) throw IllegalArgumentException("ไม่พบไฟล์")
                supportActionBar?.title = directFile!!.name
                editText.setText(directFile!!.readText(Charsets.UTF_8))
                isManifest = directFile!!.name.equals("manifest.json", true)
            } else {
                if (zipPath == null || entryPath.isEmpty()) throw IllegalArgumentException("ไม่พบไฟล์")
                zipFile = File(zipPath)
                supportActionBar?.title = entryPath.substringAfterLast('/')
                val bytes = ZipFileSystem.readEntryBytes(zipFile, entryPath)
                editText.setText(String(bytes, Charsets.UTF_8))
                isManifest = entryPath.substringAfterLast('/').equals("manifest.json", true)
            }
            highlight()
        } catch (e: Exception) {
            Toast.makeText(this, "อ่านไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }

        editText.addTextChangedListener(editorWatcher)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "บันทึก")
        if (isManifest) menu.add(0, 2, 1, "🆔 สร้าง UUID 3 ชุด")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> { finish(); return true }
            1 -> { saveAndClose(); return true }
            2 -> { generateManifestUuids(); return true }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun saveAndClose() {
        Toast.makeText(this, "กำลังบันทึก...", Toast.LENGTH_SHORT).show()
        val content = editText.text.toString()
        Thread {
            try {
                if (isManifest) validateJsonOrThrow(content)
                val direct = directFile
                if (direct != null) {
                    direct.writeText(content, Charsets.UTF_8)
                } else {
                    val tempFile = File(cacheDir, "edit_${System.currentTimeMillis()}.tmp")
                    tempFile.writeText(content, Charsets.UTF_8)
                    ZipFileSystem.replaceEntryContent(zipFile, entryPath, tempFile)
                    tempFile.delete()
                }
                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (direct != null) "บันทึกไฟล์แล้ว" else "บันทึกลงไฟล์ ZIP แล้ว",
                        Toast.LENGTH_SHORT
                    ).show()
                    setResult(RESULT_OK)
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }


    private fun validateJsonOrThrow(text: String) {
        JSONObject(text)
    }

    private fun generateManifestUuids() {
        try {
            val obj = JSONObject(editText.text.toString())
            val header = obj.optJSONObject("header") ?: JSONObject().also { obj.put("header", it) }
            header.put("uuid", UUID.randomUUID().toString())

            val modules = obj.optJSONArray("modules") ?: JSONArray().also { obj.put("modules", it) }
            val module = if (modules.length() > 0) modules.optJSONObject(0) ?: JSONObject() else JSONObject()
            if (modules.length() == 0) modules.put(module)
            module.put("uuid", UUID.randomUUID().toString())

            val dependencies = obj.optJSONArray("dependencies") ?: JSONArray().also { obj.put("dependencies", it) }
            val dep = if (dependencies.length() > 0) dependencies.optJSONObject(0) ?: JSONObject() else JSONObject()
            if (dependencies.length() == 0) dependencies.put(dep)
            dep.put("uuid", UUID.randomUUID().toString())

            editText.setText(obj.toString(2))
            Toast.makeText(this, "สร้าง UUID ใหม่ 3 ชุดแล้ว", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "manifest.json ไม่ใช่ JSON ที่ถูกต้อง: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private var applyingHighlight = false
    private val editorWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            if (!applyingHighlight) highlight()
        }
    }

    /** Lightweight editor highlighting: strings, JSON keys, comments and numbers. */
    private fun highlight() {
        if (applyingHighlight) return
        val text = editText.text.toString()
        val ss = SpannableString(text)
        val isCode = isManifest || entryPath.endsWith(".json", true) || entryPath.endsWith(".mcfunction", true)
        if (!isCode) return
        val stringRegex = Regex("\"(?:\\\\.|[^\"\\\\])*\"")
        stringRegex.findAll(text).forEach {
            val isKey = text.drop(it.range.last + 1).dropWhile { c -> c.isWhitespace() }.startsWith(":")
            ss.setSpan(ForegroundColorSpan(if (isKey) Color.rgb(30, 90, 180) else Color.rgb(150, 60, 20)),
                it.range.first, it.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        Regex("""\b\d+(?:\.\d+)?\b""").findAll(text).forEach {
            ss.setSpan(ForegroundColorSpan(Color.rgb(120, 70, 160)), it.range.first, it.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val pos = editText.selectionStart.coerceAtLeast(0).coerceAtMost(ss.length)
        applyingHighlight = true
        editText.removeTextChangedListener(editorWatcher)
        editText.setText(ss)
        editText.setSelection(pos)
        editText.addTextChangedListener(editorWatcher)
        applyingHighlight = false
    }

    companion object {
        const val EXTRA_ZIP_PATH = "zip_path"
        const val EXTRA_ENTRY_PATH = "entry_path"
        const val EXTRA_FILE_PATH = "file_path"
    }
}
