package com.example.filemanager

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.io.File

/**
 * Edits a single text entry that lives inside a zip. The entry's bytes are read into memory,
 * shown in a plain EditText, and on Save written back into the zip via
 * [ZipFileSystem.replaceEntryContent] — the rest of the archive's entries are never touched.
 */
class TextEditActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var zipFile: File
    private lateinit var entryPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_edit)

        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH)
        entryPath = intent.getStringExtra(EXTRA_ENTRY_PATH) ?: ""
        if (zipPath == null || entryPath.isEmpty()) {
            Toast.makeText(this, "เปิดไฟล์ไม่ได้", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        zipFile = File(zipPath)

        val toolbar = findViewById<Toolbar>(R.id.textEditToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = entryPath.substringAfterLast('/')

        editText = findViewById(R.id.textEditContent)

        try {
            val bytes = ZipFileSystem.readEntryBytes(zipFile, entryPath)
            editText.setText(String(bytes, Charsets.UTF_8))
        } catch (e: Exception) {
            Toast.makeText(this, "อ่านไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "บันทึก")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> { finish(); return true }
            1 -> { saveAndClose(); return true }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun saveAndClose() {
        Toast.makeText(this, "กำลังบันทึก...", Toast.LENGTH_SHORT).show()
        val content = editText.text.toString()
        Thread {
            try {
                val tempFile = File(cacheDir, "edit_${System.currentTimeMillis()}.tmp")
                tempFile.writeText(content, Charsets.UTF_8)
                ZipFileSystem.replaceEntryContent(zipFile, entryPath, tempFile)
                tempFile.delete()
                runOnUiThread {
                    Toast.makeText(this, "บันทึกลงไฟล์ ZIP แล้ว", Toast.LENGTH_SHORT).show()
                    setResult(RESULT_OK)
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    companion object {
        const val EXTRA_ZIP_PATH = "zip_path"
        const val EXTRA_ENTRY_PATH = "entry_path"
    }
}
