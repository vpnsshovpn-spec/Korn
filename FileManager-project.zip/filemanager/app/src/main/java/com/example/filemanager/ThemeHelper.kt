package com.example.filemanager

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.widget.Toolbar

/**
 * Reads the theme the user picked in the Settings dialog (saved under
 * "korn_settings" / "theme_key") and returns/applies the matching colors.
 *
 * MainActivity has its own applyThemePalette() that colors the whole main
 * screen (drawer, buttons, etc). Every other screen (text editor, zip
 * browser, storage analyzer, "open with" picker) only had a default blue
 * toolbar hardcoded in styles.xml, so picking e.g. red in Settings never
 * changed them. This file is the single place the palette is defined so
 * secondary screens can match the same theme with one call.
 */
object ThemeHelper {

    /** primary, primaryDark, background - same palette MainActivity uses. */
    fun colors(activity: Activity): Triple<Int, Int, Int> {
        val prefs = activity.getSharedPreferences("korn_settings", Activity.MODE_PRIVATE)
        val themeKey = prefs.getString("theme_key", "system") ?: "system"
        val systemDark = (activity.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        return when (themeKey) {
            "green" -> Triple(Color.rgb(46, 160, 105), Color.rgb(32, 122, 79), Color.rgb(247, 252, 249))
            "red" -> Triple(Color.rgb(220, 70, 70), Color.rgb(180, 45, 45), Color.rgb(255, 248, 248))
            "gray" -> Triple(Color.rgb(115, 123, 135), Color.rgb(82, 89, 100), Color.rgb(242, 243, 245))
            "dark" -> Triple(Color.rgb(82, 100, 120), Color.rgb(58, 72, 87), Color.rgb(30, 32, 35))
            "light" -> Triple(Color.rgb(33, 150, 243), Color.rgb(25, 118, 210), Color.WHITE)
            "system" -> if (systemDark) {
                Triple(Color.rgb(90, 155, 220), Color.rgb(55, 105, 155), Color.rgb(30, 32, 35))
            } else {
                Triple(Color.rgb(33, 150, 243), Color.rgb(25, 118, 210), Color.WHITE)
            }
            else -> Triple(Color.rgb(33, 150, 243), Color.rgb(25, 118, 210), Color.WHITE)
        }
    }

    /** For screens with their own androidx Toolbar view (TextEdit, ZipBrowser). */
    fun apply(activity: Activity, toolbar: Toolbar) {
        val (primary, primaryDark, _) = colors(activity)
        toolbar.setBackgroundColor(primary)
        activity.window.statusBarColor = primaryDark
    }

    /** For screens using the default AppCompat action bar with no custom Toolbar (OpenWith, StorageAnalyzer). */
    fun apply(activity: androidx.appcompat.app.AppCompatActivity) {
        val (primary, primaryDark, _) = colors(activity)
        activity.supportActionBar?.setBackgroundDrawable(ColorDrawable(primary))
        activity.window.statusBarColor = primaryDark
    }
}
