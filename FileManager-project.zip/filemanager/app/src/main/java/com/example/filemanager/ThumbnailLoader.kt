package com.example.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.util.concurrent.Executors

/**
 * Minimal background image-thumbnail loader for grid view, with an in-memory LRU cache.
 * No third-party image library is used - just downsampled BitmapFactory decoding.
 */
object ThumbnailLoader {

    private val executor = Executors.newFixedThreadPool(3)

    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun keyFor(file: File): String = "${file.absolutePath}_${file.lastModified()}_${file.length()}"

    /** Loads a downsampled thumbnail of [file] into [imageView], sized around [reqPx]. */
    fun load(file: File, imageView: ImageView, reqPx: Int) {
        val key = keyFor(file)
        imageView.tag = key

        val cached = cache.get(key)
        if (cached != null) {
            imageView.setImageBitmap(cached)
            return
        }

        imageView.setImageDrawable(null)
        executor.execute {
            val bmp = decodeSampled(file, reqPx)
            if (bmp != null) cache.put(key, bmp)
            imageView.post {
                // Guard against the ViewHolder having been recycled for a different item
                // while this decode was running in the background.
                if (imageView.tag == key && bmp != null) {
                    imageView.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun decodeSampled(file: File, reqSize: Int): Bitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            var sample = 1
            while (boundsOpts.outWidth / (sample * 2) >= reqSize && boundsOpts.outHeight / (sample * 2) >= reqSize) {
                sample *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}
