package com.example.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Round 18 (Task 2): background image-thumbnail loader for grid view, with an in-memory
 * LRU cache. Previously used a shared Executor + a `tag`-only guard against stale results;
 * now decodes via a coroutine launched in the *caller's* scope, and returns that Job so a
 * RecyclerView ViewHolder can cancel it explicitly on rebind/recycle (see FileAdapter.VH),
 * instead of only relying on the tag check to silently ignore a stale result after the
 * fact. The tag check is kept too, as a second line of defense.
 */
object ThumbnailLoader {

    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun keyFor(file: File): String = "${file.absolutePath}_${file.lastModified()}_${file.length()}"

    /** Synchronous cache-only lookup (no decoding, no coroutine hop). */
    fun cached(file: File): Bitmap? = cache.get(keyFor(file))

    /**
     * Loads a downsampled thumbnail of [file], sized around [reqPx], into [imageView].
     * The decode runs on Dispatchers.IO inside a coroutine launched in [scope] (normally
     * the ViewHolder's LifecycleOwner's lifecycleScope). The returned [Job] should be
     * stored on the ViewHolder and cancelled before binding a new item / in onViewRecycled,
     * so a slow decode for a recycled-away item can never land on the wrong row.
     */
    fun load(scope: CoroutineScope, file: File, imageView: ImageView, reqPx: Int): Job {
        val key = keyFor(file)
        imageView.tag = key

        val cachedBitmap = cache.get(key)
        if (cachedBitmap != null) {
            imageView.setImageBitmap(cachedBitmap)
            return Job().apply { complete() }
        }

        imageView.setImageDrawable(null)
        return scope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeSampled(file, reqPx) }
            // Guard against this ViewHolder having been recycled for a different item while
            // the decode was running - imageView.tag will have moved on to a different key.
            if (bmp != null && imageView.tag == key) {
                cache.put(key, bmp)
                imageView.setImageBitmap(bmp)
            }
        }
    }

    private fun decodeSampled(file: File, reqSize: Int): Bitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            var sample = 1
            while (boundsOpts.outWidth / (sample * 2) >= reqSize && boundsOpts.outHeight / (sample * 2) >= reqSize) {
                sample *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}
