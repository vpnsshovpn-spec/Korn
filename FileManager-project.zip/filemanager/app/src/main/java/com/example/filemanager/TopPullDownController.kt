package com.example.filemanager

import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import androidx.core.view.doOnLayout

/**
 * Owns everything about the Top Pull-Down Drawer's *behavior* - the slide
 * animation, the closed/open offset math, and the drag gesture on the handle -
 * so MainActivity only has to wire two views together (see MainActivity.kt's
 * onCreate, ~4 lines) and never touches this logic directly.
 *
 * [panel] is the root of view_top_pull_down.xml (R.id.topPullDownPanel) - a vertical
 * LinearLayout whose LAST child is [handle]'s parent strip (R.id.pullDownHandleStrip).
 * Because the handle strip is the last child, translating the whole panel up by
 * (panelHeight - handleStripHeight) tucks every other row away above the screen while
 * leaving exactly the handle strip visible right under the Toolbar - the "always-visible
 * pull tab" Korn asked for. Translating back to 0 reveals the whole panel, sliding it down
 * over whatever file-list content is underneath (it's laid out as an overlay in
 * activity_main.xml, not part of the scrolling content).
 *
 * Two ways to open/close, both supported:
 *  - Tap the handle: toggles with an animated slide (see [toggle]).
 *  - Drag the handle: panel follows the finger 1:1, then snaps open or closed on release
 *    based on how far it was dragged and how fast the finger was moving (see [handleTouch]).
 */
class TopPullDownController(
    private val panel: View,
    private val handle: View
) {

    private var isOpen = false
    private var closedOffsetPx = 0
    private var currentAnimator: ValueAnimator? = null

    private val touchSlop = ViewConfiguration.get(handle.context).scaledTouchSlop
    private val minFlingVelocity = ViewConfiguration.get(handle.context).scaledMinimumFlingVelocity

    private var velocityTracker: VelocityTracker? = null
    private var dragStartRawY = 0f
    private var dragStartTranslationY = 0f
    private var isDragging = false

    /** Call once from onCreate after both views are inflated. Starts collapsed. */
    fun setup() {
        // Measured after the first layout pass, since closedOffsetPx depends on the real
        // rendered height of the panel (which depends on category-chip count / font scale /
        // screen width) rather than a hardcoded dp value.
        panel.doOnLayout { recomputeClosedOffset(animateIfOpen = false) }

        // Re-measure on later layout passes too (rotation, font-scale change, category list
        // changing) - but only snap instantly while collapsed, so we never yank the panel out
        // from under a user who currently has it open.
        panel.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            val newHeight = bottom - top
            val oldHeight = oldBottom - oldTop
            if (newHeight != oldHeight && newHeight > 0) {
                recomputeClosedOffset(animateIfOpen = true)
            }
        }

        handle.setOnTouchListener { _, event -> handleTouch(event) }
    }

    private fun recomputeClosedOffset(animateIfOpen: Boolean) {
        val handleStripHeight = handle.parent.let { (it as? View)?.height ?: handle.height }
        val newOffset = (panel.height - handleStripHeight).coerceAtLeast(0)
        if (newOffset == closedOffsetPx) return
        closedOffsetPx = newOffset
        if (!isOpen) {
            panel.translationY = -closedOffsetPx.toFloat()
        } else if (animateIfOpen) {
            panel.translationY = 0f
        }
    }

    /** Animated open - slides the panel down over the content. */
    fun open() = animateTo(target = 0f, opening = true)

    /** Animated close - slides the panel back up, leaving only the handle visible. */
    fun close() = animateTo(target = -closedOffsetPx.toFloat(), opening = false)

    fun toggle() {
        if (isOpen) close() else open()
    }

    private fun animateTo(target: Float, opening: Boolean) {
        currentAnimator?.cancel()
        val start = panel.translationY
        currentAnimator = ValueAnimator.ofFloat(start, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { panel.translationY = it.animatedValue as Float }
            start()
        }
        isOpen = opening
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                currentAnimator?.cancel()
                velocityTracker = VelocityTracker.obtain().apply { addMovement(event) }
                dragStartRawY = event.rawY
                dragStartTranslationY = panel.translationY
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                velocityTracker?.addMovement(event)
                val deltaY = event.rawY - dragStartRawY
                if (!isDragging && Math.abs(deltaY) > touchSlop) {
                    isDragging = true
                }
                if (isDragging) {
                    val newTranslation = (dragStartTranslationY + deltaY)
                        .coerceIn(-closedOffsetPx.toFloat(), 0f)
                    panel.translationY = newTranslation
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!isDragging) {
                    // Plain tap (moved less than touch slop) - treat as a click-to-toggle.
                    velocityTracker?.recycle()
                    velocityTracker = null
                    if (event.actionMasked == MotionEvent.ACTION_UP) toggle()
                    return true
                }

                velocityTracker?.let {
                    it.addMovement(event)
                    it.computeCurrentVelocity(1000)
                }
                val velocityY = velocityTracker?.yVelocity ?: 0f
                velocityTracker?.recycle()
                velocityTracker = null
                isDragging = false

                val shouldOpen = when {
                    Math.abs(velocityY) > minFlingVelocity -> velocityY > 0f
                    else -> panel.translationY > -closedOffsetPx / 2f
                }
                if (shouldOpen) open() else close()
                return true
            }
        }
        return false
    }
}
