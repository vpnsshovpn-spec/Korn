package com.example.filemanager

import android.content.Context
import android.os.Environment
import java.io.File

/**
 * Soft-delete ("recycle bin") support.
 *
 * Deleted files/folders are moved into a hidden folder at the root of external storage
 * instead of being deleted immediately. Original location + trash time are recorded in
 * SharedPreferences (same "name|value|value" string-set pattern as BookmarksManager) so
 * items can be restored to where they came from.
 */
class TrashManager(context: Context) {

    companion object {
        const val TRASH_FOLDER_NAME = ".trash_filemanager"
    }

    val trashDir: File = File(Environment.getExternalStorageDirectory(), TRASH_FOLDER_NAME)

    private val prefs = context.getSharedPreferences("trash_prefs", Context.MODE_PRIVATE)
    private val KEY = "trash_entries"

    data class Entry(val trashedFile: File, val originalPath: String, val trashedAt: Long)

    private fun ensureDir() {
        if (!trashDir.exists()) trashDir.mkdirs()
    }

    /** Moves [file] into the trash folder and records where it came from. Returns success. */
    fun moveToTrash(file: File): Boolean {
        ensureDir()
        val ts = System.currentTimeMillis()
        val trashedName = "${ts}_${file.name}"
        val dest = File(trashDir, trashedName)
        val moved = try {
            if (file.renameTo(dest)) {
                true
            } else {
                file.copyRecursively(dest, overwrite = true)
                file.deleteRecursively()
                true
            }
        } catch (e: Exception) {
            false
        }
        if (moved) {
            val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
            current.add("$trashedName|${file.absolutePath}|$ts")
            prefs.edit().putStringSet(KEY, current).apply()
        }
        return moved
    }

    /** All current trash entries, most recently trashed first. */
    fun listEntries(): List<Entry> {
        val raw = prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()
        return raw.mapNotNull {
            val parts = it.split("|", limit = 3)
            if (parts.size == 3) {
                val f = File(trashDir, parts[0])
                if (f.exists()) Entry(f, parts[1], parts[2].toLongOrNull() ?: 0L) else null
            } else null
        }.sortedByDescending { it.trashedAt }
    }

    /** Moves [entry] back to its original location (or a "(restored N)" name if that path is now occupied). */
    fun restore(entry: Entry): Boolean {
        val originalFile = File(entry.originalPath)
        val destParent = originalFile.parentFile ?: return false
        destParent.mkdirs()
        val dest = if (originalFile.exists()) File(destParent, uniqueRestoreName(destParent, originalFile.name)) else originalFile
        val ok = try {
            if (entry.trashedFile.renameTo(dest)) {
                true
            } else {
                entry.trashedFile.copyRecursively(dest, overwrite = true)
                entry.trashedFile.deleteRecursively()
                true
            }
        } catch (e: Exception) {
            false
        }
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes [entry] from the trash folder. */
    fun deleteForever(entry: Entry): Boolean {
        val ok = if (entry.trashedFile.isDirectory) entry.trashedFile.deleteRecursively() else entry.trashedFile.delete()
        if (ok) removeMeta(entry.trashedFile.name)
        return ok
    }

    /** Permanently deletes everything currently in the trash. */
    fun emptyTrash() {
        trashDir.listFiles()?.forEach { if (it.isDirectory) it.deleteRecursively() else it.delete() }
        prefs.edit().remove(KEY).apply()
    }

    fun count(): Int = listEntries().size

    private fun removeMeta(trashedName: String) {
        val current = (prefs.getStringSet(KEY, emptySet<String>()) ?: emptySet<String>()).toMutableSet()
        current.removeAll { it.startsWith("$trashedName|") }
        prefs.edit().putStringSet(KEY, current).apply()
    }

    private fun uniqueRestoreName(dir: File, name: String): String {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        var candidate: String
        do {
            candidate = "$base (restored $i)$ext"
            i++
        } while (File(dir, candidate).exists())
        return candidate
    }
}
