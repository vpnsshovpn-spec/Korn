package com.example.filemanager

import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

/**
 * Recycle bin (soft delete) screens and dialogs - extracted out of MainActivity.kt (round 1
 * of the size-reduction plan). These are extension functions on MainActivity rather than a
 * standalone class because they read/write several pieces of MainActivity's screen state
 * (mode, adapter, trashActionBar) directly, the same way they did as private methods; moving
 * them here only required widening a few members from `private` to `internal` so this file
 * (same module) can see them. No logic was changed.
 */

internal fun MainActivity.trashConfirm(file: File) {
    AlertDialog.Builder(this)
        .setTitle("ย้าย \"${file.name}\" ไปถังขยะ?")
        .setPositiveButton("ย้ายไปถังขยะ") { _, _ ->
            if (trashManager.moveToTrash(file)) {
                Toast.makeText(this, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
                refreshCurrentView()
            } else {
                Toast.makeText(this, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.loadTrash() {
    viewModel.setMode(MainActivity.Mode.TRASH)
    adapter.setSelectionMode(false)
    trashActionBar.visibility = View.VISIBLE
    showSpecialPath("ถังขยะ")
    val trashEntries = trashManager.listEntries()
    val fileEntries = trashEntries.map { e ->
        FileEntry(
            file = e.trashedFile,
            displayName = e.trashedFile.name.replaceFirst(Regex("^\\d+_"), ""),
            subtitleOverride = "จาก: ${e.originalPath}"
        )
    }
    adapter.updateItems(fileEntries, showFullPath = false)
    supportActionBar?.subtitle = "${fileEntries.size} รายการในถังขยะ"
    swipeRefresh.isRefreshing = false
}

internal fun MainActivity.onTrashItemAction(entry: FileEntry) {
    val trashEntry = trashManager.listEntries()
        .find { it.trashedFile.absolutePath == entry.file.absolutePath } ?: return
    val title = entry.displayName ?: entry.file.name
    AlertDialog.Builder(this)
        .setTitle(title)
        .setItems(arrayOf("กู้คืน", "ลบถาวร")) { _, which ->
            when (which) {
                0 -> {
                    if (trashManager.restore(trashEntry)) {
                        Toast.makeText(this, "กู้คืนแล้ว", Toast.LENGTH_SHORT).show()
                        loadTrash()
                    } else {
                        Toast.makeText(this, "กู้คืนไม่สำเร็จ (อาจไม่พบโฟลเดอร์ต้นทางแล้ว)", Toast.LENGTH_SHORT).show()
                    }
                }
                1 -> {
                    AlertDialog.Builder(this)
                        .setTitle("ลบถาวร \"$title\"?")
                        .setMessage("ไม่สามารถกู้คืนได้อีก")
                        .setPositiveButton("ลบถาวร") { _, _ ->
                            trashManager.deleteForever(trashEntry)
                            loadTrash()
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                }
            }
        }
        .show()
}

internal fun MainActivity.emptyTrashConfirm() {
    AlertDialog.Builder(this)
        .setTitle("ล้างถังขยะทั้งหมด?")
        .setMessage("ไฟล์ทั้งหมดในถังขยะจะถูกลบถาวร ไม่สามารถกู้คืนได้")
        .setPositiveButton("ล้างถังขยะ") { _, _ ->
            trashManager.emptyTrash()
            loadTrash()
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}
