package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.io.File

/**
 * Recycle bin (soft delete) screens and dialogs - extracted out of MainActivity.kt (round 1
 * of the size-reduction plan). These are extension functions on MainActivity rather than a
 * standalone class because they read/write several pieces of MainActivity's screen state
 * (mode, adapter, trashActionBar) directly, the same way they did as private methods; moving
 * them here only required widening a few members from `private` to `internal` so this file
 * (same module) can see them. No logic was changed.
 */

internal fun MainActivity.trashConfirm(file: File) {
    val activity = this
    KornDialog.Builder(activity)
        .setTitle("ย้าย \"${file.name}\" ไปถังขยะ?")
        .setPositiveButton("ย้ายไปถังขยะ") { _, _ ->
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { trashManager.moveToTrash(file) }
                if (ok) {
                    Toast.makeText(activity, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
                    // ตัดออกจากลิสต์ปัจจุบันทันที ไม่ต้องรอสแกนโฟลเดอร์ใหม่ทั้งหมด (ดู
                    // comment ที่ removeEntryOptimistically() ใน DirectoryViewModel.kt)
                    directoryViewModel.removeEntryOptimistically(file)
                    // yield() คั่นก่อน refreshCurrentView() - กัน StateFlow ของ directoryState
                    // conflate ค่าที่เพิ่งตัดไฟล์ออกทิ้งไปกับค่า isLoading=true ที่ loadDirectory()
                    // ข้างในจะตั้งตามมาแทบจะทันที ก่อนที่ observer จะมีจังหวะได้อ่านค่าแรกเลยสักครั้ง
                    // (ดู comment ยาวที่จุดเดียวกันใน SelectionModeController.deleteSelectedToTrash())
                    yield()
                    refreshCurrentView()
                    searchIndexManager.removeFromIndex(file)
                }
                else Toast.makeText(activity, "ทำรายการไม่สำเร็จ", Toast.LENGTH_SHORT).show()
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.loadTrash() {
    directoryViewModel.setMode(MainActivity.Mode.TRASH)
    adapter.setSelectionMode(false)
    trashActionBar.visibility = View.VISIBLE
    showSpecialPath("ถังขยะ")
    lifecycleScope.launch {
    val trashEntries = withContext(Dispatchers.IO) { trashManager.listEntries() }
    val fileEntries = trashEntries.map { e ->
        FileEntry(
            file = e.trashedFile,
            displayName = e.trashedFile.name.replaceFirst(Regex("^\\d+_"), ""),
            subtitleOverride = "จาก: ${e.originalPath}"
        )
    }
    adapter.updateItems(fileEntries, showFullPath = false)
    supportActionBar?.subtitle = "${fileEntries.size} รายการในถังขยะ"
    swipeRefresh.isRefreshing = false
    }
}

internal fun MainActivity.onTrashItemAction(entry: FileEntry) {
    val activity = this
    lifecycleScope.launch {
    val trashEntry = withContext(Dispatchers.IO) { trashManager.listEntries().find { it.trashedFile.absolutePath == entry.file.absolutePath } } ?: return@launch
    val title = entry.displayName ?: entry.file.name
    KornDialog.Builder(activity)
        .setTitle(title)
        .setItems(arrayOf("กู้คืน", "ลบถาวร")) { _, which ->
            when (which) {
                0 -> {
                    lifecycleScope.launch {
                        if (withContext(Dispatchers.IO) { trashManager.restore(trashEntry) }) { Toast.makeText(activity, "กู้คืนแล้ว", Toast.LENGTH_SHORT).show(); loadTrash(); val restored = File(trashEntry.originalPath); refreshSearchIndexIncremental { if (restored.isDirectory) searchIndexManager.indexSubtree(restored) else searchIndexManager.indexFile(restored) } }
                        else Toast.makeText(activity, "กู้คืนไม่สำเร็จ (อาจไม่พบโฟลเดอร์ต้นทางแล้ว)", Toast.LENGTH_SHORT).show()
                    }
                }
                1 -> {
                    KornDialog.Builder(activity)
                        .setTitle("ลบถาวร \"$title\"?")
                        .setMessage("ไม่สามารถกู้คืนได้อีก")
                        .setPositiveButton("ลบถาวร") { _, _ ->
                            lifecycleScope.launch { withContext(Dispatchers.IO) { trashManager.deleteForever(trashEntry) }; loadTrash() }
                        }
                        .setNegativeButton("ยกเลิก", null)
                        .show()
                }
            }
        }
        .show()
    }
}

/**
 * Rotation Safety #4: this entry point (called from the "ล้างถังขยะ" toolbar button, see
 * MainViewBindingHelper.kt) now only flips [FileOperationViewModel.setTrashConfirmDialogOpen] to true -
 * it no longer builds the dialog itself. [observeTrashConfirmDialog] below is the single place
 * that actually shows it, reacting the same way whether this just set the flag, a rotation
 * recreated the Activity, or the app relaunched after a real process death restored the flag
 * from SavedStateHandle. See FileOperationViewModel.kt's "Dialog-open flags" section for the full
 * rationale.
 */
internal fun MainActivity.emptyTrashConfirm() {
    fileOperationViewModel.setTrashConfirmDialogOpen(true)
}

/** Wired from MainActivity.onCreate(), same as observeConflictBatches(). */
internal fun MainActivity.observeTrashConfirmDialog() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            fileOperationViewModel.trashConfirmDialogOpen.collect { open ->
                if (!open) {
                    trashConfirmDialogHandle?.dismiss()
                    trashConfirmDialogHandle = null
                    return@collect
                }
                // Already showing (e.g. this fired again for an unrelated reason, not a real
                // open) - don't stack a second dialog. Same guard shape as
                // ConflictBatchObserver.kt's showOrReplaceConflictDialog().
                if (trashConfirmDialogHandle?.isShowing == true) return@collect
                trashConfirmDialogHandle = KornDialog.Builder(this@observeTrashConfirmDialog)
                    .setTitle("ล้างถังขยะทั้งหมด?")
                    .setMessage("ไฟล์ทั้งหมดในถังขยะจะถูกลบถาวร ไม่สามารถกู้คืนได้")
                    .setPositiveButton("ล้างถังขยะ") { _, _ ->
                        lifecycleScope.launch { withContext(Dispatchers.IO) { trashManager.emptyTrash() }; loadTrash() }
                    }
                    .setNegativeButton("ยกเลิก", null)
                    // Only fires for a real dismissal (button tap / outside touch / back press),
                    // never for the transient teardown a rotation causes - see
                    // KornDialogFragment.onDismiss()'s doc comment. So this can't fight with
                    // rotation restore, only with an actual close.
                    .setOnDismissListener { fileOperationViewModel.setTrashConfirmDialogOpen(false) }
                    .show()
            }
        }
    }
}
