package com.example.filemanager

import android.os.Environment
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Multi-window (open folder windows) + recent-folder history functions, split out of
 * MainActivity.kt (see MainActivity-Slimdown-Plan.txt ก้อน 3.3). All of these share the same
 * [MainActivity.directoryHistoryHelper] instance and the same domain (history of opened
 * folders), so they live together in one file even though "recent folders" and "windows" were
 * separate sections in MainActivity.kt.
 */

// ---------- Recent folders ----------

internal fun MainActivity.rememberRecentFolder(dir: File) {
    lifecycleScope.launch(Dispatchers.IO) { directoryHistoryHelper.rememberRecentFolder(dir, viewModel.mode.value == MainActivity.Mode.TRASH) }
}

internal fun MainActivity.loadRecentFolders() {
    viewModel.setMode(MainActivity.Mode.SEARCH)
    viewModel.clearSearchOverlay()
    lifecycleScope.launch {
        val paths = withContext(Dispatchers.IO) { directoryHistoryHelper.loadRecentFolders() }

        if (paths.isEmpty()) {
            Toast.makeText(this@loadRecentFolders, "ยังไม่มีโฟลเดอร์ล่าสุด", Toast.LENGTH_SHORT).show()
            return@launch
        }
        viewModel.setCurrentDir(paths.first())
        showSpecialPath("โฟลเดอร์ล่าสุด")
        adapter.updateItems(paths.map { FileEntry(it) }, showFullPath = true)
        supportActionBar?.subtitle = "${paths.size} โฟลเดอร์"
    }
}

// ---------- Windows (open folder windows) ----------

internal fun MainActivity.loadOpenWindows() {
    lifecycleScope.launch {
        val paths = withContext(Dispatchers.IO) { directoryHistoryHelper.loadOpenWindows() }
        openWindows.clear()
        openWindows.addAll(paths)
    }
}

internal fun MainActivity.saveOpenWindows() {
    lifecycleScope.launch(Dispatchers.IO) { directoryHistoryHelper.saveOpenWindows(openWindows.toList()) }
}

internal fun MainActivity.rememberOpenWindow(dir: File) {
    lifecycleScope.launch {
        val updated = withContext(Dispatchers.IO) { directoryHistoryHelper.rememberOpenWindow(dir, openWindows.toList()) }
        openWindows.clear()
        openWindows.addAll(updated)
    }
}

internal fun MainActivity.showWindowsDialog() {
    // Refresh stale paths before showing the grid.
    openWindows.removeAll { !File(it).isDirectory }
    if (openWindows.isEmpty()) {
        openWindows.add(viewModel.currentDir.value.absolutePath)
        saveOpenWindows()
    }

    WindowManagerDialog(
        context = this,
        windows = openWindows,
        currentPath = viewModel.currentDir.value.absolutePath,
        onSelectHome = { loadDirectory(Environment.getExternalStorageDirectory()) },
        onSelectWindow = { target -> if (target.isDirectory) loadDirectory(target) },
        onWindowsChanged = { saveOpenWindows() }
    ).show()
}

internal fun MainActivity.clearRecentHistory() {
    lifecycleScope.launch {
        withContext(Dispatchers.IO) { directoryHistoryHelper.clearRecentHistory() }
        Toast.makeText(this@clearRecentHistory, "ล้างประวัติล่าสุดแล้ว", Toast.LENGTH_SHORT).show()
    }
}
