package com.example.filemanager

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File

/**
 * Browses a .zip file's contents as if it were a real folder tree, and can modify entries
 * in place (rename / delete / add / replace / new folder / edit text files) — all via
 * [ZipFileSystem], which rewrites only the zip on disk, never touching real storage except
 * for the temp copies it needs to read from or extract single entries to.
 */
class ZipBrowserActivity : AppCompatActivity() {

    private lateinit var zipFile: File
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var pathText: TextView
    private lateinit var adapter: ZipEntryAdapter
    private var originalArchive: File? = null
    private var selectionBar: LinearLayout? = null

    private var currentPath: String = ""
    private var pendingReplaceEntryPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zip_browser)

        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH)
        if (zipPath == null || !File(zipPath).exists()) {
            Toast.makeText(this, "ไม่พบไฟล์ ZIP", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        zipFile = File(zipPath)
        intent.getStringExtra(EXTRA_ORIGINAL_ARCHIVE_PATH)?.let { originalArchive = File(it) }

        val toolbar = findViewById<Toolbar>(R.id.zipToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = zipFile.name
        ThemeHelper.apply(this, toolbar)

        pathText = findViewById(R.id.zipPathText)
        recyclerView = findViewById(R.id.zipEntryList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ZipEntryAdapter(emptyList(), ::onEntryClick, ::onEntryLongClick)
        recyclerView.adapter = adapter
        createSelectionBar()

        swipeRefresh = findViewById(R.id.zipSwipeRefresh)
        swipeRefresh.setColorSchemeResources(R.color.primary)
        swipeRefresh.setOnRefreshListener { load() }

        load()
    }

    // ---------- Listing ----------

    private fun load() {
        pathText.text = "${zipFile.name} / $currentPath".trimEnd('/')
        supportActionBar?.subtitle = "กำลังโหลด..."
        // The "extract here" menu label depends on currentPath (root vs subfolder), so rebuild
        // it every time we navigate - onCreateOptionsMenu alone only fires once per activity.
        invalidateOptionsMenu()
        val path = currentPath
        Thread {
            val children = try {
                ZipFileSystem.childrenOf(zipFile, path)
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "อ่านไฟล์ ZIP ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                emptyList()
            }
            runOnUiThread {
                swipeRefresh.isRefreshing = false
                if (path != currentPath) return@runOnUiThread
                adapter.updateItems(children)
                supportActionBar?.subtitle = "${children.size} รายการ"
            }
        }.start()
    }

    private fun goUpOrFinish() {
        if (currentPath.isEmpty()) {
            finish()
        } else {
            currentPath = currentPath.substringBeforeLast('/', "")
            load()
        }
    }

    override fun onBackPressed() {
        goUpOrFinish()
    }

    // ---------- Item interactions ----------

    private fun onEntryClick(entry: ZipVirtualEntry) {
        if (adapter.hasSelection()) {
            adapter.toggleSelection(entry)
            updateSelectionBar()
            return
        }
        if (entry.isDirectory) {
            currentPath = entry.path
            load()
            return
        }
        val ext = entry.name.substringAfterLast('.', "").lowercase()
        if (ext in ZipFileSystem.TEXT_EXTENSIONS) {
            val i = Intent(this, TextEditActivity::class.java)
            i.putExtra(TextEditActivity.EXTRA_ZIP_PATH, zipFile.absolutePath)
            i.putExtra(TextEditActivity.EXTRA_ENTRY_PATH, entry.path)
            startActivityForResult(i, REQUEST_TEXT_EDIT)
        } else {
            previewEntry(entry)
        }
    }

    private fun previewEntry(entry: ZipVirtualEntry) {
        Toast.makeText(this, "กำลังเปิดไฟล์...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val previewDir = File(cacheDir, "zip_preview")
                previewDir.mkdirs()
                val outFile = File(previewDir, entry.name)
                ZipFileSystem.extractEntryToFile(zipFile, entry.path, outFile)
                runOnUiThread {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", outFile)
                    val mime = MimeTypeMap.getSingleton()
                        .getMimeTypeFromExtension(outFile.extension.lowercase()) ?: "*/*"
                    val i = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, mime)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "เปิดด้วย"))
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "เปิดไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun onEntryLongClick(entry: ZipVirtualEntry): Boolean {
        if (adapter.hasSelection()) {
            showEntryActions(entry)
        } else {
            adapter.toggleSelection(entry)
            updateSelectionBar()
        }
        return true
    }

    private fun showEntryActions(entry: ZipVirtualEntry) {
        val options = mutableListOf("เปลี่ยนชื่อ", "ลบ")
        if (!entry.isDirectory) options.add("แก้ไขด้วย KORN (ข้อความ / HEX)")
        options.add(if (entry.isDirectory) "แตกโฟลเดอร์นี้ออกไปที่..." else "แตกไฟล์นี้ออกไปที่...")
        if (!entry.isDirectory) options.add("แทนที่ด้วยไฟล์จากเครื่อง...")
        AlertDialog.Builder(this)
            .setTitle(entry.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "เปลี่ยนชื่อ" -> renameEntryDialog(entry)
                    "ลบ" -> deleteEntryConfirm(entry)
                    "แก้ไขด้วย KORN (ข้อความ / HEX)" -> editEntry(entry)
                    "แตกโฟลเดอร์นี้ออกไปที่...", "แตกไฟล์นี้ออกไปที่..." -> extractEntryDialog(entry)
                    "แทนที่ด้วยไฟล์จากเครื่อง..." -> {
                        pendingReplaceEntryPath = entry.path
                        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "*/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                        startActivityForResult(Intent.createChooser(i, "เลือกไฟล์แทนที่"), REQUEST_PICK_FILE_TO_REPLACE)
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun createSelectionBar() {
        val content = findViewById<android.view.ViewGroup>(android.R.id.content)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(ThemeHelper.colors(this@ZipBrowserActivity).first)
            visibility = android.view.View.GONE
        }
        val count = TextView(this).apply { text = "0"; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(12, 0, 12, 0) }
        bar.addView(count, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        fun addAction(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                setOnClickListener(action)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        addAction("ลบ") { deleteSelectedConfirm() }
        addAction("ย้าย") { moveCopySelected(true) }
        addAction("คัดลอก") { moveCopySelected(false) }
        addAction("เปลี่ยนชื่อ") { renameSelected() }
        val lp = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = android.view.Gravity.BOTTOM }
        content.addView(bar, lp)
        selectionBar = bar
        bar.tag = count
    }

    private fun updateSelectionBar() {
        val bar = selectionBar ?: return
        val count = bar.tag as? TextView
        val selected = adapter.selectedCount()
        count?.text = "เลือก $selected"
        bar.visibility = if (selected > 0) android.view.View.VISIBLE else android.view.View.GONE
        supportActionBar?.subtitle = if (selected > 0) "เลือก $selected รายการ" else ""
        adapter.notifyDataSetChanged()
    }

    private fun deleteSelectedConfirm() {
        val selected = adapter.selectedPaths()
        if (selected.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("ลบ ${selected.size} รายการ?")
            .setMessage("ระบบจะสร้าง archive ใหม่แล้วแทนที่ไฟล์เดิม หากล้มเหลวไฟล์เดิมจะไม่ถูกเปลี่ยน")
            .setPositiveButton("ลบ") { _, _ ->
                runZipOp("กำลังลบ ${selected.size} รายการ...") {
                    ZipFileSystem.deletePaths(zipFile, selected)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun renameSelected() {
        val selected = adapter.selectedEntries()
        if (selected.size != 1) {
            Toast.makeText(this, "เปลี่ยนชื่อได้ครั้งละ 1 รายการ", Toast.LENGTH_SHORT).show()
            return
        }
        renameEntryDialog(selected[0])
    }

    private fun moveCopySelected(move: Boolean) {
        val selected = adapter.selectedPaths()
        if (selected.isEmpty()) return
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(currentPath)
            hint = "เช่น assets หรือเว้นว่างสำหรับ root"
        }
        AlertDialog.Builder(this)
            .setTitle(if (move) "ย้ายไปโฟลเดอร์ใน Archive" else "คัดลอกไปโฟลเดอร์ใน Archive")
            .setMessage("ระบุ path ปลายทางภายใน archive")
            .setView(input)
            .setPositiveButton("ตกลง") { _, _ ->
                val destination = input.text.toString().trim().trim('/')
                runZipOp(if (move) "กำลังย้าย..." else "กำลังคัดลอก...") {
                    ZipFileSystem.copyPaths(zipFile, selected, destination, move)
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Edit any file inside the ZIP ----------

    private fun editEntry(entry: ZipVirtualEntry) {
        val i = Intent(this, TextEditActivity::class.java).apply {
            putExtra(TextEditActivity.EXTRA_ZIP_PATH, zipFile.absolutePath)
            putExtra(TextEditActivity.EXTRA_ENTRY_PATH, entry.path)
        }
        startActivityForResult(i, REQUEST_TEXT_EDIT)
    }

    // ---------- Rename / delete ----------

    private fun renameEntryDialog(entry: ZipVirtualEntry) {
        val input = EditText(this)
        input.setText(entry.name)
        AlertDialog.Builder(this)
            .setTitle("เปลี่ยนชื่อ")
            .setView(input)
            .setPositiveButton("เปลี่ยนชื่อ") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isEmpty() || newName == entry.name) return@setPositiveButton
                runZipOp("กำลังเปลี่ยนชื่อ...") { ZipFileSystem.renamePath(zipFile, entry.path, newName) }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun deleteEntryConfirm(entry: ZipVirtualEntry) {
        AlertDialog.Builder(this)
            .setTitle("ลบ \"${entry.name}\" ออกจาก ZIP?")
            .setMessage(if (entry.isDirectory) "ไฟล์ทั้งหมดในโฟลเดอร์นี้จะถูกลบไปด้วย ไม่สามารถกู้คืนได้" else "ไม่สามารถกู้คืนได้")
            .setPositiveButton("ลบ") { _, _ ->
                runZipOp("กำลังลบ...") { ZipFileSystem.deletePath(zipFile, entry.path) }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    /** Runs a mutating [ZipFileSystem] call off the UI thread, then reloads the current folder. */
    private fun runZipOp(progressMessage: String, op: () -> Unit) {
        val progress = android.app.ProgressDialog(this).apply {
            setMessage(progressMessage)
            setIndeterminate(true)
            setCancelable(false)
            show()
        }
        Thread {
            try {
                op()
                persistArchiveIfNeeded()
                runOnUiThread {
                    progress.dismiss()
                    adapter.clearSelection()
                    updateSelectionBar()
                    Toast.makeText(this, "สำเร็จ", Toast.LENGTH_SHORT).show()
                    load()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    Toast.makeText(this, "ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun persistArchiveIfNeeded() {
        val original = originalArchive ?: return
        if (!original.exists() || original.absolutePath == zipFile.absolutePath) return
        ArchiveManager.syncEditedArchive(zipFile, original)
    }

    // ---------- Toolbar menu: add file / new folder / extract here ----------

    // onCreateOptionsMenu only ever runs once (Android caches the menu after first build), so
    // the "extract" label - which depends on currentPath - is built in onPrepareOptionsMenu
    // instead, which reruns on every invalidateOptionsMenu() call (see load()).
    override fun onCreateOptionsMenu(menu: Menu): Boolean = true

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.clear()
        menu.add(0, 1, 0, "เพิ่มไฟล์จากเครื่อง...")
        menu.add(0, 2, 1, "สร้างโฟลเดอร์ใหม่")
        menu.add(0, 3, 2, if (currentPath.isEmpty()) "แตกไฟล์ ZIP ทั้งหมดออกไปที่..." else "แตกโฟลเดอร์นี้ออกไปที่...")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> { goUpOrFinish(); return true }
            1 -> {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(i, "เลือกไฟล์ที่จะเพิ่ม"), REQUEST_PICK_FILE_TO_ADD)
                return true
            }
            2 -> { newFolderDialog(); return true }
            3 -> { extractCurrentLocationDialog(); return true }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun newFolderDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่ในไฟล์ ZIP")
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    runZipOp("กำลังสร้างโฟลเดอร์...") { ZipFileSystem.createFolder(zipFile, currentPath, name) }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- Extract to real storage (reuses the same navigable folder-picker as "Open with") ----------

    private fun extractEntryDialog(entry: ZipVirtualEntry) {
        showDestinationFolderPicker { destDir ->
            runZipOp("กำลังแตกไฟล์...") {
                if (entry.isDirectory) {
                    val outDir = File(destDir, entry.name)
                    ZipFileSystem.extractFolderToDir(zipFile, entry.path, outDir)
                } else {
                    ZipFileSystem.extractEntryToFile(zipFile, entry.path, File(destDir, entry.name))
                }
            }
        }
    }

    private fun extractCurrentLocationDialog() {
        showDestinationFolderPicker { destDir ->
            runZipOp("กำลังแตกไฟล์...") {
                if (currentPath.isEmpty()) {
                    val outDir = File(destDir, zipFile.nameWithoutExtension)
                    outDir.mkdirs()
                    FileScanner.unzip(zipFile, outDir)
                } else {
                    val folderName = currentPath.substringAfterLast('/')
                    ZipFileSystem.extractFolderToDir(zipFile, currentPath, File(destDir, folderName))
                }
            }
        }
    }

    private fun showDestinationFolderPicker(onChosen: (File) -> Unit) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_folder_picker, null)
        val pathTextView = dialogView.findViewById<TextView>(R.id.currentPathText)
        val listView = dialogView.findViewById<ListView>(R.id.folderListView)
        val newFolderButton = dialogView.findViewById<TextView>(R.id.newFolderInPickerButton)
        val newFileButton = dialogView.findViewById<TextView>(R.id.newFileInPickerButton)

        val dialog = AlertDialog.Builder(this).setView(dialogView).setCancelable(true).create()

        var browseDir = Environment.getExternalStorageDirectory()
        val rootDir = Environment.getExternalStorageDirectory()

        // Folders sort first (and are the only navigable rows); files are listed too so the
        // user can see what's already in a folder before picking it as the destination.
        fun childrenOf(dir: File): List<File> =
            (dir.listFiles() ?: emptyArray())
                .filter { !it.name.startsWith(".") }
                .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))

        fun refresh() {
            pathTextView.text = browseDir.absolutePath
            val children = childrenOf(browseDir)
            val showUp = browseDir != rootDir
            val labels = mutableListOf<String>()
            if (showUp) labels.add("⬆️  .. (ย้อนกลับ)")
            labels.addAll(children.map { if (it.isDirectory) "📁  ${it.name}" else "📄  ${it.name}" })
            listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
            listView.setOnItemClickListener { _, _, position, _ ->
                if (showUp && position == 0) {
                    browseDir = browseDir.parentFile ?: rootDir
                    refresh()
                    return@setOnItemClickListener
                }
                val target = children[if (showUp) position - 1 else position]
                if (target.isDirectory) {
                    browseDir = target
                    refresh()
                }
                // Tapping a file does nothing - it's shown only so the user can see the folder's contents.
            }
        }
        refresh()

        newFileButton.setOnClickListener {
            val input = EditText(this)
            input.hint = "ชื่อไฟล์.txt"
            AlertDialog.Builder(this)
                .setTitle("สร้างไฟล์ใหม่")
                .setMessage("ใน ${browseDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newFile = File(browseDir, name)
                    try {
                        when {
                            newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                            newFile.createNewFile() -> refresh()
                            else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        newFolderButton.setOnClickListener {
            val input = EditText(this)
            AlertDialog.Builder(this)
                .setTitle("สร้างโฟลเดอร์ใหม่")
                .setMessage("ใน ${browseDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newDir = File(browseDir, name)
                    when {
                        newDir.exists() -> Toast.makeText(this, "มีโฟลเดอร์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                        newDir.mkdirs() -> { browseDir = newDir; refresh() }
                        else -> Toast.makeText(this, "สร้างโฟลเดอร์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        dialogView.findViewById<android.widget.Button>(R.id.chooseFolderHereButton).setOnClickListener {
            dialog.dismiss()
            onChosen(browseDir)
        }
        dialogView.findViewById<android.widget.Button>(R.id.cancelFolderPickButton).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    // ---------- Add / replace file results ----------

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        if (requestCode == REQUEST_TEXT_EDIT) {
            Thread {
                try {
                    persistArchiveIfNeeded()
                    runOnUiThread { load() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "บันทึก Archive ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }.start()
            return
        }
        val uri = data?.data ?: return
        val name = queryDisplayName(uri) ?: "unnamed_file"
        Toast.makeText(this, "กำลังนำเข้าไฟล์...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val tempFile = File(cacheDir, "import_${System.currentTimeMillis()}_$name")
                contentResolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output -> input.copyTo(output) }
                } ?: throw java.io.IOException("อ่านไฟล์ต้นทางไม่ได้")

                when (requestCode) {
                    REQUEST_PICK_FILE_TO_ADD ->
                        ZipFileSystem.addOrReplaceFile(zipFile, currentPath, name, tempFile)
                    REQUEST_PICK_FILE_TO_REPLACE ->
                        pendingReplaceEntryPath?.let { ZipFileSystem.replaceEntryContent(zipFile, it, tempFile) }
                }
                tempFile.delete()
                persistArchiveIfNeeded()
                runOnUiThread {
                    Toast.makeText(this, "สำเร็จ", Toast.LENGTH_SHORT).show()
                    load()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show() }
            } finally {
                pendingReplaceEntryPath = null
            }
        }.start()
    }

    private fun queryDisplayName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    companion object {
        const val EXTRA_ZIP_PATH = "zip_path"
        const val EXTRA_ORIGINAL_ARCHIVE_PATH = "original_archive_path"
        private const val REQUEST_PICK_FILE_TO_ADD = 201
        private const val REQUEST_PICK_FILE_TO_REPLACE = 202
        private const val REQUEST_TEXT_EDIT = 203
    }
}
