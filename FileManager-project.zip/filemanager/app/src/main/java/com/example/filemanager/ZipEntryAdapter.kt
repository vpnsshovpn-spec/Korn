package com.example.filemanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import java.io.File
import java.text.DecimalFormat
import kotlin.math.ln
import kotlin.math.pow
import com.example.filemanager.data.repository.FileCategories

class ZipEntryAdapter(
    private var items: List<ZipVirtualEntry>,
    private val zipFile: File,
    private val scope: CoroutineScope?,
    private val onClick: (ZipVirtualEntry) -> Unit,
    private val onLongClick: (ZipVirtualEntry) -> Boolean
) : RecyclerView.Adapter<ZipEntryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView = view.findViewById(R.id.entryIcon)
        val thumb: ImageView = view.findViewById(R.id.entryThumb)
        val name: TextView = view.findViewById(R.id.entryName)
        val subtitle: TextView = view.findViewById(R.id.entrySubtitle)
        var thumbnailJob: Job? = null

        fun cancelThumbnailJob() {
            thumbnailJob?.cancel()
            thumbnailJob = null
        }
    }

    fun updateItems(newItems: List<ZipVirtualEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_zip_entry, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Cancel any thumbnail decode still in flight for whatever item this row previously
        // held, before binding the new one - same guard pattern as FileAdapter/ThumbnailLoader.
        holder.cancelThumbnailJob()

        val entry = items[position]
        holder.name.text = entry.name
        val isImage = !entry.isDirectory && entry.name.substringAfterLast('.', "").lowercase() in FileCategories.IMAGES

        if (entry.isDirectory) {
            holder.thumb.visibility = View.GONE
            holder.icon.visibility = View.VISIBLE
            holder.icon.text = "📁"
            holder.subtitle.text = "โฟลเดอร์"
        } else if (isImage) {
            holder.icon.visibility = View.GONE
            holder.thumb.visibility = View.VISIBLE
            if (scope != null) {
                holder.thumbnailJob = ZipThumbnailLoader.load(scope, zipFile, entry, holder.thumb, 150)
            } else {
                holder.thumb.setImageDrawable(null)
                ZipThumbnailLoader.cached(zipFile, entry)?.let { holder.thumb.setImageBitmap(it) }
            }
            holder.subtitle.text = readableSize(entry.size)
        } else {
            holder.thumb.visibility = View.GONE
            holder.icon.visibility = View.VISIBLE
            holder.icon.text = iconFor(entry.name)
            holder.subtitle.text = readableSize(entry.size)
        }
        holder.itemView.setOnClickListener { onClick(entry) }
        holder.itemView.setOnLongClickListener { onLongClick(entry) }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        holder.cancelThumbnailJob()
    }

    override fun getItemCount(): Int = items.size

    private fun iconFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in FileCategories.IMAGES -> "🖼️"
            in FileCategories.VIDEOS -> "🎬"
            in FileCategories.MUSIC -> "🎵"
            in FileCategories.DOCS -> "📄"
            in FileCategories.APPS -> "📦"
            in FileCategories.ARCHIVES -> "🗜️"
            else -> "📄"
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / 1024.0.pow(digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
