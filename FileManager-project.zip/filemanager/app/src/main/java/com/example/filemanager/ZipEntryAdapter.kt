package com.example.filemanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.DecimalFormat
import kotlin.math.ln
import kotlin.math.pow

class ZipEntryAdapter(
    private var items: List<ZipVirtualEntry>,
    private val onClick: (ZipVirtualEntry) -> Unit,
    private val onLongClick: (ZipVirtualEntry) -> Boolean
) : RecyclerView.Adapter<ZipEntryAdapter.ViewHolder>() {

    private val selected = linkedSetOf<String>()

    fun toggleSelection(entry: ZipVirtualEntry) {
        if (!selected.add(entry.path)) selected.remove(entry.path)
        notifyDataSetChanged()
    }
    fun clearSelection() { selected.clear(); notifyDataSetChanged() }
    fun hasSelection(): Boolean = selected.isNotEmpty()
    fun selectedCount(): Int = selected.size
    fun selectedPaths(): Set<String> = selected.toSet()
    fun selectedEntries(): List<ZipVirtualEntry> = items.filter { it.path in selected }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView = view.findViewById(R.id.entryIcon)
        val name: TextView = view.findViewById(R.id.entryName)
        val subtitle: TextView = view.findViewById(R.id.entrySubtitle)
    }

    fun updateItems(newItems: List<ZipVirtualEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_zip_entry, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.name.text = entry.name
        if (entry.isDirectory) {
            holder.icon.text = "📁"
            holder.subtitle.text = "โฟลเดอร์"
        } else {
            holder.icon.text = iconFor(entry.name)
            holder.subtitle.text = readableSize(entry.size)
        }
        val isSelected = selected.contains(entry.path)
        val selectionMode = selected.isNotEmpty()
        holder.itemView.isActivated = isSelected
        holder.itemView.alpha = if (isSelected) 0.65f else 1f

        holder.check.setOnCheckedChangeListener(null)
        holder.check.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.check.isChecked = isSelected
        holder.check.setOnClickListener { toggleSelection(entry) }

        holder.itemView.setOnClickListener {
            if (selected.isNotEmpty()) toggleSelection(entry) else onClick(entry)
        }
        // Long-press behaves exactly like the normal file list: it enters selection
        // mode and selects the pressed item. A second long-press does not open a
        // special action dialog while selection mode is active.
        holder.itemView.setOnLongClickListener {
            toggleSelection(entry)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    private fun iconFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in FileCategories.IMAGES -> "🖼️"
            in FileCategories.VIDEOS -> "🎬"
            in FileCategories.MUSIC -> "🎵"
            in FileCategories.DOCS -> "📄"
            in FileCategories.APPS -> "📦"
            in FileCategories.ARCHIVES -> "🗜️"
            else -> "📄"
        }
    }

    private fun readableSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(0, units.size - 1)
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / 1024.0.pow(digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
