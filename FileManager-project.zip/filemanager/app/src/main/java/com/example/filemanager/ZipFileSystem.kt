package com.example.filemanager

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** One virtual node inside a zip: either a real entry or a folder inferred from other entries' paths. */
data class ZipVirtualEntry(
    val path: String,       // full path inside the zip, no leading/trailing slash, e.g. "images/cat.png"
    val isDirectory: Boolean,
    val size: Long,
    val time: Long
) {
    val name: String get() = path.substringAfterLast('/')
}

/**
 * Lets the file manager treat a .zip as a live, browsable, *editable* filesystem without ever
 * fully extracting it. Reading (listing / opening a single entry) uses ZipFile random access.
 * Any mutation (delete / rename / add / replace / new folder) has to rewrite the whole archive
 * into a temp file and swap it in — java.util.zip has no in-place edit support on Android — but
 * the original zip on disk is only touched at the very end, and everything else keeps its
 * original compressed bytes copied straight through (no full decompress/recompress detour).
 */
object ZipFileSystem {

    /** Immediate children of [parentPath] ("" = zip root). Folders sort first, then by name. */
    fun childrenOf(zipFile: File, parentPath: String): List<ZipVirtualEntry> {
        val prefix = if (parentPath.isEmpty()) "" else "$parentPath/"
        val children = LinkedHashMap<String, ZipVirtualEntry>()
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val name = normalize(e.name)
                if (name.isEmpty() || !name.startsWith(prefix) || name == parentPath) continue
                val rest = name.removePrefix(prefix)
                if (rest.isEmpty()) continue
                val firstSeg = rest.substringBefore('/')
                val childPath = "$prefix$firstSeg"
                val isChildDir = rest.contains('/') || e.isDirectory
                val existing = children[childPath]
                if (existing == null || (existing.isDirectory && !isChildDir)) {
                    val size = if (isChildDir) 0L else e.size
                    children[childPath] = ZipVirtualEntry(childPath, isChildDir, size, e.time)
                }
            }
        }
        return children.values.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }

    /** Reads a single entry's whole content into memory (only used for small text-file previews/edits). */
    fun readEntryBytes(zipFile: File, entryPath: String): ByteArray {
        ZipFile(zipFile).use { zf ->
            val entry = zf.getEntry(entryPath) ?: throw FileNotFoundException(entryPath)
            return zf.getInputStream(entry).use { it.readBytes() }
        }
    }

    /** Extracts one file entry out to [destFile] on real storage (for "open with another app"). */
    fun extractEntryToFile(zipFile: File, entryPath: String, destFile: File) {
        ZipFile(zipFile).use { zf ->
            val entry = zf.getEntry(entryPath) ?: throw FileNotFoundException(entryPath)
            destFile.parentFile?.mkdirs()
            zf.getInputStream(entry).use { input ->
                FileOutputStream(destFile).use { output -> input.copyTo(output) }
            }
        }
    }

    /** Extracts a whole virtual folder out to [destDir] on real storage. Guards against zip-slip. */
    fun extractFolderToDir(zipFile: File, folderPath: String, destDir: File) {
        val prefix = "$folderPath/"
        val destCanonical = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val name = normalize(e.name)
                if (!name.startsWith(prefix)) continue
                val rel = name.removePrefix(prefix)
                if (rel.isEmpty()) continue
                val outFile = File(destDir, rel)
                if (!outFile.canonicalPath.startsWith(destCanonical)) {
                    throw SecurityException("รายการในไฟล์ ZIP ไม่ปลอดภัย: $name")
                }
                if (e.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zf.getInputStream(e).use { input -> outFile.outputStream().use { input.copyTo(it) } }
                }
            }
        }
    }

    /** Deletes several files/folders in one repack operation. */
    fun deletePaths(zipFile: File, targetPaths: Collection<String>) {
        val normalized = targetPaths.map { normalize(it) }.filter { it.isNotEmpty() }.toSet()
        rewrite(zipFile, shouldKeep = { name -> normalized.none { name == it || name.startsWith("$it/") } })
    }

    /** Deletes [targetPath] (a file, or a folder and everything under it) from the zip. */
    fun deletePath(zipFile: File, targetPath: String) {
        rewrite(zipFile, shouldKeep = { name -> name != targetPath && !name.startsWith("$targetPath/") })
    }

    /** Renames the file/folder at [oldPath] to [newName], keeping it in the same parent folder. */
    fun renamePath(zipFile: File, oldPath: String, newName: String) {
        val cleanName = newName.trim().replace('\\', '/')
        if (cleanName.isEmpty() || cleanName.contains('/') || cleanName == "." || cleanName == "..") {
            throw IOException("ชื่อใหม่ไม่ถูกต้อง")
        }
        val parent = oldPath.substringBeforeLast('/', "")
        val newPath = if (parent.isEmpty()) cleanName else "$parent/$cleanName"

        // Do not create duplicate archive paths during a rename.
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val name = normalize(entries.nextElement().name)
                if (name == newPath || name.startsWith("$newPath/")) {
                    throw IOException("มีรายการชื่อเดียวกันอยู่แล้ว: $newPath")
                }
            }
        }

        rewrite(
            zipFile,
            shouldKeep = { true },
            renameEntry = { name ->
                when {
                    name == oldPath -> newPath
                    name.startsWith("$oldPath/") -> newPath + name.removePrefix(oldPath)
                    else -> name
                }
            }
        )
    }

    /** Copies selected files/folders to another virtual folder inside the archive. */
    fun copyPaths(zipFile: File, paths: Collection<String>, destinationPath: String, move: Boolean) {
        val normalized = paths.map { normalize(it) }.filter { it.isNotEmpty() }.toSet()
        val selected = normalized.filter { candidate -> normalized.none { it != candidate && candidate.startsWith("$it/") } }.toSet()
        if (selected.isEmpty()) return
        if (move && selected.any { destinationPath == it || destinationPath.startsWith("$it/") }) {
            throw IOException("ไม่สามารถย้ายโฟลเดอร์เข้าไปภายในตัวเองได้")
        }
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            val existing = mutableSetOf<String>()
            while (entries.hasMoreElements()) existing.add(normalize(entries.nextElement().name))
            for (sourcePath in selected) {
                val targetRoot = if (destinationPath.isEmpty()) sourcePath.substringAfterLast('/') else "$destinationPath/${sourcePath.substringAfterLast('/')}"
                if (existing.any { it == targetRoot || it.startsWith("$targetRoot/") }) {
                    throw IOException("มีรายการชื่อเดียวกันอยู่แล้ว: $targetRoot")
                }
            }
        }
        rewrite(
            zipFile,
            shouldKeep = { name -> !move || selected.none { name == it || name.startsWith("$it/") } },
            additionsFromArchive = selected.map { sourcePath ->
                sourcePath to if (destinationPath.isEmpty()) sourcePath.substringAfterLast('/')
                else "$destinationPath/${sourcePath.substringAfterLast('/')}"
            }
        )
    }

    /** Adds a new empty folder entry under [parentPath] ("" = root). */
    fun createFolder(zipFile: File, parentPath: String, folderName: String) {
        val folderPath = if (parentPath.isEmpty()) folderName else "$parentPath/$folderName"
        rewrite(zipFile, shouldKeep = { true }, newFolders = listOf(folderPath))
    }

    /**
     * Adds [sourceFile]'s bytes into the zip under [parentPath] as [entryName]. If an entry
     * already exists there, its content is replaced (used both for "add new file" and
     * "replace this file with one from my device").
     */
    fun addOrReplaceFile(zipFile: File, parentPath: String, entryName: String, sourceFile: File) {
        val entryPath = if (parentPath.isEmpty()) entryName else "$parentPath/$entryName"
        rewrite(
            zipFile,
            shouldKeep = { name -> name != entryPath },
            additions = listOf(entryPath to sourceFile)
        )
    }

    /** Overwrites the content of the existing entry at [entryPath] (used by the in-zip text editor's Save). */
    fun replaceEntryContent(zipFile: File, entryPath: String, newContent: File) {
        rewrite(
            zipFile,
            shouldKeep = { name -> name != entryPath },
            additions = listOf(entryPath to newContent)
        )
    }

    /** Overwrites an existing entry directly from bytes (used by the in-zip text editor's Save). */
    fun replaceEntryBytes(zipFile: File, entryPath: String, bytes: ByteArray) {
        val tempContent = File.createTempFile("korn-entry-", ".tmp", zipFile.parentFile)
        try {
            tempContent.outputStream().use { it.write(bytes) }
            replaceEntryContent(zipFile, entryPath, tempContent)
        } finally {
            if (tempContent.exists()) tempContent.delete()
        }
    }

    private fun normalize(rawName: String): String {
        var name = rawName.replace('\\', '/')
        if (name.endsWith("/")) name = name.dropLast(1)
        return name
    }

    /**
     * Copies every entry from [zipFile] into a fresh temp zip — skipping entries [shouldKeep]
     * rejects, renaming the rest through [renameEntry] — then appends [newFolders] and
     * [additions] (path -> source file to read bytes from), and finally swaps the temp file
     * in over the original. Existing entries are stream-copied without decompressing, so
     * unrelated files in the archive are untouched byte-for-byte.
     */
    private fun rewrite(
        zipFile: File,
        shouldKeep: (String) -> Boolean,
        renameEntry: (String) -> String = { it },
        newFolders: List<String> = emptyList(),
        additions: List<Pair<String, File>> = emptyList(),
        additionsFromArchive: List<Pair<String, String>> = emptyList()
    ) {
        val tempFile = File(zipFile.parentFile, "${zipFile.name}.tmp${System.currentTimeMillis()}")
        val backupFile = File(zipFile.parentFile, "${zipFile.name}.bak${System.currentTimeMillis()}")
        var replacementDone = false
        try {
            ZipFile(zipFile).use { zf ->
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                    val entries = zf.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val name = normalize(e.name)
                        if (name.isEmpty() || !shouldKeep(name)) continue
                        val newName = renameEntry(name)
                        if (newName.isEmpty()) continue
                        val outName = if (e.isDirectory) "${newName.trimEnd('/')}/" else newName
                        zos.putNextEntry(ZipEntry(outName))
                        if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zos) }
                        zos.closeEntry()
                    }

                    for ((sourcePath, targetPath) in additionsFromArchive) {
                        val root = normalize(sourcePath)
                        val destinationRoot = normalize(targetPath)
                        val all = zf.entries()
                        while (all.hasMoreElements()) {
                            val source = all.nextElement()
                            val sourceName = normalize(source.name)
                            if (sourceName != root && !sourceName.startsWith("$root/")) continue
                            val suffix = sourceName.removePrefix(root).trimStart('/')
                            val targetName = if (suffix.isEmpty()) destinationRoot else "$destinationRoot/$suffix"
                            if (targetName.isEmpty()) continue
                            val outName = if (source.isDirectory) "${targetName.trimEnd('/')}/" else targetName
                            zos.putNextEntry(ZipEntry(outName))
                            if (!source.isDirectory) zf.getInputStream(source).use { it.copyTo(zos) }
                            zos.closeEntry()
                        }
                    }

                    for (folder in newFolders) {
                        zos.putNextEntry(ZipEntry("${folder.trimEnd('/')}/"))
                        zos.closeEntry()
                    }
                    for ((entryPath, sourceFile) in additions) {
                        zos.putNextEntry(ZipEntry(entryPath))
                        sourceFile.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }

            if (!tempFile.exists() || tempFile.length() <= 0L) {
                throw IOException("สร้าง Archive ชั่วคราวไม่สำเร็จหรือไฟล์ว่าง")
            }
            RandomAccessFile(tempFile, "rw").use { it.fd.sync() }

            if (backupFile.exists()) backupFile.delete()
            if (!zipFile.renameTo(backupFile)) {
                throw IOException("ไม่สามารถสำรองไฟล์ ZIP เดิมได้")
            }
            try {
                if (!tempFile.renameTo(zipFile)) {
                    if (!zipFile.exists() && backupFile.exists()) backupFile.renameTo(zipFile)
                    throw IOException("ไม่สามารถแทนที่ไฟล์ ZIP เดิมได้")
                }
                replacementDone = true
            } catch (e: Exception) {
                if (!zipFile.exists() && backupFile.exists()) backupFile.renameTo(zipFile)
                throw e
            }

            RandomAccessFile(zipFile, "rw").use { it.fd.sync() }
            backupFile.delete()

            val context = applicationContext()
            if (context != null) {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(zipFile.absolutePath),
                    arrayOf("application/zip"),
                    null
                )
                context.sendBroadcast(
                    Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(zipFile))
                )
            }
        } finally {
            if (tempFile.exists()) tempFile.delete()
            if (!replacementDone && !zipFile.exists() && backupFile.exists()) {
                backupFile.renameTo(zipFile)
            }
            if (replacementDone && backupFile.exists()) backupFile.delete()
        }
    }

    private fun applicationContext(): Context? = try {
        val thread = Class.forName("android.app.ActivityThread")
        thread.getDeclaredMethod("currentApplication").invoke(null) as? Context
    } catch (_: Exception) { null }

    /** File extensions treated as plain text so they can be opened straight into the in-app editor. */
    val TEXT_EXTENSIONS = setOf(
        "txt", "md", "json", "xml", "csv", "log", "ini", "cfg", "conf", "properties",
        "yml", "yaml", "java", "kt", "kts", "js", "ts", "html", "css", "gradle", "py",
        "c", "cpp", "h", "sh", "bat", "mcfunction", "lang"
    )
}
