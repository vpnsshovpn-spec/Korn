package com.example.filemanager

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** One virtual node inside a zip: either a real entry or a folder inferred from other entries' paths. */
data class ZipVirtualEntry(
    val path: String,       // full path inside the zip, no leading/trailing slash, e.g. "images/cat.png"
    val isDirectory: Boolean,
    val size: Long,
    val time: Long
) {
    val name: String get() = path.substringAfterLast('/')
}

/**
 * Lets the file manager treat a .zip as a live, browsable, *editable* filesystem without ever
 * fully extracting it. Reading (listing / opening a single entry) uses ZipFile random access.
 * Any mutation (delete / rename / add / replace / new folder) has to rewrite the whole archive
 * into a temp file and swap it in — java.util.zip has no in-place edit support on Android — but
 * the original zip on disk is only touched at the very end, and everything else keeps its
 * original compressed bytes copied straight through (no full decompress/recompress detour).
 */
object ZipFileSystem {

    /** Immediate children of [parentPath] ("" = zip root). Folders sort first, then by name. */
    fun childrenOf(zipFile: File, parentPath: String): List<ZipVirtualEntry> {
        val prefix = if (parentPath.isEmpty()) "" else "$parentPath/"
        val children = LinkedHashMap<String, ZipVirtualEntry>()
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val name = normalize(e.name)
                if (name.isEmpty() || !name.startsWith(prefix) || name == parentPath) continue
                val rest = name.removePrefix(prefix)
                if (rest.isEmpty()) continue
                val firstSeg = rest.substringBefore('/')
                val childPath = "$prefix$firstSeg"
                val isChildDir = rest.contains('/') || e.isDirectory
                val existing = children[childPath]
                if (existing == null || (existing.isDirectory && !isChildDir)) {
                    val size = if (isChildDir) 0L else e.size
                    children[childPath] = ZipVirtualEntry(childPath, isChildDir, size, e.time)
                }
            }
        }
        return children.values.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }

    /** Reads a single entry's whole content into memory (only used for small text-file previews/edits). */
    fun readEntryBytes(zipFile: File, entryPath: String): ByteArray {
        ZipFile(zipFile).use { zf ->
            val entry = zf.getEntry(entryPath) ?: throw FileNotFoundException(entryPath)
            return zf.getInputStream(entry).use { it.readBytes() }
        }
    }

    /** True if [path] exists as an entry (file or folder) anywhere in [zipFile]. */
    fun pathExists(zipFile: File, path: String): Boolean {
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                if (normalize(entries.nextElement().name) == path) return true
            }
        }
        return false
    }

    /** Extracts one file entry out to [destFile] on real storage (for "open with another app"). */
    fun extractEntryToFile(zipFile: File, entryPath: String, destFile: File) {
        val safeEntryPath = validateArchivePath(entryPath)
        ZipFile(zipFile).use { zf ->
            val entry = zf.getEntry(safeEntryPath) ?: throw FileNotFoundException(entryPath)
            if (entry.isDirectory) throw IOException("ไม่สามารถแตกโฟลเดอร์เป็นไฟล์ได้: $entryPath")
            val parent = destFile.parentFile ?: throw IOException("ไม่พบโฟลเดอร์ปลายทาง")
            if (!parent.exists() && !parent.mkdirs() && !parent.isDirectory) {
                throw IOException("ไม่สามารถสร้างโฟลเดอร์ปลายทางได้")
            }
            val parentCanonical = parent.canonicalFile
            val destinationCanonical = destFile.canonicalFile
            val destinationPrefix = parentCanonical.path + File.separator
            if (!destinationCanonical.path.startsWith(destinationPrefix) && destinationCanonical != parentCanonical) {
                throw SecurityException("เส้นทางปลายทางไม่ปลอดภัย")
            }
            val temp = File.createTempFile("korn-extract-", ".tmp", parentCanonical)
            try {
                zf.getInputStream(entry).use { input ->
                    FileOutputStream(temp).use { output ->
                        input.copyTo(output)
                        output.fd.sync()
                    }
                }
                val backup = if (destFile.exists()) {
                    File(parentCanonical, ".korn-extract-backup-${destFile.name}-${System.nanoTime()}").also {
                        if (!destFile.renameTo(it)) {
                            throw IOException("ไม่สามารถสำรองไฟล์ปลายทางเดิมได้")
                        }
                    }
                } else null
                var committed = false
                try {
                    if (!temp.renameTo(destFile)) {
                        if (backup != null && backup.exists()) backup.renameTo(destFile)
                        throw IOException("ไม่สามารถย้ายไฟล์ที่แตกออกมาไปยังปลายทางได้")
                    }
                    committed = true
                    if (backup != null && backup.exists()) backup.delete()
                } finally {
                    if (!committed && backup != null && backup.exists() && !destFile.exists()) {
                        backup.renameTo(destFile)
                    }
                }
            } finally {
                if (temp.exists()) temp.delete()
            }
        }
    }

    /** Extracts a whole virtual folder out to [destDir] on real storage. Guards against zip-slip. */
    fun extractFolderToDir(zipFile: File, folderPath: String, destDir: File) {
        val prefix = "$folderPath/"
        val destCanonical = destDir.canonicalPath + File.separator
        ZipFile(zipFile).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val name = normalize(e.name)
                if (!name.startsWith(prefix)) continue
                val rel = name.removePrefix(prefix)
                if (rel.isEmpty()) continue
                val outFile = File(destDir, rel)
                if (!outFile.canonicalPath.startsWith(destCanonical)) {
                    throw SecurityException("รายการในไฟล์ ZIP ไม่ปลอดภัย: $name")
                }
                if (e.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    zf.getInputStream(e).use { input -> outFile.outputStream().use { input.copyTo(it) } }
                }
            }
        }
    }

    /** Deletes [targetPath] (a file, or a folder and everything under it) from the zip. */
    fun deletePath(zipFile: File, targetPath: String) {
        rewrite(zipFile, shouldKeep = { name -> name != targetPath && !name.startsWith("$targetPath/") })
    }

    /** Renames the file/folder at [oldPath] to [newName], keeping it in the same parent folder. */
    fun renamePath(zipFile: File, oldPath: String, newName: String) {
        val parent = oldPath.substringBeforeLast('/', "")
        val newPath = if (parent.isEmpty()) newName else "$parent/$newName"
        rewrite(
            zipFile,
            shouldKeep = { true },
            renameEntry = { name ->
                when {
                    name == oldPath -> newPath
                    name.startsWith("$oldPath/") -> newPath + name.removePrefix(oldPath)
                    else -> name
                }
            }
        )
    }

    /**
     * Moves [sourcePath] (a file, or a folder and everything under it) to under
     * [destParentPath] ("" = zip root) - a generalization of renamePath() that can also change
     * the parent folder, not just the name, so items can be moved between folders *within the
     * same zip* without ever extracting anything to real storage. Same single-pass rewrite()
     * used by every other mutation here: unrelated entries are stream-copied unchanged.
     */
    fun movePath(zipFile: File, sourcePath: String, destParentPath: String) {
        val name = sourcePath.substringAfterLast('/')
        val destPath = if (destParentPath.isEmpty()) name else "$destParentPath/$name"
        if (destPath == sourcePath) return
        if (destParentPath == sourcePath || destParentPath.startsWith("$sourcePath/")) {
            throw IllegalArgumentException("ย้ายโฟลเดอร์เข้าไปในตัวเองไม่ได้")
        }
        if (pathExists(zipFile, destPath)) {
            throw IllegalStateException("มีไฟล์/โฟลเดอร์ชื่อนี้อยู่ที่ปลายทางแล้ว")
        }
        rewrite(
            zipFile,
            shouldKeep = { true },
            renameEntry = { name2 ->
                when {
                    name2 == sourcePath -> destPath
                    name2.startsWith("$sourcePath/") -> destPath + name2.removePrefix(sourcePath)
                    else -> name2
                }
            }
        )
    }

    /**
     * Copies [sourcePath] (a file, or a folder and everything under it) to under
     * [destParentPath] within the *same* zip, leaving the original in place. Runs its own
     * single rewrite pass (can't reuse the shared rewrite() helper since it needs to write
     * some entries *twice* - once at their original path, once at the copy's path): every
     * original entry is streamed straight through unchanged, and any entry under [sourcePath]
     * is additionally streamed a second time under [destParentPath] - ZipFile supports
     * re-reading any entry's bytes as many times as needed within one open session, so the
     * duplicate never touches real storage or decompresses anything either.
     */
    fun copyPath(zipFile: File, sourcePath: String, destParentPath: String) {
        val name = sourcePath.substringAfterLast('/')
        val destPath = if (destParentPath.isEmpty()) name else "$destParentPath/$name"
        if (destPath == sourcePath) {
            throw IllegalStateException("ปลายทางเดียวกับต้นทาง")
        }
        if (destParentPath == sourcePath || destParentPath.startsWith("$sourcePath/")) {
            throw IllegalArgumentException("คัดลอกโฟลเดอร์เข้าไปในตัวเองไม่ได้")
        }
        if (pathExists(zipFile, destPath)) {
            throw IllegalStateException("มีไฟล์/โฟลเดอร์ชื่อนี้อยู่ที่ปลายทางแล้ว")
        }
        val tempFile = File(zipFile.parentFile, "${zipFile.name}.tmp${System.currentTimeMillis()}")
        try {
            ZipFile(zipFile).use { zf ->
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                    val entries = zf.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val entryName = normalize(e.name)
                        if (entryName.isEmpty()) continue
                        writeEntry(zos, entryName, e.isDirectory) { zf.getInputStream(e) }
                        val underSource = entryName == sourcePath || entryName.startsWith("$sourcePath/")
                        if (underSource) {
                            val copyName = destPath + entryName.removePrefix(sourcePath)
                            writeEntry(zos, copyName, e.isDirectory) { zf.getInputStream(e) }
                        }
                    }
                }
            }
            commitTempZip(zipFile, tempFile)
        } catch (e: Exception) {
            tempFile.delete()
            throw e
        }
    }

    /**
     * Copies [sourcePath] (a file, or a folder and everything under it) from [sourceZip] into
     * [destZip] under [destParentPath] - copying between two *different* zip/mcaddon/mcpack
     * files. Still never extracts to real storage: entries are streamed straight from the
     * source zip's ZipFile into a rewrite of the destination zip. Combine with deletePath() on
     * [sourceZip] afterwards for a "move" instead of a "copy" between two files.
     */
    fun copyPathAcrossZips(sourceZip: File, sourcePath: String, destZip: File, destParentPath: String) {
        val name = sourcePath.substringAfterLast('/')
        val destPath = if (destParentPath.isEmpty()) name else "$destParentPath/$name"
        if (pathExists(destZip, destPath)) {
            throw IllegalStateException("มีไฟล์/โฟลเดอร์ชื่อนี้อยู่ที่ปลายทางแล้ว")
        }
        val tempFile = File(destZip.parentFile, "${destZip.name}.tmp${System.currentTimeMillis()}")
        try {
            ZipFile(destZip).use { destZf ->
                ZipFile(sourceZip).use { srcZf ->
                    ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                        // 1) เก็บทุก entry เดิมของปลายทางไว้เหมือนเดิมทั้งหมด
                        val destEntries = destZf.entries()
                        while (destEntries.hasMoreElements()) {
                            val e = destEntries.nextElement()
                            val entryName = normalize(e.name)
                            if (entryName.isEmpty()) continue
                            writeEntry(zos, entryName, e.isDirectory) { destZf.getInputStream(e) }
                        }
                        // 2) เพิ่ม entry จากไฟล์ต้นทางที่อยู่ใต้ sourcePath เข้าไปใต้ destPath
                        val srcEntries = srcZf.entries()
                        while (srcEntries.hasMoreElements()) {
                            val e = srcEntries.nextElement()
                            val entryName = normalize(e.name)
                            if (entryName.isEmpty()) continue
                            val underSource = entryName == sourcePath || entryName.startsWith("$sourcePath/")
                            if (!underSource) continue
                            val newName = destPath + entryName.removePrefix(sourcePath)
                            writeEntry(zos, newName, e.isDirectory) { srcZf.getInputStream(e) }
                        }
                    }
                }
            }
            commitTempZip(destZip, tempFile)
        } catch (e: Exception) {
            tempFile.delete()
            throw e
        }
    }

    private inline fun writeEntry(zos: ZipOutputStream, name: String, isDirectory: Boolean, inputStream: () -> java.io.InputStream) {
        zos.putNextEntry(ZipEntry(if (isDirectory) "$name/" else name))
        if (!isDirectory) inputStream().use { it.copyTo(zos) }
        zos.closeEntry()
    }

    /** Adds a new empty folder entry under [parentPath] ("" = root). */
    fun createFolder(zipFile: File, parentPath: String, folderName: String) {
        val folderPath = if (parentPath.isEmpty()) folderName else "$parentPath/$folderName"
        rewrite(zipFile, shouldKeep = { true }, newFolders = listOf(folderPath))
    }

    /**
     * Adds [sourceFile]'s bytes into the zip under [parentPath] as [entryName]. If an entry
     * already exists there, its content is replaced (used both for "add new file" and
     * "replace this file with one from my device").
     */
    fun addOrReplaceFile(zipFile: File, parentPath: String, entryName: String, sourceFile: File) {
        val entryPath = if (parentPath.isEmpty()) entryName else "$parentPath/$entryName"
        rewrite(
            zipFile,
            shouldKeep = { name -> name != entryPath },
            additions = listOf(entryPath to sourceFile)
        )
    }

    /** Overwrites the content of the existing entry at [entryPath] (used by the in-zip text editor's Save). */
    fun replaceEntryContent(zipFile: File, entryPath: String, newContent: File) {
        rewrite(
            zipFile,
            shouldKeep = { name -> name != entryPath },
            additions = listOf(entryPath to newContent)
        )
    }

    /** Overwrites an existing entry directly from bytes (used by the in-zip text editor's Save). */
    fun replaceEntryBytes(zipFile: File, entryPath: String, bytes: ByteArray) {
        val tempContent = File.createTempFile("korn-entry-", ".tmp", zipFile.parentFile)
        try {
            tempContent.outputStream().use { it.write(bytes) }
            replaceEntryContent(zipFile, entryPath, tempContent)
        } finally {
            if (tempContent.exists()) tempContent.delete()
        }
    }

    private fun validateArchivePath(rawName: String): String {
        val name = normalize(rawName)
        if (name.isEmpty() || name.startsWith('/') || name.matches(Regex("^[A-Za-z]:/.*"))) {
            throw SecurityException("เส้นทางในไฟล์ ZIP ไม่ปลอดภัย: $rawName")
        }
        val parts = name.split('/')
        if (parts.any { it == ".." } || parts.any { it.isEmpty() }) {
            throw SecurityException("เส้นทางในไฟล์ ZIP ไม่ปลอดภัย: $rawName")
        }
        return name
    }

    private fun normalize(rawName: String): String {
        var name = rawName.replace('\\', '/')
        if (name.endsWith("/")) name = name.dropLast(1)
        return name
    }

    /**
     * Copies every entry from [zipFile] into a fresh temp zip — skipping entries [shouldKeep]
     * rejects, renaming the rest through [renameEntry] — then appends [newFolders] and
     * [additions] (path -> source file to read bytes from), and finally swaps the temp file
     * in over the original. Existing entries are stream-copied without decompressing, so
     * unrelated files in the archive are untouched byte-for-byte.
     */
    private fun rewrite(
        zipFile: File,
        shouldKeep: (String) -> Boolean,
        renameEntry: (String) -> String = { it },
        newFolders: List<String> = emptyList(),
        additions: List<Pair<String, File>> = emptyList()
    ) {
        val tempFile = File(zipFile.parentFile, "${zipFile.name}.tmp${System.currentTimeMillis()}")
        try {
            ZipFile(zipFile).use { zf ->
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                    val entries = zf.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val name = normalize(e.name)
                        if (name.isEmpty() || !shouldKeep(name)) continue
                        val newName = renameEntry(name)
                        writeEntry(zos, newName, e.isDirectory) { zf.getInputStream(e) }
                    }
                    for (folder in newFolders) {
                        zos.putNextEntry(ZipEntry("$folder/"))
                        zos.closeEntry()
                    }
                    for ((entryPath, sourceFile) in additions) {
                        zos.putNextEntry(ZipEntry(entryPath))
                        sourceFile.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
            commitTempZip(zipFile, tempFile)
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    /**
     * Swaps a freshly-written [tempFile] in over [zipFile]. Shared by rewrite() and by
     * copyPath()/copyPathAcrossZips() (which can't reuse rewrite() itself since they need to
     * write some entries *twice*, once at the original path and once at the copy's path).
     * Android's File.renameTo() cannot reliably replace an existing file, so a rollback copy
     * of the original is kept until the new archive is confirmed to be in place - the original
     * is only ever touched at this very last step, never while [tempFile] is being built.
     */
    private fun commitTempZip(zipFile: File, tempFile: File) {
        val backupFile = File(zipFile.parentFile, "${zipFile.name}.bak${System.currentTimeMillis()}")
        if (!zipFile.renameTo(backupFile)) {
            throw IOException("ไม่สามารถสำรองไฟล์ ZIP เดิมได้")
        }
        var committed = false
        try {
            if (!tempFile.renameTo(zipFile)) {
                if (!backupFile.renameTo(zipFile)) {
                    throw IOException("ไม่สามารถกู้คืนไฟล์ ZIP เดิมได้")
                }
                throw IOException("ไม่สามารถบันทึกไฟล์ ZIP ได้")
            }
            committed = true
        } finally {
            if (committed && backupFile.exists() && !backupFile.delete()) {
                // The new archive is already committed; failure to remove the backup must
                // not destroy it. Leave the backup for cleanup/recovery rather than deleting
                // the only known-good archive.
            }
        }
    }

    /** File extensions treated as plain text so they can be opened straight into the in-app editor. */
    val TEXT_EXTENSIONS = setOf(
        "txt", "md", "json", "xml", "csv", "log", "ini", "cfg", "conf", "properties",
        "yml", "yaml", "java", "kt", "kts", "js", "ts", "html", "css", "gradle", "py",
        "c", "cpp", "h", "sh", "bat", "mcfunction", "lang"
    )

    /**
     * Extensions this file is actually built to read/write via java.util.zip's ZipFile -
     * a narrower set than ArchiveManager.BROWSE_EXTENSIONS (which also lists formats like
     * .rar/.7z/.tar that this class can't touch). Used by the "copy/move to another zip file"
     * picker to only let the user land on a file this code can actually write into.
     */
    val ZIP_FORMAT_EXTENSIONS = setOf("zip", "mcpack", "mcaddon", "mcworld", "apk", "apks", "xapk", "mtz")

    fun isZipFormatFile(file: File): Boolean =
        ZIP_FORMAT_EXTENSIONS.any { file.name.lowercase().endsWith(".$it") }
}
