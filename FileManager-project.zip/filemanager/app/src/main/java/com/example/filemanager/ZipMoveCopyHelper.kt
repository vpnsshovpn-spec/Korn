package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "ย้ายไปที่..." / "คัดลอกไปที่..." for an entry inside a zip - lets the user move/copy a file
 * or folder to a different folder *within the same zip*, or across into a completely
 * *different* zip/mcaddon/mcpack file, all without ever extracting anything to real storage
 * (see ZipFileSystem.movePath / copyPath / copyPathAcrossZips - every byte is streamed
 * straight from one zip's ZipFile into the other zip's rewrite, nothing lands on disk as a
 * loose unpacked file at any point).
 *
 * Kept in its own file rather than folded into ZipBrowserActivity.kt, matching this project's
 * existing pattern of splitting screen logic into extension-function helper files (see
 * FileClickHelper.kt, TrashUiController.kt, etc.) so the Activity itself doesn't keep growing.
 */
internal fun ZipBrowserActivity.moveOrCopyEntryDialog(entry: ZipVirtualEntry, isMove: Boolean) {
    val verb = if (isMove) "ย้าย" else "คัดลอก"
    val options = arrayOf("โฟลเดอร์อื่นในไฟล์ ZIP นี้...", "ไฟล์ ZIP/mcaddon อื่น...")
    KornDialog.Builder(this)
        .setTitle("$verb \"${entry.name}\" ไปที่")
        .setItems(options) { _, which ->
            when (which) {
                0 -> pickZipFolderDestination(zipFile, currentPath) { destParentPath ->
                    confirmAndRunMoveOrCopy(entry, zipFile, destParentPath, isMove)
                }
                1 -> pickAnotherZipFile { otherZip ->
                    pickZipFolderDestination(otherZip, "") { destParentPath ->
                        confirmAndRunMoveOrCopy(entry, otherZip, destParentPath, isMove)
                    }
                }
            }
        }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

private fun ZipBrowserActivity.confirmAndRunMoveOrCopy(
    entry: ZipVirtualEntry,
    destZip: File,
    destParentPath: String,
    isMove: Boolean
) {
    val sameZip = destZip.canonicalPath == zipFile.canonicalPath
    // ถ้าโฟลเดอร์ปลายทางที่เลือกอยู่ข้างในของ (หรือคือ) รายการที่กำลังจะย้าย/คัดลอกเอง (เป็นไปได้
    // แค่ตอนย้าย/คัดลอกภายในไฟล์ ZIP เดียวกันเท่านั้น เพราะไฟล์ ZIP คนละไฟล์ไม่มีทาง "อยู่ข้างใน"
    // กันได้) เช็คตรงนี้ก่อนเริ่มงานเลย จะได้ไม่ต้องขึ้น toast "กำลังทำงาน..." แวบหนึ่งแล้วพังทันที
    // - ZipFileSystem.movePath()/copyPath() มีการเช็คแบบเดียวกันซ้ำอีกชั้นอยู่แล้วเป็นด่านสุดท้าย
    if (sameZip && (destParentPath == entry.path || destParentPath.startsWith("${entry.path}/"))) {
        val msg = if (isMove) "ย้ายเข้าไปในตัวเองไม่ได้" else "คัดลอกเข้าไปในตัวเองไม่ได้"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        return
    }
    // เหมือนบั๊กใน ZipBrowserActivity.runZipOp() (ดูคอมเมนต์ที่นั่น): toast แจ้งเริ่ม/จบสั้น ๆ
    // 2 วิ อาจโผล่มาไม่ทันเห็นเลยถ้าไฟล์เล็กและทำงานเสร็จเร็วมาก - ใช้ dialog ค้างหน้าจอไว้ตลอด
    // ช่วงที่ทำงานแทน ให้เห็นชัดว่ากำลังย้าย/คัดลอกอยู่จริง ไม่ใช่ค้างเฉย ๆ โดยไม่มีอะไรเกิดขึ้น
    // มีปุ่ม "ซ่อน" แบบเดียวกับ runZipOp() - ข้อจำกัดเดียวกัน: ซ่อนแล้วอยู่หน้านี้ต่องานทำต่อจนเสร็จ
    // ปกติ แต่ถ้าปิดหน้าดูไฟล์ ZIP นี้ไปเลยระหว่างทำงาน งานจะถูกยกเลิกกลางคัน (ไม่มี Service
    // เบื้องหลังแบบตัวหลัก - ตามที่ตกลงกันว่าจุดนี้ใช้กับงานเล็ก ๆ พอ ไฟล์ใหญ่ให้ใช้ฟีเจอร์หลัก)
    val progressDialog = KornDialog.Builder(this)
        .setTitle(if (isMove) "กำลังย้าย..." else "กำลังคัดลอก...")
        .setView(android.widget.ProgressBar(this).apply {
            isIndeterminate = true
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        })
        .setCancelable(false)
        .setNeutralButton("ซ่อน") { d, _ -> d.dismiss() }
        .show()
    lifecycleScope.launch(Dispatchers.IO) {
        try {
            if (sameZip) {
                if (isMove) ZipFileSystem.movePath(zipFile, entry.path, destParentPath)
                else ZipFileSystem.copyPath(zipFile, entry.path, destParentPath)
            } else {
                ZipFileSystem.copyPathAcrossZips(zipFile, entry.path, destZip, destParentPath)
                if (isMove) ZipFileSystem.deletePath(zipFile, entry.path)
            }
            withContext(Dispatchers.Main) {
                progressDialog.dismiss()
                Toast.makeText(this@confirmAndRunMoveOrCopy, "สำเร็จ", Toast.LENGTH_SHORT).show()
                load()
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                progressDialog.dismiss()
                Toast.makeText(this@confirmAndRunMoveOrCopy, "ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/**
 * Browses *real* storage (same folders-and-files style as ZipBrowserActivity's own
 * showDestinationFolderPicker for "extract to...") but here tapping a folder navigates in
 * while tapping a zip/mcaddon/mcpack file (per ZipFileSystem.isZipFormatFile) picks *that
 * file* as the destination archive - there's no "choose this folder" step since the thing
 * being picked is a file, not a folder.
 */
private fun ZipBrowserActivity.pickAnotherZipFile(onChosen: (File) -> Unit) {
    val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_folder_picker, null)
    val pathTextView = dialogView.findViewById<TextView>(R.id.currentPathText)
    val listView = dialogView.findViewById<ListView>(R.id.folderListView)
    val sortButton = dialogView.findViewById<TextView>(R.id.sortInPickerButton)
    dialogView.findViewById<TextView>(R.id.newFileInPickerButton).visibility = View.GONE
    dialogView.findViewById<TextView>(R.id.newFolderInPickerButton).visibility = View.GONE
    dialogView.findViewById<Button>(R.id.chooseFolderHereButton).visibility = View.GONE
    ThemeHelper.applyFolderPickerDialog(this, dialogView)

    val dialog = KornDialog.Builder(this).setView(dialogView).setCancelable(true).create()

    val rootDir = Environment.getExternalStorageDirectory()
    var browseDir = rootDir
    // เหมือน pickerSortKey/pickerSortAscending ของ ZipBrowserActivity.showDestinationFolderPicker()
    // (และของ OpenWithActivity.showFolderPickerDialog() ต้นแบบ) แต่นี่เป็น extension function
    // ไม่ใช่ member ของคลาส เลยเก็บเป็นตัวแปร local ที่ closure จับไว้แทนฟิลด์ของคลาส
    var sortKey = PickAnotherZipSortKey.NAME
    var sortAscending = true

    fun childrenOf(dir: File): List<File> {
        val comparator: Comparator<File> = when (sortKey) {
            PickAnotherZipSortKey.NAME -> compareBy { it.name.lowercase() }
            PickAnotherZipSortKey.SIZE -> compareBy { it.length() }
            PickAnotherZipSortKey.DATE -> compareBy { it.lastModified() }
        }
        val ordered = if (sortAscending) comparator else comparator.reversed()
        return (dir.listFiles() ?: emptyArray())
            .filter { !it.name.startsWith(".") }
            .sortedWith(compareBy<File> { !it.isDirectory }.then(ordered))
    }

    fun refresh() {
        pathTextView.text = browseDir.absolutePath
        val children = childrenOf(browseDir)
        val showUp = browseDir != rootDir
        val labels = mutableListOf<String>()
        if (showUp) labels.add("⬆️  .. (ย้อนกลับ)")
        labels.addAll(children.map {
            when {
                it.isDirectory -> "📁  ${it.name}"
                ZipFileSystem.isZipFormatFile(it) -> "🗜️  ${it.name}"
                else -> "📄  ${it.name}"
            }
        })
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        listView.setOnItemClickListener { _, _, position, _ ->
            if (showUp && position == 0) {
                browseDir = browseDir.parentFile ?: rootDir
                refresh()
                return@setOnItemClickListener
            }
            val target = children[if (showUp) position - 1 else position]
            when {
                target.isDirectory -> { browseDir = target; refresh() }
                ZipFileSystem.isZipFormatFile(target) -> { dialog.dismiss(); onChosen(target) }
                // ไฟล์อื่นที่ไม่ใช่ zip/mcaddon แตะแล้วไม่ทำอะไร (โชว์ไว้ให้เห็นบริบทในโฟลเดอร์เฉยๆ
                // เหมือน showDestinationFolderPicker เดิมของหน้านี้)
                else -> {}
            }
        }
    }
    refresh()

    sortButton.setOnClickListener {
        val options = arrayOf(
            "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
            "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
            "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
        )
        val checked = when {
            sortKey == PickAnotherZipSortKey.NAME && sortAscending -> 0
            sortKey == PickAnotherZipSortKey.NAME -> 1
            sortKey == PickAnotherZipSortKey.SIZE && !sortAscending -> 2
            sortKey == PickAnotherZipSortKey.SIZE -> 3
            !sortAscending -> 4
            else -> 5
        }
        KornDialog.Builder(this)
            .setTitle("เรียงลำดับ")
            .setSingleChoiceItems(options, checked) { d, which ->
                when (which) {
                    0 -> { sortKey = PickAnotherZipSortKey.NAME; sortAscending = true }
                    1 -> { sortKey = PickAnotherZipSortKey.NAME; sortAscending = false }
                    2 -> { sortKey = PickAnotherZipSortKey.SIZE; sortAscending = false }
                    3 -> { sortKey = PickAnotherZipSortKey.SIZE; sortAscending = true }
                    4 -> { sortKey = PickAnotherZipSortKey.DATE; sortAscending = false }
                    5 -> { sortKey = PickAnotherZipSortKey.DATE; sortAscending = true }
                }
                d.dismiss()
                refresh()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    dialogView.findViewById<Button>(R.id.cancelFolderPickButton).setOnClickListener { dialog.dismiss() }
    dialog.show()
}

private enum class PickAnotherZipSortKey { NAME, SIZE, DATE }

/**
 * Browses [targetZip]'s virtual folder tree (starting at [startPath]) and hands back the
 * chosen folder's path via [onChosen] - the in-zip equivalent of the real-storage folder
 * picker, built on the exact same childrenOf()/createFolder() primitives ZipBrowserActivity
 * itself uses to render its own file list, so this never touches real storage either.
 */
private fun ZipBrowserActivity.pickZipFolderDestination(targetZip: File, startPath: String, onChosen: (String) -> Unit) {
    val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_folder_picker, null)
    val pathTextView = dialogView.findViewById<TextView>(R.id.currentPathText)
    val listView = dialogView.findViewById<ListView>(R.id.folderListView)
    val newFolderButton = dialogView.findViewById<TextView>(R.id.newFolderInPickerButton)
    val sortButton = dialogView.findViewById<TextView>(R.id.sortInPickerButton)
    dialogView.findViewById<TextView>(R.id.newFileInPickerButton).visibility = View.GONE
    ThemeHelper.applyFolderPickerDialog(this, dialogView)

    val dialog = KornDialog.Builder(this).setView(dialogView).setCancelable(true).create()

    var browsePath = startPath
    var sortKey = PickAnotherZipSortKey.NAME
    var sortAscending = true

    fun sorted(children: List<ZipVirtualEntry>): List<ZipVirtualEntry> {
        val comparator: Comparator<ZipVirtualEntry> = when (sortKey) {
            PickAnotherZipSortKey.NAME -> compareBy { it.name.lowercase() }
            PickAnotherZipSortKey.SIZE -> compareBy { it.size }
            PickAnotherZipSortKey.DATE -> compareBy { it.time }
        }
        val ordered = if (sortAscending) comparator else comparator.reversed()
        return children.sortedWith(compareBy<ZipVirtualEntry> { !it.isDirectory }.then(ordered))
    }

    fun refresh() {
        pathTextView.text = "${targetZip.name} / $browsePath".trimEnd('/')
        lifecycleScope.launch(Dispatchers.IO) {
            val children = try {
                sorted(ZipFileSystem.childrenOf(targetZip, browsePath))
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@pickZipFolderDestination, "อ่านไฟล์ ZIP ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                }
                emptyList()
            }
            withContext(Dispatchers.Main) {
                val showUp = browsePath.isNotEmpty()
                val labels = mutableListOf<String>()
                if (showUp) labels.add("⬆️  .. (ย้อนกลับ)")
                labels.addAll(children.map { if (it.isDirectory) "📁  ${it.name}" else "📄  ${it.name}" })
                listView.adapter = ArrayAdapter(this@pickZipFolderDestination, android.R.layout.simple_list_item_1, labels)
                listView.setOnItemClickListener { _, _, position, _ ->
                    if (showUp && position == 0) {
                        browsePath = browsePath.substringBeforeLast('/', "")
                        refresh()
                        return@setOnItemClickListener
                    }
                    val target = children[if (showUp) position - 1 else position]
                    if (target.isDirectory) {
                        browsePath = target.path
                        refresh()
                    }
                    // แตะไฟล์ไม่ทำอะไร (โชว์ไว้ให้เห็นบริบทในโฟลเดอร์เฉยๆ เหมือนกับตัวเลือกโฟลเดอร์
                    // จริงบนเครื่อง) เพราะปลายทางที่เลือกได้คือ "โฟลเดอร์" เท่านั้น
                }
            }
        }
    }
    refresh()

    sortButton.setOnClickListener {
        val options = arrayOf(
            "ชื่อ (ก-ฮ)", "ชื่อ (ฮ-ก)",
            "ขนาด (มาก-น้อย)", "ขนาด (น้อย-มาก)",
            "วันที่แก้ไข (ใหม่-เก่า)", "วันที่แก้ไข (เก่า-ใหม่)"
        )
        val checked = when {
            sortKey == PickAnotherZipSortKey.NAME && sortAscending -> 0
            sortKey == PickAnotherZipSortKey.NAME -> 1
            sortKey == PickAnotherZipSortKey.SIZE && !sortAscending -> 2
            sortKey == PickAnotherZipSortKey.SIZE -> 3
            !sortAscending -> 4
            else -> 5
        }
        KornDialog.Builder(this)
            .setTitle("เรียงลำดับ")
            .setSingleChoiceItems(options, checked) { d, which ->
                when (which) {
                    0 -> { sortKey = PickAnotherZipSortKey.NAME; sortAscending = true }
                    1 -> { sortKey = PickAnotherZipSortKey.NAME; sortAscending = false }
                    2 -> { sortKey = PickAnotherZipSortKey.SIZE; sortAscending = false }
                    3 -> { sortKey = PickAnotherZipSortKey.SIZE; sortAscending = true }
                    4 -> { sortKey = PickAnotherZipSortKey.DATE; sortAscending = false }
                    5 -> { sortKey = PickAnotherZipSortKey.DATE; sortAscending = true }
                }
                d.dismiss()
                refresh()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    newFolderButton.setOnClickListener {
        val input = EditText(this)
        KornDialog.Builder(this)
            .setTitle("สร้างโฟลเดอร์ใหม่")
            .setMessage("ใน ${targetZip.name} / $browsePath".trimEnd('/'))
            .setView(input)
            .setPositiveButton("สร้าง") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val parentAtCreateTime = browsePath
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        ZipFileSystem.createFolder(targetZip, parentAtCreateTime, name)
                        withContext(Dispatchers.Main) {
                            browsePath = if (parentAtCreateTime.isEmpty()) name else "$parentAtCreateTime/$name"
                            refresh()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(this@pickZipFolderDestination, "สร้างโฟลเดอร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    dialogView.findViewById<Button>(R.id.chooseFolderHereButton).setOnClickListener {
        dialog.dismiss()
        onChosen(browsePath)
    }
    dialogView.findViewById<Button>(R.id.cancelFolderPickButton).setOnClickListener {
        dialog.dismiss()
    }
    dialog.show()
}
