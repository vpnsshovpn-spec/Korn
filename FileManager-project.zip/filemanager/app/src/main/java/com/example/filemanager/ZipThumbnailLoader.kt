package com.example.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Background image-thumbnail loader for image entries *inside* a .zip/.mcaddon, used by the
 * zip-browsing screen (ZipEntryAdapter). Mirrors [ThumbnailLoader]'s pattern (in-memory LRU
 * cache, cancellable per-ViewHolder Job, `tag`-based stale-result guard) but the source bytes
 * come from [ZipFileSystem.readEntryBytes] (reading straight out of the zip via ZipFile random
 * access) instead of a real file on disk.
 */
object ZipThumbnailLoader {

    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun keyFor(zipFile: File, entry: ZipVirtualEntry): String =
        "${zipFile.absolutePath}_${zipFile.lastModified()}::${entry.path}_${entry.size}_${entry.time}"

    /** Synchronous cache-only lookup (no decoding, no coroutine hop). */
    fun cached(zipFile: File, entry: ZipVirtualEntry): Bitmap? = cache.get(keyFor(zipFile, entry))

    /**
     * Loads a downsampled thumbnail of [entry] (an image file inside [zipFile]), sized around
     * [reqPx], into [imageView]. Runs on Dispatchers.IO inside a coroutine launched in [scope]
     * (normally the hosting Activity's lifecycleScope). The returned [Job] should be stored on
     * the ViewHolder and cancelled before binding a new item / in onViewRecycled, same as
     * [ThumbnailLoader.load].
     */
    fun load(scope: CoroutineScope, zipFile: File, entry: ZipVirtualEntry, imageView: ImageView, reqPx: Int): Job {
        val key = keyFor(zipFile, entry)
        imageView.tag = key

        val cachedBitmap = cache.get(key)
        if (cachedBitmap != null) {
            imageView.setImageBitmap(cachedBitmap)
            return Job().apply { complete() }
        }

        imageView.setImageDrawable(null)
        return scope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeSampled(zipFile, entry, reqPx) }
            // Guard against this ViewHolder having been recycled for a different item while
            // the decode was running - imageView.tag will have moved on to a different key.
            if (bmp != null && imageView.tag == key) {
                cache.put(key, bmp)
                imageView.setImageBitmap(bmp)
            }
        }
    }

    private fun decodeSampled(zipFile: File, entry: ZipVirtualEntry, reqSize: Int): Bitmap? {
        return try {
            val bytes = ZipFileSystem.readEntryBytes(zipFile, entry.path)
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            var sample = 1
            while (boundsOpts.outWidth / (sample * 2) >= reqSize && boundsOpts.outHeight / (sample * 2) >= reqSize) {
                sample *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }
}
