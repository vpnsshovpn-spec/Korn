package com.example.filemanager.data.repository

import com.github.junrar.Archive
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.compressors.CompressorStreamFactory
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Multi-format archive bridge.
 *
 * Browse mode materializes a temporary ZIP in app cache and opens it with the
 * existing ZipBrowserActivity. This keeps the existing UI/editing code intact.
 * The original archive is never renamed to .zip.
 */
/**
 * Percent-change-only progress callback wrapper, shared by compress()/extract() below.
 * [onProgress] is only ever invoked when the rounded percent actually moves, so a caller
 * (ArchiveOperationService) driving a throttled notify() off of it isn't flooded with
 * thousands of no-op calls for large archives.
 */
private class ArchiveProgressReporter(private val onProgress: ((Int) -> Unit)?) {
    private var lastPercent = -1
    fun report(current: Long, total: Long) {
        if (onProgress == null || total <= 0) return
        val percent = ((current * 100) / total).toInt().coerceIn(0, 100)
        if (percent != lastPercent) {
            lastPercent = percent
            onProgress.invoke(percent)
        }
    }
}

/** Wraps a raw archive-file InputStream so sequential reads (streaming formats) drive [reporter]. */
private class ArchiveProgressInputStream(
    private val delegate: InputStream,
    private val totalBytes: Long,
    private val reporter: ArchiveProgressReporter
) : InputStream() {
    private var readBytes = 0L
    override fun read(): Int {
        val b = delegate.read()
        if (b >= 0) { readBytes++; reporter.report(readBytes, totalBytes) }
        return b
    }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = delegate.read(b, off, len)
        if (n > 0) { readBytes += n; reporter.report(readBytes, totalBytes) }
        return n
    }
    override fun close() = delegate.close()
}

object ArchiveManager {
    val BROWSE_EXTENSIONS = setOf(
        "zip","mcpack","mcaddon","mcworld","7z","tar","tgz","tar.gz","bz2","tbz2","tar.bz2",
        "xz","txz","tar.xz","lz4","zst","rar","rar5","apk","apks","xapk","mtz","arj","cpio",
        "gz","lzh","cab","chm","wim","egg","alz","iso","img","dmg","deb","rpm"
    )

    fun isArchive(file: File): Boolean {
        val n = file.name.lowercase()
        return BROWSE_EXTENSIONS.any { n == it || n.endsWith(".$it") } ||
                n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")) ||
                n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                n.matches(Regex(".*\\.r\\d{2}$"))
    }

    fun isPasswordCandidate(file: File): Boolean =
        file.name.lowercase().let { it.endsWith(".rar") || it.endsWith(".rar5") ||
            it.contains(".part") && it.endsWith(".rar") ||
            it.endsWith(".7z") || it.matches(Regex(".*\\.7z\\.\\d{3}$")) }

    fun materializeForBrowse(input: File, cacheDir: File, password: String? = null): File {
        val actual = combineSplitIfNeeded(input, cacheDir)
        val out = File(cacheDir, "browse_${System.currentTimeMillis()}.zip")
        out.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            when (formatOf(actual)) {
                "zip" -> copyZipToZip(actual, zos)
                "7z" -> sevenZipToZip(actual, zos, password)
                "rar" -> rarToZip(actual, zos, password)
                "tar" -> FileInputStream(actual).use { archiveStreamToZip(it, "tar", zos) }
                "tar.gz","tgz" -> compressedArchiveToZip(actual, CompressorStreamFactory.GZIP, zos)
                "tar.bz2","tbz2" -> compressedArchiveToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "tar.xz","txz" -> compressedArchiveToZip(actual, CompressorStreamFactory.XZ, zos)
                "gz" -> singleCompressedToZip(actual, CompressorStreamFactory.GZIP, zos)
                "bz2" -> singleCompressedToZip(actual, CompressorStreamFactory.BZIP2, zos)
                "xz" -> singleCompressedToZip(actual, CompressorStreamFactory.XZ, zos)
                "lz4" -> singleCompressedToZip(actual, CompressorStreamFactory.LZ4_FRAMED, zos)
                "zst" -> singleCompressedToZip(actual, CompressorStreamFactory.ZSTANDARD, zos)
                "arj","cpio","ar" -> FileInputStream(actual).use { archiveStreamToZip(it, null, zos) }
                else -> throw UnsupportedOperationException(
                    "KORN ยังไม่สามารถอ่าน ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
                )
            }
        }
        if (actual != input) actual.delete()
        return out
    }

    /**
     * [onProgress] (0-100, called on the caller's thread) is optional - existing call sites
     * that don't pass it behave exactly as before. When provided, zip/7z/rar report progress
     * by uncompressed bytes extracted so far (their entry APIs expose sizes upfront); every
     * other format reports by raw archive-file bytes read so far, since those are read
     * strictly sequentially anyway - see ArchiveProgressInputStream above.
     *
     * [overwriteEntries]/[skipEntries]/[renameEntries] are sets of entry relative paths (the
     * same normalized form [listEntries] returns) the user already resolved a name conflict
     * for via the ConflictDialogHelper.kt flow (ArchiveConflictResolver.kt). All three default
     * to empty, so existing callers are unaffected. An entry not in any of the three sets keeps
     * the pre-existing behavior exactly: written straight to its normal path, silently
     * overwriting whatever (if anything) is already there.
     */
    fun extract(
        input: File, destination: File, password: String? = null, onProgress: ((Int) -> Unit)? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        val actual = combineSplitIfNeeded(input, destination.parentFile ?: destination)
        destination.mkdirs()
        val reporter = ArchiveProgressReporter(onProgress)
        val totalBytes = actual.length()
        // Every extracted file's path is appended here as it's written, then reported to
        // MediaStore in one batched scan at the end - a single call regardless of how many
        // files came out, instead of one round-trip per file.
        val extracted = mutableListOf<String>()
        when (formatOf(actual)) {
            "zip" -> extractZip(actual, destination, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "7z" -> extract7z(actual, destination, password, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "rar" -> extractRar(actual, destination, password, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "tar" -> ArchiveProgressInputStream(FileInputStream(actual), totalBytes, reporter).use { extractArchiveStream(it, destination, extracted, overwriteEntries, skipEntries, renameEntries) }
            "tar.gz","tgz" -> extractCompressedArchive(actual, CompressorStreamFactory.GZIP, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "tar.bz2","tbz2" -> extractCompressedArchive(actual, CompressorStreamFactory.BZIP2, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "tar.xz","txz" -> extractCompressedArchive(actual, CompressorStreamFactory.XZ, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "gz" -> extractSingleCompressed(actual, CompressorStreamFactory.GZIP, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "bz2" -> extractSingleCompressed(actual, CompressorStreamFactory.BZIP2, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "xz" -> extractSingleCompressed(actual, CompressorStreamFactory.XZ, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "lz4" -> extractSingleCompressed(actual, CompressorStreamFactory.LZ4_FRAMED, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "zst" -> extractSingleCompressed(actual, CompressorStreamFactory.ZSTANDARD, destination, totalBytes, reporter, extracted, overwriteEntries, skipEntries, renameEntries)
            "arj","cpio","ar" -> ArchiveProgressInputStream(FileInputStream(actual), totalBytes, reporter).use { extractArchiveStream(it, destination, extracted, overwriteEntries, skipEntries, renameEntries) }
            else -> throw UnsupportedOperationException(
                "KORN ยังไม่สามารถ Extract ${input.extension.uppercase()} ได้โดยตรงในรุ่นนี้"
            )
        }
        if (actual != input) actual.delete()
        notifyMediaScannerPaths(extracted)
    }

    /**
     * Lists the relative path of every *file* entry (directories excluded - a directory
     * merging into an existing one isn't a name conflict) an archive would produce on
     * extract, in the exact same normalized form (see [safeEntryName]) [safeOutput] uses to
     * compute the real output path - so a caller can check each one against the destination
     * folder ahead of time and know it's checking the same path extract() will actually write
     * to. Nothing is extracted or written; formats with seekable metadata (zip/7z/rar) only
     * read headers, and stream formats (tar/tar.gz/.../arj/cpio/ar) skip entry content the
     * same way ArchiveInputStream.getNextEntry() always has - so this is cheap even for large
     * archives. Single-file compressed formats (gz/bz2/xz/lz4/zst) have exactly one implicit
     * "entry" - the same derived name [extractSingleCompressed] uses - so no reading happens
     * for those at all, not even headers.
     *
     * [cacheDir] is only used for reassembling split archives (.7z.001/.zip.001/.partN.rar),
     * mirroring [combineSplitIfNeeded]'s use inside extract() - the temp joined file is deleted
     * before returning either way. Reassembly (and any archive reading below) happens twice
     * across a scan+extract pair (once here, once for real in extract()) - a deliberate
     * trade-off to keep this a pure, side-effect-free preview instead of threading a cached
     * "already combined" file across the Activity/Service boundary.
     */
    fun listEntries(input: File, cacheDir: File, password: String? = null): List<String> {
        val actual = combineSplitIfNeeded(input, cacheDir)
        try {
            return when (formatOf(actual)) {
                "zip" -> listZipEntries(actual)
                "7z" -> list7zEntries(actual, password)
                "rar" -> listRarEntries(actual, password)
                "tar" -> FileInputStream(actual).use { listArchiveStreamEntries(it) }
                "tar.gz","tgz" -> listCompressedArchiveEntries(actual, CompressorStreamFactory.GZIP)
                "tar.bz2","tbz2" -> listCompressedArchiveEntries(actual, CompressorStreamFactory.BZIP2)
                "tar.xz","txz" -> listCompressedArchiveEntries(actual, CompressorStreamFactory.XZ)
                "gz","bz2","xz","lz4","zst" -> listOfNotNull(safeEntryName(actual.name.substringBeforeLast('.')))
                "arj","cpio","ar" -> FileInputStream(actual).use { listArchiveStreamEntries(it) }
                // Unrecognized format: extract() itself will throw UnsupportedOperationException
                // when actually run - nothing meaningful to preview here, so just report no
                // conflicts and let that existing error path handle it, same as before this
                // feature existed.
                else -> emptyList()
            }
        } finally {
            if (actual != input) actual.delete()
        }
    }

    private fun listZipEntries(src: File): List<String> {
        val result = mutableListOf<String>()
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                if (entry.isDirectory) continue
                safeEntryName(entry.name)?.let { result.add(it) }
            }
        }
        return result
    }

    private fun list7zEntries(src: File, password: String?): List<String> {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            return seven.entries.mapNotNull { e -> if (e.isDirectory) null else safeEntryName(e.name) }
        }
    }

    private fun listRarEntries(src: File, password: String?): List<String> {
        Archive(src, password ?: "").use { archive ->
            return archive.fileHeaders.mapNotNull { h -> if (h.isDirectory) null else safeEntryName(h.fileName) }
        }
    }

    private fun listArchiveStreamEntries(input: InputStream): List<String> {
        val result = mutableListOf<String>()
        input.use { raw ->
            val ais: ArchiveInputStream<*> = ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    if (!e.isDirectory && stream.canReadEntryData(e)) {
                        safeEntryName(e.name)?.let { result.add(it) }
                    }
                    e = stream.nextEntry
                }
            }
        }
        return result
    }

    private fun listCompressedArchiveEntries(src: File, algorithm: String): List<String> {
        val result = mutableListOf<String>()
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                result.addAll(listTarStreamEntries(cin))
            }
        }
        return result
    }

    private fun listTarStreamEntries(input: InputStream): List<String> {
        val result = mutableListOf<String>()
        TarArchiveInputStream(BufferedInputStream(input)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                if (!e.isDirectory) safeEntryName(e.name)?.let { result.add(it) }
                e = tar.nextEntry
            }
        }
        return result
    }

    private fun formatOf(f: File): String {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") -> "tar.gz"
            n.endsWith(".tar.bz2") -> "tar.bz2"
            n.endsWith(".tar.xz") -> "tar.xz"
            n.endsWith(".tgz") -> "tgz"
            n.endsWith(".tbz2") -> "tbz2"
            n.endsWith(".txz") -> "txz"
            n.endsWith(".rar") || n.endsWith(".rar5") || n.matches(Regex(".*\\.part\\d+\\.rar$")) ||
                    n.matches(Regex(".*\\.r\\d{2}$")) -> "rar"
            n.endsWith(".7z") || n.matches(Regex(".*\\.7z\\.\\d{3}$")) -> "7z"
            n.endsWith(".zip") || n.endsWith(".mcpack") || n.endsWith(".mcaddon") ||
                    n.endsWith(".mcworld") || n.endsWith(".apk") || n.endsWith(".apks") ||
                    n.endsWith(".xapk") || n.endsWith(".mtz") -> "zip"
            n.endsWith(".tar") -> "tar"
            n.endsWith(".bz2") -> "bz2"
            n.endsWith(".gz") -> "gz"
            n.endsWith(".xz") -> "xz"
            n.endsWith(".lz4") -> "lz4"
            n.endsWith(".zst") -> "zst"
            n.endsWith(".arj") -> "arj"
            n.endsWith(".cpio") -> "cpio"
            n.endsWith(".ar") || n.endsWith(".deb") -> "ar"
            else -> n.substringAfterLast('.', "")
        }
    }

    private fun combineSplitIfNeeded(input: File, cacheDir: File): File {
        val n = input.name.lowercase()
        if (!(n.matches(Regex(".*\\.(7z|zip)\\.\\d{3}$")))) return input
        val baseName = input.name.substringBeforeLast('.')
        val base = File(input.parentFile, baseName)
        val parts = (input.parentFile?.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("$baseName.", true) && it.name.substringAfterLast('.').toIntOrNull() != null }
            .sortedBy { it.name.substringAfterLast('.').toInt() }
        if (parts.isEmpty()) throw IOException("ไม่พบไฟล์ part ที่เหลือ")
        val combined = File(cacheDir, "joined_${System.currentTimeMillis()}_$baseName")
        combined.outputStream().buffered().use { out -> parts.forEach { it.inputStream().buffered().use { ins -> ins.copyTo(out) } } }
        return combined
    }

    private fun copyZipToZip(src: File, zos: ZipOutputStream) {
        ZipFile(src).use { zf ->
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val name = safeEntryName(entry.name) ?: continue
                zos.putNextEntry(ZipEntry(if (entry.isDirectory) "$name/" else name))
                if (!entry.isDirectory) zf.getInputStream(entry).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun sevenZipToZip(src: File, zos: ZipOutputStream, password: String?) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var e = seven.nextEntry
            while (e != null) {
                val name = safeEntryName(e.name)
                if (name == null) { e = seven.nextEntry; continue }
                zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                if (!e.isDirectory) {
                    val buf = ByteArray(8192)
                    var r = seven.read(buf)
                    while (r > 0) { zos.write(buf, 0, r); r = seven.read(buf) }
                }
                zos.closeEntry()
                e = seven.nextEntry
            }
        }
    }

    private fun rarToZip(src: File, zos: ZipOutputStream, password: String?) {
        Archive(src, password ?: "").use { archive ->
            for (h in archive.fileHeaders) {
                val name = safeEntryName(h.fileName) ?: continue
                zos.putNextEntry(ZipEntry(if (h.isDirectory) "$name/" else name))
                if (!h.isDirectory) archive.extractFile(h, zos)
                zos.closeEntry()
            }
        }
    }

    private fun archiveStreamToZip(input: InputStream, forced: String?, zos: ZipOutputStream) {
        input.use { raw ->
            val ais: ArchiveInputStream<*> = if (forced == "tar") {
                TarArchiveInputStream(BufferedInputStream(raw))
            } else {
                ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            }
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val name = safeEntryName(e.name)
                    if (name != null && stream.canReadEntryData(e)) {
                        zos.putNextEntry(ZipEntry(if (e.isDirectory) "$name/" else name))
                        if (!e.isDirectory) stream.copyTo(zos)
                        zos.closeEntry()
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun compressedArchiveToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { cin ->
                archiveStreamToZip(cin, "tar", zos)
            }
        }
    }

    private fun singleCompressedToZip(src: File, algorithm: String, zos: ZipOutputStream) {
        val outName = src.name.substringBeforeLast('.')
        zos.putNextEntry(ZipEntry(outName))
        FileInputStream(src).use { fin ->
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(fin)).use { it.copyTo(zos) }
        }
        zos.closeEntry()
    }

    private fun extractZip(
        src: File, dest: File, reporter: ArchiveProgressReporter? = null, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        ZipFile(src).use { zf ->
            var total = 1L
            if (reporter != null) {
                var sum = 0L
                val counting = zf.entries()
                while (counting.hasMoreElements()) sum += counting.nextElement().size.coerceAtLeast(0)
                total = sum.coerceAtLeast(1L)
            }
            var done = 0L
            val e = zf.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                val out = safeOutput(dest, entry.name, overwriteEntries, skipEntries, renameEntries)
                if (out != null) {
                    if (entry.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        zf.getInputStream(entry).use { input -> out.outputStream().use { output -> input.copyTo(output) } }
                        collector?.add(out.absolutePath)
                    }
                }
                // Progress always advances per source entry (even a skipped one) - matches
                // extract7z()/extractRar() below, so a batch with some SKIP choices still
                // reaches 100% instead of stalling partway through.
                if (reporter != null) { done += entry.size.coerceAtLeast(0); reporter.report(done, total) }
            }
        }
    }

    private fun extract7z(
        src: File, dest: File, password: String?, reporter: ArchiveProgressReporter? = null, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        val b = SevenZFile.builder().setFile(src)
        if (!password.isNullOrEmpty()) b.setPassword(password)
        b.get().use { seven ->
            var total = 1L
            if (reporter != null) {
                var sum = 0L
                for (entry in seven.entries) sum += entry.size.coerceAtLeast(0)
                total = sum.coerceAtLeast(1L)
            }
            var done = 0L
            var e = seven.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name, overwriteEntries, skipEntries, renameEntries)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { seven.getInputStream(e).copyTo(it) }
                        collector?.add(out.absolutePath)
                    }
                }
                if (reporter != null) { done += e.size.coerceAtLeast(0); reporter.report(done, total) }
                e = seven.nextEntry
            }
        }
    }

    private fun extractRar(
        src: File, dest: File, password: String?, reporter: ArchiveProgressReporter? = null, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        Archive(src, password ?: "").use { archive ->
            val headers = archive.fileHeaders
            // Entry-count based (not byte-based): junrar's per-entry unpacked-size field isn't
            // worth depending on here - counting headers is guaranteed-safe and still gives a
            // reasonable, steadily-advancing progress bar for typical archives.
            val total = headers.size.coerceAtLeast(1).toLong()
            var done = 0L
            for (h in headers) {
                val out = safeOutput(dest, h.fileName, overwriteEntries, skipEntries, renameEntries)
                if (out != null) {
                    if (h.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { archive.extractFile(h, it) }
                        collector?.add(out.absolutePath)
                    }
                }
                done++
                reporter?.report(done, total)
            }
        }
    }

    private fun extractArchiveStream(
        input: InputStream, dest: File, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        input.use { raw ->
            val ais: ArchiveInputStream<*> = ArchiveStreamFactory().createArchiveInputStream(BufferedInputStream(raw))
            ais.use { stream ->
                var e = stream.nextEntry
                while (e != null) {
                    val out = safeOutput(dest, e.name, overwriteEntries, skipEntries, renameEntries)
                    if (out != null) {
                        if (e.isDirectory) out.mkdirs()
                        else if (stream.canReadEntryData(e)) {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { stream.copyTo(it) }
                            collector?.add(out.absolutePath)
                        }
                    }
                    e = stream.nextEntry
                }
            }
        }
    }

    private fun extractCompressedArchive(
        src: File, algorithm: String, dest: File,
        totalBytes: Long = 0, reporter: ArchiveProgressReporter? = null, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        FileInputStream(src).use { fin ->
            val wrapped: InputStream = if (reporter != null) ArchiveProgressInputStream(fin, totalBytes, reporter) else fin
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(wrapped)).use { cin ->
                extractTarStream(cin, dest, collector, overwriteEntries, skipEntries, renameEntries)
            }
        }
    }

    private fun extractTarStream(
        input: InputStream, dest: File, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        TarArchiveInputStream(BufferedInputStream(input)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                val out = safeOutput(dest, e.name, overwriteEntries, skipEntries, renameEntries)
                if (out != null) {
                    if (e.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tar.copyTo(it) }
                        collector?.add(out.absolutePath)
                    }
                }
                e = tar.nextEntry
            }
        }
    }

    private fun extractSingleCompressed(
        src: File, algorithm: String, dest: File,
        totalBytes: Long = 0, reporter: ArchiveProgressReporter? = null, collector: MutableList<String>? = null,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ) {
        // Single-file formats only ever have one implicit "entry" (no archive metadata gives
        // it a name), so a SKIP choice here means "extract nothing" - handled directly instead
        // of via safeOutput, since safeOutput returning null for any other reason means "unsafe
        // name" and must still throw below exactly as before this feature existed.
        val entryName = src.name.substringBeforeLast('.')
        if (safeEntryName(entryName) in skipEntries) return
        val out = safeOutput(dest, entryName, overwriteEntries, skipEntries, renameEntries) ?: throw SecurityException("ชื่อไฟล์ไม่ปลอดภัย")
        out.parentFile?.mkdirs()
        FileInputStream(src).use { fin ->
            val wrapped: InputStream = if (reporter != null) ArchiveProgressInputStream(fin, totalBytes, reporter) else fin
            CompressorStreamFactory().createCompressorInputStream(algorithm, BufferedInputStream(wrapped)).use { input -> out.outputStream().use { output -> input.copyTo(output) } }
        }
        collector?.add(out.absolutePath)
    }

    private fun safeEntryName(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val n = raw.replace('\\','/').trimStart('/')
        if (n.split('/').any { it == ".." }) return null
        return n
    }

    /**
     * Resolves an entry's raw archive path to its real output [File], the same way it always
     * has - plus, when the entry's normalized relative path is one the user already made a
     * conflict decision for (see [extract]'s doc): deletes the existing item first for
     * OVERWRITE, or redirects to a fresh unique name for RENAME. A path in neither set (the
     * overwhelmingly common case - no conflict was ever found for it) falls straight through
     * to the pre-existing behavior: written to its normal path, silently replacing anything
     * already there. SKIP is handled by returning null, same as the existing "unsafe path"
     * case - every caller already treats a null return as "don't write this entry".
     */
    private fun safeOutput(
        dest: File, raw: String?,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ): File? {
        val name = safeEntryName(raw) ?: return null
        if (name in skipEntries) return null
        var out = File(dest, name)
        val base = dest.canonicalPath + File.separator
        if (!out.canonicalPath.startsWith(base)) return null
        if (name in overwriteEntries) {
            if (out.existsCompat()) out.deleteRecursivelyCompat()
        } else if (name in renameEntries && out.existsCompat()) {
            val parent = out.parentFile ?: dest
            out = File(parent, uniqueName(parent, out.name))
        }
        return out
    }

    // Old compress ("zip") side removed - see ArchiveDialogs.kt / CompressOperationService.kt.
    // Archive creation is now handled entirely by ArchiveEngine.kt (the "สร้างไฟล์ ของฉัน" flow).
}
