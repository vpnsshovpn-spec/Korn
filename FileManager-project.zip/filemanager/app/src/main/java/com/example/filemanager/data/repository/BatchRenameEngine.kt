package com.example.filemanager.data.repository

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Batch Rename V2 — Rename Engine / UseCase
 *
 * ไฟล์นี้เป็นไฟล์ใหม่ทั้งหมด แยกออกจาก UI โดยสมบูรณ์:
 *  - planRenames(): คำนวณชื่อไฟล์ใหม่ทั้งหมดล่วงหน้า (pure function, ไม่แตะระบบไฟล์)
 *  - execute(): สั่งเปลี่ยนชื่อจริงบน background thread พร้อม error handling
 *
 * ใช้ File.renameToCompat() ซึ่งเป็น extension function เดิมของโปรเจกต์ (FileOpsCompat.kt)
 * โดยเรียกใช้เฉยๆ ไม่มีการแก้ไขไฟล์นั้นแต่อย่างใด
 */
object BatchRenameEngine {

    /** อักขระที่ห้ามใช้ในชื่อไฟล์ (ครอบคลุมทั้งข้อจำกัดทั่วไปและของการ์ด FAT/exFAT) */
    private val ILLEGAL_CHARS = charArrayOf('/', '\\', ':', '*', '?', '"', '<', '>', '|')

    data class PlannedRename(val original: File, val newName: String)

    data class RenameSummary(val renamed: Int, val skipped: Int, val renamedPairs: List<Pair<File, File>> = emptyList())

    /** ความกว้าง zero-padding จากความยาวของข้อความเลขเริ่มต้น เช่น "01" -> 2 หลัก, "001" -> 3 หลัก */
    private fun paddingWidth(startNumberText: String): Int =
        startNumberText.trim().length.coerceAtLeast(1)

    private fun startNumber(startNumberText: String): Int =
        startNumberText.trim().toIntOrNull()?.coerceAtLeast(0) ?: 1

    private fun hasIllegalChars(name: String): Boolean = name.any { it in ILLEGAL_CHARS }

    /** นามสกุลที่จะใช้จริง: ใช้ค่าที่ผู้ใช้กรอกถ้ามี ไม่งั้นดึงนามสกุลเดิมของไฟล์นั้นๆ มาใช้ */
    private fun resolveExtension(file: File, newExtensionInput: String): String {
        val trimmed = newExtensionInput.trim().removePrefix(".")
        if (trimmed.isNotEmpty()) return trimmed
        if (file.isDirectory) return ""
        val dot = file.name.lastIndexOf('.')
        return if (dot > 0) file.name.substring(dot + 1) else ""
    }

    private fun originalStem(file: File): String {
        val dot = file.name.lastIndexOf('.')
        return if (!file.isDirectory && dot > 0) file.name.substring(0, dot) else file.name
    }

    /**
     * คำนวณรายชื่อไฟล์ใหม่ทั้งหมดล่วงหน้าตามโหมดที่เลือก (ไม่แตะระบบไฟล์จริง)
     * ลำดับใน [files] จะเป็นลำดับที่ใช้รันเลขในโหมด A
     */
    fun planRenames(files: List<File>, form: BatchRenameFormState): List<PlannedRename> {
        val mode = form.mode
        val width = (mode as? BatchRenameMode.NameWithNumber)?.let { paddingWidth(it.startNumberText) } ?: 0
        val start = (mode as? BatchRenameMode.NameWithNumber)?.let { startNumber(it.startNumberText) } ?: 0

        return files.mapIndexed { index, file ->
            val ext = resolveExtension(file, form.newExtension)
            val stem = when (mode) {
                is BatchRenameMode.NameWithNumber -> {
                    val number = (start + index).toString().padStart(width, '0')
                    "${mode.baseName}$number"
                }
                is BatchRenameMode.PrefixWithOriginal -> "${mode.prefix}${originalStem(file)}"
            }
            val newName = if (!file.isDirectory && ext.isNotEmpty()) "$stem.$ext" else stem
            PlannedRename(file, newName)
        }
    }

    /**
     * รันการเปลี่ยนชื่อจริงบน background thread
     * Error handling ครอบคลุม: ชื่อซ้ำกันเองในชุดที่กำลังเปลี่ยน, ชื่อชนกับไฟล์ปลายทางที่มีอยู่แล้ว,
     * อักขระต้องห้าม, ชื่อว่าง/ไม่เปลี่ยนแปลง, และไฟล์ถูกล็อก/เปลี่ยนชื่อไม่สำเร็จ (exception ใดๆ ถูกจับและนับเป็น skip)
     */
    suspend fun execute(
        planned: List<PlannedRename>,
        ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    ): RenameSummary = withContext(ioDispatcher) {
        var renamed = 0
        var skipped = 0
        val renamedPairs = mutableListOf<Pair<File, File>>()
        val reservedNames = mutableSetOf<String>()

        for ((file, newName) in planned) {
            try {
                if (newName.isBlank() || newName == file.name ||
                    hasIllegalChars(newName) || newName in reservedNames
                ) {
                    skipped++
                    continue
                }
                val dest = File(file.parentFile, newName)
                if (dest.exists() && dest.absolutePath != file.absolutePath) {
                    skipped++
                    continue
                }
                if (file.renameToCompat(dest)) {
                    reservedNames.add(newName)
                    renamed++
                    renamedPairs += file to dest
                } else {
                    skipped++
                }
            } catch (_: Exception) {
                skipped++
            }
        }
        RenameSummary(renamed, skipped, renamedPairs)
    }
}
