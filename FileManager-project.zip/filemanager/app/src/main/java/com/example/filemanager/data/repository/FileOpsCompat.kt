package com.example.filemanager.data.repository

import android.media.MediaScannerConnection
import com.example.filemanager.App
import com.example.filemanager.ShizukuManager
import com.example.filemanager.shizuku.ShizukuFileService
import java.io.File

/**
 * Drop-in replacements for the standard [File] operations used throughout
 * the app. Each one tries the normal java.io call first — which is all
 * that's needed for ordinary storage — and only reaches for the Shizuku
 * remote service (a separate, differently-privileged process) if that
 * fails AND Shizuku is actually connected. On a device without Shizuku,
 * or for any file the app could already reach normally, behavior is
 * identical to calling the java.io method directly.
 */

/**
 * Tells MediaStore about a file this app just wrote directly to disk, so it shows
 * up immediately in other apps' media/file pickers instead of only after the next
 * full media scan (e.g. a reboot). Best-effort - a failed scan just delays when the
 * file becomes visible elsewhere, it's not a functional problem for this app.
 */
private fun File.notifyMediaScanner() {
    try {
        MediaScannerConnection.scanFile(App.instance, arrayOf(absolutePath), null, null)
    } catch (e: Exception) {
        // Ignore - best effort only.
    }
}

/**
 * Batch variant of [notifyMediaScanner] - reports every path in a single scan call instead
 * of one MediaScannerConnection round-trip per file. Use this whenever multiple paths need
 * reporting at once (e.g. every file an archive extracted). Best-effort, same as above.
 */
fun notifyMediaScannerPaths(paths: List<String>) {
    if (paths.isEmpty()) return
    try {
        MediaScannerConnection.scanFile(App.instance, paths.toTypedArray(), null, null)
    } catch (e: Exception) {
        // Ignore - best effort only.
    }
}

fun File.listFilesCompat(): List<File>? {
    val local = listFiles()
    if (local != null && local.isNotEmpty()) return local.toList()
    // Android/data (and similar) often report as an empty, "successfully listed"
    // folder rather than throwing — so an empty result is also worth double
    // checking against Shizuku, not just a null one.
    if (!ShizukuManager.hasPermission()) return local?.toList()
    val remote = ShizukuFileService.listDir(absolutePath)
    return when {
        !remote.isNullOrEmpty() -> remote.map { File(this, it.name) }
        local != null -> local.toList()
        else -> null
    }
}

fun File.existsCompat(): Boolean {
    if (exists()) return true
    return ShizukuManager.hasPermission() && ShizukuFileService.exists(absolutePath)
}

fun File.mkdirsCompat(): Boolean {
    if (mkdirs()) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.mkdirs(absolutePath)
}

fun File.deleteCompat(): Boolean {
    if (delete()) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.delete(absolutePath)
}

fun File.deleteRecursivelyCompat(): Boolean {
    val ok = try { deleteRecursively() } catch (e: Exception) { false }
    if (ok) return true
    if (!ShizukuManager.hasPermission()) return false
    return ShizukuFileService.deleteRecursive(absolutePath)
}

/** Move/rename [this] to [dest]. */
fun File.renameToCompat(dest: File): Boolean {
    // Captured before the rename call - this File instance still points at the old
    // abstract path afterward, so we grab it up front for clarity either way.
    val oldPath = absolutePath
    if (renameTo(dest)) {
        // Scan both: the new path so it shows up immediately, and the old path so
        // MediaStore drops its now-stale index entry instead of leaving a dangling
        // reference to a file that no longer exists.
        notifyMediaScannerPaths(listOf(oldPath, dest.absolutePath))
        return true
    }
    if (!ShizukuManager.hasPermission()) return false
    val ok = ShizukuFileService.renameTo(absolutePath, dest.absolutePath)
    if (ok) notifyMediaScannerPaths(listOf(oldPath, dest.absolutePath))
    return ok
}

/** Copy [this] (file or directory) to [dest], leaving the source in place. */
fun File.copyRecursivelyCompat(dest: File, overwrite: Boolean = true): Boolean {
    val ok = try { copyRecursively(dest, overwrite) } catch (e: Exception) { false }
    if (ok) {
        dest.notifyMediaScanner()
        return true
    }
    if (!ShizukuManager.hasPermission()) return false
    val remoteOk = ShizukuFileService.copyRecursive(absolutePath, dest.absolutePath)
    if (remoteOk) dest.notifyMediaScanner()
    return remoteOk
}

fun File.createNewFileCompat(): Boolean {
    val ok = try { createNewFile() } catch (e: Exception) { false }
    if (ok) {
        notifyMediaScanner()
        return true
    }
    if (!ShizukuManager.hasPermission()) return false
    val remoteOk = ShizukuFileService.createNewFile(absolutePath)
    if (remoteOk) notifyMediaScanner()
    return remoteOk
}

/**
 * Whether reaching [this] needs Shizuku at all — i.e. it doesn't exist and
 * isn't readable through the app's own process, but does exist by way of
 * the remote service. Used to decide whether to show the "open via Shizuku"
 * copy-out path for reading/editing a protected file.
 */
fun File.needsShizuku(): Boolean {
    if (exists() && canRead()) return false
    return ShizukuManager.hasPermission() && ShizukuFileService.exists(absolutePath)
}
