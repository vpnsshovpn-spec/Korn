package com.example.filemanager.data.repository

import com.example.filemanager.TrashManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Extension groups used for the category shortcuts (images / video / music / docs / apps / archives). */
object FileCategories {
    val IMAGES = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
    val VIDEOS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")
    val MUSIC = setOf("mp3", "wav", "flac", "m4a", "ogg", "aac")
    val DOCS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv")
    val APPS = setOf("apk")
    val ARCHIVES = setOf(
        "zip", "rar", "rar5", "7z", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz",
        "lz4", "zst", "iso", "img", "dmg", "deb", "rpm", "apk", "apks", "xapk", "mtz",
        "cab", "arj", "lzh", "chm", "wim", "cpio", "egg", "alz",
        "mcpack", "mcaddon", "mcworld"
    )
}

/**
 * Recursive scanning (for category browsing + search) and zip/unzip helpers.
 * Everything here runs on a background thread from MainActivity — these functions
 * do not touch the UI themselves.
 */
object FileScanner {

    /** Recursively collects files under [root] whose extension is in [extensions]. */
    fun scanByExtensions(root: File, extensions: Set<String>, showHidden: Boolean): List<File> {
        val results = mutableListOf<File>()
        walk(root, showHidden) { f ->
            if (!f.isDirectory && f.extension.lowercase() in extensions) results.add(f)
        }
        return results
    }

    /** Recursively collects files/folders whose name contains [query] (case-insensitive). */
    fun searchByName(root: File, query: String, showHidden: Boolean): List<File> {
        val results = mutableListOf<File>()
        val q = query.lowercase()
        walk(root, showHidden) { f ->
            if (f.name.lowercase().contains(q)) results.add(f)
        }
        return results
    }

    /** Plain-text extensions eligible for the "search inside file content" toggle. */
    val CONTENT_SEARCH_EXTENSIONS = setOf("txt", "md", "json", "xml", "java", "kt", "log", "csv")

    /** Files larger than this are skipped for content search (still matched by name). */
    const val CONTENT_SEARCH_MAX_BYTES = 5L * 1024 * 1024

    /** One content search hit: the matching file plus the line it was found on (for the snippet/highlight). */
    data class ContentMatch(val file: File, val line: String)

    /**
     * Same traversal as [searchByName], but when [searchContent] is true also opens eligible
     * plain-text files (see [CONTENT_SEARCH_EXTENSIONS], size-capped by [CONTENT_SEARCH_MAX_BYTES])
     * and checks their contents for [query]. A file/folder matches if its name matches OR (when
     * enabled) its content matches; the returned [ContentMatch.line] is null unless the hit came
     * from content so callers can tell the two apart.
     */
    fun searchByNameAndContent(
        root: File,
        query: String,
        showHidden: Boolean,
        searchContent: Boolean
    ): List<ContentMatch> {
        val results = mutableListOf<ContentMatch>()
        val q = query.lowercase()
        walk(root, showHidden) { f ->
            val nameMatches = f.name.lowercase().contains(q)
            var matchedLine: String? = null
            if (searchContent && !f.isDirectory &&
                f.extension.lowercase() in CONTENT_SEARCH_EXTENSIONS &&
                f.length() in 1L..CONTENT_SEARCH_MAX_BYTES
            ) {
                matchedLine = findContentMatch(f, query)
            }
            if (nameMatches || matchedLine != null) {
                results.add(ContentMatch(f, matchedLine ?: ""))
            }
        }
        return results
    }

    /** Returns the first matching line's text (trimmed/snipped), or null if [query] isn't found or the file can't be read as text. */
    private fun findContentMatch(file: File, query: String): String? {
        return try {
            file.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val idx = line.indexOf(query, ignoreCase = true)
                    if (idx >= 0) {
                        val start = maxOf(0, idx - 40)
                        val end = minOf(line.length, idx + query.length + 40)
                        val prefix = if (start > 0) "…" else ""
                        val suffix = if (end < line.length) "…" else ""
                        return@useLines prefix + line.substring(start, end).trim() + suffix
                    }
                }
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun walk(dir: File, showHidden: Boolean, action: (File) -> Unit) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            // Android/data and Android/obb throw on modern Android even with MANAGE_EXTERNAL_STORAGE
            // in some OEM builds - skip them instead of letting the scan blow up.
            if (child.isDirectory && dir.name == "Android" && (child.name == "data" || child.name == "obb")) continue
            // Never let the recycle bin's own folder show up inside search/category results.
            if (child.isDirectory && child.name == TrashManager.TRASH_FOLDER_NAME) continue
            if (!showHidden && child.name.startsWith(".")) continue
            action(child)
            if (child.isDirectory && child.canRead()) {
                walk(child, showHidden, action)
            }
        }
    }

    /** Zips [source] (a single file or a whole folder) into [destZip]. */
    fun zip(source: File, destZip: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(destZip))).use { zos ->
            if (source.isDirectory) {
                zipDir(source, source.name, zos)
            } else {
                zipSingleFile(source, source.name, zos)
            }
        }
    }

    private fun zipDir(dir: File, base: String, zos: ZipOutputStream) {
        val children = dir.listFiles() ?: emptyArray()
        if (children.isEmpty()) {
            zos.putNextEntry(ZipEntry("$base/"))
            zos.closeEntry()
            return
        }
        for (child in children) {
            val entryName = "$base/${child.name}"
            if (child.isDirectory) {
                zipDir(child, entryName, zos)
            } else {
                zipSingleFile(child, entryName, zos)
            }
        }
    }

    private fun zipSingleFile(file: File, entryName: String, zos: ZipOutputStream) {
        zos.putNextEntry(ZipEntry(entryName))
        file.inputStream().use { it.copyTo(zos) }
        zos.closeEntry()
    }

    /** Extracts [zipFile] into [destDir]. Guards against zip-slip (entries escaping destDir). */
    fun unzip(zipFile: File, destDir: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            val destCanonical = destDir.canonicalPath + File.separator
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                val outCanonical = outFile.canonicalPath
                if (!outCanonical.startsWith(destCanonical)) {
                    throw SecurityException("รายการในไฟล์ ZIP ไม่ปลอดภัย: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
