package com.example.filemanager.data.search

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local Search Index — รอบ 1.
 *
 * แถวเดียว = ไฟล์/โฟลเดอร์หนึ่งรายการที่เจอตอนสแกน [SearchIndexManager.rebuildFullIndex].
 * ยังไม่ผูกกับพฤติกรรมค้นหาที่ผู้ใช้เห็นในรอบนี้ (ดู search-index-project-plan.txt
 * ข้อ 5) — สร้างไว้เป็นชั้นข้อมูลแยกตัวก่อน รอบ 2 ถึงจะเปลี่ยน MainViewModel ให้
 * query จากตารางนี้แทนการเดินดิสก์สดของ FileScanner
 *
 * [path] เป็น primary key ตรงๆ (แทนที่จะใช้ autoGenerate id) เพราะ path บนดิสก์
 * ไม่ซ้ำกันอยู่แล้วโดยธรรมชาติ และทำให้ insertAll แบบ REPLACE (ดู [SearchIndexDao])
 * อัปเดตแถวเดิมทับได้ตรงๆ เวลา rebuild ใหม่ทั้งก้อน
 *
 * [nameLowercase] เก็บแยกจาก [name] ตัวเดิม (ไม่ lowercase) เพื่อให้ query ด้วย
 * `WHERE nameLowercase LIKE '%q%'` ในรอบ 2 ไม่ต้องเรียก LOWER() ที่ระดับ SQL ทุกแถว
 * ทุกครั้งที่ query (คำนวณไว้ล่วงหน้าตอน insert ครั้งเดียวพอ)
 */
@Entity(tableName = "search_index")
data class SearchIndexEntity(
    @PrimaryKey
    val path: String,
    val name: String,
    val nameLowercase: String,
    val extension: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val isDirectory: Boolean
)
