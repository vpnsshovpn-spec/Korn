package com.example.filemanager.data.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import com.example.filemanager.data.repository.ArchiveManager

/**
 * Runs archive extract ("unzip") jobs outside the Activity lifecycle, the same way
 * FileOperationService.kt already does for copy/move - see that file's class doc for the
 * underlying reasoning. This lets the user tap "ซ่อน" on the progress dialog and go do
 * something else in the app while the extraction keeps working in the background, with a
 * persistent notification tracking the percent.
 *
 * The old compress ("zip") side of this service (ACTION_ZIP/startZip(), calling
 * ArchiveManager.compress()) was removed once the newer "สร้างไฟล์ Archive…" flow
 * (CompressOperationService.kt / ArchiveEngine.kt) fully replaced it as the only way to create
 * archives in the app. This service now only handles extraction.
 *
 * notify() itself is throttled to at most once every [NOTIFY_THROTTLE_MS] (a plain elapsed-time
 * check, not a coroutine debounce) since ArchiveManager's onProgress callback can fire many
 * times a second for large archives - without this, updating the status bar that often can
 * make the UI feel like it's stuttering. The BROADCAST_PROGRESS broadcast used to drive the
 * in-app dialog/ViewModel is NOT throttled the same way (it's cheap, in-process, and the
 * dialog only redraws on collect anyway), so the dialog's progress bar still feels smooth even
 * though the system notification updates less often.
 */
class ArchiveOperationService : Service() {

    companion object {
        const val CHANNEL_ID = "archive_operations"
        private const val NOTIFICATION_ID = 4301
        private const val NOTIFY_THROTTLE_MS = 500L
        private const val CONTENT_REQUEST_CODE = 4302

        const val ACTION_UNZIP = "com.example.filemanager.action.ARCHIVE_UNZIP"
        private const val EXTRA_SOURCE = "extra_source"
        private const val EXTRA_DEST = "extra_dest"
        private const val EXTRA_PASSWORD = "extra_password"
        private const val EXTRA_OVERWRITE_ENTRIES = "extra_overwrite_entries"
        private const val EXTRA_SKIP_ENTRIES = "extra_skip_entries"
        private const val EXTRA_RENAME_ENTRIES = "extra_rename_entries"

        const val BROADCAST_PROGRESS = "com.example.filemanager.ARCHIVE_OP_PROGRESS"
        const val BROADCAST_DONE = "com.example.filemanager.ARCHIVE_OP_DONE"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_IS_UNZIP = "extra_is_unzip"
        const val EXTRA_ARCHIVE_NAME = "extra_archive_name"
        const val EXTRA_SUCCESS = "extra_success"
        const val EXTRA_ERROR = "extra_error"
        const val EXTRA_DEST_PATH = "extra_dest_path"

        /**
         * Starts a background extract ("unzip") job. [source] is the archive file itself.
         * [overwriteEntries]/[skipEntries]/[renameEntries] are entry relative paths (see
         * [ArchiveManager.listEntries]/[ArchiveManager.extract]) the user already resolved a
         * name conflict for via ArchiveConflictResolver.kt - all three default to empty, so
         * existing call sites (none left after this change, but kept for signature safety)
         * behave exactly as before.
         */
        fun startUnzip(
            context: Context, source: File, destination: File, password: String?,
            overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
        ) {
            val intent = Intent(context, ArchiveOperationService::class.java).apply {
                action = ACTION_UNZIP
                putExtra(EXTRA_SOURCE, source.absolutePath)
                putExtra(EXTRA_DEST, destination.absolutePath)
                putExtra(EXTRA_PASSWORD, password)
                putStringArrayListExtra(EXTRA_OVERWRITE_ENTRIES, ArrayList(overwriteEntries))
                putStringArrayListExtra(EXTRA_SKIP_ENTRIES, ArrayList(skipEntries))
                putStringArrayListExtra(EXTRA_RENAME_ENTRIES, ArrayList(renameEntries))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private lateinit var notificationManager: NotificationManager

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "การแตกไฟล์", NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sourcePath = intent?.getStringExtra(EXTRA_SOURCE)
        val destPath = intent?.getStringExtra(EXTRA_DEST)
        val password = intent?.getStringExtra(EXTRA_PASSWORD)
        val overwriteEntries = (intent?.getStringArrayListExtra(EXTRA_OVERWRITE_ENTRIES) ?: arrayListOf()).toSet()
        val skipEntries = (intent?.getStringArrayListExtra(EXTRA_SKIP_ENTRIES) ?: arrayListOf()).toSet()
        val renameEntries = (intent?.getStringArrayListExtra(EXTRA_RENAME_ENTRIES) ?: arrayListOf()).toSet()

        if (sourcePath == null || destPath == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val source = File(sourcePath)
        val destination = File(destPath)
        val archiveName = source.name

        startForeground(NOTIFICATION_ID, buildNotification(archiveName, 0).build())

        job = scope.launch {
            runUnzip(source, destination, password, overwriteEntries, skipEntries, renameEntries)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    // Test-only visibility: exposes the pure extract + notify/broadcast logic to
    // ArchiveOperationServiceTest.kt without needing a full Service lifecycle or the
    // startForegroundService()/onStartCommand() path - same pattern as
    // FileOperationService.runOperation(). Behavior/signature for the production call
    // site (onStartCommand) is unchanged - this is the same private implementation,
    // just visible in-module. Returns success so a test can assert on it directly.
    internal fun runUnzip(
        source: File, destination: File, password: String?,
        overwriteEntries: Set<String> = emptySet(), skipEntries: Set<String> = emptySet(), renameEntries: Set<String> = emptySet()
    ): Boolean {
        val archiveName = source.name
        var lastNotifyAt = 0L
        var success = true
        var errorMessage: String? = null
        try {
            val onProgress: (Int) -> Unit = { percent ->
                broadcastProgress(percent, archiveName)
                val now = System.currentTimeMillis()
                if (now - lastNotifyAt >= NOTIFY_THROTTLE_MS) {
                    lastNotifyAt = now
                    notificationManager.notify(NOTIFICATION_ID, buildNotification(archiveName, percent).build())
                }
            }
            ArchiveManager.extract(source, destination, password, onProgress, overwriteEntries, skipEntries, renameEntries)
        } catch (e: Exception) {
            success = false
            errorMessage = e.message
            if (destination != source.parentFile) destination.deleteRecursively()
        }
        notificationManager.notify(NOTIFICATION_ID, buildNotification(archiveName, 100, success).build())
        broadcastDone(archiveName, destination.absolutePath, success, errorMessage)
        return success
    }

    private fun buildNotification(archiveName: String, percent: Int, done: Boolean = false): NotificationCompat.Builder {
        val title = if (done) "แตกไฟล์เสร็จแล้ว" else "กำลังแตกไฟล์: $archiveName"
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(if (done) archiveName else "$percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setAutoCancel(done)
            .setProgress(100, percent, false)
        if (!done) {
            // แตะ notification นี้ (ตอนงานยังทำอยู่ - รวมถึงตอนที่ผู้ใช้กด "ซ่อน" dialog ไปแล้ว)
            // ให้เปิดแอปกลับมาพร้อมเรียก dialog กลับมาโผล่ - ดู MainActivity.onNewIntent()/
            // handleReopenProgressIntent(). CLEAR_TOP+SINGLE_TOP ทำให้ถ้าแอปยังรันอยู่ (แม้อยู่
            // เบื้องหลัง) จะใช้ Activity instance เดิม (เรียก onNewIntent ไม่ใช่สร้างใหม่)
            val contentIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(MainActivity.EXTRA_REOPEN_ARCHIVE_PROGRESS, true)
            }
            val contentPendingIntent = PendingIntent.getActivity(
                this, CONTENT_REQUEST_CODE, contentIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.setContentIntent(contentPendingIntent)
        }
        return builder
    }

    private fun broadcastProgress(percent: Int, archiveName: String) {
        sendBroadcast(Intent(BROADCAST_PROGRESS).apply {
            setPackage(packageName)
            putExtra(EXTRA_PERCENT, percent)
            putExtra(EXTRA_IS_UNZIP, true)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
        })
    }

    private fun broadcastDone(archiveName: String, destPath: String, success: Boolean, error: String?) {
        sendBroadcast(Intent(BROADCAST_DONE).apply {
            setPackage(packageName)
            putExtra(EXTRA_IS_UNZIP, true)
            putExtra(EXTRA_ARCHIVE_NAME, archiveName)
            putExtra(EXTRA_DEST_PATH, destPath)
            putExtra(EXTRA_SUCCESS, success)
            putExtra(EXTRA_ERROR, error)
        })
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
