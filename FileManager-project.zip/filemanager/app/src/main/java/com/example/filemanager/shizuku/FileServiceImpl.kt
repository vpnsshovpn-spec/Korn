package com.example.filemanager.shizuku

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * Lives in the separate process Shizuku starts (running as the "shell" user
 * from ADB, or as root) — NOT in this app's normal process/uid. Shizuku
 * instantiates this class by name (see [com.example.filemanager.shizuku.ShizukuFileService])
 * and hands its Binder back to the app that bound it.
 *
 * Must have a public no-arg constructor: Shizuku creates it via reflection.
 */
class FileServiceImpl : IFileService.Stub() {

    override fun listDir(path: String): List<RemoteFileEntry> {
        val children = File(path).listFiles() ?: return emptyList()
        return children.map {
            RemoteFileEntry(it.name, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified())
        }
    }

    override fun exists(path: String): Boolean = File(path).exists()
    override fun isDirectory(path: String): Boolean = File(path).isDirectory
    override fun isFile(path: String): Boolean = File(path).isFile
    override fun length(path: String): Long = File(path).length()
    override fun mkdirs(path: String): Boolean = File(path).mkdirs()
    override fun delete(path: String): Boolean = File(path).delete()
    override fun deleteRecursive(path: String): Boolean = File(path).deleteRecursively()

    override fun renameTo(srcPath: String, dstPath: String): Boolean {
        val src = File(srcPath)
        val dst = File(dstPath)
        return try {
            if (src.renameTo(dst)) return true
            if (!src.exists()) return false
            dst.parentFile?.mkdirs()

            val temp = File(dst.parentFile, ".korn-rename-${dst.name}-${System.nanoTime()}")
            val backup = File(dst.parentFile, ".korn-backup-${dst.name}-${System.nanoTime()}")
            try {
                if (dst.exists() && !dst.renameTo(backup)) return false
                src.copyRecursively(temp, overwrite = false)
                if (!temp.exists()) throw IOException("copy failed")
                if (!temp.renameTo(dst)) {
                    temp.deleteRecursively()
                    if (backup.exists()) backup.renameTo(dst)
                    return false
                }
                if (!src.deleteRecursively()) {
                    // The destination is valid, but keeping the source is safer than deleting
                    // data after a failed cleanup. Report failure so the caller can retry.
                    return false
                }
                if (backup.exists()) backup.deleteRecursively()
                true
            } catch (_: Exception) {
                if (temp.exists()) temp.deleteRecursively()
                if (!dst.exists() && backup.exists()) backup.renameTo(dst)
                false
            } finally {
                if (temp.exists()) temp.deleteRecursively()
                if (backup.exists() && !dst.exists()) backup.renameTo(dst)
            }
        } catch (_: Exception) {
            false
        }
    }

    override fun createNewFile(path: String): Boolean = try {
        val f = File(path)
        f.parentFile?.mkdirs()
        f.createNewFile()
    } catch (e: Exception) {
        false
    }

    override fun copyRecursive(srcPath: String, dstPath: String): Boolean = try {
        File(srcPath).copyRecursively(File(dstPath), overwrite = true)
    } catch (e: Exception) {
        false
    }

    override fun openReadFd(path: String): ParcelFileDescriptor? {
        return try {
            val f = File(path)
            val pipe = ParcelFileDescriptor.createPipe()
            val readSide = pipe[0]
            val writeSide = pipe[1]
            Thread {
                try {
                    FileInputStream(f).use { input ->
                        ParcelFileDescriptor.AutoCloseOutputStream(writeSide).use { out ->
                            input.copyTo(out)
                        }
                    }
                } catch (e: Exception) {
                    try { writeSide.close() } catch (_: Exception) {}
                }
            }.start()
            readSide
        } catch (e: Exception) {
            null
        }
    }

    override fun openWriteFd(path: String, append: Boolean): ParcelFileDescriptor? {
        return try {
            val f = File(path)
            f.parentFile?.mkdirs()
            val pipe = ParcelFileDescriptor.createPipe()
            val readSide = pipe[0]
            val writeSide = pipe[1]
            Thread {
                try {
                    ParcelFileDescriptor.AutoCloseInputStream(readSide).use { input ->
                        FileOutputStream(f, append).use { out ->
                            input.copyTo(out)
                        }
                    }
                } catch (e: Exception) {
                    try { readSide.close() } catch (_: Exception) {}
                }
            }.start()
            writeSide
        } catch (e: Exception) {
            null
        }
    }

    override fun destroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
