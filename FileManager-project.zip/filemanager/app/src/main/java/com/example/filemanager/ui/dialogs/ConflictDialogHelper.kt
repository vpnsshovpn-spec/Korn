package com.example.filemanager.ui.dialogs

import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import com.example.filemanager.ConflictAction
import com.example.filemanager.ConflictResolution
import com.example.filemanager.MainActivity

/**
 * The single shared "ชื่อไฟล์ซ้ำ" (filename conflict) dialog used by both Copy/Move
 * (FileOperationService) and Extract (ArchiveOperationService) whenever a destination
 * path already exists. Kept out of MainActivity.kt itself - MainActivity only ever
 * calls [MainActivity.showConflictDialog]; the layout/wiring lives entirely here,
 * the same split already used for ArchiveProgressDialogHelper.kt/CompressProgressDialogHelper.kt.
 *
 * AlertDialog (and therefore KornDialog) only supports 3 native buttons
 * (positive/negative/neutral), but this prompt needs 4 mutually exclusive choices
 * (เขียนทับ/เปลี่ยนชื่อ/ข้าม/ยกเลิก), so all 4 are built as plain Buttons inside the
 * dialog's custom view instead of relying on KornDialog's built-in button slots.
 *
 * This file only shows the dialog and reports back a single [ConflictResolution] via
 * [onResolved] - it has no knowledge of copy/move/extract itself. Deciding when to
 * call this (per conflicting file, honoring a previous applyToAll answer) is the
 * job of whatever calls this from Part 2/Part 3, not this file.
 */

internal fun MainActivity.showConflictDialog(
    fileName: String,
    onResolved: (ConflictResolution) -> Unit
): KornDialog.KornDialogHandle {
    val pad = dp(16)

    val message = TextView(this).apply {
        text = "พบไฟล์ชื่อซ้ำ:\n$fileName\n\nต้องการทำอย่างไร?"
        textSize = 14f
    }

    val applyToAllCheckbox = CheckBox(this).apply {
        text = "ใช้ตัวเลือกนี้กับไฟล์ที่เหลือทั้งหมด"
        textSize = 13f
    }

    lateinit var handle: KornDialog.KornDialogHandle

    fun choiceButton(label: String, action: ConflictAction): Button =
        Button(this).apply {
            text = label
            setOnClickListener {
                onResolved(ConflictResolution(action, applyToAllCheckbox.isChecked))
                handle.dismiss()
            }
        }

    val overwriteButton = choiceButton("เขียนทับ", ConflictAction.OVERWRITE)
    val renameButton = choiceButton("เปลี่ยนชื่อ", ConflictAction.RENAME)
    val skipButton = choiceButton("ข้าม", ConflictAction.SKIP)

    // ยกเลิก is its own borderless text link on a separate row below the other 3
    // choices, matching the reference mockup - packing all 4 as regular Buttons into
    // one horizontal row made the row wider than the dialog and pushed/clipped
    // "ยกเลิก" past the right edge on narrower screens.
    val cancelButton = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
        text = "ยกเลิก"
        setOnClickListener {
            onResolved(ConflictResolution(ConflictAction.CANCEL, applyToAllCheckbox.isChecked))
            handle.dismiss()
        }
    }

    val buttonRow = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.END
    }
    val buttonLayoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4) }
    buttonRow.addView(overwriteButton, buttonLayoutParams)
    buttonRow.addView(renameButton, buttonLayoutParams)
    buttonRow.addView(skipButton, buttonLayoutParams)

    val cancelRow = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.END
    }
    cancelRow.addView(cancelButton, LinearLayout.LayoutParams(-2, -2))

    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad / 2, pad, pad / 2)
    }
    container.addView(message, LinearLayout.LayoutParams(-1, -2))
    container.addView(applyToAllCheckbox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    container.addView(buttonRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    container.addView(cancelRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

    // Not cancelable by back-press/outside-tap: a conflict must be answered with one
    // of the 4 explicit choices above, same reasoning as the archive progress dialog's
    // setCancelable(false) - an implicit dismiss here would leave the caller waiting
    // for a resolution that never arrives.
    handle = KornDialog.Builder(this)
        .setTitle("ไฟล์ซ้ำ")
        .setView(container)
        .setCancelable(false)
        .show()

    return handle
}
