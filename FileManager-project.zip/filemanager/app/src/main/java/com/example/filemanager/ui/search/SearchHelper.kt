package com.example.filemanager.ui.search

import android.os.Environment
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import com.example.filemanager.MainActivity
import com.example.filemanager.R
import com.example.filemanager.SearchFilterViewModel
import com.example.filemanager.ui.dialogs.KornDialog

/**
 * File/content search: the search dialog (cream-styled, live/debounced-as-you-type), the
 * sealed SearchUiState renderer, the match highlighter, and the toolbar search button.
 * Extracted out of MainActivity.kt (round 6 of the size-reduction plan; reworked for the
 * Background Archive Operations + Search UI request). The actual scan, debounce, job
 * cancellation, and StateFlow now live in SearchFilterViewModel.kt (moved there from
 * MainViewModel.kt in Round 2 step 4 - see refactor-instructions.txt) - this file only builds
 * the dialog, forwards user input into the ViewModel, and renders whatever state comes back.
 * lastSearchQuery/lastSearchContentEnabled are read via searchFilterViewModel directly (round
 * 18 wrapper removal).
 */

/**
 * Rotation Safety #4: this entry point (called from the toolbar search button, see
 * setupToolbarSearchButton() below) now only flips [MainViewModel.setSearchDialogOpen] to
 * true - it no longer builds the dialog itself. [observeSearchDialogOpenState] is the single
 * place that actually shows it, reacting the same way whether this just set the flag, a
 * rotation recreated the Activity, or the app relaunched after a real process death restored
 * the flag from SavedStateHandle. See MainViewModel.kt's "Dialog-open flags" section for the
 * full rationale.
 */
internal fun MainActivity.searchDialog() {
    searchFilterViewModel.setSearchDialogOpen(true)
}

/** Wired from MainActivity.onCreate(), same as observeConflictBatches(). */
internal fun MainActivity.observeSearchDialogOpenState() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            searchFilterViewModel.searchDialogOpen.collect { open ->
                if (!open) {
                    searchDialogHandle?.dismiss()
                    searchDialogHandle = null
                    return@collect
                }
                // Already showing (e.g. this fired again for an unrelated reason, not a real
                // open) - don't stack a second dialog. Same guard shape as
                // ConflictBatchObserver.kt's showOrReplaceConflictDialog().
                if (searchDialogHandle?.isShowing == true) return@collect
                searchDialogHandle = buildAndShowSearchDialog()
            }
        }
    }
}

/**
 * Builds and shows the actual "ค้นหาไฟล์" dialog. Pre-fills from searchFilterViewModel.lastSearchQuery/
 * lastSearchContentEnabled - already SavedStateHandle-backed and kept in sync on every
 * keystroke by onSearchQueryChanged() below - so a dialog rebuilt after process death shows
 * the same typed text/checkbox state the user left it in, with no extra state needed here.
 */
private fun MainActivity.buildAndShowSearchDialog(): KornDialog.KornDialogHandle {
    val container = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(16)
        setPadding(pad, pad / 2, pad, 0)
        setBackgroundResource(R.drawable.bg_search_dialog_cream)
    }
    val input = EditText(this).apply {
        hint = "ชื่อไฟล์หรือโฟลเดอร์"
        setText(searchFilterViewModel.lastSearchQuery.value ?: "")
        setTextColor(getColorCompat(R.color.search_cream_text))
        setHintTextColor(getColorCompat(R.color.search_cream_hint))
        setBackgroundResource(R.drawable.bg_search_input_cream)
    }
    container.addView(input, LinearLayout.LayoutParams(-1, -2))

    val contentCheckbox = CheckBox(this).apply {
        text = "ค้นหาในเนื้อหาไฟล์ด้วย"
        isChecked = searchFilterViewModel.lastSearchContentEnabled.value
        setTextColor(getColorCompat(R.color.search_cream_text))
        val pad = dp(8)
        setPadding(0, pad, 0, 0)
    }
    container.addView(contentCheckbox, LinearLayout.LayoutParams(-1, -2))

    val root = Environment.getExternalStorageDirectory()

    // Hybrid Search Strategy, live-as-you-type: every keystroke goes through
    // searchFilterViewModel.onSearchQueryChanged(), which itself debounces (~250ms) and cancels the
    // previous scan - so the dialog itself doesn't need its own debounce timer.
    input.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            val q = s?.toString()?.trim().orEmpty()
            if (q.isEmpty()) return
            directoryViewModel.setMode(MainActivity.Mode.SEARCH)
            trashActionBar.visibility = View.GONE
            showSpecialPath("ผลค้นหา: \"$q\"")
            searchFilterViewModel.onSearchQueryChanged(
                q, contentCheckbox.isChecked, root, directoryViewModel.showHidden.value,
                directoryViewModel.sortKey.value, directoryViewModel.sortAscending.value
            )
        }
    })
    contentCheckbox.setOnCheckedChangeListener { _, checked ->
        val q = input.text.toString().trim()
        if (q.isNotEmpty() && directoryViewModel.mode.value == MainActivity.Mode.SEARCH) {
            searchFilterViewModel.onSearchQueryChanged(
                q, checked, root, directoryViewModel.showHidden.value,
                directoryViewModel.sortKey.value, directoryViewModel.sortAscending.value
            )
        }
    }

    return KornDialog.Builder(this)
        .setTitle("ค้นหาไฟล์")
        .setView(container)
        .setPositiveButton("ค้นหา") { _, _ ->
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) runSearch(q, contentCheckbox.isChecked)
        }
        .setNegativeButton("ยกเลิก", null)
        // Only fires for a real dismissal (button tap / outside touch / back press), never for
        // the transient teardown a rotation causes - see KornDialogFragment.onDismiss()'s doc
        // comment. So this can't fight with rotation restore, only with an actual close.
        .setOnDismissListener { searchFilterViewModel.setSearchDialogOpen(false) }
        .show()
}

/**
 * Runs immediately (no debounce wait) - used by the dialog's "ค้นหา" button, and by
 * refreshCurrentView() for pull-to-refresh / rotation while already in search mode.
 */
internal fun MainActivity.runSearch(query: String, searchContent: Boolean = searchFilterViewModel.lastSearchContentEnabled.value) {
    directoryViewModel.setMode(MainActivity.Mode.SEARCH)
    trashActionBar.visibility = View.GONE
    showSpecialPath("ผลค้นหา: \"$query\"")
    val root = Environment.getExternalStorageDirectory()
    searchFilterViewModel.runSearchImmediate(
        query, searchContent, root, directoryViewModel.showHidden.value,
        directoryViewModel.sortKey.value, directoryViewModel.sortAscending.value
    )
}

/**
 * Renders [SearchFilterViewModel.searchUiState] into the overlay views added to
 * activity_main.xml (searchLoadingView/searchEmptyView) plus the normal file list/adapter for
 * Success. Gated on [SearchFilterViewModel.searchActive] so it never draws on top of the
 * unrelated "recent folders" screen, which also reuses Mode.SEARCH (see loadRecentFolders())
 * but never touches this state.
 */
internal fun MainActivity.observeSearchState() {
    val loadingView = findViewById<View>(R.id.searchLoadingView)
    val emptyView = findViewById<View>(R.id.searchEmptyView)

    // บั๊กเดิม: clearSearchOverlay() (ใน SearchFilterViewModel.kt - เรียกตอนออกจากโหมดค้นหา
    // เช่น กดกลับ/กดโฮม) ตั้งแค่ searchActive.value = false เฉยๆ ไม่เคยสั่งซ่อน loadingView/
    // emptyView หรือคืนค่า swipeRefresh.visibility ให้เลย - collector ของ searchUiState ด้านล่าง
    // ก็ถูก gate ด้วย "if (!searchActive.value) return@collect" พอ searchActive เป็น false
    // ก็หยุดตอบสนองไปเลยทันที ไม่มีโอกาสได้เคลียร์ overlay ที่ค้างอยู่แม้แต่ครั้งเดียว - ถ้าผล
    // ค้นหาล่าสุดก่อนออกจากหน้านี้คือ "ไม่พบไฟล์" (emptyView โชว์อยู่, swipeRefresh ถูกซ่อนไว้)
    // ทั้ง 2 อย่างจะค้างอยู่แบบนั้นตลอดไป ทับซ้อนบนเนื้อหาจริงของโฟลเดอร์ที่กลับมาแสดง แม้ mode
    // จะเปลี่ยนกลับเป็นปกติแล้วก็ตาม (ตรงกับอาการที่เจอ: หัวข้อบอกจำนวนรายการของโฟลเดอร์จริง
    // แต่จอถูกทับด้วย "ไม่พบไฟล์ที่ค้นหา" ค้างอยู่)
    // แก้โดยเพิ่ม collector แยกต่างหากที่คอยฟัง searchActive โดยเฉพาะ คอยรีเซ็ต overlay พวกนี้
    // กลับเป็นปกติทุกครั้งที่ออกจากโหมดค้นหา
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            searchFilterViewModel.searchActive.collect { active ->
                if (!active) {
                    loadingView.visibility = View.GONE
                    emptyView.visibility = View.GONE
                    swipeRefresh.visibility = View.VISIBLE
                }
            }
        }
    }

    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            searchFilterViewModel.searchUiState.collect { state ->
                if (!searchFilterViewModel.searchActive.value) return@collect
                when (state) {
                    is SearchFilterViewModel.SearchUiState.Loading -> {
                        loadingView.visibility = View.VISIBLE
                        emptyView.visibility = View.GONE
                        swipeRefresh.visibility = View.INVISIBLE
                        supportActionBar?.subtitle = "กำลังค้นหา..."
                    }
                    is SearchFilterViewModel.SearchUiState.Empty -> {
                        loadingView.visibility = View.GONE
                        emptyView.visibility = View.VISIBLE
                        swipeRefresh.visibility = View.INVISIBLE
                        adapter.updateItems(emptyList(), showFullPath = true)
                        supportActionBar?.subtitle = "0 รายการ"
                        swipeRefresh.isRefreshing = false
                    }
                    is SearchFilterViewModel.SearchUiState.Success -> {
                        loadingView.visibility = View.GONE
                        emptyView.visibility = View.GONE
                        swipeRefresh.visibility = View.VISIBLE
                        val query = searchFilterViewModel.lastSearchQuery.value.orEmpty()
                        val entries = state.entries.map { entry ->
                            val sub = entry.subtitleOverride
                            if (sub is String && sub.isNotEmpty()) entry.copy(subtitleOverride = highlightMatch(sub, query)) else entry
                        }
                        adapter.updateItems(entries, showFullPath = true)
                        supportActionBar?.subtitle = "${entries.size} รายการ"
                        swipeRefresh.isRefreshing = false
                    }
                    is SearchFilterViewModel.SearchUiState.Error -> {
                        loadingView.visibility = View.GONE
                        emptyView.visibility = View.GONE
                        swipeRefresh.visibility = View.VISIBLE
                        swipeRefresh.isRefreshing = false
                        supportActionBar?.subtitle = "เกิดข้อผิดพลาด"
                    }
                }
            }
        }
    }
}

/** Wraps every case-insensitive occurrence of [query] inside [text] with a highlighted span. */
internal fun MainActivity.highlightMatch(text: String, query: String): CharSequence {
    if (query.isEmpty()) return text
    val spannable = android.text.SpannableString(text)
    var start = 0
    while (true) {
        val idx = text.indexOf(query, start, ignoreCase = true)
        if (idx < 0) break
        spannable.setSpan(
            android.text.style.BackgroundColorSpan(0xFFFFEB3B.toInt()),
            idx, idx + query.length,
            android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannable.setSpan(
            android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
            idx, idx + query.length,
            android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        start = idx + query.length
    }
    return spannable
}

internal fun MainActivity.setupToolbarSearchButton() {
    val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
    val button = android.widget.ImageButton(this).apply {
        setImageResource(R.drawable.ic_search)
        background = null
        contentDescription = "ค้นหา"
        setPadding(12, 8, 12, 8)
        setOnClickListener { if (directoryViewModel.mode.value != MainActivity.Mode.TRASH && directoryViewModel.mode.value != MainActivity.Mode.APPS) searchDialog() }
    }
    val lp = androidx.appcompat.widget.Toolbar.LayoutParams(
        dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL
    )
    toolbar.addView(button, lp)
}

private fun MainActivity.getColorCompat(colorRes: Int): Int = androidx.core.content.ContextCompat.getColor(this, colorRes)
