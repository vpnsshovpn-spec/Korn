package com.example.filemanager.ui.selection

import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.filemanager.MainActivity
import com.example.filemanager.addBookmark
import com.example.filemanager.batchRenameDialog
import com.example.filemanager.data.repository.ArchiveManager
import com.example.filemanager.extractArchiveDialog
import com.example.filemanager.formatDateTime
import com.example.filemanager.hideFile
import com.example.filemanager.readableSize
import com.example.filemanager.renameDialog
import com.example.filemanager.showCreateArchiveDialog
import com.example.filemanager.ui.dialogs.KornDialog

/**
 * Multi-select mode (selection subtitle, enter/exit selection, action bar visibility,
 * the "เพิ่มเติม" menu, properties dialog, and copy/move/rename/delete/share for the
 * current selection) - extracted out of MainActivity.kt (round 8 of the size-reduction plan).
 * No logic changed, only location + widening the following members from private to internal
 * so this file can reach them: selectionActionBar, clipboardActionBar, selectionMoreButton,
 * clipboardFiles, clipboardIsCut, confirmDelete, hideFile(), renameDialog().
 * No bound-reference (::) call sites for these functions, so no this:: fix was needed
 * (unlike round 4).
 *
 * Rotation Safety #5: the "เพิ่มเติม" menu was originally a plain android.widget.PopupMenu -
 * fine for a quick action sheet, but a PopupMenu has no concept of surviving an Activity
 * recreation at all (rotation OR process death alike; it's just closed/gone). Rebuilt below on
 * KornDialog (setItems()) instead, using the same FileOperationViewModel + SavedStateHandle "open" flag
 * pattern as Rotation Safety #4's two dialogs, so it now survives a rotation the normal
 * KornDialog/FragmentManager way AND auto-reopens after a real process-death relaunch. See
 * FileOperationViewModel.kt's selectionMoreMenuOpen doc comment for the one caveat that's specific to
 * this menu (the underlying file selection itself isn't process-death-safe by earlier,
 * deliberate design) and how observeSelectionMoreMenu() below handles it.
 */

internal fun MainActivity.updateSelectionSubtitle() {
    supportActionBar?.subtitle = "เลือก ${adapter.selectionCount()} รายการ"
}

internal fun MainActivity.enterSelectionMode() {
    adapter.setSelectionMode(true)
    swipeRefresh.isEnabled = false
    updateSelectionSubtitle()
    updateActionBars()
}

internal fun MainActivity.exitSelectionMode() {
    adapter.setSelectionMode(false)
    swipeRefresh.isEnabled = true
    updateActionBars()
    refreshCurrentView()
}

internal fun MainActivity.updateActionBars() {
    if (!isSelectionActionBarInitialized) return
    selectionActionBar.visibility = if (adapter.selectionMode) View.VISIBLE else View.GONE
    clipboardActionBar.visibility =
        if (!adapter.selectionMode && fileOperationViewModel.clipboardFiles.value.isNotEmpty()) View.VISIBLE else View.GONE
    trashActionBar.visibility = if (!adapter.selectionMode && directoryViewModel.mode.value == MainActivity.Mode.TRASH) View.VISIBLE else View.GONE
}

/**
 * Entry point (called from selectionMoreButton, see MainViewBindingHelper.kt). The
 * empty-selection guard stays here and fires synchronously, same as before - nothing
 * process-death-related to persist for that case, there's simply nothing to show a menu for.
 * Otherwise this only flips [FileOperationViewModel.setSelectionMoreMenuOpen] to true; the actual
 * KornDialog is built by [observeSelectionMoreMenu] below.
 */
internal fun MainActivity.showSelectionMoreMenu() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }
    fileOperationViewModel.setSelectionMoreMenuOpen(true)
}

/** Wired from MainActivity.onCreate(), same as observeConflictBatches()/observeTrashConfirmDialog(). */
internal fun MainActivity.observeSelectionMoreMenu() {
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED) {
            fileOperationViewModel.selectionMoreMenuOpen.collect { open ->
                if (!open) {
                    selectionMoreMenuDialogHandle?.dismiss()
                    selectionMoreMenuDialogHandle = null
                    return@collect
                }
                // Already showing (e.g. this fired again for an unrelated reason, not a real
                // open) - don't stack a second dialog. Same guard shape as
                // ConflictBatchObserver.kt's showOrReplaceConflictDialog().
                if (selectionMoreMenuDialogHandle?.isShowing == true) return@collect

                val files = adapter.getSelectedFiles()
                if (files.isEmpty()) {
                    // The flag survived process death (SavedStateHandle) but the selection it
                    // was for deliberately didn't - see FileOperationViewModel.kt's doc comment on
                    // selectionMoreMenuOpen. No files to build a menu for; clear the flag and
                    // tell the user why, the same shape as the extract-batch password-loss
                    // notice in MainViewModel.restoreExtractBatch().
                    fileOperationViewModel.setSelectionMoreMenuOpen(false)
                    Toast.makeText(this@observeSelectionMoreMenu, "รายการที่เลือกไว้หายไป (แอปถูกปิดกลางคัน) กรุณาเลือกใหม่", Toast.LENGTH_SHORT).show()
                    return@collect
                }
                selectionMoreMenuDialogHandle = buildAndShowSelectionMoreMenu(files)
            }
        }
    }
}

/**
 * Builds and shows the actual "เพิ่มเติม" dialog for the current [files] selection - same item
 * set/branching as the original PopupMenu version (single file vs. directory vs. hidden file
 * vs. multi-selection), just expressed as a KornDialog.setItems() list instead. Each item is
 * (label, action) so the setItems() listener can dispatch straight by index.
 */
private fun MainActivity.buildAndShowSelectionMoreMenu(files: List<File>): KornDialog.KornDialogHandle {
    val actions = mutableListOf<Pair<String, () -> Unit>>()
    actions += "เลือกทั้งหมด" to { adapter.selectAll() }
    actions += "แชร์ที่เลือก" to { shareSelected() }
    actions += "บีบอัดไฟล์..." to { showCreateArchiveDialog(files) }

    if (files.size == 1) {
        val file = files[0]
        actions += "เปลี่ยนชื่อ" to { renameDialog(file) }
        actions += "รายละเอียด" to { showPropertiesDialog(file) }
        if (file.isDirectory) {
            actions += "เพิ่มในรายการโปรด" to { addBookmark(file) }
        }
        actions += (if (file.name.startsWith(".")) "เลิกซ่อน" else "ซ่อน") to {
            hideFile(file, !file.name.startsWith("."))
        }
        if (!file.isDirectory && ArchiveManager.isArchive(file)) {
            actions += "แตกไฟล์…" to { extractArchiveDialog(file) }
        }
    } else {
        actions += "เปลี่ยนชื่อหลายไฟล์" to { batchRenameDialog() }
    }

    val labels = actions.map { it.first }.toTypedArray()
    return KornDialog.Builder(this)
        .setTitle("เพิ่มเติม")
        .setItems(labels) { _, which -> actions[which].second() }
        // Only fires for a real dismissal (item tap / outside touch / back press), never for
        // the transient teardown a rotation causes - see KornDialogFragment.onDismiss()'s doc
        // comment. So this can't fight with rotation restore, only with an actual close.
        // AlertDialog.Builder.setItems() dismisses on any item tap, same as PopupMenu did.
        .setOnDismissListener { fileOperationViewModel.setSelectionMoreMenuOpen(false) }
        .show()
}

/**
 * "รายละเอียด" (Details/Properties) - shown from the selection "เพิ่มเติม" menu when
 * exactly one item is selected. Mirrors the kind of properties dialog other file
 * managers show (type, location, contents, size, modified date, permissions).
 */
internal fun MainActivity.showPropertiesDialog(file: File) {
    val sb = StringBuilder()
    sb.append("ชนิด: ").append(if (file.isDirectory) "แฟ้ม" else "ไฟล์").append("\n\n")
    sb.append("ที่ตั้ง: ").append(file.absolutePath).append("\n\n")

    if (file.isDirectory) {
        var fileCount = 0
        var dirCount = 0
        var totalSize = 0L
        runCatching {
            file.walkTopDown().forEach { f ->
                if (f == file) return@forEach
                if (f.isDirectory) dirCount++ else {
                    fileCount++
                    totalSize += f.length()
                }
            }
        }
        sb.append("ประกอบด้วย: $fileCount ไฟล์, $dirCount โฟลเดอร์").append("\n\n")
        sb.append("ขนาด: ${readableSize(totalSize)}").append("\n\n")
    } else {
        sb.append("ขนาด: ${readableSize(file.length())}").append("\n\n")
    }

    sb.append("แก้ไขล่าสุด: ${formatDateTime(file.lastModified())}").append("\n\n")
    sb.append("อ่านได้: ${if (file.canRead()) "ใช่" else "ไม่"}").append("\n")
    sb.append("เขียนได้: ${if (file.canWrite()) "ใช่" else "ไม่"}").append("\n")
    sb.append("ซ่อน: ${if (file.name.startsWith(".")) "ใช่" else "ไม่"}")

    KornDialog.Builder(this)
        .setTitle("คุณสมบัติ")
        .setMessage(sb.toString())
        .setPositiveButton("ปิด", null)
        .show()
}

internal fun MainActivity.copySelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    fileOperationViewModel.setClipboardFiles(files)
    fileOperationViewModel.setClipboardIsCut(false)
    exitSelectionMode()
    updateActionBars()
    Toast.makeText(this, "คัดลอก ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
}

internal fun MainActivity.moveSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    fileOperationViewModel.setClipboardFiles(files)
    fileOperationViewModel.setClipboardIsCut(true)
    exitSelectionMode()
    updateActionBars()
    Toast.makeText(this, "เลือกย้าย ${files.size} รายการแล้ว วางที่โฟลเดอร์ปลายทาง", Toast.LENGTH_SHORT).show()
}

internal fun MainActivity.renameSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) {
        toastNoSelection()
        return
    }
    if (files.size == 1) {
        renameDialog(files[0])
    } else {
        batchRenameDialog()
    }
}

internal fun MainActivity.deleteSelectedToTrash() {
    val activity = this
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    val action = {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                files.forEach { trashManager.moveToTrash(it) }
            }
            // ตัดออกจากลิสต์ปัจจุบันทันที ไม่ต้องรอสแกนโฟลเดอร์ใหม่ทั้งหมด (ดู comment ที่
            // removeEntryOptimistically() ใน DirectoryViewModel.kt) - ยิ่งสำคัญตรงนี้เพราะเป็น
            // batch delete: ลบพร้อมกันหลายไฟล์ยิ่งทำให้รอสแกนโฟลเดอร์ใหม่ทั้งหมดช้าเห็นได้ชัดกว่า
            // ลบทีละไฟล์เดียว
            files.forEach { directoryViewModel.removeEntryOptimistically(it) }
            exitSelectionMode()
            Toast.makeText(activity, "ย้ายไปถังขยะแล้ว", Toast.LENGTH_SHORT).show()
            files.forEach { searchIndexManager.removeFromIndex(it) }
        }
    }
    if (!confirmDelete) { action(); return }
    KornDialog.Builder(this)
        .setTitle("ย้าย ${files.size} รายการไปถังขยะ?")
        .setPositiveButton("ย้ายไปถังขยะ") { _, _ -> action() }
        .setNegativeButton("ยกเลิก", null)
        .show()
}

internal fun MainActivity.shareSelected() {
    val files = adapter.getSelectedFiles()
    if (files.isEmpty()) { toastNoSelection(); return }
    try {
        val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
    } catch (e: Exception) {
        Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

internal fun MainActivity.toastNoSelection() {
    Toast.makeText(this, "ยังไม่ได้เลือกไฟล์", Toast.LENGTH_SHORT).show()
}
