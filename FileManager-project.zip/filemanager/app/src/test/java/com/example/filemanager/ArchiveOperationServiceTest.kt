package com.example.filemanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.rules.TemporaryFolder
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Unit tests for ArchiveOperationService.runUnzip() - the extract-and-broadcast logic
 * pulled out of onStartCommand()'s coroutine body, same "test-only visibility" pattern
 * FileOperationService.runOperation() already uses (see that class's test for the
 * captureDoneBroadcast()/Looper.idle() reasoning this file reuses).
 *
 * Only plain, unencrypted .zip archives are exercised here via java.util.zip - real 7z/rar
 * extraction depends on external native/library behavior this project doesn't stub, and
 * ArchiveManager's own format-dispatch (formatOf()) is not part of what this file needs to
 * verify; runUnzip() just needs *some* real archive that ArchiveManager.extract() can
 * process end to end so the success/broadcast/notification wiring can be checked.
 *
 * Not yet run against real Gradle/Robolectric (no network access here) - treat first CI
 * run on this file with the same scrutiny as any new test, not a rubber stamp.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ArchiveOperationServiceTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun newService(): ArchiveOperationService =
        Robolectric.buildService(ArchiveOperationService::class.java).create().get()

    private fun makeZip(dir: File, name: String, entries: Map<String, String>): File {
        val zipFile = File(dir, name)
        ZipOutputStream(zipFile.outputStream()).use { zos ->
            for ((entryName, content) in entries) {
                zos.putNextEntry(ZipEntry(entryName))
                zos.write(content.toByteArray())
                zos.closeEntry()
            }
        }
        return zipFile
    }

    /** Registers a receiver for ARCHIVE_OP_DONE, runs [block], and returns the broadcast intent. */
    private fun captureDoneBroadcast(block: () -> Unit): Intent {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var captured: Intent? = null
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                captured = intent
            }
        }
        context.registerReceiver(receiver, IntentFilter(ArchiveOperationService.BROADCAST_DONE), Context.RECEIVER_NOT_EXPORTED)
        try {
            block()
            shadowOf(Looper.getMainLooper()).idle()
        } finally {
            context.unregisterReceiver(receiver)
        }
        return captured ?: error("ARCHIVE_OP_DONE was never broadcast")
    }

    @Test
    fun `extracting a valid zip reports success and writes the entries`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = File(tempFolder.newFolder("dest_parent"), "extracted")
        val zip = makeZip(srcDir, "archive.zip", mapOf("a.txt" to "hello", "sub/b.txt" to "world"))

        val result = captureDoneBroadcast {
            service.runUnzip(zip, destDir, password = null)
        }

        assertTrue(result.getBooleanExtra(ArchiveOperationService.EXTRA_SUCCESS, false))
        assertEquals("archive.zip", result.getStringExtra(ArchiveOperationService.EXTRA_ARCHIVE_NAME))
        assertEquals(destDir.absolutePath, result.getStringExtra(ArchiveOperationService.EXTRA_DEST_PATH))
        assertTrue(File(destDir, "a.txt").exists())
        assertEquals("hello", File(destDir, "a.txt").readText())
        assertTrue(File(destDir, "sub/b.txt").exists())
        assertEquals("world", File(destDir, "sub/b.txt").readText())
    }

    @Test
    fun `runUnzip return value matches the broadcast success flag`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = File(tempFolder.newFolder("dest_parent"), "extracted")
        val zip = makeZip(srcDir, "archive.zip", mapOf("a.txt" to "hello"))

        var returned = false
        val result = captureDoneBroadcast {
            returned = service.runUnzip(zip, destDir, password = null)
        }

        assertTrue(returned)
        assertEquals(returned, result.getBooleanExtra(ArchiveOperationService.EXTRA_SUCCESS, !returned))
    }

    @Test
    fun `extracting a missing source file reports failure and does not throw`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = File(tempFolder.newFolder("dest_parent"), "extracted")
        val missingZip = File(srcDir, "does_not_exist.zip")

        val result = captureDoneBroadcast {
            service.runUnzip(missingZip, destDir, password = null)
        }

        assertFalse(result.getBooleanExtra(ArchiveOperationService.EXTRA_SUCCESS, true))
        assertEquals("does_not_exist.zip", result.getStringExtra(ArchiveOperationService.EXTRA_ARCHIVE_NAME))
    }

    @Test
    fun `extracting an unsupported format reports failure with an error message`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = File(tempFolder.newFolder("dest_parent"), "extracted")
        val notAnArchive = File(srcDir, "plain.txt").apply { writeText("not an archive") }

        val result = captureDoneBroadcast {
            service.runUnzip(notAnArchive, destDir, password = null)
        }

        assertFalse(result.getBooleanExtra(ArchiveOperationService.EXTRA_SUCCESS, true))
        assertTrue(
            "a failed extract should report a non-null error message",
            result.getStringExtra(ArchiveOperationService.EXTRA_ERROR) != null
        )
    }
}
