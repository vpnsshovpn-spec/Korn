package com.example.filemanager

import android.content.res.Configuration
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import android.widget.TextView

/**
 * Tests for BookmarksBar.kt.
 *
 * Covered: isDarkThemeActive()'s four branches (explicit dark/light + system-follows-day/night),
 * and refreshBookmarksBar()'s rendering of the chip bar (empty state, one chip per bookmark with
 * the expected label, and that a second call clears the previous chips instead of appending).
 *
 * Not covered: addBookmark(), manageBookmarksDialog() - both build/drive KornDialog.Builder
 * dialogs (with an EditText/ListView inside), matching the same "no dialog-callback test
 * pattern established in this project" skip reason used for ConflictDialogHelper and the
 * dialog-only parts of ClipboardHelper/FileOpenHelper in earlier rounds. The click/long-click
 * listeners set on each chip inside refreshBookmarksBar() (open folder, delete-confirm dialog)
 * are for the same reason not exercised here - only the resulting view tree is asserted.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class BookmarksBarTest {

    private lateinit var activity: MainActivity

    @Before
    fun setUp() {
        android.os.Environment.getExternalStorageDirectory().listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }

    @Test
    fun `isDarkThemeActive is true when themeKey is explicitly dark`() {
        activity.viewModel.setThemeKey("dark")
        assertTrue(activity.isDarkThemeActive())
    }

    @Test
    fun `isDarkThemeActive is false when themeKey is explicitly light`() {
        activity.viewModel.setThemeKey("light")
        assertFalse(activity.isDarkThemeActive())
    }

    @Test
    fun `isDarkThemeActive is false for a non-dark color theme key regardless of system mode`() {
        activity.viewModel.setThemeKey("blue")
        assertFalse(activity.isDarkThemeActive())
    }

    @Test
    fun `isDarkThemeActive follows the system when themeKey is system and system is day`() {
        activity.viewModel.setThemeKey("system")
        activity.resources.configuration.uiMode =
            (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
                Configuration.UI_MODE_NIGHT_NO

        assertFalse(activity.isDarkThemeActive())
    }

    @Test
    fun `isDarkThemeActive follows the system when themeKey is system and system is night`() {
        activity.viewModel.setThemeKey("system")
        activity.resources.configuration.uiMode =
            (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
                Configuration.UI_MODE_NIGHT_YES

        assertTrue(activity.isDarkThemeActive())
    }

    @Test
    fun `refreshBookmarksBar renders no chips when there are no bookmarks`() {
        activity.refreshBookmarksBar()

        assertEquals(0, activity.bookmarksBar.childCount)
    }

    @Test
    fun `refreshBookmarksBar renders one labeled chip per bookmark`() {
        activity.bookmarksManager.add("Downloads", "/sdcard/Download")
        activity.bookmarksManager.add("Photos", "/sdcard/DCIM")

        activity.refreshBookmarksBar()

        assertEquals(2, activity.bookmarksBar.childCount)
        val labels = (0 until activity.bookmarksBar.childCount).map {
            (activity.bookmarksBar.getChildAt(it) as TextView).text.toString()
        }
        assertTrue(labels.contains("⭐ Downloads"))
        assertTrue(labels.contains("⭐ Photos"))
    }

    @Test
    fun `refreshBookmarksBar clears previously rendered chips instead of appending`() {
        activity.bookmarksManager.add("Downloads", "/sdcard/Download")
        activity.refreshBookmarksBar()
        assertEquals(1, activity.bookmarksBar.childCount)

        activity.bookmarksManager.add("Photos", "/sdcard/DCIM")
        activity.refreshBookmarksBar()

        // 2, not 3 - proves removeAllViews() ran before re-adding rather than appending on top.
        assertEquals(2, activity.bookmarksBar.childCount)
    }
}
