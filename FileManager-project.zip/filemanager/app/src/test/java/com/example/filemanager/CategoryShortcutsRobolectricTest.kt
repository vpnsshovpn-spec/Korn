package com.example.filemanager

import android.os.Looper
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/**
 * Robolectric UI-level test for CategoryShortcuts.kt - the still-pending piece flagged in
 * KORN-Next-Steps-Handoff.txt alongside CategoryShortcutsTest.kt's existing plain-JVM
 * categoryChipActiveLabel() coverage (that file explicitly says it does NOT cover the actual
 * chip views/click wiring - this file does). Same MainActivity + ShadowExternalStorageManager
 * setup as MainActivityRotationTest.kt, reused here rather than duplicated with variations,
 * since setupCategoryBar() runs unconditionally as part of MainActivity.onCreate().
 *
 * Not yet run against real Gradle/Robolectric (no network access here) - treat first CI run
 * on this file with the same scrutiny as any new test, not a rubber stamp.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class CategoryShortcutsRobolectricTest {

    private lateinit var externalRoot: File

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        File(externalRoot, "photo.jpg").writeText("x")
        File(externalRoot, "notes.txt").writeText("x")
    }

    @After
    fun tearDown() {
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun directoryViewModelOf(activity: MainActivity): DirectoryViewModel =
        ViewModelProvider(activity)[DirectoryViewModel::class.java]

    // Same reasoning/pattern as MainActivityRotationTest.kt's awaitInitialLoadSettled() -
    // onCreate()'s initial loadDirectory() runs on a real background thread Robolectric's
    // paused main-looper doesn't control, so settle it before each test's own assertions.
    // Round 2 (MainViewModel split, step 1 of 4): directoryState/mode/currentCategoryLabel
    // now live on DirectoryViewModel, not MainViewModel.
    private fun awaitInitialLoadSettled(vm: DirectoryViewModel) {
        val deadline = System.currentTimeMillis() + 2000
        while (vm.directoryState.value.isLoading && System.currentTimeMillis() < deadline) {
            Thread.sleep(10)
        }
    }

    private fun idle() = shadowOf(Looper.getMainLooper()).idle()

    @Test
    fun `category bar is populated with all 7 category chips in order`() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val vm = directoryViewModelOf(activity)
        awaitInitialLoadSettled(vm)

        val labels = (0 until activity.categoryBar.childCount).map {
            (activity.categoryBar.getChildAt(it) as TextView).text.toString()
        }

        assertEquals(
            listOf("ทั้งหมด", "รูปภาพ", "วิดีโอ", "เพลง", "เอกสาร", "แอปพลิเคชัน", "ไฟล์บีบอัด"),
            labels
        )
    }

    @Test
    fun `tapping a category chip switches mode to CATEGORY with that label`() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val vm = directoryViewModelOf(activity)
        awaitInitialLoadSettled(vm)

        val imagesChip = (0 until activity.categoryBar.childCount)
            .map { activity.categoryBar.getChildAt(it) as TextView }
            .first { it.text == "รูปภาพ" }
        imagesChip.performClick()
        idle()

        assertEquals(MainActivity.Mode.CATEGORY, vm.mode.value)
        assertEquals("รูปภาพ", vm.currentCategoryLabel.value)
    }

    @Test
    fun `tapping the ทั้งหมด chip returns mode to NORMAL`() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val vm = directoryViewModelOf(activity)
        awaitInitialLoadSettled(vm)
        vm.setMode(MainActivity.Mode.CATEGORY)
        vm.setCurrentCategoryLabel("รูปภาพ")

        val allChip = (0 until activity.categoryBar.childCount)
            .map { activity.categoryBar.getChildAt(it) as TextView }
            .first { it.text == "ทั้งหมด" }
        allChip.performClick()
        idle()

        assertEquals(MainActivity.Mode.NORMAL, vm.mode.value)
    }

    @Test
    fun `tapping the แอปพลิเคชัน chip switches mode to APPS`() {
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val vm = directoryViewModelOf(activity)
        awaitInitialLoadSettled(vm)

        val appsChip = (0 until activity.categoryBar.childCount)
            .map { activity.categoryBar.getChildAt(it) as TextView }
            .first { it.text == "แอปพลิเคชัน" }
        appsChip.performClick()
        idle()

        assertEquals(MainActivity.Mode.APPS, vm.mode.value)
    }
}
