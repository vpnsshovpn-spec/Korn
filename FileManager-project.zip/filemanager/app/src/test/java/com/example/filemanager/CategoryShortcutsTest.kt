package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Level 1 test for CategoryShortcuts.kt's chip active-state logic (categoryChipActiveLabel).
 *
 * Pure-logic only - no Robolectric, no MainViewModel instance, no Android framework calls.
 * categoryChipActiveLabel() takes MainActivity.Mode + a nullable category label and returns
 * which chip label (if any) should render as "active"; that's exactly the mapping this test
 * checks. This guards the selected-chip highlighting fix (filled pill vs outline) against a
 * future edit to CategoryShortcuts.kt silently breaking which chip lights up.
 */
class CategoryShortcutsTest {

    @Test
    fun `NORMAL mode marks ทั้งหมด as active`() {
        assertEquals("ทั้งหมด", categoryChipActiveLabel(MainActivity.Mode.NORMAL, null))
    }

    @Test
    fun `NORMAL mode ignores any leftover category label`() {
        // currentCategoryLabel can still hold a stale value from a previous category visit;
        // NORMAL mode must win regardless of what's in it.
        assertEquals("ทั้งหมด", categoryChipActiveLabel(MainActivity.Mode.NORMAL, "รูปภาพ"))
    }

    @Test
    fun `APPS mode marks แอปพลิเคชัน as active`() {
        assertEquals("แอปพลิเคชัน", categoryChipActiveLabel(MainActivity.Mode.APPS, null))
    }

    @Test
    fun `CATEGORY mode with รูปภาพ marks รูปภาพ as active`() {
        assertEquals("รูปภาพ", categoryChipActiveLabel(MainActivity.Mode.CATEGORY, "รูปภาพ"))
    }

    @Test
    fun `CATEGORY mode with ไฟล์บีบอัด marks ไฟล์บีบอัด as active`() {
        assertEquals("ไฟล์บีบอัด", categoryChipActiveLabel(MainActivity.Mode.CATEGORY, "ไฟล์บีบอัด"))
    }

    @Test
    fun `CATEGORY mode with null label means no chip is active`() {
        // Shouldn't happen in practice (runCategoryScan always sets a label before switching
        // to CATEGORY), but the mapping should still fail safe to "nothing highlighted"
        // rather than accidentally matching some chip.
        assertNull(categoryChipActiveLabel(MainActivity.Mode.CATEGORY, null))
    }

    @Test
    fun `SEARCH mode means no chip is active`() {
        assertNull(categoryChipActiveLabel(MainActivity.Mode.SEARCH, null))
    }

    @Test
    fun `TRASH mode means no chip is active`() {
        assertNull(categoryChipActiveLabel(MainActivity.Mode.TRASH, null))
    }
}
