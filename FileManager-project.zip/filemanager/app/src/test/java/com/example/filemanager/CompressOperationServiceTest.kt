package com.example.filemanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.rules.TemporaryFolder
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/**
 * Unit tests for CompressOperationService's runSingleArchive()/runSeparatePerItem() - the
 * ArchiveEngine.compress()-driving logic pulled out of onStartCommand()'s coroutine body,
 * same "test-only visibility" pattern FileOperationService.runOperation() and
 * ArchiveOperationService.runUnzip() already use (see FileOperationServiceIndexBroadcastTest.kt
 * for the captureDoneBroadcast()/Looper.idle() reasoning reused here).
 *
 * Both target functions stayed `suspend` (they were before this change too, just private) so
 * production behavior/signature is unchanged - tests drive them with kotlinx.coroutines.runBlocking.
 *
 * Cancellation (ArchiveCancelledException via the onCancel callback) is intentionally NOT
 * covered here: it's gated on the companion object's `cancelRequested`, which is private even
 * to this same-package test class (only accessible through requestCancel(), which itself starts
 * a second Service intent - out of scope for this round). Only the ZIP format is exercised,
 * since ArchiveEngine's own per-format compression logic (7z/tar/etc.) isn't what this file
 * needs to verify - just that runSingleArchive()/runSeparatePerItem() call it correctly and
 * broadcast the right result.
 *
 * Not yet run against real Gradle/Robolectric (no network access here) - treat first CI run on
 * this file with the same scrutiny as any new test, not a rubber stamp.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CompressOperationServiceTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun newService(): CompressOperationService =
        Robolectric.buildService(CompressOperationService::class.java).create().get()

    private fun zipOptions(sourceFiles: List<File>, outputDir: File, outputFileName: String, separatePerItem: Boolean = false) =
        CompressOptions(
            sourceFiles = sourceFiles,
            outputDir = outputDir,
            outputFileName = outputFileName,
            format = CompressFormat.ZIP,
            level = CompressionLevel.DEFAULT,
            volumeSizeBytes = 0L,
            password = null,
            encryptionType = EncryptionType.DEFAULT,
            deleteSourceAfterCompress = false,
            createSeparateArchivePerItem = separatePerItem
        )

    /** Registers a receiver for COMPRESS_OP_DONE, runs [block], and returns the broadcast intent. */
    private fun captureDoneBroadcast(block: () -> Unit): Intent {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var captured: Intent? = null
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                captured = intent
            }
        }
        context.registerReceiver(receiver, IntentFilter(CompressOperationService.BROADCAST_DONE), Context.RECEIVER_NOT_EXPORTED)
        try {
            block()
            shadowOf(Looper.getMainLooper()).idle()
        } finally {
            context.unregisterReceiver(receiver)
        }
        return captured ?: error("COMPRESS_OP_DONE was never broadcast")
    }

    @Test
    fun `compressing a single file into one zip reports success and creates the archive`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val outDir = tempFolder.newFolder("out")
        val file = File(srcDir, "a.txt").apply { writeText("hello") }
        val options = zipOptions(listOf(file), outDir, "archive.zip")

        val result = captureDoneBroadcast {
            runBlocking { service.runSingleArchive(options) }
        }

        assertTrue(result.getBooleanExtra(CompressOperationService.EXTRA_SUCCESS, false))
        assertFalse(result.getBooleanExtra(CompressOperationService.EXTRA_CANCELLED, true))
        assertTrue(File(outDir, "archive.zip").exists())
        assertEquals(
            listOf(File(outDir, "archive.zip").absolutePath),
            result.getStringArrayListExtra(CompressOperationService.EXTRA_CREATED_PATHS)
        )
    }

    @Test
    fun `deleteSourceAfterCompress removes the source and reports it in deletedPaths`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val outDir = tempFolder.newFolder("out")
        val file = File(srcDir, "a.txt").apply { writeText("hello") }
        val options = zipOptions(listOf(file), outDir, "archive.zip").copy(deleteSourceAfterCompress = true)

        val result = captureDoneBroadcast {
            runBlocking { service.runSingleArchive(options) }
        }

        assertTrue(result.getBooleanExtra(CompressOperationService.EXTRA_SUCCESS, false))
        assertFalse("source should be deleted after a successful compress", file.exists())
        assertEquals(
            listOf(file.absolutePath),
            result.getStringArrayListExtra(CompressOperationService.EXTRA_DELETED_PATHS)
        )
    }

    @Test
    fun `compressing with a missing source reports failure, not a crash`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val outDir = tempFolder.newFolder("out")
        val missingFile = File(srcDir, "missing.txt")
        val options = zipOptions(listOf(missingFile), outDir, "archive.zip")

        val result = captureDoneBroadcast {
            runBlocking { service.runSingleArchive(options) }
        }

        assertFalse(result.getBooleanExtra(CompressOperationService.EXTRA_SUCCESS, true))
        assertFalse(result.getBooleanExtra(CompressOperationService.EXTRA_CANCELLED, false))
    }

    @Test
    fun `separate-per-item mode creates one archive per source and names them uniquely`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val outDir = tempFolder.newFolder("out")
        val fileA = File(srcDir, "a.txt").apply { writeText("aaa") }
        val fileB = File(srcDir, "b.txt").apply { writeText("bbb") }
        val options = zipOptions(listOf(fileA, fileB), outDir, "unused.zip", separatePerItem = true)

        val result = captureDoneBroadcast {
            runBlocking { service.runSeparatePerItem(options) }
        }

        assertTrue(result.getBooleanExtra(CompressOperationService.EXTRA_SUCCESS, false))
        assertTrue(File(outDir, "a.zip").exists())
        assertTrue(File(outDir, "b.zip").exists())
        val created = result.getStringArrayListExtra(CompressOperationService.EXTRA_CREATED_PATHS)
        assertEquals(2, created?.size)
    }
}
