package com.example.filemanager

import com.example.filemanager.ui.directory.DirectoryBreadcrumbHelper
import com.example.filemanager.ui.directory.DirectoryBrowserHelper
import android.graphics.Typeface
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper
import java.io.File

/**
 * Tests for DirectoryBreadcrumbHelper.kt - pure View-rendering logic with no Activity/
 * ViewModel dependency, so a plain Robolectric application Context (RuntimeEnvironment.
 * getApplication()) is enough to construct the LinearLayout/HorizontalScrollView it needs;
 * no MainActivity setup required.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DirectoryBreadcrumbHelperTest {

    private lateinit var breadcrumbBar: LinearLayout
    private lateinit var breadcrumbScroll: HorizontalScrollView
    private var clickedFolder: File? = null
    private lateinit var helper: DirectoryBreadcrumbHelper

    @Before
    fun setUp() {
        val context = RuntimeEnvironment.getApplication()
        breadcrumbBar = LinearLayout(context)
        breadcrumbScroll = HorizontalScrollView(context)
        clickedFolder = null
        helper = DirectoryBreadcrumbHelper(
            breadcrumbBar = breadcrumbBar,
            breadcrumbScroll = breadcrumbScroll,
            textPrimary = R.color.text_primary,
            textSecondary = R.color.text_secondary,
            onFolderClick = { clickedFolder = it }
        )
    }

    // Separator (">") views are TextViews too, so filtering by type alone isn't enough -
    // only the actual folder-label TextViews are set clickable in DirectoryBreadcrumbHelper's
    // render(); separators are left at their default (non-clickable). Filtering on that is
    // what distinguishes the two without relying on child position/count.
    private fun labelTextViews(): List<TextView> =
        (0 until breadcrumbBar.childCount)
            .mapNotNull { breadcrumbBar.getChildAt(it) as? TextView }
            .filter { it.isClickable }

    @Test
    fun `render with one part shows only that part, no separator, bold`() {
        val root = File("/storage/emulated/0")
        helper.render(listOf(DirectoryBrowserHelper.BreadcrumbPart("ภายในเครื่อง", root)))

        assertEquals(1, breadcrumbBar.childCount)
        val label = breadcrumbBar.getChildAt(0) as TextView
        assertEquals("ภายในเครื่อง", label.text)
        assertEquals(Typeface.DEFAULT_BOLD, label.typeface)
    }

    @Test
    fun `render with three parts adds separators between each and bolds only the last`() {
        val root = File("/storage/emulated/0")
        val downloads = File(root, "Download")
        val sub = File(downloads, "sub")
        helper.render(
            listOf(
                DirectoryBrowserHelper.BreadcrumbPart("ภายในเครื่อง", root),
                DirectoryBrowserHelper.BreadcrumbPart("Download", downloads),
                DirectoryBrowserHelper.BreadcrumbPart("sub", sub)
            )
        )

        // 3 labels + 2 ">" separators in between = 5 children total.
        assertEquals(5, breadcrumbBar.childCount)

        val labels = labelTextViews()
        assertEquals(3, labels.size)
        assertEquals("ภายในเครื่อง", labels[0].text)
        assertEquals("Download", labels[1].text)
        assertEquals("sub", labels[2].text)

        // Only the last part (the current directory) is bold; earlier ones are not.
        assertFalse(labels[0].typeface == Typeface.DEFAULT_BOLD)
        assertFalse(labels[1].typeface == Typeface.DEFAULT_BOLD)
        assertEquals(Typeface.DEFAULT_BOLD, labels[2].typeface)
    }

    @Test
    fun `render sets a Thai content description naming the folder`() {
        val root = File("/storage/emulated/0")
        helper.render(listOf(DirectoryBrowserHelper.BreadcrumbPart("ภายในเครื่อง", root)))

        val label = breadcrumbBar.getChildAt(0) as TextView
        assertEquals("ไปที่โฟลเดอร์ ภายในเครื่อง", label.contentDescription)
    }

    @Test
    fun `clicking a breadcrumb label invokes onFolderClick with that part's folder`() {
        val root = File("/storage/emulated/0")
        val downloads = File(root, "Download")
        helper.render(
            listOf(
                DirectoryBrowserHelper.BreadcrumbPart("ภายในเครื่อง", root),
                DirectoryBrowserHelper.BreadcrumbPart("Download", downloads)
            )
        )

        val labels = labelTextViews()
        labels[0].performClick()
        assertEquals(root, clickedFolder)

        labels[1].performClick()
        assertEquals(downloads, clickedFolder)
    }

    @Test
    fun `render clears any previously rendered breadcrumb before adding new parts`() {
        val root = File("/storage/emulated/0")
        helper.render(
            listOf(
                DirectoryBrowserHelper.BreadcrumbPart("ก", root),
                DirectoryBrowserHelper.BreadcrumbPart("ข", File(root, "b")),
                DirectoryBrowserHelper.BreadcrumbPart("ค", File(root, "b/c"))
            )
        )
        assertEquals(5, breadcrumbBar.childCount) // 3 labels + 2 separators

        helper.render(listOf(DirectoryBrowserHelper.BreadcrumbPart("ก", root)))
        assertEquals(1, breadcrumbBar.childCount) // old children gone, only the new one left
    }

    @Test
    fun `showSpecialPath replaces breadcrumb with a single bold label`() {
        val root = File("/storage/emulated/0")
        helper.render(
            listOf(
                DirectoryBrowserHelper.BreadcrumbPart("ก", root),
                DirectoryBrowserHelper.BreadcrumbPart("ข", File(root, "b"))
            )
        )

        helper.showSpecialPath("ถังขยะ")

        assertEquals(1, breadcrumbBar.childCount)
        val label = breadcrumbBar.getChildAt(0) as TextView
        assertEquals("ถังขยะ", label.text)
        assertEquals(Typeface.DEFAULT_BOLD, label.typeface)
    }

    @Test
    fun `render does not crash while posting the scroll-to-end call`() {
        // scrollToEnd() posts fullScroll() to the view's message queue. Not asserting on the
        // resulting scroll position/API here (Robolectric's HorizontalScrollView has no real
        // measured width to scroll against in this bare setup, and I'm not confident enough
        // in a specific Shadow API for this without being able to run it) - this only proves
        // render()+the posted Runnable complete without throwing once the looper is flushed.
        val root = File("/storage/emulated/0")
        helper.render(listOf(DirectoryBrowserHelper.BreadcrumbPart("ก", root)))
        ShadowLooper.idleMainLooper()
    }
}
