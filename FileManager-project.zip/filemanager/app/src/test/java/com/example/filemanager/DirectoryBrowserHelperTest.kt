package com.example.filemanager

import com.example.filemanager.ui.directory.DirectoryBrowserHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Tests for DirectoryBrowserHelper.kt - pure directory-listing/breadcrumb/sort logic with no
 * Activity/ViewModel dependency, same style as DirectoryNavigationHelperTest.kt: Robolectric is
 * only needed because a couple of methods call the Android framework's
 * Environment.getExternalStorageDirectory().
 *
 * canAccess()/load()'s Shizuku fallback path is not separately exercised - under Robolectric,
 * ShizukuManager.hasPermission() always resolves to false (no real Shizuku binder is available
 * in this environment, same reasoning FileOpenHelperTest.kt/DirectoryBrowserHelperTest's sibling
 * files already rely on for isAvailable()/checkSelfPermission() paths), so listFilesCompat()/
 * needsShizuku() always fall through to the plain java.io.File behavior exercised below.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DirectoryBrowserHelperTest {

    private lateinit var helper: DirectoryBrowserHelper
    private lateinit var root: File

    @Before
    fun setUp() {
        helper = DirectoryBrowserHelper()
        root = android.os.Environment.getExternalStorageDirectory()
        root.listFiles()?.forEach { it.deleteRecursively() }
    }

    // ---- canAccess() ----

    @Test
    fun `canAccess is true for an existing readable directory`() {
        assertTrue(helper.canAccess(root))
    }

    @Test
    fun `canAccess is false for a directory that does not exist and has no Shizuku fallback`() {
        val missing = File(root, "does-not-exist")
        assertFalse(helper.canAccess(missing))
    }

    // ---- comparator() ----

    @Test
    fun `comparator always sorts directories before files regardless of field`() {
        val fileEntry = FileEntry(File(root, "b.txt").apply { writeText("x") })

        val comparator = helper.comparator(MainActivity.SortKey.NAME, ascending = true)

        // "a-dir" would sort before "b.txt" alphabetically anyway, so use a name that would
        // normally sort AFTER the file to prove the folders-first rule, not just name order.
        val laterNamedDir = FileEntry(File(root, "z-dir").apply { mkdirs() })
        val sorted = listOf(fileEntry, laterNamedDir).sortedWith(comparator)

        assertEquals(laterNamedDir, sorted[0])
        assertEquals(fileEntry, sorted[1])
    }

    @Test
    fun `comparator by NAME respects ascending and descending`() {
        val a = FileEntry(File(root, "a.txt").apply { writeText("x") })
        val b = FileEntry(File(root, "b.txt").apply { writeText("x") })

        val ascending = listOf(b, a).sortedWith(helper.comparator(MainActivity.SortKey.NAME, true))
        assertEquals(listOf(a, b), ascending)

        val descending = listOf(a, b).sortedWith(helper.comparator(MainActivity.SortKey.NAME, false))
        assertEquals(listOf(b, a), descending)
    }

    @Test
    fun `comparator by SIZE treats directories as size 0 and sorts files by real length`() {
        val small = FileEntry(File(root, "small.txt").apply { writeText("x") })
        val big = FileEntry(File(root, "big.txt").apply { writeText("x".repeat(50)) })

        val ascending = listOf(big, small).sortedWith(helper.comparator(MainActivity.SortKey.SIZE, true))
        assertEquals(listOf(small, big), ascending)
    }

    @Test
    fun `comparator by DATE respects ascending and descending`() {
        val older = File(root, "older.txt").apply { writeText("x"); setLastModified(1_000_000) }
        val newer = File(root, "newer.txt").apply { writeText("x"); setLastModified(2_000_000) }

        val ascending = listOf(FileEntry(newer), FileEntry(older))
            .sortedWith(helper.comparator(MainActivity.SortKey.DATE, true))
        assertEquals(listOf(FileEntry(older), FileEntry(newer)), ascending)

        val descending = listOf(FileEntry(older), FileEntry(newer))
            .sortedWith(helper.comparator(MainActivity.SortKey.DATE, false))
        assertEquals(listOf(FileEntry(newer), FileEntry(older)), descending)
    }

    // ---- buildEntries() ----

    @Test
    fun `buildEntries hides dotfiles unless showHidden is true`() {
        val visible = File(root, "visible.txt").apply { writeText("x") }
        val hidden = File(root, ".hidden.txt").apply { writeText("x") }
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val withoutHidden = helper.buildEntries(listOf(visible, hidden), isRoot = false, showHidden = false, comparator = comparator)
        assertEquals(listOf(visible), withoutHidden.map { it.file })

        val withHidden = helper.buildEntries(listOf(visible, hidden), isRoot = false, showHidden = true, comparator = comparator)
        assertEquals(setOf(visible, hidden), withHidden.map { it.file }.toSet())
    }

    @Test
    fun `buildEntries hides the trash folder only at the storage root`() {
        val trash = File(root, TrashManager.TRASH_FOLDER_NAME).apply { mkdirs() }
        val other = File(root, "normal").apply { mkdirs() }
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val atRoot = helper.buildEntries(listOf(trash, other), isRoot = true, showHidden = true, comparator = comparator)
        assertEquals(listOf(other), atRoot.map { it.file })

        val notAtRoot = helper.buildEntries(listOf(trash, other), isRoot = false, showHidden = true, comparator = comparator)
        assertEquals(setOf(trash, other), notAtRoot.map { it.file }.toSet())
    }

    // ---- load() ----

    @Test
    fun `load lists real children of a real directory using the given comparator`() {
        File(root, "b.txt").writeText("x")
        File(root, "a.txt").writeText("x")
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val result = helper.load(root, showHidden = false, comparator = comparator)

        assertEquals(root, result.directory)
        assertEquals(listOf("a.txt", "b.txt"), result.entries.map { it.file.name })
    }

    @Test
    fun `load excludes the trash folder at the storage root`() {
        File(root, TrashManager.TRASH_FOLDER_NAME).mkdirs()
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val result = helper.load(root, showHidden = true, comparator = comparator)

        assertTrue(result.entries.none { it.file.name == TrashManager.TRASH_FOLDER_NAME })
    }

    @Test
    fun `load returns an empty result for a directory that cannot be listed`() {
        val missing = File(root, "does-not-exist")
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val result = helper.load(missing, showHidden = false, comparator = comparator)

        assertTrue(result.entries.isEmpty())
    }

    // ---- breadcrumbParts() ----

    @Test
    fun `breadcrumbParts at the storage root returns a single root label part`() {
        val parts = helper.breadcrumbParts(root)

        assertEquals(1, parts.size)
        assertEquals(root.canonicalFile, parts[0].folder)
    }

    @Test
    fun `breadcrumbParts for a nested directory includes root then each path segment`() {
        val sub = File(root, "Download/sub").apply { mkdirs() }

        val parts = helper.breadcrumbParts(sub)

        assertEquals(3, parts.size)
        assertEquals(root.canonicalFile, parts[0].folder)
        assertEquals("Download", parts[1].label)
        assertEquals(File(root, "Download").canonicalFile, parts[1].folder)
        assertEquals("sub", parts[2].label)
        assertEquals(sub.canonicalFile, parts[2].folder)
    }

    @Test
    fun `breadcrumbParts for a directory outside storage root returns a single self-labeled part`() {
        val outside = File("/data/local/tmp/outside")

        val parts = helper.breadcrumbParts(outside)

        assertEquals(1, parts.size)
        assertEquals("outside", parts[0].label)
    }

    // ---- subfolders() ----

    @Test
    fun `subfolders returns only visible directories, sorted, not files`() {
        File(root, "b-dir").mkdirs()
        File(root, "a-dir").mkdirs()
        File(root, "a-file.txt").writeText("x")
        val comparator = helper.comparator(MainActivity.SortKey.NAME, true)

        val result = helper.subfolders(root, comparator)

        assertEquals(listOf("a-dir", "b-dir"), result.map { it.name })
    }
}
