package com.example.filemanager

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 17 / Task 3: unit tests for DirectoryHistoryHelper's DataStore+JSON-backed logic
 * (recent-folder history and open-window persistence). Robolectric provides a real
 * Context (with a real filesDir) on the JVM, which is all DataStore needs to round-trip
 * correctly here, without needing a device/emulator. Only the public API is exercised,
 * so these tests are unchanged by the SharedPreferences -> DataStore migration.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DirectoryHistoryHelperTest {

    private lateinit var helper: DirectoryHistoryHelper
    private lateinit var dirA: File
    private lateinit var dirB: File

    @Before
    fun setUp() {
        val context = RuntimeEnvironment.getApplication()
        helper = DirectoryHistoryHelper(context)
        // Use real, existing directories so isDirectory/canRead checks pass like on device.
        dirA = context.cacheDir
        dirB = context.filesDir
    }

    @Test
    fun `rememberRecentFolder then loadRecentFolders returns it`() = runBlocking {
        helper.rememberRecentFolder(dirA, isTrashMode = false)
        val loaded = helper.loadRecentFolders()
        assertTrue(loaded.any { it.absolutePath == dirA.absolutePath })
    }

    @Test
    fun `rememberRecentFolder ignores trash mode`() = runBlocking {
        helper.rememberRecentFolder(dirA, isTrashMode = true)
        val loaded = helper.loadRecentFolders()
        assertTrue(loaded.isEmpty())
    }

    @Test
    fun `rememberRecentFolder moves repeated folder to the front without duplicating`() = runBlocking {
        helper.rememberRecentFolder(dirA, isTrashMode = false)
        helper.rememberRecentFolder(dirB, isTrashMode = false)
        helper.rememberRecentFolder(dirA, isTrashMode = false)

        val loaded = helper.loadRecentFolders()
        assertEquals(dirA.absolutePath, loaded.first().absolutePath)
        // dirA should appear exactly once even though it was remembered twice.
        assertEquals(1, loaded.count { it.absolutePath == dirA.absolutePath })
    }

    @Test
    fun `clearRecentHistory empties recent folders`() = runBlocking {
        helper.rememberRecentFolder(dirA, isTrashMode = false)
        helper.clearRecentHistory()
        assertTrue(helper.loadRecentFolders().isEmpty())
    }

    @Test
    fun `saveOpenWindows then loadOpenWindows round-trips paths`() = runBlocking {
        val paths = listOf(dirA.absolutePath, dirB.absolutePath)
        helper.saveOpenWindows(paths)
        val loaded = helper.loadOpenWindows()
        assertEquals(paths, loaded)
    }

    @Test
    fun `saveOpenWindows caps at 12 entries`() = runBlocking {
        val many = (1..20).map { File(dirA, "sub$it").apply { mkdirs() }.absolutePath }
        helper.saveOpenWindows(many)
        assertEquals(12, helper.loadOpenWindows().size)
    }

    @Test
    fun `rememberOpenWindow adds new path to front and dedupes existing`() = runBlocking {
        val updated1 = helper.rememberOpenWindow(dirA, emptyList())
        assertEquals(listOf(dirA.canonicalPath), updated1)

        val updated2 = helper.rememberOpenWindow(dirB, updated1)
        assertEquals(listOf(dirB.canonicalPath, dirA.canonicalPath), updated2)

        // Re-opening dirA should move it back to the front, not duplicate it.
        val updated3 = helper.rememberOpenWindow(dirA, updated2)
        assertEquals(listOf(dirA.canonicalPath, dirB.canonicalPath), updated3)
        assertFalse(updated3.size > 2)
    }
}
