package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Tests for DirectoryNavigationHelper.kt - the pure back-navigation/root-boundary rules
 * used by the normal directory browser.
 *
 * Robolectric is needed only because externalStorageRoot() calls the Android framework's
 * Environment.getExternalStorageDirectory() - the class itself holds no Activity/ViewModel
 * state, so no MainActivity/Robolectric.buildActivity() setup is needed here, unlike
 * SettingsHelperTest.kt or MainActivityRotationTest.kt.
 *
 * Not covered: normalize()'s catch-and-fall-back-to-absoluteFile() branch. Triggering
 * canonicalFile() to actually throw needs a filesystem edge case (e.g. a null byte in the
 * path) whose behavior isn't reliably known without running it in this project's actual CI
 * JVM/OS - recorded honestly as untested rather than guessed at with an assertion that
 * might be flaky.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DirectoryNavigationHelperTest {

    private lateinit var helper: DirectoryNavigationHelper
    private lateinit var root: File
    private lateinit var subDir: File
    private lateinit var nestedDir: File

    @Before
    fun setUp() {
        helper = DirectoryNavigationHelper()
        root = android.os.Environment.getExternalStorageDirectory()
        root.listFiles()?.forEach { it.deleteRecursively() }
        subDir = File(root, "sub").apply { mkdirs() }
        nestedDir = File(subDir, "nested").apply { mkdirs() }
    }

    @Test
    fun `externalStorageRoot returns the canonical external storage directory`() {
        assertEquals(root.canonicalFile, helper.externalStorageRoot())
    }

    @Test
    fun `normalize returns the canonical form of a real directory`() {
        // subDir's non-canonical form (with a redundant ".." segment) should still resolve
        // to the same canonical directory.
        val withRedundantSegment = File(subDir, "../sub")
        assertEquals(subDir.canonicalFile, helper.normalize(withRedundantSegment))
    }

    @Test
    fun `isExternalStorageRoot is true at the storage root`() {
        assertTrue(helper.isExternalStorageRoot(root))
    }

    @Test
    fun `isExternalStorageRoot is false for a subdirectory`() {
        assertFalse(helper.isExternalStorageRoot(subDir))
    }

    @Test
    fun `parentForBackNavigation returns null at the storage root`() {
        assertNull(helper.parentForBackNavigation(root))
    }

    @Test
    fun `parentForBackNavigation returns the parent directory for a subdirectory`() {
        assertEquals(root.canonicalFile, helper.parentForBackNavigation(subDir))
    }

    @Test
    fun `parentForBackNavigation walks up correctly from a nested directory`() {
        assertEquals(subDir.canonicalFile, helper.parentForBackNavigation(nestedDir))
    }
}
