package com.example.filemanager

import android.view.View
import androidx.lifecycle.ViewModelProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowToast
import java.io.File

/**
 * Round 2 (see KORN-Next-Steps-Handoff.txt): first dedicated test file for
 * DirectoryStateObserver.kt. Goes through a real MainActivity/MainViewModel pair via
 * Robolectric (same setup as MainActivityRotationTest.kt) instead of testing the collector
 * logic in isolation, since observeDirectoryState() reaches directly into several Activity
 * fields (adapter, trashActionBar, supportActionBar, swipeRefresh) per its own class doc - a
 * fake/mocked Activity would just be re-describing that wiring instead of verifying it.
 *
 * Not yet confirmed GREEN on real CI (no gradlew/Android SDK in this sandbox, same limitation
 * as every previous round - see KORN-Handoff-Status.txt). One thing specifically worth
 * flagging: the FileOpDone test below is the first attempt in this project at asserting on a
 * MainViewModel.UiEvent emitted through viewModelScope.launch { _events.emit(...) } - see
 * MainViewModelTest.kt's own note admitting this was previously left untested because it
 * needs either kotlinx-coroutines-test or an idled Robolectric main looper. This file goes
 * with the latter (shadowOf(Looper.getMainLooper()).idle()), since it already has a real
 * Activity/Looper on hand and the project doesn't have kotlinx-coroutines-test wired up yet.
 * If that turns out not to be enough to make the emit land synchronously, that test - not the
 * two guard tests above it - is the one to look at first.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class DirectoryStateObserverTest {

    private lateinit var externalRoot: File

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        File(externalRoot, "a.txt").writeText("x")
        File(externalRoot, "b.txt").writeText("x")
    }

    @After
    fun tearDown() {
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun viewModelOf(activity: MainActivity): MainViewModel =
        ViewModelProvider(activity)[MainViewModel::class.java]

    // Same race documented in MainActivityRotationTest.kt: onCreate() kicks off the first
    // loadDirectory() on Dispatchers.IO, a real background thread Robolectric's paused main
    // looper doesn't control - settle it first so every test starts from a clean state.
    private fun awaitInitialLoadSettled(vm: MainViewModel) {
        val deadline = System.currentTimeMillis() + 2000
        while (vm.directoryState.value.isLoading && System.currentTimeMillis() < deadline) {
            Thread.sleep(10)
        }
    }

    private fun idleMainLooper() {
        shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    @Test
    fun `stale directoryState replay does not overwrite a non-NORMAL mode view`() {
        // Regression test for the guard documented at the top of observeDirectoryState():
        // directoryState is a StateFlow, so any *new* collector - including the one a real
        // Activity recreate() would start via repeatOnLifecycle(STARTED) re-entering - replays
        // whatever NORMAL-mode listing was last loaded, even while the user has since
        // navigated to trash/category/search/apps (none of which update directoryState
        // itself). Exercised here by attaching a second collector directly via
        // observeDirectoryState() rather than a full recreate(), so the assertion isn't
        // racing loadTrash()'s own unawaited Dispatchers.IO work (see MainActivityRotationTest
        // .kt's existing note on that same gap) - a plain second subscription reproduces
        // exactly the "stale replay to a fresh collector" shape without that extra noise.
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        val vm = viewModelOf(activity)
        awaitInitialLoadSettled(vm)

        // directoryState.value now holds the NORMAL-mode listing (a.txt, b.txt) from the
        // initial load above, and is left untouched for the rest of this test - standing in
        // for the "stale" state a real trash/category/search visit would leave behind.
        vm.setMode(MainActivity.Mode.TRASH)

        val sentinel = FileEntry(File(externalRoot, "deleted.txt"), displayName = "deleted.txt")
        activity.adapter.updateItems(listOf(sentinel), showFullPath = true)
        activity.updateActionBars()
        activity.supportActionBar?.subtitle = "1 รายการในถังขยะ"

        assertEquals(View.VISIBLE, activity.trashActionBar.visibility)
        assertEquals(1, activity.adapter.itemCount)

        // A second collector on the same Activity instance receives an immediate replay of
        // directoryState's cached (stale, NORMAL-mode) value - the same shape of event a
        // recreate()'s fresh repeatOnLifecycle(STARTED) collector would receive.
        activity.observeDirectoryState()
        idleMainLooper()

        assertEquals(MainActivity.Mode.TRASH, vm.mode.value)
        assertEquals(
            "stale directoryState replay must not repopulate the adapter while in TRASH mode",
            1, activity.adapter.itemCount
        )
        assertEquals(
            "stale directoryState replay must not force trashActionBar back to GONE",
            View.VISIBLE, activity.trashActionBar.visibility
        )
        assertEquals(
            "stale directoryState replay must not overwrite the trash subtitle",
            "1 รายการในถังขยะ", activity.supportActionBar?.subtitle
        )
    }

    @Test
    fun `directoryState updates still apply normally in NORMAL mode`() {
        // Baseline/non-regression counterpart to the test above: confirms the guard is scoped
        // to "not NORMAL" specifically, rather than accidentally swallowing every replay.
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        val vm = viewModelOf(activity)
        awaitInitialLoadSettled(vm)

        assertEquals(MainActivity.Mode.NORMAL, vm.mode.value)
        assertEquals(2, activity.adapter.itemCount)
        assertEquals("2 รายการ", activity.supportActionBar?.subtitle)
    }

    @Test
    fun `FileOpDone with no failures shows a toast and exits selection mode without crashing`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        val vm = viewModelOf(activity)
        awaitInitialLoadSettled(vm)

        activity.adapter.setSelectionMode(true)
        assertTrue(activity.adapter.selectionMode)

        vm.setFileOpDone(doneCount = 2, totalCount = 2, failures = emptyList())
        idleMainLooper()
        awaitInitialLoadSettled(vm) // FileOpDone's success path re-triggers loadDirectory()

        assertFalse(
            "FileOpDone should exit selection mode once the background operation finishes",
            activity.adapter.selectionMode
        )
        assertEquals("เสร็จสิ้น 2/2 รายการ", ShadowToast.getTextOfLatestToast())
    }
}
