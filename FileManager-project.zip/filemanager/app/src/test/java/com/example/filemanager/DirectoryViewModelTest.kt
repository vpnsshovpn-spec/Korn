package com.example.filemanager

import android.os.Environment
import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): unit tests for
 * DirectoryViewModel, moved out of MainViewModelTest.kt together with the state itself
 * (originally Round 14's settings/display tests and Round 16's navigation/directory tests).
 * Same two things checked for each StateFlow as before the split: (1) it starts with the
 * expected default value, and (2) its setter function actually updates `.value`.
 *
 * Robolectric is used because currentDir/lastNormalDir's defaults call
 * android.os.Environment.getExternalStorageDirectory(), a real Android framework method
 * that isn't available on a plain JVM unit test.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DirectoryViewModelTest {

    private lateinit var viewModel: DirectoryViewModel

    @Before
    fun setUp() {
        viewModel = DirectoryViewModel(SavedStateHandle())
    }

    // ---- Round 14: settings/display state ----

    @Test
    fun `showHidden defaults to false and can be updated`() {
        assertFalse(viewModel.showHidden.value)
        viewModel.setShowHidden(true)
        assertTrue(viewModel.showHidden.value)
    }

    @Test
    fun `sortKey defaults to NAME and can be updated`() {
        assertEquals(MainActivity.SortKey.NAME, viewModel.sortKey.value)
        viewModel.setSortKey(MainActivity.SortKey.DATE)
        assertEquals(MainActivity.SortKey.DATE, viewModel.sortKey.value)
    }

    @Test
    fun `sortAscending defaults to true and can be updated`() {
        assertTrue(viewModel.sortAscending.value)
        viewModel.setSortAscending(false)
        assertFalse(viewModel.sortAscending.value)
    }

    @Test
    fun `isGridMode defaults to false and can be updated`() {
        assertFalse(viewModel.isGridMode.value)
        viewModel.setIsGridMode(true)
        assertTrue(viewModel.isGridMode.value)
    }

    @Test
    fun `fileViewMode defaults to LIST and can be updated`() {
        assertEquals(FileAdapter.ViewMode.LIST, viewModel.fileViewMode.value)
        viewModel.setFileViewMode(FileAdapter.ViewMode.GRID)
        assertEquals(FileAdapter.ViewMode.GRID, viewModel.fileViewMode.value)
    }

    // ---- Round 16: navigation/directory state ----

    @Test
    fun `currentDir and lastNormalDir default to external storage directory`() {
        val expected = Environment.getExternalStorageDirectory()
        assertEquals(expected, viewModel.currentDir.value)
        assertEquals(expected, viewModel.lastNormalDir.value)
    }

    @Test
    fun `currentDir can be updated independently of lastNormalDir`() {
        val newDir = File("/sdcard/Download")
        viewModel.setCurrentDir(newDir)
        assertEquals(newDir, viewModel.currentDir.value)
        // lastNormalDir should be untouched by a currentDir-only update.
        assertEquals(Environment.getExternalStorageDirectory(), viewModel.lastNormalDir.value)
    }

    @Test
    fun `lastNormalDir can be updated`() {
        val newDir = File("/sdcard/Pictures")
        viewModel.setLastNormalDir(newDir)
        assertEquals(newDir, viewModel.lastNormalDir.value)
    }

    @Test
    fun `mode defaults to NORMAL and can be updated`() {
        assertEquals(MainActivity.Mode.NORMAL, viewModel.mode.value)
        viewModel.setMode(MainActivity.Mode.TRASH)
        assertEquals(MainActivity.Mode.TRASH, viewModel.mode.value)
        viewModel.setMode(MainActivity.Mode.APPS)
        assertEquals(MainActivity.Mode.APPS, viewModel.mode.value)
    }

    @Test
    fun `category label and extensions default to null and can be updated together`() {
        assertNull(viewModel.currentCategoryLabel.value)
        assertNull(viewModel.currentCategoryExts.value)

        viewModel.setCurrentCategoryLabel("รูปภาพ")
        viewModel.setCurrentCategoryExts(setOf("jpg", "png"))

        assertEquals("รูปภาพ", viewModel.currentCategoryLabel.value)
        assertEquals(setOf("jpg", "png"), viewModel.currentCategoryExts.value)
    }

    @Test
    fun `category label and extensions can be cleared back to null`() {
        viewModel.setCurrentCategoryLabel("วิดีโอ")
        viewModel.setCurrentCategoryExts(setOf("mp4"))

        viewModel.setCurrentCategoryLabel(null)
        viewModel.setCurrentCategoryExts(null)

        assertNull(viewModel.currentCategoryLabel.value)
        assertNull(viewModel.currentCategoryExts.value)
    }

    // ---- Round 17 / Task 1: directory listing data flow ----

    @Test
    fun `directoryState defaults to loading with external storage directory`() {
        val state = viewModel.directoryState.value
        assertTrue(state.isLoading)
        assertEquals(Environment.getExternalStorageDirectory(), state.currentDir)
        assertTrue(state.entries.isEmpty())
    }
}
