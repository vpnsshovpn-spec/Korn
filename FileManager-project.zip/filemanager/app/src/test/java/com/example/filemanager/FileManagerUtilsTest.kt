package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * Round 17: unit tests for the pure, stateless helpers in FileManagerUtils.kt.
 * These don't touch Activity or Context, so they run as plain JVM tests
 * (no Robolectric needed).
 */
class FileManagerUtilsTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    // ---- readableSize ----

    @Test
    fun `readableSize formats zero and negative as 0 B`() {
        assertEquals("0 B", readableSize(0))
        assertEquals("0 B", readableSize(-5))
    }

    @Test
    fun `readableSize stays in bytes below 1024`() {
        assertEquals("512 B", readableSize(512))
    }

    @Test
    fun `readableSize converts to KB and MB correctly`() {
        assertEquals("1 KB", readableSize(1024))
        assertEquals("1 MB", readableSize(1024L * 1024))
        assertEquals("1 GB", readableSize(1024L * 1024 * 1024))
    }

    @Test
    fun `readableSize rounds to one decimal place`() {
        // 1536 bytes = 1.5 KB exactly
        assertEquals("1.5 KB", readableSize(1536))
    }

    // ---- formatDateTime ----

    @Test
    fun `formatDateTime does not crash and returns non-blank text`() {
        val result = formatDateTime(System.currentTimeMillis())
        assertNotEquals("", result.trim())
    }

    // ---- uniqueName ----

    @Test
    fun `uniqueName returns desired name when it does not exist`() {
        val dir = tempFolder.root
        assertEquals("photo.jpg", uniqueName(dir, "photo.jpg"))
    }

    @Test
    fun `uniqueName appends counter when file already exists`() {
        val dir = tempFolder.root
        File(dir, "photo.jpg").createNewFile()
        assertEquals("photo (1).jpg", uniqueName(dir, "photo.jpg"))
    }

    @Test
    fun `uniqueName keeps incrementing counter past existing copies`() {
        val dir = tempFolder.root
        File(dir, "photo.jpg").createNewFile()
        File(dir, "photo (1).jpg").createNewFile()
        File(dir, "photo (2).jpg").createNewFile()
        assertEquals("photo (3).jpg", uniqueName(dir, "photo.jpg"))
    }

    @Test
    fun `uniqueName handles directory names without an extension`() {
        val dir = tempFolder.root
        File(dir, "New folder").mkdir()
        assertEquals("New folder (1)", uniqueName(dir, "New folder", isDir = true))
    }

    @Test
    fun `uniqueName treats a name with no extension correctly when not a directory`() {
        val dir = tempFolder.root
        File(dir, "README").createNewFile()
        assertEquals("README (1)", uniqueName(dir, "README"))
    }
}
