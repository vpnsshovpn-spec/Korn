package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowToast
import java.io.File

/**
 * Tests for FileOpenHelper.kt - only resolveForOpen()'s two synchronous branches are
 * covered.
 *
 * Not covered (recorded honestly):
 * - openFile()/openFileInternally()/openFileExternally(): build dialogs (KornDialog) or
 *   start real Activities/Intents (ImageViewerActivity, TextEditActivity,
 *   Intent.createChooser) - no established pattern for asserting on either in this
 *   project's tests yet.
 * - resolveForOpen()'s Shizuku-download branch (file.needsShizuku() == true): would need a
 *   real/faked Shizuku service connection, which this project's tests don't set up
 *   anywhere.
 * - rememberRecentFile()'s success path (writes to AppDataStore via
 *   lifecycleScope.launch(Dispatchers.IO), a real background coroutine not under test
 *   control) - only its early-return guard (non-file input) is exercised below, since that
 *   returns synchronously before the coroutine is ever launched.
 *
 * ShizukuManager.hasPermission() reliably returns false under Robolectric (isAvailable()
 * calls Shizuku.pingBinder(), which throws with no real Shizuku binder present and is
 * caught -> false), so an unreadable file with no Shizuku deterministically hits the
 * "เปิดไฟล์ไม่ได้" toast branch below rather than the Shizuku-download branch.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class FileOpenHelperTest {

    private lateinit var externalRoot: File
    private lateinit var activity: MainActivity

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }

    @Test
    fun `resolveForOpen calls action directly with the original file when it is readable`() {
        val file = File(externalRoot, "note.txt").apply { writeText("hi") }

        var resolvedFile: File? = null
        var syncBackTo: File? = null
        var actionCalled = false
        activity.resolveForOpen(file) { resolved, sync ->
            actionCalled = true
            resolvedFile = resolved
            syncBackTo = sync
        }

        assert(actionCalled)
        assertEquals(file, resolvedFile)
        assertNull(syncBackTo)
    }

    @Test
    fun `resolveForOpen shows a toast and does not call action when the file cannot be read and Shizuku is unavailable`() {
        val missingFile = File(externalRoot, "does_not_exist.txt")

        var actionCalled = false
        activity.resolveForOpen(missingFile) { _, _ -> actionCalled = true }

        assertEquals("เปิดไฟล์ไม่ได้", ShadowToast.getTextOfLatestToast())
        assert(!actionCalled)
    }

    @Test
    fun `rememberRecentFile does nothing and does not crash for a directory (non-file) input`() {
        val dir = File(externalRoot, "a_folder").apply { mkdirs() }
        // isFile is false for a directory, so the guard clause returns before the
        // coroutine that would touch AppDataStore is ever launched - safe to assert
        // synchronously with no need to await a background coroutine.
        activity.rememberRecentFile(dir)
    }
}
