package com.example.filemanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.rules.TemporaryFolder
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Unit tests for FileOperationService's copy/move logic and the search-index-diff
 * payload (indexAdds/indexMoves/indexRemovals/indexNeedsFullSync) it broadcasts on
 * FILE_OP_DONE - which DirectoryStateObserver.kt consumes to do incremental search
 * index updates instead of a full rebuild for every background copy/move.
 *
 * NEW TEST TERRITORY for this project: no earlier test drives a real Service via
 * Robolectric, or captures a sendBroadcast() payload with a registered receiver.
 * I could not run this against a real Gradle/Robolectric environment before
 * handing it over (no network access here) - the prior round already showed manual
 * code review missing a real bug, so treat first-run CI results on this file with
 * the same scrutiny, not as a rubber stamp.
 *
 * runOperation() was widened from private to internal (production behavior/signature
 * unchanged) so it can be called directly and synchronously here, without needing
 * coroutines or the full startForegroundService()/onStartCommand() path. Only local
 * java.io file paths are exercised - no Shizuku, matching the same JVM-environment
 * constraint FileOpsCompatTest.kt documents (ShizukuManager.hasPermission() always
 * returns false on a plain JVM test, so the Shizuku fallback branch is never hit here).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FileOperationServiceIndexBroadcastTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun newService(): FileOperationService =
        Robolectric.buildService(FileOperationService::class.java).create().get()

    /** Registers a receiver for FILE_OP_DONE, runs [block], and returns the broadcast intent. */
    private fun captureDoneBroadcast(block: () -> Unit): Intent {
        val context = ApplicationProvider.getApplicationContext<Context>()
        var captured: Intent? = null
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                captured = intent
            }
        }
        context.registerReceiver(receiver, IntentFilter(FileOperationService.BROADCAST_DONE), Context.RECEIVER_NOT_EXPORTED)
        try {
            block()
        } finally {
            context.unregisterReceiver(receiver)
        }
        return captured ?: error("FILE_OP_DONE was never broadcast")
    }

    @Test
    fun `copying a single file reports it as an indexAdds entry, not a move`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = tempFolder.newFolder("dest")
        val file = File(srcDir, "a.txt").apply { writeText("hello") }

        val result = captureDoneBroadcast {
            service.runOperation(listOf(file), destDir, move = false)
        }

        assertEquals(1, result.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, -1))
        assertEquals(
            listOf(File(destDir, "a.txt").absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS)
        )
        assertTrue(result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_MOVES).isNullOrEmpty())
        assertTrue(result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_REMOVALS).isNullOrEmpty())
        assertFalse(result.getBooleanExtra(FileOperationService.EXTRA_INDEX_NEEDS_FULL_SYNC, true))
        assertTrue(File(destDir, "a.txt").exists())
        assertTrue("copy must leave the source file in place", file.exists())
    }

    @Test
    fun `moving a single file within the same volume reports an indexMoves entry`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = tempFolder.newFolder("dest")
        val file = File(srcDir, "a.txt").apply { writeText("hello") }
        val expectedDest = File(destDir, "a.txt")

        val result = captureDoneBroadcast {
            service.runOperation(listOf(file), destDir, move = true)
        }

        assertEquals(1, result.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, -1))
        assertEquals(
            listOf(file.absolutePath + "\u0000" + expectedDest.absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_MOVES)
        )
        assertTrue(result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS).isNullOrEmpty())
        assertFalse(result.getBooleanExtra(FileOperationService.EXTRA_INDEX_NEEDS_FULL_SYNC, true))
        assertTrue(expectedDest.exists())
        assertFalse("move must remove the source", file.exists())
    }

    @Test
    fun `copying a folder recursively reports only the top-level destination as an indexAdds entry`() {
        // indexSubtree() (called on the receiving end for a directory indexAdds entry)
        // walks the whole destination folder itself, so runOperation only needs to name
        // the top-level destination - not every file inside it.
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destParent = tempFolder.newFolder("dest")
        val srcFolder = File(srcDir, "Photos").apply { mkdirs() }
        File(srcFolder, "a.jpg").writeText("x")
        val nested = File(srcFolder, "2024").apply { mkdirs() }
        File(nested, "b.jpg").writeText("x")

        val result = captureDoneBroadcast {
            service.runOperation(listOf(srcFolder), destParent, move = false)
        }

        assertEquals(
            listOf(File(destParent, "Photos").absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS)
        )
        assertTrue(File(destParent, "Photos/a.jpg").exists())
        assertTrue(File(destParent, "Photos/2024/b.jpg").exists())
    }

    @Test
    fun `an already-resolved overwrite deletes the old destination and reports both the removal and the new entry`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = tempFolder.newFolder("dest")
        val file = File(srcDir, "a.txt").apply { writeText("new content") }
        val existingDest = File(destDir, "a.txt").apply { writeText("old content") }

        val result = captureDoneBroadcast {
            service.runOperation(listOf(file), destDir, move = false, overwritePaths = setOf(file.absolutePath))
        }

        assertEquals(
            listOf(existingDest.absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_REMOVALS)
        )
        assertEquals(
            listOf(existingDest.absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS)
        )
        assertEquals("new content", existingDest.readText())
    }

    @Test
    fun `an unresolved name conflict falls back to auto-rename and reports the renamed destination`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = tempFolder.newFolder("dest")
        val file = File(srcDir, "a.txt").apply { writeText("new content") }
        File(destDir, "a.txt").writeText("old content") // pre-existing, not in overwritePaths

        val result = captureDoneBroadcast {
            service.runOperation(listOf(file), destDir, move = false) // no overwritePaths
        }

        val expectedRenamedDest = File(destDir, "a (1).txt")
        assertEquals(
            listOf(expectedRenamedDest.absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS)
        )
        assertEquals("old content", File(destDir, "a.txt").readText()) // original left untouched
        assertEquals("new content", expectedRenamedDest.readText())
    }

    @Test
    fun `multiple sources with one missing source still reports the successful ones and needs full sync for the failure`() {
        val service = newService()
        val srcDir = tempFolder.newFolder("src")
        val destDir = tempFolder.newFolder("dest")
        val goodFile = File(srcDir, "good.txt").apply { writeText("x") }
        val missingFile = File(srcDir, "missing.txt") // never created on disk

        val result = captureDoneBroadcast {
            service.runOperation(listOf(goodFile, missingFile), destDir, move = false)
        }

        assertEquals(1, result.getIntExtra(FileOperationService.EXTRA_DONE_COUNT, -1))
        assertEquals(2, result.getIntExtra(FileOperationService.EXTRA_TOTAL_COUNT, -1))
        assertEquals(
            listOf(File(destDir, "good.txt").absolutePath),
            result.getStringArrayListExtra(FileOperationService.EXTRA_INDEX_ADDS)
        )
        assertTrue(
            "a failed source must not silently claim a clean index diff",
            result.getBooleanExtra(FileOperationService.EXTRA_INDEX_NEEDS_FULL_SYNC, false)
        )
        assertFalse(result.getStringArrayListExtra(FileOperationService.EXTRA_FAILED_NAMES).isNullOrEmpty())
    }
}
