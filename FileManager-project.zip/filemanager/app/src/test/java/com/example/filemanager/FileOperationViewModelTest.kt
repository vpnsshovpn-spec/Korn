package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): unit tests for
 * FileOperationViewModel, moved out of MainViewModelTest.kt along with the state itself -
 * clipboard (Round 15), multi-select (Round A), and copy/move progress (Round B). Same two
 * things checked for each StateFlow: (1) it starts with the expected default value, and (2)
 * its setter function actually updates `.value`.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FileOperationViewModelTest {

    private lateinit var viewModel: FileOperationViewModel

    @Before
    fun setUp() {
        viewModel = FileOperationViewModel(SavedStateHandle())
    }

    // ---- Round 15: clipboard state ----

    @Test
    fun `clipboardFiles defaults to empty and can be updated`() {
        assertTrue(viewModel.clipboardFiles.value.isEmpty())
        val files = listOf(File("/sdcard/a.txt"), File("/sdcard/b.txt"))
        viewModel.setClipboardFiles(files)
        assertEquals(files, viewModel.clipboardFiles.value)
    }

    @Test
    fun `clipboardIsCut defaults to false and can be updated`() {
        assertFalse(viewModel.clipboardIsCut.value)
        viewModel.setClipboardIsCut(true)
        assertTrue(viewModel.clipboardIsCut.value)
    }

    // ---- Round A: multi-select state ----

    @Test
    fun `selectionMode and selectedPaths default to false and empty`() {
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `setSelectionState updates both selectionMode and selectedPaths together`() {
        val paths = setOf("/sdcard/a.txt", "/sdcard/b.txt")
        viewModel.setSelectionState(true, paths)
        assertTrue(viewModel.selectionMode.value)
        assertEquals(paths, viewModel.selectedPaths.value)
    }

    @Test
    fun `setSelectionState can clear selection back to defaults`() {
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt"))
        viewModel.setSelectionState(false, emptySet())
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `a fresh FileAdapter hydrates its local selection from an already-populated ViewModel`() {
        // Simulates Activity recreation (rotation): the ViewModel survives and already
        // holds a selection; a brand-new FileAdapter created against it (as MainActivity's
        // onCreate does) should pick that selection up instead of starting empty.
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt", "/sdcard/b.txt"))

        val adapter = FileAdapter(
            context = org.robolectric.RuntimeEnvironment.getApplication(),
            viewModel = viewModel,
            initialItems = emptyList(),
            onClick = {},
            onLongClick = { true },
            onStartDrag = { _, _ -> true },
            onDropOnFolder = { _, _ -> true }
        )

        assertTrue(adapter.selectionMode)
        assertEquals(2, adapter.selectionCount())
    }

    // ---- Round B: copy/move progress state ----

    @Test
    fun `fileOpState defaults to not running`() {
        assertFalse(viewModel.fileOpState.value.isRunning)
        assertEquals(0, viewModel.fileOpState.value.percent)
    }

    @Test
    fun `setFileOpProgress marks running and stores percent, counts, and direction`() {
        viewModel.setFileOpProgress(percent = 42, doneCount = 1, totalCount = 3, isMove = true)
        val state = viewModel.fileOpState.value
        assertTrue(state.isRunning)
        assertEquals(42, state.percent)
        assertEquals(1, state.doneCount)
        assertEquals(3, state.totalCount)
        assertTrue(state.isMove)
    }

    @Test
    fun `setFileOpDone resets isRunning back to false`() {
        viewModel.setFileOpProgress(percent = 50, doneCount = 1, totalCount = 2, isMove = false)
        viewModel.setFileOpDone(doneCount = 2, totalCount = 2, failures = emptyList())
        assertFalse(viewModel.fileOpState.value.isRunning)
    }

    // Note: FileOpDoneEvent itself (emitted via viewModelScope.launch { _events.emit(...) })
    // is not covered here - asserting on it would need either kotlinx-coroutines-test's
    // runTest/TestDispatcher or idling Robolectric's main looper, neither of which this
    // project has wired up yet. Only the synchronous fileOpState half of setFileOpDone()
    // (asserted above) is verified by this test file.
}
