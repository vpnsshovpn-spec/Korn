package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * FIX-7: unit tests for FileOpsCompat.
 *
 * On a JVM test there is no real Shizuku binder to connect to, so
 * ShizukuManager.hasPermission() always returns false here (it wraps the real check in a
 * try/catch and fails closed). That means every *Compat() function in this file can only be
 * exercised on its "local java.io succeeded" or "local java.io failed AND no Shizuku" branches
 * — never the "fell back to the remote Shizuku service" branch. The comment in FileOpsCompat.kt
 * states the contract this is meant to lock in: "on a device without Shizuku, behavior must be
 * identical to calling the java.io method directly." These tests verify exactly that contract.
 *
 * Robolectric (not a plain JVm test) is needed because every successful mutating call
 * (mkdirsCompat, deleteCompat, renameToCompat, copyRecursivelyCompat, createNewFileCompat)
 * calls notifyMediaScanner(), which calls MediaScannerConnection.scanFile(App.instance, ...) —
 * a real Android API. It's wrapped in try/catch so a scan failure is silently ignored, but the
 * call itself needs a real (or Robolectric-simulated) Context to not throw something the
 * try/catch doesn't expect.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FileOpsCompatTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    // ---- existsCompat ----

    @Test
    fun `existsCompat true for a real file, false for a missing one`() {
        val realFile = tempFolder.newFile("real.txt")
        assertTrue(realFile.existsCompat())

        val missing = File(tempFolder.root, "missing.txt")
        assertFalse(missing.existsCompat())
    }

    // ---- listFilesCompat ----

    @Test
    fun `listFilesCompat returns local children when the folder has some`() {
        tempFolder.newFile("a.txt")
        tempFolder.newFile("b.txt")
        val children = tempFolder.root.listFilesCompat()
        assertEquals(2, children?.size)
    }

    @Test
    fun `listFilesCompat returns empty list for an empty folder without Shizuku`() {
        val emptyDir = tempFolder.newFolder("empty")
        // local listFiles() on an empty dir returns an empty (non-null) array; without
        // Shizuku available there's nothing to double-check it against, so the contract is
        // to hand back that same empty list rather than null.
        val children = emptyDir.listFilesCompat()
        assertEquals(0, children?.size)
    }

    @Test
    fun `listFilesCompat returns null for a path that is not a directory`() {
        val plainFile = tempFolder.newFile("notadir.txt")
        assertNull(plainFile.listFilesCompat())
    }

    // ---- mkdirsCompat ----

    @Test
    fun `mkdirsCompat creates nested folders and reports success`() {
        val nested = File(tempFolder.root, "one/two/three")
        assertTrue(nested.mkdirsCompat())
        assertTrue(nested.exists())
        assertTrue(nested.isDirectory)
    }

    // ---- deleteCompat / deleteRecursivelyCompat ----

    @Test
    fun `deleteCompat removes a single file`() {
        val file = tempFolder.newFile("to-delete.txt")
        assertTrue(file.deleteCompat())
        assertFalse(file.exists())
    }

    @Test
    fun `deleteCompat on a missing file without Shizuku returns false`() {
        val missing = File(tempFolder.root, "ghost.txt")
        assertFalse(missing.deleteCompat())
    }

    @Test
    fun `deleteRecursivelyCompat removes a folder and its nested children`() {
        val dir = tempFolder.newFolder("parent")
        File(dir, "child.txt").writeText("x")
        val nestedDir = File(dir, "nested").apply { mkdirs() }
        File(nestedDir, "deep.txt").writeText("y")

        assertTrue(dir.deleteRecursivelyCompat())
        assertFalse(dir.exists())
    }

    // ---- renameToCompat ----

    @Test
    fun `renameToCompat moves and renames a file`() {
        val source = tempFolder.newFile("source.txt").apply { writeText("hello") }
        val dest = File(tempFolder.root, "renamed.txt")

        assertTrue(source.renameToCompat(dest))
        assertFalse(source.exists())
        assertTrue(dest.exists())
        assertEquals("hello", dest.readText())
    }

    // ---- copyRecursivelyCompat ----

    @Test
    fun `copyRecursivelyCompat copies a file and leaves the source in place`() {
        val source = tempFolder.newFile("orig.txt").apply { writeText("copy me") }
        val dest = File(tempFolder.root, "copy.txt")

        assertTrue(source.copyRecursivelyCompat(dest))
        assertTrue(source.exists())
        assertTrue(dest.exists())
        assertEquals("copy me", dest.readText())
    }

    @Test
    fun `copyRecursivelyCompat copies a whole folder tree`() {
        val srcDir = tempFolder.newFolder("src-tree")
        File(srcDir, "file1.txt").writeText("a")
        val srcSubDir = File(srcDir, "sub").apply { mkdirs() }
        File(srcSubDir, "file2.txt").writeText("b")
        val destDir = File(tempFolder.root, "dest-tree")

        assertTrue(srcDir.copyRecursivelyCompat(destDir))
        assertTrue(File(destDir, "file1.txt").exists())
        assertTrue(File(destDir, "sub/file2.txt").exists())
        // source untouched
        assertTrue(File(srcDir, "file1.txt").exists())
    }

    // ---- createNewFileCompat ----

    @Test
    fun `createNewFileCompat creates an empty new file`() {
        val newFile = File(tempFolder.root, "brand-new.txt")
        assertTrue(newFile.createNewFileCompat())
        assertTrue(newFile.exists())
    }

    @Test
    fun `createNewFileCompat on an already-existing file returns false`() {
        val existing = tempFolder.newFile("already.txt")
        assertFalse(existing.createNewFileCompat())
    }

    // ---- needsShizuku ----

    @Test
    fun `needsShizuku is false for a normal readable file`() {
        val file = tempFolder.newFile("readable.txt")
        assertFalse(file.needsShizuku())
    }

    @Test
    fun `needsShizuku is false for a missing file without Shizuku available`() {
        // Contract: needsShizuku only returns true when Shizuku is BOTH available AND can
        // see the file. With no Shizuku connected in this JVM test, a missing file must
        // report false (nothing else can reach it either), not true.
        val missing = File(tempFolder.root, "nope.txt")
        assertFalse(missing.needsShizuku())
    }
}
