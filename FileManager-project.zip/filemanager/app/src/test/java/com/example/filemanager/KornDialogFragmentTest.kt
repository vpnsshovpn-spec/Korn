package com.example.filemanager

import com.example.filemanager.ui.dialogs.KornDialog
import com.example.filemanager.ui.dialogs.KornDialogFragment
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

/**
 * Unit tests for KornDialog/KornDialogFragment.kt - the project's central DialogFragment
 * wrapper. First test for this file (see the code-review report the "Rotation Safety"
 * sessions in KORN-Next-Steps-Handoff.txt worked through: 🔴 the reused-customView-across-
 * rotation crash risk this file's buildAlertDialog()/onDestroyView() detachFromParent() calls
 * exist to prevent - that fix is exercised directly below).
 *
 * Uses a bare androidx.fragment.app.FragmentActivity as the host (not MainActivity) since
 * KornDialog.Builder only requires *some* FragmentActivity context - this sidesteps
 * MainActivity.onCreate()'s unrelated Environment.isExternalStorageManager() Robolectric
 * shadow requirement (see MainActivityRotationTest.kt's RED-fix #2/#3) entirely, since none
 * of that machinery is what's under test here.
 *
 * Not yet run against real Gradle/Robolectric (no network access here) - treat first CI run
 * on this file with the same scrutiny as any new test, not a rubber stamp.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class KornDialogFragmentTest {

    private fun newActivity(): FragmentActivity =
        Robolectric.buildActivity(FragmentActivity::class.java).setup().get()

    private fun idle() = shadowOf(Looper.getMainLooper()).idle()

    @Test
    fun `basic dialog shows with title and message`() {
        val activity = newActivity()

        val handle = KornDialog.Builder(activity)
            .setTitle("หัวข้อ")
            .setMessage("ข้อความ")
            .show()
        idle()

        assertTrue(handle.isShowing)
    }

    @Test
    fun `positive button click invokes the listener and dismisses`() {
        val activity = newActivity()
        var clicked = false

        val handle = KornDialog.Builder(activity)
            .setTitle("ยืนยัน")
            .setPositiveButton("ตกลง") { _, _ -> clicked = true }
            .show()
        idle()

        handle.getButton(android.content.DialogInterface.BUTTON_POSITIVE).performClick()
        idle()

        assertTrue(clicked)
        assertFalse("dialog should be gone after the positive button dismisses it", handle.isShowing)
    }

    @Test
    fun `setItems reports the tapped index to the listener`() {
        val activity = newActivity()
        var tappedIndex = -1

        KornDialog.Builder(activity)
            .setItems(arrayOf("หนึ่ง", "สอง", "สาม")) { _, which -> tappedIndex = which }
            .show()
        idle()

        val fragment = activity.supportFragmentManager.fragments.filterIsInstance<KornDialogFragment>().first()
        val dialog = fragment.dialog as AlertDialog
        val listView = dialog.listView
        listView.performItemClick(listView.getChildAt(1) ?: View(activity), 1, listView.adapter.getItemId(1))
        idle()

        assertEquals(1, tappedIndex)
    }

    @Test
    fun `dismiss clears the spec so it cannot be reused after teardown`() {
        val activity = newActivity()

        val handle = KornDialog.Builder(activity, stableId = "test-stable-id")
            .setTitle("test")
            .show()
        idle()

        assertTrue(KornDialog.take("test-stable-id") != null)

        handle.dismiss()
        idle()

        assertFalse(handle.isShowing)
        assertNull(
            "onDismiss() should remove the spec from KornDialog's static map on a real dismissal",
            KornDialog.take("test-stable-id")
        )
    }

    @Test
    fun `a custom view survives a rotation without the 'already has a parent' crash`() {
        val controller = Robolectric.buildActivity(FragmentActivity::class.java).setup()
        val activity = controller.get()
        val customView = TextView(activity).apply { text = "custom" }

        KornDialog.Builder(activity, stableId = "rotation-view-test")
            .setView(customView)
            .setCancelable(false)
            .show()
        idle()
        assertTrue(customView.parent != null)

        // The regression this guards against: FragmentManager recreating the dialog fragment
        // across a configuration change (recreate(), same pattern MainActivityRotationTest.kt
        // uses) while buildAlertDialog() reuses the *same* customView instance - without
        // KornDialogFragment.onDestroyView()'s detachFromParent() call, this throws "The
        // specified child already has a parent" instead of completing cleanly. Simply not
        // throwing here IS the assertion this regression test exists for.
        controller.recreate()
        idle()

        // The spec (and its customView reference) is still registered under the stable id -
        // recreate() is a config change, not a real dismissal, so onDismiss() never fired.
        assertTrue(KornDialog.take("rotation-view-test") != null)
    }
}
