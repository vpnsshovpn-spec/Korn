package com.example.filemanager

import androidx.lifecycle.ViewModelProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round C (ViewModel migration plan, round 3 of 4 - see KORN-Next-Steps-Handoff.txt section 5).
 * First real rotation test in this project: everything below drives an actual
 * ActivityController.recreate() - the same destroy-old-instance / create-new-instance cycle a
 * real screen rotation triggers - instead of only asserting on MainViewModel in isolation
 * (MainViewModelTest's hydration test already covers that narrower case).
 *
 * RED-fix #1: an earlier version called the nonexistent
 * ShadowEnvironment.setIsExternalStorageManager() - removed, see git history / handoff
 * section 9.1.
 *
 * RED-fix #2: with that call removed, the actual CI stack trace showed
 * Environment.isExternalStorageManager() itself throws ArrayIndexOutOfBoundsException when
 * called under Robolectric (no built-in shadow exists for it in 4.13 - the real method body
 * runs and hits device-only state). checkPermissionsAndLoad() calls this on every
 * MainActivity.onCreate(), so even the very first buildActivity(...).setup() crashed before
 * getting anywhere near recreate(). Fixed with a small custom shadow
 * (ShadowExternalStorageManager.kt) registered below via @Config(shadows = [...]) - see that
 * file's doc for why a custom shadow instead of a built-in one. This also means permission
 * IS granted in every test in this file now, unlike the (now-corrected) earlier assumption.
 *
 * RED-fix #3: the next CI log showed a *different* crash at setUp() line ~50
 * (Environment.getExternalStorageDirectory()), not inside onCreate() at all - because the
 * RED-fix #2 shadow originally `@Implements`-replaced Environment wholesale instead of only
 * overriding isExternalStorageManager(). Fixed in ShadowExternalStorageManager.kt by extending
 * Robolectric's built-in ShadowEnvironment instead of replacing it - see that file's doc.
 *
 * What this file does NOT cover (recorded honestly, not glossed over):
 * - Real device Shizuku/permission-dialog behavior - only the Robolectric-simulated path.
 * - Full TRASH-mode list rendering after recreate (loadTrash() runs on lifecycleScope/
 *   Dispatchers.IO and isn't awaited here) - only that viewModel.mode.value itself survives.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class MainActivityRotationTest {

    private lateinit var externalRoot: File

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        File(externalRoot, "a.txt").writeText("x")
        File(externalRoot, "b.txt").writeText("x")
    }

    @After
    fun tearDown() {
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun viewModelOf(activity: MainActivity): MainViewModel =
        ViewModelProvider(activity)[MainViewModel::class.java]

    // Round 2 (MainViewModel split, step 1 of 4): mode/currentDir/lastNormalDir/directoryState
    // now live on DirectoryViewModel, not MainViewModel - see that class's own ViewModelProvider
    // lookup below, used the same way as viewModelOf() above.
    private fun directoryViewModelOf(activity: MainActivity): DirectoryViewModel =
        ViewModelProvider(activity)[DirectoryViewModel::class.java]

    // Round 2 (MainViewModel split, step 2 of 4): clipboard/selection/fileOpState now live on
    // FileOperationViewModel, not MainViewModel - see that class's own ViewModelProvider lookup
    // below, used the same way as viewModelOf()/directoryViewModelOf() above.
    private fun fileOperationViewModelOf(activity: MainActivity): FileOperationViewModel =
        ViewModelProvider(activity)[FileOperationViewModel::class.java]

    /**
     * With permission now genuinely granted (RED-fix #2), checkPermissionsAndLoad() kicks
     * off DirectoryViewModel.loadDirectory() on Dispatchers.IO as the last step of onCreate() -
     * a real background thread, not something Robolectric's paused main-looper controls.
     * If a test mutates ViewModel state (mode/currentDir/selection) before that first load
     * finishes, the load's own completion can race in afterward and stomp the test's value
     * (loadDirectory() unconditionally sets currentDir/mode as part of its result). This
     * polls directoryState.isLoading back to false first so every test starts from a
     * settled ViewModel, closing that race for the *initial* setup() call. (The much
     * smaller window around recreate()'s own reload firing between recreate() returning
     * and the assertion running immediately after is not addressed here - accepted as a
     * residual, undocumented-until-now flakiness risk rather than pulling in
     * kotlinx-coroutines-test, which this project doesn't have wired up yet - see
     * MainViewModelTest.kt's existing note on the same gap.)
     */
    private fun awaitInitialLoadSettled(vm: DirectoryViewModel) {
        val deadline = System.currentTimeMillis() + 2000
        while (vm.directoryState.value.isLoading && System.currentTimeMillis() < deadline) {
            Thread.sleep(10)
        }
    }

    @Test
    fun `selection state survives Activity recreate and the new adapter hydrates from it`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = fileOperationViewModelOf(controller.get())
        awaitInitialLoadSettled(directoryViewModelOf(controller.get()))

        val paths = setOf(File(externalRoot, "a.txt").absolutePath)
        vm1.setSelectionState(true, paths)

        val activity2 = controller.recreate().get()
        val vm2 = fileOperationViewModelOf(activity2)

        // Guaranteed by androidx.lifecycle as long as MainActivity declares no
        // android:configChanges for orientation/screenSize (confirmed absent in
        // AndroidManifest.xml) - asserted here rather than assumed.
        assertSame(vm1, vm2)
        assertTrue(vm2.selectionMode.value)
        assertEquals(paths, vm2.selectedPaths.value)

        // Round A's specific goal: the *new* FileAdapter built by onCreate() during the
        // recreate must hydrate from the surviving ViewModel instead of starting empty.
        assertTrue(activity2.adapter.selectionMode)
        assertEquals(paths.size, activity2.adapter.selectionCount())
    }

    @Test
    fun `in-progress copy-move percent survives Activity recreate and re-renders the subtitle`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = fileOperationViewModelOf(controller.get())
        awaitInitialLoadSettled(directoryViewModelOf(controller.get()))

        vm1.setFileOpProgress(percent = 42, doneCount = 1, totalCount = 3, isMove = true)

        val activity2 = controller.recreate().get()
        val vm2 = fileOperationViewModelOf(activity2)

        assertTrue(vm2.fileOpState.value.isRunning)
        assertEquals(42, vm2.fileOpState.value.percent)
        // observeFileOpState() re-subscribes to the sticky StateFlow in the new Activity's
        // onCreate() and should immediately re-render the in-progress subtitle.
        assertEquals("กำลังย้าย… 42%", activity2.supportActionBar?.subtitle)
    }

    @Test
    fun `non-NORMAL mode is not silently reset back to NORMAL on recreate`() {
        // Regression test for the Round 17 fix documented in PermissionFlowHelper.kt:
        // checkPermissionsAndLoad() must call refreshCurrentView() (not loadDirectory(),
        // which force-resets mode to NORMAL) when savedInstanceState is non-null, i.e. this
        // onCreate() run is a recreate rather than a first launch. Now that permission is
        // genuinely granted in this file (RED-fix #2), this branch is actually exercised -
        // unlike the earlier, now-corrected version of this comment which had to admit it
        // wasn't (permission was never granted then, so the branch was never reached).
        //
        // Round 2 (MainViewModel split, step 1 of 4): mode now lives on DirectoryViewModel.
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val dvm1 = directoryViewModelOf(controller.get())
        awaitInitialLoadSettled(dvm1)

        dvm1.setMode(MainActivity.Mode.TRASH)

        val activity2 = controller.recreate().get()
        val dvm2 = directoryViewModelOf(activity2)

        assertEquals(MainActivity.Mode.TRASH, dvm2.mode.value)
    }

    @Test
    fun `current directory survives Activity recreate`() {
        // Round 2 (MainViewModel split, step 1 of 4): currentDir/lastNormalDir now live on
        // DirectoryViewModel.
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val dvm1 = directoryViewModelOf(controller.get())
        awaitInitialLoadSettled(dvm1)

        val subDir = File(externalRoot, "sub").apply { mkdirs() }
        dvm1.setCurrentDir(subDir)
        dvm1.setLastNormalDir(subDir)

        val activity2 = controller.recreate().get()
        val dvm2 = directoryViewModelOf(activity2)

        assertEquals(subDir, dvm2.currentDir.value)
        assertEquals(subDir, dvm2.lastNormalDir.value)
    }
}
