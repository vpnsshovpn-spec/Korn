package com.example.filemanager

import androidx.lifecycle.ViewModelProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round C (ViewModel migration plan, round 3 of 4 - see KORN-Next-Steps-Handoff.txt section 5).
 * First real rotation test in this project: everything below drives an actual
 * ActivityController.recreate() - the same destroy-old-instance / create-new-instance cycle a
 * real screen rotation triggers - instead of only asserting on MainViewModel in isolation
 * (MainViewModelTest's hydration test already covers that narrower case).
 *
 * BUILD FIX (this file was RED on the first CI run): the original version called
 * ShadowEnvironment.setIsExternalStorageManager(true), which doesn't exist on this
 * project's Robolectric version (4.13) - "Unresolved reference: setIsExternalStorageManager".
 * That shadow call has been removed rather than replaced, because it turned out to be
 * unnecessary: in MainActivity.onCreate(), the ViewModel wiring, FileAdapter creation, and
 * observeFileOpState()/observeDirectoryState() subscriptions all run *before*
 * checkPermissionsAndLoad() is called (see the last line of onCreate()). Storage permission
 * being granted or not only affects what checkPermissionsAndLoad() does afterward (load a
 * directory vs. show a "please grant access" toast + Settings intent, both harmless no-ops
 * under Robolectric) - it has no bearing on whether the state set directly on the ViewModel
 * in these tests (selection, fileOpState, mode, currentDir) survives a recreate.
 *
 * What this file does NOT cover (recorded honestly, not glossed over):
 * - Real device Shizuku/permission-dialog behavior - only the Robolectric-simulated path.
 * - Full TRASH-mode list rendering after recreate (loadTrash() runs on lifecycleScope/
 *   Dispatchers.IO and isn't awaited here) - only that viewModel.mode.value itself survives,
 *   which is the specific Round 17 regression PermissionFlowHelper.kt's comment describes.
 * - The directory listing itself (directoryState) never populates in these tests, since
 *   permission is never granted here and loadDirectory() is therefore never reached - not
 *   needed for what this file asserts, but worth knowing if a future round extends this file.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainActivityRotationTest {

    private lateinit var externalRoot: File

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        File(externalRoot, "a.txt").writeText("x")
        File(externalRoot, "b.txt").writeText("x")
    }

    @After
    fun tearDown() {
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun viewModelOf(activity: MainActivity): MainViewModel =
        ViewModelProvider(activity)[MainViewModel::class.java]

    @Test
    fun `selection state survives Activity recreate and the new adapter hydrates from it`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = viewModelOf(controller.get())

        val paths = setOf(File(externalRoot, "a.txt").absolutePath)
        vm1.setSelectionState(true, paths)

        val activity2 = controller.recreate().get()
        val vm2 = viewModelOf(activity2)

        // Guaranteed by androidx.lifecycle as long as MainActivity declares no
        // android:configChanges for orientation/screenSize (confirmed absent in
        // AndroidManifest.xml) - asserted here rather than assumed.
        assertSame(vm1, vm2)
        assertTrue(vm2.selectionMode.value)
        assertEquals(paths, vm2.selectedPaths.value)

        // Round A's specific goal: the *new* FileAdapter built by onCreate() during the
        // recreate must hydrate from the surviving ViewModel instead of starting empty.
        assertTrue(activity2.adapter.selectionMode)
        assertEquals(paths.size, activity2.adapter.selectionCount())
    }

    @Test
    fun `in-progress copy-move percent survives Activity recreate and re-renders the subtitle`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = viewModelOf(controller.get())

        vm1.setFileOpProgress(percent = 42, doneCount = 1, totalCount = 3, isMove = true)

        val activity2 = controller.recreate().get()
        val vm2 = viewModelOf(activity2)

        assertTrue(vm2.fileOpState.value.isRunning)
        assertEquals(42, vm2.fileOpState.value.percent)
        // observeFileOpState() re-subscribes to the sticky StateFlow in the new Activity's
        // onCreate() and should immediately re-render the in-progress subtitle.
        assertEquals("กำลังย้าย… 42%", activity2.supportActionBar?.subtitle)
    }

    @Test
    fun `non-NORMAL mode is not silently reset back to NORMAL on recreate`() {
        // NOTE (corrected after the first build): this test does NOT actually exercise the
        // Round 17 checkPermissionsAndLoad() refreshCurrentView()-vs-loadDirectory() branch
        // described in PermissionFlowHelper.kt - that branch only runs once storage
        // permission is granted, and no test in this file grants it (see the class doc).
        // Without permission, checkPermissionsAndLoad() short-circuits into the "request
        // access" branch before ever checking savedInstanceState, so it never touches mode
        // either way. What this test actually proves is narrower: MainViewModel.mode itself
        // is untouched by anything else in onCreate()'s recreate path. Confirming the
        // Round 17 branch itself would need a real granted-permission test, which is a gap
        // left for a future round, not something claimed as done here.
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = viewModelOf(controller.get())

        vm1.setMode(MainActivity.Mode.TRASH)

        val activity2 = controller.recreate().get()
        val vm2 = viewModelOf(activity2)

        assertEquals(MainActivity.Mode.TRASH, vm2.mode.value)
    }

    @Test
    fun `current directory survives Activity recreate`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val vm1 = viewModelOf(controller.get())

        val subDir = File(externalRoot, "sub").apply { mkdirs() }
        vm1.setCurrentDir(subDir)
        vm1.setLastNormalDir(subDir)

        val activity2 = controller.recreate().get()
        val vm2 = viewModelOf(activity2)

        assertEquals(subDir, vm2.currentDir.value)
        assertEquals(subDir, vm2.lastNormalDir.value)
    }
}
