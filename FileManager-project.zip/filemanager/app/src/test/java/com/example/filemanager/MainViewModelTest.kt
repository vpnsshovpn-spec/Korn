package com.example.filemanager

import android.os.Environment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 17: unit tests for MainViewModel.
 *
 * MainViewModel holds every piece of state moved out of MainActivity across Round 14-16
 * (settings/display, clipboard, navigation/directory). These tests check two things for
 * each StateFlow: (1) it starts with the expected default value, and (2) its setter
 * function actually updates `.value`. This is exactly the behavior MainActivity's old
 * get()/set() wrappers rely on, so a regression here would silently break navigation,
 * sorting, clipboard, or search across the whole app.
 *
 * Robolectric is used because MainViewModel's currentDir/lastNormalDir defaults call
 * android.os.Environment.getExternalStorageDirectory(), a real Android framework method
 * that isn't available on a plain JVM unit test.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @Before
    fun setUp() {
        viewModel = MainViewModel()
    }

    // ---- Round 14: settings/display state ----

    @Test
    fun `showHidden defaults to false and can be updated`() {
        assertFalse(viewModel.showHidden.value)
        viewModel.setShowHidden(true)
        assertTrue(viewModel.showHidden.value)
    }

    @Test
    fun `sortKey defaults to NAME and can be updated`() {
        assertEquals(MainActivity.SortKey.NAME, viewModel.sortKey.value)
        viewModel.setSortKey(MainActivity.SortKey.DATE)
        assertEquals(MainActivity.SortKey.DATE, viewModel.sortKey.value)
    }

    @Test
    fun `sortAscending defaults to true and can be updated`() {
        assertTrue(viewModel.sortAscending.value)
        viewModel.setSortAscending(false)
        assertFalse(viewModel.sortAscending.value)
    }

    @Test
    fun `isGridMode defaults to false and can be updated`() {
        assertFalse(viewModel.isGridMode.value)
        viewModel.setIsGridMode(true)
        assertTrue(viewModel.isGridMode.value)
    }

    @Test
    fun `fileViewMode defaults to LIST and can be updated`() {
        assertEquals(FileAdapter.ViewMode.LIST, viewModel.fileViewMode.value)
        viewModel.setFileViewMode(FileAdapter.ViewMode.GRID)
        assertEquals(FileAdapter.ViewMode.GRID, viewModel.fileViewMode.value)
    }

    @Test
    fun `themeKey defaults to blue and can be updated`() {
        assertEquals("blue", viewModel.themeKey.value)
        viewModel.setThemeKey("purple")
        assertEquals("purple", viewModel.themeKey.value)
    }

    // ---- Round 15: clipboard state ----

    @Test
    fun `clipboardFiles defaults to empty and can be updated`() {
        assertTrue(viewModel.clipboardFiles.value.isEmpty())
        val files = listOf(File("/sdcard/a.txt"), File("/sdcard/b.txt"))
        viewModel.setClipboardFiles(files)
        assertEquals(files, viewModel.clipboardFiles.value)
    }

    @Test
    fun `clipboardIsCut defaults to false and can be updated`() {
        assertFalse(viewModel.clipboardIsCut.value)
        viewModel.setClipboardIsCut(true)
        assertTrue(viewModel.clipboardIsCut.value)
    }

    // ---- Round 16: navigation/directory state ----

    @Test
    fun `currentDir and lastNormalDir default to external storage directory`() {
        val expected = Environment.getExternalStorageDirectory()
        assertEquals(expected, viewModel.currentDir.value)
        assertEquals(expected, viewModel.lastNormalDir.value)
    }

    @Test
    fun `currentDir can be updated independently of lastNormalDir`() {
        val newDir = File("/sdcard/Download")
        viewModel.setCurrentDir(newDir)
        assertEquals(newDir, viewModel.currentDir.value)
        // lastNormalDir should be untouched by a currentDir-only update.
        assertEquals(Environment.getExternalStorageDirectory(), viewModel.lastNormalDir.value)
    }

    @Test
    fun `lastNormalDir can be updated`() {
        val newDir = File("/sdcard/Pictures")
        viewModel.setLastNormalDir(newDir)
        assertEquals(newDir, viewModel.lastNormalDir.value)
    }

    @Test
    fun `mode defaults to NORMAL and can be updated`() {
        assertEquals(MainActivity.Mode.NORMAL, viewModel.mode.value)
        viewModel.setMode(MainActivity.Mode.TRASH)
        assertEquals(MainActivity.Mode.TRASH, viewModel.mode.value)
        viewModel.setMode(MainActivity.Mode.APPS)
        assertEquals(MainActivity.Mode.APPS, viewModel.mode.value)
    }

    @Test
    fun `category label and extensions default to null and can be updated together`() {
        assertNull(viewModel.currentCategoryLabel.value)
        assertNull(viewModel.currentCategoryExts.value)

        viewModel.setCurrentCategoryLabel("รูปภาพ")
        viewModel.setCurrentCategoryExts(setOf("jpg", "png"))

        assertEquals("รูปภาพ", viewModel.currentCategoryLabel.value)
        assertEquals(setOf("jpg", "png"), viewModel.currentCategoryExts.value)
    }

    @Test
    fun `category label and extensions can be cleared back to null`() {
        viewModel.setCurrentCategoryLabel("วิดีโอ")
        viewModel.setCurrentCategoryExts(setOf("mp4"))

        viewModel.setCurrentCategoryLabel(null)
        viewModel.setCurrentCategoryExts(null)

        assertNull(viewModel.currentCategoryLabel.value)
        assertNull(viewModel.currentCategoryExts.value)
    }

    @Test
    fun `lastSearchQuery defaults to null and can be updated`() {
        assertNull(viewModel.lastSearchQuery.value)
        viewModel.setLastSearchQuery("photo")
        assertEquals("photo", viewModel.lastSearchQuery.value)
    }

    @Test
    fun `lastSearchContentEnabled defaults to false and can be updated`() {
        assertFalse(viewModel.lastSearchContentEnabled.value)
        viewModel.setLastSearchContentEnabled(true)
        assertTrue(viewModel.lastSearchContentEnabled.value)
    }

    // ---- Round A: multi-select state ----

    @Test
    fun `selectionMode and selectedPaths default to false and empty`() {
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `setSelectionState updates both selectionMode and selectedPaths together`() {
        val paths = setOf("/sdcard/a.txt", "/sdcard/b.txt")
        viewModel.setSelectionState(true, paths)
        assertTrue(viewModel.selectionMode.value)
        assertEquals(paths, viewModel.selectedPaths.value)
    }

    @Test
    fun `setSelectionState can clear selection back to defaults`() {
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt"))
        viewModel.setSelectionState(false, emptySet())
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `a fresh FileAdapter hydrates its local selection from an already-populated ViewModel`() {
        // Simulates Activity recreation (rotation): the ViewModel survives and already
        // holds a selection; a brand-new FileAdapter created against it (as MainActivity's
        // onCreate does) should pick that selection up instead of starting empty.
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt", "/sdcard/b.txt"))

        val adapter = FileAdapter(
            context = org.robolectric.RuntimeEnvironment.getApplication(),
            viewModel = viewModel,
            initialItems = emptyList(),
            onClick = {},
            onLongClick = { true },
            onStartDrag = { _, _ -> true },
            onDropOnFolder = { _, _ -> true }
        )

        assertTrue(adapter.selectionMode)
        assertEquals(2, adapter.selectionCount())
    }
}
