package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Round 17: unit tests for MainViewModel.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see round2-instructions.txt): the
 * showHidden/sortKey/sortAscending/isGridMode/fileViewMode and currentDir/lastNormalDir/mode/
 * category-filter tests that used to live here moved to DirectoryViewModelTest.kt along with
 * the state itself.
 *
 * Round 2 (MainViewModel split, step 2 of 4 - see round2-instructions.txt): the clipboard,
 * multi-select, and copy/move progress tests that used to live here moved to
 * FileOperationViewModelTest.kt along with the state itself.
 *
 * Round 2 (MainViewModel split, step 4 of 4 - see refactor-instructions.txt): the
 * lastSearchQuery/lastSearchContentEnabled tests that used to live here moved to
 * SearchFilterViewModelTest.kt along with the state itself. This was the last of the 4 steps:
 * the only thing left to test on MainViewModel is themeKey.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @Before
    fun setUp() {
        viewModel = MainViewModel(SavedStateHandle())
    }

    // ---- Round 14: settings/display state ----

    @Test
    fun `themeKey defaults to blue and can be updated`() {
        assertEquals("blue", viewModel.themeKey.value)
        viewModel.setThemeKey("purple")
        assertEquals("purple", viewModel.themeKey.value)
    }

    // ---- Round 15: clipboard state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)

    // ---- Round 16: search-related state ----
    // (lastSearchQuery/lastSearchContentEnabled tests moved to SearchFilterViewModelTest.kt in
    // Round 2, step 4 - see this file's class doc.)

    // ---- Round A: multi-select state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)

    // ---- Round B: copy/move progress state ----
    // (moved to FileOperationViewModelTest.kt in Round 2, step 2 - see this file's class doc.)
}
