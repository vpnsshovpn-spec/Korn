package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 17: unit tests for MainViewModel.
 *
 * Round 2 (MainViewModel split, step 1 of 4 - see refactor-instructions.txt): the
 * showHidden/sortKey/sortAscending/isGridMode/fileViewMode and currentDir/lastNormalDir/mode/
 * category-filter tests that used to live here moved to DirectoryViewModelTest.kt along with
 * the state itself. What remains here is everything else Round 14-22 put on MainViewModel:
 * themeKey, clipboard, lastSearchQuery/lastSearchContentEnabled, multi-select, and copy/move
 * progress state. Same two things checked for each StateFlow: (1) it starts with the expected
 * default value, and (2) its setter function actually updates `.value`.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @Before
    fun setUp() {
        viewModel = MainViewModel(SavedStateHandle())
    }

    // ---- Round 14: settings/display state ----

    @Test
    fun `themeKey defaults to blue and can be updated`() {
        assertEquals("blue", viewModel.themeKey.value)
        viewModel.setThemeKey("purple")
        assertEquals("purple", viewModel.themeKey.value)
    }

    // ---- Round 15: clipboard state ----

    @Test
    fun `clipboardFiles defaults to empty and can be updated`() {
        assertTrue(viewModel.clipboardFiles.value.isEmpty())
        val files = listOf(File("/sdcard/a.txt"), File("/sdcard/b.txt"))
        viewModel.setClipboardFiles(files)
        assertEquals(files, viewModel.clipboardFiles.value)
    }

    @Test
    fun `clipboardIsCut defaults to false and can be updated`() {
        assertFalse(viewModel.clipboardIsCut.value)
        viewModel.setClipboardIsCut(true)
        assertTrue(viewModel.clipboardIsCut.value)
    }

    // ---- Round 16: search-related state that stayed on MainViewModel ----
    // (currentDir/lastNormalDir/mode/category-filter tests moved to DirectoryViewModelTest.kt
    // in Round 2, step 1 - see this file's class doc.)

    @Test
    fun `lastSearchQuery defaults to null and can be updated`() {
        assertNull(viewModel.lastSearchQuery.value)
        viewModel.setLastSearchQuery("photo")
        assertEquals("photo", viewModel.lastSearchQuery.value)
    }

    @Test
    fun `lastSearchContentEnabled defaults to false and can be updated`() {
        assertFalse(viewModel.lastSearchContentEnabled.value)
        viewModel.setLastSearchContentEnabled(true)
        assertTrue(viewModel.lastSearchContentEnabled.value)
    }

    // ---- Round A: multi-select state ----

    @Test
    fun `selectionMode and selectedPaths default to false and empty`() {
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `setSelectionState updates both selectionMode and selectedPaths together`() {
        val paths = setOf("/sdcard/a.txt", "/sdcard/b.txt")
        viewModel.setSelectionState(true, paths)
        assertTrue(viewModel.selectionMode.value)
        assertEquals(paths, viewModel.selectedPaths.value)
    }

    @Test
    fun `setSelectionState can clear selection back to defaults`() {
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt"))
        viewModel.setSelectionState(false, emptySet())
        assertFalse(viewModel.selectionMode.value)
        assertTrue(viewModel.selectedPaths.value.isEmpty())
    }

    @Test
    fun `a fresh FileAdapter hydrates its local selection from an already-populated ViewModel`() {
        // Simulates Activity recreation (rotation): the ViewModel survives and already
        // holds a selection; a brand-new FileAdapter created against it (as MainActivity's
        // onCreate does) should pick that selection up instead of starting empty.
        viewModel.setSelectionState(true, setOf("/sdcard/a.txt", "/sdcard/b.txt"))

        val adapter = FileAdapter(
            context = org.robolectric.RuntimeEnvironment.getApplication(),
            viewModel = viewModel,
            initialItems = emptyList(),
            onClick = {},
            onLongClick = { true },
            onStartDrag = { _, _ -> true },
            onDropOnFolder = { _, _ -> true }
        )

        assertTrue(adapter.selectionMode)
        assertEquals(2, adapter.selectionCount())
    }

    // ---- Round B: copy/move progress state ----

    @Test
    fun `fileOpState defaults to not running`() {
        assertFalse(viewModel.fileOpState.value.isRunning)
        assertEquals(0, viewModel.fileOpState.value.percent)
    }

    @Test
    fun `setFileOpProgress marks running and stores percent, counts, and direction`() {
        viewModel.setFileOpProgress(percent = 42, doneCount = 1, totalCount = 3, isMove = true)
        val state = viewModel.fileOpState.value
        assertTrue(state.isRunning)
        assertEquals(42, state.percent)
        assertEquals(1, state.doneCount)
        assertEquals(3, state.totalCount)
        assertTrue(state.isMove)
    }

    @Test
    fun `setFileOpDone resets isRunning back to false`() {
        viewModel.setFileOpProgress(percent = 50, doneCount = 1, totalCount = 2, isMove = false)
        viewModel.setFileOpDone(doneCount = 2, totalCount = 2, failures = emptyList())
        assertFalse(viewModel.fileOpState.value.isRunning)
    }

    // Note: UiEvent.FileOpDone itself (emitted via viewModelScope.launch { _events.emit(...) })
    // is not covered here - asserting on it would need either kotlinx-coroutines-test's
    // runTest/TestDispatcher or idling Robolectric's main looper, neither of which this
    // project has wired up yet. Only the synchronous fileOpState half of setFileOpDone()
    // (asserted above) is verified by this test file.
}
