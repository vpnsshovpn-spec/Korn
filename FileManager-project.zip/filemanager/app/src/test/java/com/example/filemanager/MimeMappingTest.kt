package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ApplicationProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/**
 * FIX-7 gap #1: MIME mapping.
 *
 * OpenWithActivity.mimeTypeFor() and PickerActivity.matchesFilter()/resolveMimeFilter() are
 * both private and depend on MimeTypeMap/ContentResolver, so they can't be unit tested
 * directly as plain JVM functions. Instead these tests drive the real Activity through
 * Robolectric and check the *observable* result of the private logic: the mime "type" on the
 * Intent that ends up handed to startActivity() (for OpenWithActivity), and which files
 * survive the filter into the visible list (for PickerActivity).
 *
 * IMPORTANT: unlike real Android, Robolectric's MimeTypeMap.getSingleton() ships with NO
 * extension->mime data by default (getMimeTypeFromExtension() returns null for everything
 * until you register mappings yourself). The first version of this test file assumed the
 * real device table was present and every assertion failed against the wildcard mime type - see
 * the round that fixed this in KORN-Next-Steps-Handoff.txt. ShadowMimeTypeMap is Robolectric's
 * documented way to seed exactly the mappings a test needs.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MimeMappingTest {

    private lateinit var cacheDir: File

    @Before
    fun setUp() {
        cacheDir = ApplicationProvider.getApplicationContext<App>().cacheDir
        // PickerActivity always starts browsing at external storage root - clear it so each
        // test sees exactly the files it creates, not leftovers from a previous test.
        externalRoot().listFiles()?.forEach { it.deleteRecursively() }

        shadowOf(android.webkit.MimeTypeMap.getSingleton()).apply {
            addExtensionMimeTypeMapping("jpg", "image/jpeg")
            addExtensionMimeTypeMapping("txt", "text/plain")
            addExtensionMimeTypeMapping("zip", "application/zip")
            addExtensionMimeTypeMapping("mp3", "audio/mpeg")
        }
    }

    @After
    fun tearDown() {
        externalRoot().listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun externalRoot(): File = android.os.Environment.getExternalStorageDirectory()

    /** Builds OpenWithActivity for a file:// Uri with the given name, clicks "open with another
     *  app", and returns the mime type Robolectric captured on the forwarded Intent. */
    private fun resolvedMimeTypeFor(fileName: String): String? {
        val file = File(cacheDir, fileName).apply { writeText("x") }
        val intent = Intent(Intent.ACTION_VIEW).apply { data = Uri.fromFile(file) }
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()
        activity.findViewById<Button>(R.id.openAnotherAppButton).performClick()
        val chooser = shadowOf(activity).nextStartedActivity
        val inner = chooser?.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
        return inner?.type
    }

    @Test
    fun `jpg file resolves to image mime type`() {
        assertEquals("image/jpeg", resolvedMimeTypeFor("photo.jpg"))
    }

    @Test
    fun `txt file resolves to text mime type`() {
        assertEquals("text/plain", resolvedMimeTypeFor("notes.txt"))
    }

    @Test
    fun `zip file resolves to zip mime type`() {
        assertEquals("application/zip", resolvedMimeTypeFor("archive.zip"))
    }

    @Test
    fun `unrecognized extension falls back to wildcard mime type`() {
        assertEquals("*/*", resolvedMimeTypeFor("data.notarealext"))
    }

    // ---- PickerActivity.matchesFilter / resolveMimeFilter ----

    @Test
    fun `PickerActivity image filter hides non-matching files but keeps folders`() {
        val root = externalRoot()
        File(root, "photo.jpg").writeText("x")
        File(root, "notes.txt").writeText("x")
        File(root, "sub").mkdirs()

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        val activity = Robolectric.buildActivity(PickerActivity::class.java, intent).setup().get()
        val itemCount = activity.findViewById<RecyclerView>(R.id.pickerList).adapter?.itemCount

        // "sub" folder + photo.jpg match; notes.txt is filtered out.
        assertEquals(2, itemCount)
    }

    @Test
    fun `PickerActivity wildcard filter shows every file`() {
        val root = externalRoot()
        File(root, "photo.jpg").writeText("x")
        File(root, "notes.txt").writeText("x")

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        val activity = Robolectric.buildActivity(PickerActivity::class.java, intent).setup().get()
        val itemCount = activity.findViewById<RecyclerView>(R.id.pickerList).adapter?.itemCount

        assertEquals(2, itemCount)
    }

    @Test
    fun `PickerActivity EXTRA_MIME_TYPES list matches any of several types`() {
        val root = externalRoot()
        File(root, "photo.jpg").writeText("x")
        File(root, "song.mp3").writeText("x")
        File(root, "notes.txt").writeText("x")

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "audio/mpeg"))
        }
        val activity = Robolectric.buildActivity(PickerActivity::class.java, intent).setup().get()
        val itemCount = activity.findViewById<RecyclerView>(R.id.pickerList).adapter?.itemCount

        // photo.jpg (image/*) and song.mp3 (audio/mpeg) match; notes.txt does not.
        assertEquals(2, itemCount)
    }
}
