package com.example.filemanager

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * FIX-7: unit tests for MinecraftAddonTools.
 *
 * isArchiveExtension() is the one function in this file that's pure (no Activity/Context
 * dependency), so it's testable as a plain JVM test with no Robolectric needed.
 */
class MinecraftAddonToolsTest {

    @Test
    fun `recognizes minecraft archive extensions case-insensitively`() {
        assertTrue(MinecraftAddonTools.isArchiveExtension("zip"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("ZIP"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("mcpack"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("McPack"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("mcaddon"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("MCADDON"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("mcworld"))
        assertTrue(MinecraftAddonTools.isArchiveExtension("McWorld"))
    }

    @Test
    fun `rejects unrelated extensions`() {
        assertFalse(MinecraftAddonTools.isArchiveExtension("txt"))
        assertFalse(MinecraftAddonTools.isArchiveExtension("rar"))
        assertFalse(MinecraftAddonTools.isArchiveExtension("7z"))
        assertFalse(MinecraftAddonTools.isArchiveExtension(""))
        assertFalse(MinecraftAddonTools.isArchiveExtension("mcpackx"))
        assertFalse(MinecraftAddonTools.isArchiveExtension("zipp"))
    }
}
