package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.widget.Button
import androidx.core.content.FileProvider
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/**
 * FIX-7 gap #2: OpenWith URI flow.
 *
 * shareableUriFor() is private, so - same approach as MimeMappingTest - these tests drive
 * OpenWithActivity through Robolectric and inspect the actual Intent it hands to
 * startActivity(), rather than calling the private method directly.
 *
 * The important thing under test is the security property documented on shareableUriFor()
 * itself: a file:// Uri (which could come straight from an external app's Intent) must never
 * be handed to another app as-is. It has to be copied into this app's own cache dir first and
 * shared as a content:// Uri through FileProvider - never a raw file:// path pointing at
 * wherever the original really lives.
 *
 * Note: the original handoff doc mentioned testing an ACTION_SEND_MULTIPLE path, but
 * OpenWithActivity does not actually implement ACTION_SEND_MULTIPLE (only ACTION_VIEW and
 * ACTION_SEND are handled - see the `when (intent?.action)` in onCreate, and the manifest's
 * intent-filters for this activity). There's nothing to test there because that flow isn't
 * wired up in this codebase; any other action, including SEND_MULTIPLE, is treated as
 * "no file received" (finishes with a toast) - covered below.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OpenWithUriFlowTest {

    private val context get() = ApplicationProvider.getApplicationContext<App>()

    @Test
    fun `opening a file uri with another app converts it to a content uri, not the raw file path`() {
        val file = File(context.cacheDir, "incoming.pdf").apply { writeText("pdf bytes") }
        val intent = Intent(Intent.ACTION_VIEW).apply { data = Uri.fromFile(file) }
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()

        activity.findViewById<Button>(R.id.openAnotherAppButton).performClick()

        val chooser = shadowOf(activity).nextStartedActivity
        val forwarded = chooser?.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
        assertEquals("content", forwarded?.data?.scheme)
        assertTrue(
            (forwarded?.flags ?: 0) and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0
        )
    }

    @Test
    fun `sharing a file uri also converts it to a content uri via the same helper`() {
        val file = File(context.cacheDir, "incoming.jpg").apply { writeText("jpg bytes") }
        val intent = Intent(Intent.ACTION_VIEW).apply { data = Uri.fromFile(file) }
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()

        activity.findViewById<Button>(R.id.shareButton).performClick()

        val chooser = shadowOf(activity).nextStartedActivity
        val forwarded = chooser?.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
        val sharedUri = forwarded?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        assertEquals("content", sharedUri?.scheme)
    }

    @Test
    fun `a uri that is already content scheme passes through unchanged`() {
        val file = File(context.cacheDir, "already_shared.pdf").apply { writeText("bytes") }
        val alreadyContentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        val intent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_STREAM, alreadyContentUri)
            type = "application/pdf"
        }
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()

        activity.findViewById<Button>(R.id.shareButton).performClick()

        val chooser = shadowOf(activity).nextStartedActivity
        val forwarded = chooser?.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
        val sharedUri = forwarded?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        // Passed straight through - not re-copied into a second cache file.
        assertEquals(alreadyContentUri, sharedUri)
    }

    @Test
    fun `ACTION_SEND without an EXTRA_STREAM finishes with no file received`() {
        val intent = Intent(Intent.ACTION_SEND)
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()
        assertTrue(activity.isFinishing)
    }

    @Test
    fun `an unrecognized action finishes with no file received`() {
        val intent = Intent("android.intent.action.SEND_MULTIPLE")
        val activity = Robolectric.buildActivity(OpenWithActivity::class.java, intent).setup().get()
        assertTrue(activity.isFinishing)
    }
}
