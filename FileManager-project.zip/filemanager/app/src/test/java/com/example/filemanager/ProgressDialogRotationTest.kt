package com.example.filemanager

import androidx.lifecycle.ViewModelProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/**
 * Round 2 (see KORN-Next-Steps-Handoff.txt): regression coverage for the
 * "Archive/CompressProgressDialogHelper duplicate-dialog-on-rotation cleanup" item.
 *
 * What was actually still wrong, since Rotation Safety #3 (KornDialog.dismissStale(), added
 * in an earlier round) looked at first like it already covered this: dismissStale() was only
 * ever called reactively, from inside showArchiveProgressDialog()/showCompressProgressDialog()
 * - which only run once observeArchiveOpState()/observeCompressOpState()'s
 * repeatOnLifecycle(STARTED) collector first fires on the *new* Activity instance after a
 * recreate. But FragmentManager restores the *previous* instance's dialog fragment (under the
 * same stable tag) as part of super.onCreate() and shows it again on its own once this
 * Activity reaches onStart() - a point that lands at or before repeatOnLifecycle(STARTED)
 * fires, not after. So the reactive dismissStale() call could lose that race and briefly leave
 * two KornDialogFragment instances under the same tag while a zip/unzip or archive-creation
 * job is still running across a rotation.
 *
 * Fix: MainActivity.onCreate() now calls dismissStaleArchiveProgressDialogIfAny()/
 * dismissStaleCompressProgressDialogIfAny() directly, right after super.onCreate() and before
 * onStart() ever runs - see the comment at that call site in MainActivity.kt. This file checks
 * the observable result: after recreate() while an op is running, exactly one KornDialogFragment
 * exists and it's showing - not that any particular internal call happened.
 *
 * Not yet confirmed GREEN on real CI (no gradlew/Android SDK in this sandbox - same limitation
 * noted throughout KORN-Handoff-Status.txt).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class ProgressDialogRotationTest {

    private lateinit var externalRoot: File

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
        File(externalRoot, "a.txt").writeText("x")
    }

    @After
    fun tearDown() {
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    private fun viewModelOf(activity: MainActivity): MainViewModel =
        ViewModelProvider(activity)[MainViewModel::class.java]

    private fun awaitInitialLoadSettled(vm: MainViewModel) {
        val deadline = System.currentTimeMillis() + 2000
        while (vm.directoryState.value.isLoading && System.currentTimeMillis() < deadline) {
            Thread.sleep(10)
        }
    }

    private fun idleMainLooper() {
        shadowOf(android.os.Looper.getMainLooper()).idle()
    }

    @Test
    fun `archive progress dialog does not duplicate across Activity recreate while running`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity1 = controller.get()
        val vm1 = viewModelOf(activity1)
        awaitInitialLoadSettled(vm1)

        vm1.setArchiveOpStarted(isUnzip = true, archiveName = "test.zip")
        idleMainLooper()
        assertTrue(
            "sanity check: the dialog should actually be up before we rotate",
            activity1.archiveProgressDialogHandle?.isShowing == true
        )

        val activity2 = controller.recreate().get()
        idleMainLooper()

        val dialogFragments = activity2.supportFragmentManager.fragments
            .filterIsInstance<KornDialogFragment>()
        assertEquals(
            "exactly one archive progress dialog fragment should exist after recreate, not two",
            1, dialogFragments.size
        )
        assertTrue(dialogFragments.single().dialog?.isShowing == true)
    }

    @Test
    fun `compress progress dialog does not duplicate across Activity recreate while running`() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity1 = controller.get()
        val vm1 = viewModelOf(activity1)
        awaitInitialLoadSettled(vm1)

        vm1.setCompressOpStarted(archiveName = "test.zip")
        idleMainLooper()
        assertTrue(
            "sanity check: the dialog should actually be up before we rotate",
            activity1.compressProgressDialogHandle?.isShowing == true
        )

        val activity2 = controller.recreate().get()
        idleMainLooper()

        val dialogFragments = activity2.supportFragmentManager.fragments
            .filterIsInstance<KornDialogFragment>()
        assertEquals(
            "exactly one compress progress dialog fragment should exist after recreate, not two",
            1, dialogFragments.size
        )
        assertTrue(dialogFragments.single().dialog?.isShowing == true)
    }
}
