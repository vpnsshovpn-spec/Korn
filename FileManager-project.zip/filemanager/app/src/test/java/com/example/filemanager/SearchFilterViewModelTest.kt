package com.example.filemanager

import androidx.lifecycle.SavedStateHandle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Round 2 (MainViewModel split, step 4 of 4 - see refactor-instructions.txt): unit tests for
 * SearchFilterViewModel, moved out of MainViewModelTest.kt along with the state itself -
 * lastSearchQuery/lastSearchContentEnabled (Round 16). Same two things checked for each
 * StateFlow: (1) it starts with the expected default value, and (2) its setter function
 * actually updates `.value`.
 *
 * Not covered here (same reasoning as ArchiveOperationViewModel getting no dedicated test file
 * in step 3 - MainViewModelTest.kt never had tests for state that wasn't there to move):
 * searchDialogOpen, searchActive, and searchUiState's default value were never covered by
 * MainViewModelTest.kt either, so this is a pure move, not new coverage. onSearchQueryChanged()/
 * runSearchImmediate()/runSearchNow() are not covered for the same reason
 * SearchHelperTest.kt's class doc gives for skipping them: they launch a real
 * viewModelScope coroutine with no test dispatcher/sync point established anywhere in this
 * project.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SearchFilterViewModelTest {

    private lateinit var viewModel: SearchFilterViewModel

    @Before
    fun setUp() {
        viewModel = SearchFilterViewModel(SavedStateHandle())
    }

    // ---- Round 16: search query/options state ----

    @Test
    fun `lastSearchQuery defaults to null and can be updated`() {
        assertNull(viewModel.lastSearchQuery.value)
        viewModel.setLastSearchQuery("photo")
        assertEquals("photo", viewModel.lastSearchQuery.value)
    }

    @Test
    fun `lastSearchContentEnabled defaults to false and can be updated`() {
        assertFalse(viewModel.lastSearchContentEnabled.value)
        viewModel.setLastSearchContentEnabled(true)
        assertTrue(viewModel.lastSearchContentEnabled.value)
    }
}
