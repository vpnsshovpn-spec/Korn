package com.example.filemanager

import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.widget.ImageButton
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Tests for SearchHelper.kt.
 *
 * Covered: highlightMatch()'s span placement (pure string/Spannable logic), runSearch()'s
 * synchronous UI setup (mode switch, hiding the trash bar, breadcrumb label) - not the async
 * search results themselves, since viewModel.runSearchImmediate() launches a real
 * viewModelScope coroutine with no test dispatcher/sync point established anywhere in this
 * project - and setupToolbarSearchButton()'s button wiring.
 *
 * Not covered: searchDialog() (KornDialog.Builder, same skip reason as every other dialog
 * builder in this project) and observeSearchState() (a lifecycleScope.repeatOnLifecycle
 * collector over a StateFlow - no established pattern in this project drives/awaits a
 * repeatOnLifecycle collector synchronously, so its 4 render branches are left untested here
 * rather than guessed at).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class SearchHelperTest {

    private lateinit var activity: MainActivity

    @Before
    fun setUp() {
        android.os.Environment.getExternalStorageDirectory().listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }

    // ---- highlightMatch() ----

    @Test
    fun `highlightMatch returns the original text unchanged when the query is empty`() {
        val result = activity.highlightMatch("hello world", "")
        assertEquals("hello world", result.toString())
        assertTrue(result !is Spanned || (result as Spanned).getSpans(0, result.length, Any::class.java).isEmpty())
    }

    @Test
    fun `highlightMatch spans every case-insensitive occurrence of the query`() {
        val result = activity.highlightMatch("Foo foo FOO bar", "foo") as SpannableString

        val bgSpans = result.getSpans(0, result.length, BackgroundColorSpan::class.java)
        val boldSpans = result.getSpans(0, result.length, StyleSpan::class.java)
        assertEquals(3, bgSpans.size)
        assertEquals(3, boldSpans.size)
        // First match starts at index 0 ("Foo").
        assertEquals(0, result.getSpanStart(bgSpans[0]))
        assertEquals(3, result.getSpanEnd(bgSpans[0]))
    }

    @Test
    fun `highlightMatch does not span text with no match`() {
        val result = activity.highlightMatch("hello world", "xyz") as SpannableString
        assertTrue(result.getSpans(0, result.length, BackgroundColorSpan::class.java).isEmpty())
    }

    // ---- runSearch() ----

    @Test
    fun `runSearch switches to search mode, hides the trash bar, and shows the query as the breadcrumb`() {
        activity.trashActionBar.visibility = android.view.View.VISIBLE

        activity.runSearch("report", searchContent = false)

        assertEquals(MainActivity.Mode.SEARCH, activity.viewModel.mode.value)
        assertEquals(android.view.View.GONE, activity.trashActionBar.visibility)
        assertEquals(1, activity.breadcrumbBar.childCount)
        val label = activity.breadcrumbBar.getChildAt(0) as android.widget.TextView
        assertEquals("ผลค้นหา: \"report\"", label.text)
    }

    // ---- setupToolbarSearchButton() ----

    @Test
    fun `setupToolbarSearchButton adds a search button with the expected content description`() {
        val toolbar = activity.findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        val countBefore = toolbar.childCount

        activity.setupToolbarSearchButton()

        assertEquals(countBefore + 1, toolbar.childCount)
        val added = toolbar.getChildAt(toolbar.childCount - 1) as ImageButton
        assertEquals("ค้นหา", added.contentDescription)
    }

    // The button's click listener (mode guard + searchDialog()) is not exercised: searchDialog()
    // is built on KornDialog.Builder, which under the hood shows a KornDialogFragment via the
    // FragmentManager - no existing test in this project drives that show()/transaction timing,
    // so asserting a dialog appeared here would be guessing at Shadow behavior rather than
    // verifying it, the same reason every other KornDialog-driving method is skipped.
}
