package com.example.filemanager

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import com.example.filemanager.data.search.SearchIndexManager

/**
 * Unit tests for [SearchIndexManager]'s incremental update functions, per
 * KORN-SearchIndex-Incremental-Plan.txt รอบที่ 1 ข้อ 3.
 *
 * Each test gets its own in-memory Room database (via SearchIndexManager's
 * test-only [daoOverride] constructor param) so tests never share state and
 * never touch disk for the DB itself. Robolectric is still needed because
 * SearchIndexManager touches real Android APIs (SharedPreferences, Environment).
 *
 * rebuildFullIndex()/search()/isEmpty()/initialize() themselves are NOT
 * re-tested here — the plan says those must stay untouched, and this file
 * only covers the new incremental surface.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class SearchIndexManagerIncrementalTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun newManager(): SearchIndexManager {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val db = Room.inMemoryDatabaseBuilder(context, SearchIndexDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        return SearchIndexManager(context, daoOverride = db.searchIndexDao())
    }

    // ---- indexFile() ----

    @Test
    fun `indexFile then search finds it`() = runBlocking {
        val manager = newManager()
        val file = tempFolder.newFile("report.txt")

        manager.indexFile(file)

        val results = manager.search("report", showHidden = true)
        assertEquals(listOf(file.absolutePath), results.map { it.absolutePath })
    }

    @Test
    fun `indexFile twice on same path does not duplicate`() = runBlocking {
        val manager = newManager()
        val file = tempFolder.newFile("dup.txt")

        manager.indexFile(file)
        manager.indexFile(file)

        assertEquals(1, manager.search("dup", showHidden = true).size)
    }

    // ---- removeFromIndex() ----

    @Test
    fun `removeFromIndex single file removes it from search`() = runBlocking {
        val manager = newManager()
        val file = tempFolder.newFile("temp.txt")
        manager.indexFile(file)

        manager.removeFromIndex(file)

        assertTrue(manager.search("temp", showHidden = true).isEmpty())
    }

    @Test
    fun `removeFromIndex folder removes itself and all descendants`() = runBlocking {
        val manager = newManager()
        val folder = tempFolder.newFolder("Photos")
        val childFile = File(folder, "a.jpg").apply { writeText("x") }
        val subFolder = File(folder, "2024").apply { mkdirs() }
        val grandchild = File(subFolder, "b.jpg").apply { writeText("x") }
        manager.indexFile(folder)
        manager.indexFile(childFile)
        manager.indexFile(subFolder)
        manager.indexFile(grandchild)

        manager.removeFromIndex(folder)

        assertTrue(manager.search("Photos", showHidden = true).isEmpty())
        assertTrue(manager.search("a.jpg", showHidden = true).isEmpty())
        assertTrue(manager.search("2024", showHidden = true).isEmpty())
        assertTrue(manager.search("b.jpg", showHidden = true).isEmpty())
    }

    @Test
    fun `removeFromIndex folder does not touch a sibling with a shared name prefix`() = runBlocking {
        // Regression check for LIKE-prefix matching: "Photos" must not also delete
        // "PhotosOld" (a sibling folder whose name merely starts with the same text).
        val manager = newManager()
        val folder = tempFolder.newFolder("Photos")
        val sibling = tempFolder.newFolder("PhotosOld")
        val siblingChild = File(sibling, "keep.jpg").apply { writeText("x") }
        manager.indexFile(folder)
        manager.indexFile(sibling)
        manager.indexFile(siblingChild)

        manager.removeFromIndex(folder)

        assertEquals(listOf(siblingChild.absolutePath), manager.search("keep", showHidden = true).map { it.absolutePath })
        assertEquals(1, manager.search("PhotosOld", showHidden = true).size)
    }

    // ---- renameOrMoveInIndex() ----

    @Test
    fun `renameOrMoveInIndex single file updates its path`() = runBlocking {
        val manager = newManager()
        val oldFile = tempFolder.newFile("old.txt")
        manager.indexFile(oldFile)
        val newFile = File(oldFile.parentFile, "new.txt")

        manager.renameOrMoveInIndex(oldFile, newFile)

        val results = manager.search("new", showHidden = true)
        assertEquals(listOf(newFile.absolutePath), results.map { it.absolutePath })
        assertTrue(manager.search("old", showHidden = true).isEmpty())
    }

    @Test
    fun `renameOrMoveInIndex folder updates descendant paths but keeps their names`() = runBlocking {
        val manager = newManager()
        val root = tempFolder.newFolder("Docs")
        val child = File(root, "notes.txt").apply { writeText("x") }
        manager.indexFile(root)
        manager.indexFile(child)

        val renamedRoot = File(root.parentFile, "Documents")
        root.renameTo(renamedRoot) // do the real filesystem rename too, since renameOrMoveInIndex
        // walks the destination on disk to self-heal - see next test for that behavior.
        val renamedChild = File(renamedRoot, "notes.txt")

        manager.renameOrMoveInIndex(root, renamedRoot)

        val childResults = manager.search("notes", showHidden = true)
        assertEquals(listOf(renamedChild.absolutePath), childResults.map { it.absolutePath })
        assertTrue(manager.search("Docs", showHidden = true).isEmpty())
    }

    @Test
    fun `renameOrMoveInIndex same path is a no-op`() = runBlocking {
        val manager = newManager()
        val file = tempFolder.newFile("same.txt")
        manager.indexFile(file)

        manager.renameOrMoveInIndex(file, file)

        assertEquals(1, manager.search("same", showHidden = true).size)
    }

    @Test
    fun `renameOrMoveInIndex folder self-heals descendants that were never indexed`() = runBlocking {
        // If oldPath had zero rows in the index (the SQL rename touches nothing),
        // renameOrMoveInIndex falls back to walking the destination on disk so an
        // entirely un-indexed folder still becomes searchable after being renamed.
        val manager = newManager()
        val root = tempFolder.newFolder("Unindexed")
        File(root, "surprise.txt").writeText("x")
        // Note: root and its child were never passed to indexFile()/indexSubtree().

        val renamedRoot = File(root.parentFile, "Renamed")
        root.renameTo(renamedRoot)
        val renamedChild = File(renamedRoot, "surprise.txt")

        manager.renameOrMoveInIndex(root, renamedRoot)

        assertEquals(
            listOf(renamedChild.absolutePath),
            manager.search("surprise", showHidden = true).map { it.absolutePath }
        )
    }

    @Test
    fun `renameOrMoveInIndex skips the destination disk walk when descendants were already indexed`() = runBlocking {
        // Perf fix: when the SQL rename touches at least one row (the folder was already
        // indexed), renameOrMoveInIndex must NOT re-walk the destination on disk. We prove
        // it here by planting a file on disk after indexing but before the rename/move -
        // if the walk ran, that extra file would show up in search results; it must not.
        val manager = newManager()
        val root = tempFolder.newFolder("Tracked")
        val indexedChild = File(root, "known.txt").apply { writeText("x") }
        manager.indexFile(root)
        manager.indexFile(indexedChild)

        val renamedRoot = File(root.parentFile, "TrackedRenamed")
        root.renameTo(renamedRoot)
        // Planted on disk only, never passed to indexFile() - would only be picked up if
        // renameOrMoveInIndex still did a full disk walk of the destination.
        File(renamedRoot, "planted-after-index.txt").writeText("x")

        manager.renameOrMoveInIndex(root, renamedRoot)

        assertTrue(manager.search("planted-after-index", showHidden = true).isEmpty())
        // The already-indexed child must still have moved correctly via the SQL rename.
        assertEquals(
            listOf(File(renamedRoot, "known.txt").absolutePath),
            manager.search("known.txt", showHidden = true).map { it.absolutePath }
        )
    }

    @Test
    fun `renameOrMoveInIndex updates nameLowercase for the renamed row, not just path`() = runBlocking {
        // Regression test: renamePathPrefix() must update name/nameLowercase/extension for
        // the exact renamed row, not just the path column - otherwise search (which matches
        // on nameLowercase, not path) keeps surfacing the file under its old name and never
        // finds it under the new one.
        val manager = newManager()
        val oldFile = tempFolder.newFile("report.txt")
        manager.indexFile(oldFile)
        val newFile = File(oldFile.parentFile, "summary.txt")

        manager.renameOrMoveInIndex(oldFile, newFile)

        assertTrue(manager.search("report", showHidden = true).isEmpty())
        assertEquals(
            listOf(newFile.absolutePath),
            manager.search("summary", showHidden = true).map { it.absolutePath }
        )
    }

    @Test
    fun `renameOrMoveInIndex renaming a folder does not change its descendants' own names`() = runBlocking {
        // A descendant's row (matched via LIKE prefix, not path=) must keep its own
        // name/nameLowercase unchanged - only the folder's own row gets a new name.
        val manager = newManager()
        val root = tempFolder.newFolder("Docs")
        val child = File(root, "notes.txt").apply { writeText("x") }
        manager.indexFile(root)
        manager.indexFile(child)

        val renamedRoot = File(root.parentFile, "Documents")
        manager.renameOrMoveInIndex(root, renamedRoot)

        // The child's own display name must still be "notes.txt", searchable as such.
        assertEquals(1, manager.search("notes.txt", showHidden = true).size)
        // The folder itself must now be searchable under its new name...
        assertEquals(1, manager.search("Documents", showHidden = true).size)
        // ...and no longer under the old one.
        assertTrue(manager.search("Docs", showHidden = true).isEmpty())
    }

    // ---- indexSubtree() ----

    @Test
    fun `indexSubtree inserts every file copied into a folder`() = runBlocking {
        val manager = newManager()
        val root = tempFolder.newFolder("Copied")
        File(root, "one.txt").writeText("x")
        val sub = File(root, "nested").apply { mkdirs() }
        File(sub, "two.txt").writeText("x")

        manager.indexSubtree(root)

        assertEquals(1, manager.search("one.txt", showHidden = true).size)
        assertEquals(1, manager.search("two.txt", showHidden = true).size)
        assertEquals(1, manager.search("nested", showHidden = true).size)
    }

    @Test
    fun `indexSubtree also makes the root folder itself searchable`() = runBlocking {
        val manager = newManager()
        val root = tempFolder.newFolder("CopiedRoot")

        manager.indexSubtree(root)

        assertEquals(1, manager.search("CopiedRoot", showHidden = true).size)
    }

    @Test
    fun `indexSubtree on an empty folder does not throw`() = runBlocking {
        val manager = newManager()
        val root = tempFolder.newFolder("Empty")

        manager.indexSubtree(root)

        assertEquals(1, manager.search("Empty", showHidden = true).size)
    }

    // ---- path-with-wildcard-characters regression (SQL LIKE '%'/'_' as literal chars) ----

    @Test
    fun `removeFromIndex handles folder names containing SQL LIKE wildcard characters`() = runBlocking {
        val manager = newManager()
        val folder = tempFolder.newFolder("100%_done")
        val child = File(folder, "a.txt").apply { writeText("x") }
        manager.indexFile(folder)
        manager.indexFile(child)

        manager.removeFromIndex(folder)

        assertTrue(manager.search("a.txt", showHidden = true).isEmpty())
    }
}
