package com.example.filemanager

import androidx.appcompat.app.AppCompatDelegate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Tests for SettingsHelper.kt - user preferences persistence and night-mode application.
 *
 * Uses Robolectric.buildActivity(MainActivity::class.java).setup() (same pattern as
 * MainActivityRotationTest.kt) to get a real MainActivity + MainViewModel pair, since
 * SettingsHelper's constructor requires a MainActivity and every method reads/writes
 * activity.viewModel + activity.getSharedPreferences(). SettingsHelper itself is
 * instantiated directly here (`SettingsHelper(activity)`) rather than through
 * MainActivity's private wrapper functions, since SettingsHelper's own methods are
 * already public/internal.
 *
 * What this file covers:
 * - loadUserPreferences() defaults on a clean SharedPreferences file
 * - saveUserPreferences() + loadUserPreferences() round-trips every persisted field
 * - applySavedNightMode()'s three branches (dark/system/other -> NO)
 *
 * What this file does NOT cover (recorded honestly, not glossed over):
 * - showSettingsDialog()/showAboutKornDialog()/showThemeDialog(): these build real dialog
 *   UI through KornDialog.Builder (DialogFragment-backed, see KornDialogFragment.kt) and
 *   asserting on their rendered content is a heavier Robolectric UI test not attempted here.
 * - applyThemePalette(): touches ~15 individual views (toolbar, drawer, breadcrumb, nav
 *   header, tool buttons, pull-down handle strip) - not covered here either; would need
 *   its own dedicated test file if this level of detail becomes worth verifying.
 *
 * Each test uses a fresh SharedPreferences file (cleared in setUp()) named "korn_settings",
 * matching the name SettingsHelper hardcodes internally.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class SettingsHelperTest {

    private lateinit var externalRoot: File
    private lateinit var activity: MainActivity
    private lateinit var helper: SettingsHelper

    @Before
    fun setUp() {
        externalRoot = android.os.Environment.getExternalStorageDirectory()
        externalRoot.listFiles()?.forEach { it.deleteRecursively() }

        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        helper = SettingsHelper(activity)

        // Clean slate: clear any preferences a previous test in this run may have left behind
        // (Robolectric's SharedPreferences backing store persists across tests in the same
        // process unless explicitly cleared).
        activity.getSharedPreferences("korn_settings", android.content.Context.MODE_PRIVATE)
            .edit().clear().commit()
    }

    // ---- loadUserPreferences(): defaults on first run ----

    @Test
    fun `loadUserPreferences applies documented defaults when nothing was ever saved`() {
        helper.loadUserPreferences()

        assertFalse(activity.viewModel.showHidden.value)
        assertFalse(activity.viewModel.isGridMode.value)
        assertEquals(FileAdapter.ViewMode.LIST, activity.viewModel.fileViewMode.value)
        assertTrue(activity.confirmDelete)
        assertEquals(MainActivity.SortKey.NAME, activity.viewModel.sortKey.value)
        assertTrue(activity.viewModel.sortAscending.value)
        assertEquals("system", activity.viewModel.themeKey.value)
    }

    // ---- saveUserPreferences() + loadUserPreferences(): round trip ----

    @Test
    fun `saved preferences survive a save-then-load round trip`() {
        activity.viewModel.setShowHidden(true)
        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.GRID)
        activity.confirmDelete = false
        activity.viewModel.setSortKey(MainActivity.SortKey.SIZE)
        activity.viewModel.setSortAscending(false)
        activity.viewModel.setThemeKey("dark")

        helper.saveUserPreferences()

        // Flip every field back to something else, to prove loadUserPreferences() actually
        // restores from disk rather than the test coincidentally already matching.
        activity.viewModel.setShowHidden(false)
        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.LIST)
        activity.confirmDelete = true
        activity.viewModel.setSortKey(MainActivity.SortKey.NAME)
        activity.viewModel.setSortAscending(true)
        activity.viewModel.setThemeKey("system")

        helper.loadUserPreferences()

        assertTrue(activity.viewModel.showHidden.value)
        assertTrue(activity.viewModel.isGridMode.value)
        assertEquals(FileAdapter.ViewMode.GRID, activity.viewModel.fileViewMode.value)
        assertFalse(activity.confirmDelete)
        assertEquals(MainActivity.SortKey.SIZE, activity.viewModel.sortKey.value)
        assertFalse(activity.viewModel.sortAscending.value)
        assertEquals("dark", activity.viewModel.themeKey.value)
    }

    @Test
    fun `saving COMPACT view mode round trips and does not force grid mode`() {
        // loadUserPreferences() has a second line that derives isGridMode from
        // fileViewMode == GRID - COMPACT should leave isGridMode false.
        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.COMPACT)
        activity.viewModel.setIsGridMode(false)
        helper.saveUserPreferences()

        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.LIST)
        helper.loadUserPreferences()

        assertEquals(FileAdapter.ViewMode.COMPACT, activity.viewModel.fileViewMode.value)
        assertFalse(activity.viewModel.isGridMode.value)
    }

    @Test
    fun `saving DETAILS view mode round trips correctly`() {
        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.DETAILS)
        helper.saveUserPreferences()

        activity.viewModel.setFileViewMode(FileAdapter.ViewMode.LIST)
        helper.loadUserPreferences()

        assertEquals(FileAdapter.ViewMode.DETAILS, activity.viewModel.fileViewMode.value)
    }

    // ---- applySavedNightMode() ----

    @Test
    fun `applySavedNightMode with dark theme key sets MODE_NIGHT_YES`() {
        activity.viewModel.setThemeKey("dark")
        helper.applySavedNightMode()
        assertEquals(AppCompatDelegate.MODE_NIGHT_YES, AppCompatDelegate.getDefaultNightMode())
    }

    @Test
    fun `applySavedNightMode with system theme key follows system`() {
        activity.viewModel.setThemeKey("system")
        helper.applySavedNightMode()
        assertEquals(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, AppCompatDelegate.getDefaultNightMode())
    }

    @Test
    fun `applySavedNightMode with a light-family theme key (not dark or system) sets MODE_NIGHT_NO`() {
        // blue/green/red/gray/light all fall into the same "else" branch in
        // SettingsHelper.applySavedNightMode() - only "dark" and "system" are special-cased.
        activity.viewModel.setThemeKey("blue")
        helper.applySavedNightMode()
        assertEquals(AppCompatDelegate.MODE_NIGHT_NO, AppCompatDelegate.getDefaultNightMode())
    }
}
