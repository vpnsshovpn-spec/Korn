package com.example.filemanager

import android.os.Environment
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.shadows.ShadowEnvironment

/**
 * Round C, RED-fix #2 (see KORN-Next-Steps-Handoff.txt section 9.2/9.3): the CI stack trace
 * showed Environment.isExternalStorageManager() itself throws ArrayIndexOutOfBoundsException
 * under Robolectric - no built-in shadow covers it in 4.13, so the real framework method body
 * runs and crashes on device-only state.
 *
 * RED-fix #3 (found from the *next* CI log, a different failure than #1/#2): the very first
 * version of this file was `@Implements(Environment::class) object ShadowExternalStorageManager`
 * implementing ONLY isExternalStorageManager(). That fully replaces Robolectric's built-in
 * ShadowEnvironment for the Environment class within this test - every OTHER Environment method
 * this test class calls (starting with getExternalStorageDirectory() in setUp(), line 50) then
 * has no shadow at all and falls through to the real Android framework body, which crashes with
 * the exact same ArrayIndexOutOfBoundsException signature, just at a different call site
 * (setUp() itself, before any test body or even the first buildActivity().setup() runs - hence
 * "externalRoot" in tearDown() reporting as never-initialized in the CI log).
 *
 * Fix: extend the built-in org.robolectric.shadows.ShadowEnvironment instead of replacing it
 * wholesale. Static @Implementation methods this subclass does NOT declare are still resolved
 * on the inherited built-in shadow via Robolectric's normal shadow method lookup (this is
 * Robolectric's documented pattern for narrowly overriding one method of a built-in shadow).
 * Only isExternalStorageManager() is overridden here; getExternalStorageDirectory() and every
 * other Environment method this project's tests call keep using the built-in shadow behavior
 * unchanged.
 */
@Implements(Environment::class)
class ShadowExternalStorageManager : ShadowEnvironment() {
    companion object {
        @JvmStatic
        @Implementation
        fun isExternalStorageManager(): Boolean = true
    }
}
