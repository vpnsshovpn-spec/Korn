package com.example.filemanager

import android.os.Environment
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements

/**
 * Round C, RED-fix #2 (see KORN-Next-Steps-Handoff.txt section 9.2/9.3): the actual CI stack
 * trace showed Environment.isExternalStorageManager() itself throws
 * ArrayIndexOutOfBoundsException ("Index 0 out of bounds for length 0") when called under
 * Robolectric - it has no built-in shadow in Robolectric 4.13 at all, so the real Android
 * framework method body runs and crashes on state that only exists on a real device. This
 * is a different, more specific finding than the RED-fix #1 guess
 * (ShadowEnvironment.setIsExternalStorageManager(), which doesn't exist as a method - this
 * is why: there IS no built-in shadow for this method to call).
 *
 * The fix is a small custom shadow targeting just this one method, registered via
 * @Config(shadows = [ShadowExternalStorageManager::class]) on MainActivityRotationTest.
 * This is Robolectric's standard documented mechanism for covering framework methods that
 * don't have (or don't have the right) built-in shadow behavior - it does not depend on
 * guessing an API name that may or may not exist in this Robolectric version.
 */
@Implements(Environment::class)
object ShadowExternalStorageManager {
    @JvmStatic
    @Implementation
    fun isExternalStorageManager(): Boolean = true
}
