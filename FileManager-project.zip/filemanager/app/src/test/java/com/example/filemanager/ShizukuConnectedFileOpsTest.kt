package com.example.filemanager

import android.content.pm.PackageManager
import com.example.filemanager.shizuku.IFileService
import com.example.filemanager.shizuku.RemoteFileEntry
import com.example.filemanager.shizuku.ShizukuFileService
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.Mockito.mockStatic
import org.mockito.Mockito.`when`
import org.mockito.MockedStatic
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import rikka.shizuku.Shizuku
import java.io.File
import com.example.filemanager.data.repository.copyRecursivelyCompat
import com.example.filemanager.data.repository.createNewFileCompat
import com.example.filemanager.data.repository.deleteCompat
import com.example.filemanager.data.repository.existsCompat
import com.example.filemanager.data.repository.listFilesCompat
import com.example.filemanager.data.repository.mkdirsCompat
import com.example.filemanager.data.repository.needsShizuku
import com.example.filemanager.data.repository.renameToCompat

/**
 * FIX-7 gap #2 (Shizuku "connected and responding" path).
 *
 * FileOpsCompatTest.kt can only exercise the "no Shizuku" branch of every *Compat() function,
 * because ShizukuManager.hasPermission() wraps the real rikka.shizuku.Shizuku static calls in a
 * try/catch that fails closed with no real binder available in a plain JVM test. This file fills
 * that gap two ways:
 *
 * 1. Statically mocks rikka.shizuku.Shizuku (pingBinder/isPreV11/checkSelfPermission) so
 *    ShizukuManager.hasPermission() runs its real (unmocked) logic and legitimately returns
 *    true, the same as it would on a device with Shizuku installed and permission granted.
 * 2. Reflectively injects a mock IFileService into ShizukuFileService's private `service`
 *    field. ShizukuFileService.ensureBound() short-circuits to true whenever that field is
 *    already non-null, so this stands in for a real bound remote process without needing to
 *    fake Shizuku.bindUserService()'s actual IPC connection.
 *
 * Together these simulate "Shizuku is installed, permission is granted, and the remote service
 * answers successfully." Each test below forces the *local* java.io call to fail first (missing
 * file/parent, non-directory parent, etc.) so control genuinely reaches the Shizuku branch,
 * matching how FileOpsCompat only consults Shizuku after java.io has already failed.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ShizukuConnectedFileOpsTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var shizukuStatic: MockedStatic<Shizuku>
    private lateinit var mockService: IFileService

    @Before
    fun setUp() {
        shizukuStatic = mockStatic(Shizuku::class.java)
        shizukuStatic.`when`<Boolean> { Shizuku.pingBinder() }.thenReturn(true)
        shizukuStatic.`when`<Boolean> { Shizuku.isPreV11() }.thenReturn(false)
        shizukuStatic.`when`<Int> { Shizuku.checkSelfPermission() }
            .thenReturn(PackageManager.PERMISSION_GRANTED)

        mockService = mock(IFileService::class.java)
        injectRemoteService(mockService)
    }

    @After
    fun tearDown() {
        injectRemoteService(null)
        shizukuStatic.close()
    }

    private fun injectRemoteService(service: IFileService?) {
        val field = ShizukuFileService::class.java.getDeclaredField("service")
        field.isAccessible = true
        field.set(ShizukuFileService, service)
    }

    // ---- sanity check on the harness itself ----

    @Test
    fun `harness makes ShizukuManager report permission granted`() {
        assertTrue(ShizukuManager.hasPermission())
    }

    // ---- existsCompat ----

    @Test
    fun `existsCompat falls back to Shizuku when the file does not exist locally`() {
        val protectedFile = File(tempFolder.root, "protected.txt") // never created locally
        `when`(mockService.exists(protectedFile.absolutePath)).thenReturn(true)

        assertTrue(protectedFile.existsCompat())
    }

    // ---- mkdirsCompat ----

    @Test
    fun `mkdirsCompat falls back to Shizuku when local mkdirs is structurally impossible`() {
        // A file (not a directory) as the parent makes java.io's mkdirs() fail for real.
        val blockingFile = tempFolder.newFile("blocker")
        val target = File(blockingFile, "sub")
        `when`(mockService.mkdirs(target.absolutePath)).thenReturn(true)

        assertTrue(target.mkdirsCompat())
    }

    // ---- deleteCompat ----

    @Test
    fun `deleteCompat falls back to Shizuku when the file does not exist locally`() {
        val missing = File(tempFolder.root, "missing.txt")
        `when`(mockService.delete(missing.absolutePath)).thenReturn(true)

        assertTrue(missing.deleteCompat())
    }

    // ---- deleteRecursivelyCompat ----
    //
    // Note: unlike delete(), Kotlin's File.deleteRecursively() returns true for a path that
    // doesn't exist locally (nothing to delete, vacuously succeeds) - so "missing locally"
    // can't be used to force deleteRecursivelyCompat() into its Shizuku branch the way it works
    // for the other *Compat() functions above, and reliably forcing a real local failure isn't
    // possible in a container that runs as root (permission bits don't stop root). This test
    // instead confirms the Shizuku-connected layer itself - ShizukuFileService.deleteRecursive()
    // - correctly delegates to the remote service once connected, which is the piece
    // deleteRecursivelyCompat() falls back to whenever java.io does genuinely fail.

    @Test
    fun `ShizukuFileService deleteRecursive delegates to the connected remote service`() {
        val path = File(tempFolder.root, "protected_dir").absolutePath
        `when`(mockService.deleteRecursive(path)).thenReturn(true)

        assertTrue(ShizukuFileService.deleteRecursive(path))
    }

    // ---- renameToCompat ----

    @Test
    fun `renameToCompat falls back to Shizuku when the source does not exist locally`() {
        val missingSrc = File(tempFolder.root, "missing_src.txt")
        val dest = File(tempFolder.root, "dest.txt")
        `when`(mockService.exists(missingSrc.absolutePath)).thenReturn(true)
        `when`(mockService.renameTo(missingSrc.absolutePath, dest.absolutePath)).thenReturn(true)

        assertTrue(missingSrc.renameToCompat(dest))
    }

    // ---- copyRecursivelyCompat ----

    @Test
    fun `copyRecursivelyCompat falls back to Shizuku when the source does not exist locally`() {
        val missingSrc = File(tempFolder.root, "missing_src.txt")
        val dest = File(tempFolder.root, "dest.txt")
        `when`(mockService.exists(missingSrc.absolutePath)).thenReturn(true)
        `when`(mockService.copyRecursive(missingSrc.absolutePath, dest.absolutePath)).thenReturn(true)

        assertTrue(missingSrc.copyRecursivelyCompat(dest))
    }

    // ---- createNewFileCompat ----

    @Test
    fun `createNewFileCompat falls back to Shizuku when the parent folder does not exist locally`() {
        // A nonexistent parent directory makes java.io's createNewFile() throw, so the local
        // attempt genuinely fails rather than just returning false.
        val target = File(File(tempFolder.root, "no_such_parent"), "new.txt")
        `when`(mockService.createNewFile(target.absolutePath)).thenReturn(true)

        assertTrue(target.createNewFileCompat())
    }

    // ---- needsShizuku ----

    @Test
    fun `needsShizuku is true when the file is unreachable locally but exists remotely`() {
        val protectedFile = File(tempFolder.root, "protected.txt") // never created locally
        `when`(mockService.exists(protectedFile.absolutePath)).thenReturn(true)

        assertTrue(protectedFile.needsShizuku())
    }

    @Test
    fun `needsShizuku is false once the file is already readable locally`() {
        val realFile = tempFolder.newFile("real.txt")
        assertFalse(realFile.needsShizuku())
    }

    // ---- listFilesCompat ----

    @Test
    fun `listFilesCompat merges in remote entries when the local folder looks empty`() {
        val emptyDir = tempFolder.newFolder("empty")
        `when`(mockService.listDir(emptyDir.absolutePath)).thenReturn(
            listOf(RemoteFileEntry("remote.txt", isDirectory = false, length = 0L, lastModified = 0L))
        )

        val children = emptyDir.listFilesCompat()
        assertEquals(1, children?.size)
        assertEquals("remote.txt", children?.first()?.name)
    }
}
