package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import com.example.filemanager.data.local.StorageSetupHelper

/**
 * Tests for StorageSetupHelper.kt.
 *
 * Covered: ensureDevelopmentBookmarksSafe()'s no-op path, getRemovableStorageDirectories()'s
 * SDK-gate branch (both sides), updateRemovableStorageDrawerItem()'s empty-list branch, and
 * updateStorageBar()'s success path (real StatFs against the sandbox's real external-storage
 * directory, same approach ClipboardHelperTest.kt/DirectoryNavigationHelperTest.kt use for
 * filesystem-backed assertions).
 *
 * Not covered: openAndroidDataFolder(), openAndroidDataFolderSaf(), launchSafPicker() - all
 * three build/drive KornDialog.Builder dialogs or SAF Intents/ContentResolver permissions,
 * matching the project's established "no dialog-callback test pattern exists yet" skip reason
 * (see ClipboardHelperTest.kt, ConflictDialogHelper - skipped last round).
 *
 * getRemovableStorageDirectories()'s SDK>=R branch is asserted as empty on the assumption that
 * Robolectric's built-in ShadowStorageManager returns no storage volumes by default when the
 * test doesn't register any - not verified against a real device with an actual SD card/USB
 * volume attached, since no such shadow/fixture exists anywhere in this project yet.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], shadows = [ShadowExternalStorageManager::class])
class StorageSetupHelperTest {

    private lateinit var activity: MainActivity
    private lateinit var helper: StorageSetupHelper

    @Before
    fun setUp() {
        android.os.Environment.getExternalStorageDirectory().listFiles()?.forEach { it.deleteRecursively() }
        activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        helper = StorageSetupHelper(activity)
    }

    @Test
    fun `ensureDevelopmentBookmarksSafe does not throw and leaves bookmarks untouched`() {
        // MinecraftAddonTools#ensureDevelopmentBookmarks is currently a disabled no-op, so this
        // should simply return without adding anything and without hitting the catch clause.
        helper.ensureDevelopmentBookmarksSafe()

        assertTrue(activity.bookmarksManager.getAll().isEmpty())
    }

    @Test
    @Config(sdk = [29])
    fun `getRemovableStorageDirectories returns empty list below API 30 without touching StorageManager`() {
        assertTrue(helper.getRemovableStorageDirectories().isEmpty())
    }

    @Test
    fun `getRemovableStorageDirectories returns empty list when no volumes are removable`() {
        assertTrue(helper.getRemovableStorageDirectories().isEmpty())
    }

    @Test
    fun `updateRemovableStorageDrawerItem hides the drawer item when there is no removable storage`() {
        val item = activity.navigationView.menu.findItem(R.id.nav_removable)!!
        item.isVisible = true // force it on first, so the assertion proves the method acted

        helper.updateRemovableStorageDrawerItem()

        assertFalse(item.isVisible)
    }

    @Test
    fun `updateStorageBar populates the storage bar views without leaving the error fallback text`() {
        val storageBar = activity.findViewById<android.widget.ProgressBar>(R.id.storageBar)
        val storagePercent = activity.findViewById<android.widget.TextView>(R.id.storagePercent)
        val storageText = activity.findViewById<android.widget.TextView>(R.id.storageText)

        helper.updateStorageBar()

        assertEquals(100, storageBar.max)
        assertTrue(storageBar.progress in 0..100)
        assertTrue(storagePercent.text.toString().endsWith("%"))
        // The catch block sets storageText to "" on failure - a non-empty value containing the
        // expected Thai label proves the success path ran, not the fallback.
        assertTrue(storageText.text.toString().startsWith("ทั้งหมด"))
        assertTrue(storageText.text.toString().contains("ใช้ไป"))
    }
}
