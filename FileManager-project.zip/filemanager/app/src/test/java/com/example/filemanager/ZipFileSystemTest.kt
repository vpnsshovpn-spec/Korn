package com.example.filemanager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * FIX-7: unit tests for ZipFileSystem.
 *
 * Zips under test are built with plain java.util.zip.ZipOutputStream directly (not through
 * ZipFileSystem's own write path), so the "malicious entry" cases below simulate a zip that
 * was crafted by an attacker/some other tool - not one this app's own validation ever had a
 * chance to touch on the way in. That's the same shape as a real Zip Slip exploit: the archive
 * already contains a dangerous entry name before this app ever opens it.
 */
class ZipFileSystemTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun rawZip(vararg entries: Pair<String, String>): File {
        val zip = tempFolder.newFile("test-${System.nanoTime()}.zip")
        ZipOutputStream(zip.outputStream()).use { zos ->
            for ((name, content) in entries) {
                zos.putNextEntry(ZipEntry(name))
                if (!name.endsWith("/")) zos.write(content.toByteArray())
                zos.closeEntry()
            }
        }
        return zip
    }

    // ==================== childrenOf ====================

    @Test
    fun `childrenOf root lists top-level folders and files, folders first`() {
        val zip = rawZip(
            "a.txt" to "A",
            "folder/b.txt" to "B",
            "folder/sub/c.txt" to "C"
        )
        val children = ZipFileSystem.childrenOf(zip, "")
        assertEquals(listOf("folder", "a.txt"), children.map { it.name })
        assertTrue(children[0].isDirectory)
        assertFalse(children[1].isDirectory)
    }

    @Test
    fun `childrenOf a subfolder lists only its direct children`() {
        val zip = rawZip(
            "folder/b.txt" to "B",
            "folder/sub/c.txt" to "C"
        )
        val children = ZipFileSystem.childrenOf(zip, "folder")
        assertEquals(listOf("sub", "b.txt"), children.map { it.name })
    }

    // ==================== extractEntryToFile: Zip Slip protection ====================

    @Test
    fun `extractEntryToFile rejects a traversal path`() {
        val zip = rawZip("../evil.txt" to "pwned")
        val dest = File(tempFolder.newFolder("out"), "landing.txt")
        assertThrows(SecurityException::class.java) {
            ZipFileSystem.extractEntryToFile(zip, "../evil.txt", dest)
        }
    }

    @Test
    fun `extractEntryToFile rejects an absolute unix path`() {
        val zip = rawZip("/etc/evil.txt" to "pwned")
        val dest = File(tempFolder.newFolder("out2"), "landing.txt")
        assertThrows(SecurityException::class.java) {
            ZipFileSystem.extractEntryToFile(zip, "/etc/evil.txt", dest)
        }
    }

    @Test
    fun `extractEntryToFile rejects a windows drive absolute path`() {
        val zip = rawZip("C:/evil.txt" to "pwned")
        val dest = File(tempFolder.newFolder("out3"), "landing.txt")
        assertThrows(SecurityException::class.java) {
            ZipFileSystem.extractEntryToFile(zip, "C:/evil.txt", dest)
        }
    }

    @Test
    fun `extractEntryToFile succeeds for a normal safe entry`() {
        val zip = rawZip("docs/readme.txt" to "hello world")
        val dest = File(tempFolder.newFolder("out4"), "readme.txt")
        ZipFileSystem.extractEntryToFile(zip, "docs/readme.txt", dest)
        assertTrue(dest.exists())
        assertEquals("hello world", dest.readText())
    }

    @Test
    fun `extractEntryToFile leaves an existing destination untouched when extraction fails`() {
        val zip = rawZip("real.txt" to "real content")
        val destDir = tempFolder.newFolder("out5")
        val dest = File(destDir, "landing.txt").apply { writeText("original, must survive") }

        assertThrows(java.io.FileNotFoundException::class.java) {
            // entry does not exist in the zip
            ZipFileSystem.extractEntryToFile(zip, "missing.txt", dest)
        }
        assertEquals("original, must survive", dest.readText())
    }

    // ==================== extractFolderToDir: Zip Slip protection ====================

    @Test
    fun `extractFolderToDir rejects an entry that escapes destDir via traversal`() {
        val zip = rawZip(
            "pack/inside.txt" to "fine",
            "pack/../../escaped.txt" to "pwned"
        )
        val destDir = tempFolder.newFolder("extractDest")
        assertThrows(SecurityException::class.java) {
            ZipFileSystem.extractFolderToDir(zip, "pack", destDir)
        }
    }

    @Test
    fun `extractFolderToDir extracts a normal nested folder correctly`() {
        val zip = rawZip(
            "pack/a.txt" to "A",
            "pack/nested/b.txt" to "B"
        )
        val destDir = tempFolder.newFolder("extractDest2")
        ZipFileSystem.extractFolderToDir(zip, "pack", destDir)
        assertEquals("A", File(destDir, "a.txt").readText())
        assertEquals("B", File(destDir, "nested/b.txt").readText())
    }

    // ==================== deletePath ====================

    @Test
    fun `deletePath removes a folder and everything nested under it`() {
        val zip = rawZip(
            "a.txt" to "A",
            "folder/b.txt" to "B",
            "folder/sub/c.txt" to "C"
        )
        ZipFileSystem.deletePath(zip, "folder")
        val remaining = ZipFileSystem.childrenOf(zip, "")
        assertEquals(listOf("a.txt"), remaining.map { it.name })
    }

    // ==================== renamePath ====================

    @Test
    fun `renamePath renames a single file within its parent folder`() {
        val zip = rawZip("folder/old.txt" to "content")
        ZipFileSystem.renamePath(zip, "folder/old.txt", "new.txt")
        val children = ZipFileSystem.childrenOf(zip, "folder")
        assertEquals(listOf("new.txt"), children.map { it.name })
        assertEquals("content", ZipFileSystem.readEntryBytes(zip, "folder/new.txt").decodeToString())
    }

    @Test
    fun `renamePath renames a folder and keeps its nested children`() {
        val zip = rawZip(
            "folder/b.txt" to "B",
            "folder/sub/c.txt" to "C"
        )
        ZipFileSystem.renamePath(zip, "folder", "renamed")
        val rootChildren = ZipFileSystem.childrenOf(zip, "")
        assertEquals(listOf("renamed"), rootChildren.map { it.name })
        val innerChildren = ZipFileSystem.childrenOf(zip, "renamed")
        assertEquals(listOf("sub", "b.txt"), innerChildren.map { it.name })
        assertEquals("C", ZipFileSystem.readEntryBytes(zip, "renamed/sub/c.txt").decodeToString())
    }

    // ==================== createFolder ====================

    @Test
    fun `createFolder adds an empty folder visible in childrenOf`() {
        val zip = rawZip("a.txt" to "A")
        ZipFileSystem.createFolder(zip, "", "newdir")
        val children = ZipFileSystem.childrenOf(zip, "")
        assertEquals(setOf("newdir", "a.txt"), children.map { it.name }.toSet())
        assertTrue(children.first { it.name == "newdir" }.isDirectory)
    }

    // ==================== addOrReplaceFile / replaceEntryBytes ====================

    @Test
    fun `addOrReplaceFile adds a brand new entry`() {
        val zip = rawZip("existing.txt" to "old")
        val source = tempFolder.newFile("source.txt").apply { writeText("new content") }
        ZipFileSystem.addOrReplaceFile(zip, "", "added.txt", source)
        assertEquals("new content", ZipFileSystem.readEntryBytes(zip, "added.txt").decodeToString())
        // existing entry untouched
        assertEquals("old", ZipFileSystem.readEntryBytes(zip, "existing.txt").decodeToString())
    }

    @Test
    fun `addOrReplaceFile replaces an existing entry's content`() {
        val zip = rawZip("target.txt" to "old content")
        val source = tempFolder.newFile("replacement.txt").apply { writeText("replaced content") }
        ZipFileSystem.addOrReplaceFile(zip, "", "target.txt", source)
        assertEquals("replaced content", ZipFileSystem.readEntryBytes(zip, "target.txt").decodeToString())
    }

    @Test
    fun `replaceEntryBytes overwrites content directly from a byte array`() {
        val zip = rawZip("note.txt" to "before edit")
        ZipFileSystem.replaceEntryBytes(zip, "note.txt", "after edit".toByteArray())
        assertEquals("after edit", ZipFileSystem.readEntryBytes(zip, "note.txt").decodeToString())
    }

    // ==================== movePath ====================

    @Test
    fun `movePath moves a single file into a different folder`() {
        val zip = rawZip("a.txt" to "A", "folder/dummy.txt" to "D")
        ZipFileSystem.movePath(zip, "a.txt", "folder")
        assertEquals(emptyList<String>(), ZipFileSystem.childrenOf(zip, "").map { it.name }.filter { it == "a.txt" })
        val inFolder = ZipFileSystem.childrenOf(zip, "folder").map { it.name }
        assertTrue(inFolder.contains("a.txt"))
        assertEquals("A", ZipFileSystem.readEntryBytes(zip, "folder/a.txt").decodeToString())
    }

    @Test
    fun `movePath moves a folder and keeps its nested children`() {
        val zip = rawZip(
            "src/b.txt" to "B",
            "src/sub/c.txt" to "C",
            "dest/dummy.txt" to "D"
        )
        ZipFileSystem.movePath(zip, "src", "dest")
        assertTrue(ZipFileSystem.childrenOf(zip, "").map { it.name }.none { it == "src" })
        val moved = ZipFileSystem.childrenOf(zip, "dest").map { it.name }
        assertTrue(moved.contains("src"))
        assertEquals("C", ZipFileSystem.readEntryBytes(zip, "dest/src/sub/c.txt").decodeToString())
    }

    @Test
    fun `movePath refuses moving a folder into itself or a descendant`() {
        val zip = rawZip("folder/sub/c.txt" to "C")
        assertThrows(IllegalArgumentException::class.java) {
            ZipFileSystem.movePath(zip, "folder", "folder/sub")
        }
    }

    @Test
    fun `movePath refuses when destination already has an entry with that name`() {
        val zip = rawZip("a.txt" to "A", "folder/a.txt" to "existing")
        assertThrows(IllegalStateException::class.java) {
            ZipFileSystem.movePath(zip, "a.txt", "folder")
        }
    }

    // ==================== copyPath (same zip) ====================

    @Test
    fun `copyPath copies a file and leaves the original in place`() {
        val zip = rawZip("a.txt" to "A", "folder/dummy.txt" to "D")
        ZipFileSystem.copyPath(zip, "a.txt", "folder")
        assertEquals("A", ZipFileSystem.readEntryBytes(zip, "a.txt").decodeToString())
        assertEquals("A", ZipFileSystem.readEntryBytes(zip, "folder/a.txt").decodeToString())
    }

    @Test
    fun `copyPath copies a folder with nested children, original untouched`() {
        val zip = rawZip("src/b.txt" to "B", "src/sub/c.txt" to "C")
        ZipFileSystem.copyPath(zip, "src", "")
        // original still there
        assertEquals("C", ZipFileSystem.readEntryBytes(zip, "src/sub/c.txt").decodeToString())
        val rootChildren = ZipFileSystem.childrenOf(zip, "").map { it.name }
        assertEquals(1, rootChildren.size)
        assertEquals("src", rootChildren[0])
    }

    @Test
    fun `copyPath refuses copying a folder into itself or a descendant`() {
        val zip = rawZip("folder/sub/c.txt" to "C")
        assertThrows(IllegalArgumentException::class.java) {
            ZipFileSystem.copyPath(zip, "folder", "folder/sub")
        }
    }

    @Test
    fun `copyPath refuses when destination already has an entry with that name`() {
        val zip = rawZip("a.txt" to "A", "folder/a.txt" to "existing")
        assertThrows(IllegalStateException::class.java) {
            ZipFileSystem.copyPath(zip, "a.txt", "folder")
        }
    }

    // ==================== copyPathAcrossZips ====================

    @Test
    fun `copyPathAcrossZips copies a file from one zip into another`() {
        val source = rawZip("a.txt" to "hello")
        val dest = rawZip("existing.txt" to "already here")
        ZipFileSystem.copyPathAcrossZips(source, "a.txt", dest, "")
        assertEquals("hello", ZipFileSystem.readEntryBytes(dest, "a.txt").decodeToString())
        // source zip is untouched by a copy (no delete)
        assertEquals("hello", ZipFileSystem.readEntryBytes(source, "a.txt").decodeToString())
        // destination's pre-existing entry survives the rewrite
        assertEquals("already here", ZipFileSystem.readEntryBytes(dest, "existing.txt").decodeToString())
    }

    @Test
    fun `copyPathAcrossZips copies a folder with nested children into a subfolder of the destination`() {
        val source = rawZip("pack/b.txt" to "B", "pack/sub/c.txt" to "C")
        val dest = rawZip("readme.txt" to "R")
        ZipFileSystem.createFolder(dest, "", "imported")
        ZipFileSystem.copyPathAcrossZips(source, "pack", dest, "imported")
        assertEquals("C", ZipFileSystem.readEntryBytes(dest, "imported/pack/sub/c.txt").decodeToString())
        assertEquals("B", ZipFileSystem.readEntryBytes(dest, "imported/pack/b.txt").decodeToString())
    }

    @Test
    fun `copyPathAcrossZips refuses when destination already has an entry with that name`() {
        val source = rawZip("a.txt" to "A")
        val dest = rawZip("a.txt" to "existing")
        assertThrows(IllegalStateException::class.java) {
            ZipFileSystem.copyPathAcrossZips(source, "a.txt", dest, "")
        }
    }

    // ==================== isZipFormatFile ====================

    @Test
    fun `isZipFormatFile recognizes known zip-family extensions and rejects others`() {
        assertTrue(ZipFileSystem.isZipFormatFile(File("addon.mcaddon")))
        assertTrue(ZipFileSystem.isZipFormatFile(File("world.mcworld")))
        assertTrue(ZipFileSystem.isZipFormatFile(File("archive.ZIP")))
        assertFalse(ZipFileSystem.isZipFormatFile(File("archive.rar")))
        assertFalse(ZipFileSystem.isZipFormatFile(File("archive.7z")))
    }

    // ==================== zip stays valid after mutation ====================

    @Test
    fun `zip remains readable and consistent after a sequence of mutations`() {
        val zip = rawZip("a.txt" to "A", "b.txt" to "B")
        ZipFileSystem.createFolder(zip, "", "docs")
        ZipFileSystem.addOrReplaceFile(zip, "docs", "readme.txt", tempFolder.newFile("r.txt").apply { writeText("readme") })
        ZipFileSystem.renamePath(zip, "b.txt", "b-renamed.txt")
        ZipFileSystem.deletePath(zip, "a.txt")

        // The zip file itself must still open and iterate cleanly.
        ZipFile(zip).use { zf ->
            val names = mutableListOf<String>()
            val entries = zf.entries()
            while (entries.hasMoreElements()) names.add(entries.nextElement().name.trimEnd('/'))
            assertTrue(names.contains("b-renamed.txt"))
            assertTrue(names.contains("docs/readme.txt"))
            assertFalse(names.contains("a.txt"))
            assertFalse(names.contains("b.txt"))
        }
        assertEquals("readme", ZipFileSystem.readEntryBytes(zip, "docs/readme.txt").decodeToString())
    }
}
