package com.example.filemanager

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.LayoutInflater
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/**
 * This activity is registered for android.intent.action.VIEW / SEND with a wildcard
 * mimeType so the app shows up in the system "Open with" chooser for any file type.
 */
class OpenWithActivity : AppCompatActivity() {

    private var incomingUri: Uri? = null
    private var incomingName: String = "unknown"
    private lateinit var bookmarksManager: BookmarksManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_open_with)
        bookmarksManager = BookmarksManager(this)

        incomingUri = when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> intent.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }

        if (incomingUri == null) {
            Toast.makeText(this, "ไม่พบไฟล์ที่ส่งมา", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        incomingName = queryFileName(incomingUri!!) ?: "unnamed_file"

        if (MinecraftAddonTools.isArchiveExtension(incomingName.substringAfterLast('.', ""))) {
            openIncomingMinecraftArchive()
            return
        }

        findViewById<TextView>(R.id.fileNameText).text = incomingName
        findViewById<TextView>(R.id.fileInfoText).text = incomingUri.toString()

        findViewById<android.widget.Button>(R.id.saveToButton).setOnClickListener {
            showBookmarkChooser()
        }
        findViewById<android.widget.Button>(R.id.browseButton).setOnClickListener {
            openDestinationFolderPicker()
        }
        findViewById<android.widget.Button>(R.id.openAnotherAppButton).setOnClickListener {
            val shareableUri = shareableUriFor(incomingUri!!)
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(shareableUri, mimeTypeFor(incomingUri!!))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "เปิดด้วย"))
        }
        findViewById<android.widget.Button>(R.id.shareButton).setOnClickListener {
            shareIncomingFile()
        }
        findViewById<android.widget.Button>(R.id.closeButton).setOnClickListener { finish() }
    }

    private fun openIncomingMinecraftArchive() {
        Thread {
            try {
                val source = incomingUri ?: throw IllegalArgumentException("ไม่พบ URI")
                val cacheFile = File(cacheDir, "incoming_${System.currentTimeMillis()}_${incomingName}")
                if (source.scheme == "file") {
                    File(source.path ?: throw IllegalArgumentException("พาธไม่ถูกต้อง")).copyTo(cacheFile, overwrite = true)
                } else {
                    contentResolver.openInputStream(source)?.use { input ->
                        cacheFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalArgumentException("อ่านไฟล์ไม่ได้")
                }
                runOnUiThread {
                    val i = Intent(this, ZipBrowserActivity::class.java)
                    i.putExtra(ZipBrowserActivity.EXTRA_ZIP_PATH, cacheFile.absolutePath)
                    startActivity(i)
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "เปิด ${incomingName} ไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }.start()
    }

    /**
     * Forwards the file that was opened into this app back out through the system share
     * sheet (e.g. so a PDF someone "opened with" this app can be shared onward to LINE,
     * email, etc.) — the same "open -> share forward" flow other file managers offer.
     */
    private fun shareIncomingFile() {
        val uri = incomingUri ?: return
        try {
            val shareUri = shareableUriFor(uri)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeTypeFor(uri)
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "แชร์ไฟล์"))
        } catch (e: Exception) {
            Toast.makeText(this, "แชร์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * file:// URIs can't be handed to other apps on modern Android (FileUriExposedException),
     * so route those through our own FileProvider first. content:// URIs from the app that
     * opened us are passed through as-is.
     */
    private fun shareableUriFor(uri: Uri): Uri {
        if (uri.scheme == "file") {
            val file = File(uri.path ?: return uri)
            return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        }
        return uri
    }

    private fun mimeTypeFor(uri: Uri): String {
        contentResolver.getType(uri)?.let { return it }
        val ext = incomingName.substringAfterLast('.', "")
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "*/*"
    }

    private fun queryFileName(uri: Uri): String? {
        if (uri.scheme == "file") return File(uri.path ?: "").name
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    private fun showBookmarkChooser() {
        val bookmarks = bookmarksManager.getAll()
        if (bookmarks.isEmpty()) {
            Toast.makeText(this, "ยังไม่มีบุ๊คมาร์ก โปรดเพิ่มโฟลเดอร์ในแอปหลักก่อน", Toast.LENGTH_LONG).show()
            return
        }
        val names = bookmarks.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("บันทึกไปที่โฟลเดอร์ไหน?")
            .setItems(names) { _, which ->
                copyToFolder(File(bookmarks[which].path))
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    /**
     * Real "choose destination folder yourself" picker: lets the user navigate the
     * device's folders (starting at external storage root) and copy the incoming
     * file into whichever one they land on — same flow as RS File Explorer's
     * "คัดลอกไปที่" (copy to).
     */
    private fun openDestinationFolderPicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
            Toast.makeText(this, "โปรดอนุญาต \"เข้าถึงไฟล์ทั้งหมด\" ก่อน แล้วกลับมากดเลือกโฟลเดอร์ปลายทางอีกครั้ง", Toast.LENGTH_LONG).show()
            return
        }
        showFolderPickerDialog(Environment.getExternalStorageDirectory())
    }

    private fun showFolderPickerDialog(startDir: File) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_folder_picker, null)
        val pathText = dialogView.findViewById<TextView>(R.id.currentPathText)
        val listView = dialogView.findViewById<ListView>(R.id.folderListView)
        val newFolderButton = dialogView.findViewById<TextView>(R.id.newFolderInPickerButton)
        val newFileButton = dialogView.findViewById<TextView>(R.id.newFileInPickerButton)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        var currentDir = startDir
        val rootDir = Environment.getExternalStorageDirectory()

        // Folders sort first (and are the only navigable rows); files are listed too so the
        // user can see what's already in a folder before picking it as the destination.
        fun childrenOf(dir: File): List<File> {
            return (dir.listFiles() ?: emptyArray())
                .filter { !it.name.startsWith(".") }
                .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        }

        fun refresh() {
            pathText.text = currentDir.absolutePath
            val children = childrenOf(currentDir)
            val showUp = currentDir != rootDir
            val labels = mutableListOf<String>()
            if (showUp) labels.add("⬆️  .. (ย้อนกลับ)")
            labels.addAll(children.map { if (it.isDirectory) "📁  ${it.name}" else "📄  ${it.name}" })

            listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
            listView.setOnItemClickListener { _, _, position, _ ->
                if (showUp && position == 0) {
                    currentDir = currentDir.parentFile ?: rootDir
                    refresh()
                    return@setOnItemClickListener
                }
                val target = children[if (showUp) position - 1 else position]
                if (target.isDirectory) {
                    currentDir = target
                    refresh()
                }
                // Tapping a file does nothing - it's shown only so the user can see the folder's contents.
            }
        }
        refresh()

        newFileButton.setOnClickListener {
            val input = EditText(this)
            input.hint = "ชื่อไฟล์.txt"
            AlertDialog.Builder(this)
                .setTitle("สร้างไฟล์ใหม่")
                .setMessage("ใน ${currentDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newFile = File(currentDir, name)
                    try {
                        when {
                            newFile.exists() -> Toast.makeText(this, "มีไฟล์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                            newFile.createNewFile() -> refresh()
                            else -> Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this, "สร้างไฟล์ไม่สำเร็จ: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        newFolderButton.setOnClickListener {
            val input = EditText(this)
            AlertDialog.Builder(this)
                .setTitle("สร้างโฟลเดอร์ใหม่")
                .setMessage("ใน ${currentDir.absolutePath}")
                .setView(input)
                .setPositiveButton("สร้าง") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isEmpty()) return@setPositiveButton
                    val newDir = File(currentDir, name)
                    when {
                        newDir.exists() -> Toast.makeText(this, "มีโฟลเดอร์นี้อยู่แล้ว", Toast.LENGTH_SHORT).show()
                        newDir.mkdirs() -> { currentDir = newDir; refresh() }
                        else -> Toast.makeText(this, "สร้างโฟลเดอร์ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }

        dialogView.findViewById<android.widget.Button>(R.id.chooseFolderHereButton).setOnClickListener {
            dialog.dismiss()
            copyToFolder(currentDir)
        }
        dialogView.findViewById<android.widget.Button>(R.id.cancelFolderPickButton).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun copyToFolder(destDir: File) {
        try {
            if (!destDir.exists()) destDir.mkdirs()
            val destFile = File(destDir, incomingName)
            contentResolver.openInputStream(incomingUri!!)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "บันทึกไปที่ ${destFile.absolutePath} แล้ว", Toast.LENGTH_LONG).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "บันทึกไม่สำเร็จ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
