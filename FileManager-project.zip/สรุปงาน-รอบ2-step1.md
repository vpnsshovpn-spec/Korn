# สรุปงาน: MainViewModel Split — รอบ 2 (STEP 1 จาก 4)

อ้างอิงแผนจาก `refactor-instructions.txt` — แตก state ที่เกี่ยวกับ "การเรียกดูโฟลเดอร์"
ออกจาก `MainViewModel` ไปเป็น `DirectoryViewModel` ตัวใหม่

## สิ่งที่ย้ายไป DirectoryViewModel.kt (ไฟล์ใหม่)

จาก `MainViewModel` เดิม:
- `showHidden`, `sortKey`, `sortAscending`, `isGridMode`, `fileViewMode` (Round 14)
- `currentDir`, `lastNormalDir`, `mode`, `currentCategoryLabel`, `currentCategoryExts`
  (Round 16, ผูก SavedStateHandle ตั้งแต่ Round 22)
- `directoryState` + `loadDirectory()` (Round 17)

**หมายเหตุ (เบี่ยงจากแผนเดิมนิดหน่อย):** `directoryState`/`loadDirectory()` ไม่ได้อยู่ใน
ลิสต์ของ `refactor-instructions.txt` ตรงๆ แต่มันอ่าน/เขียน `currentDir`/`lastNormalDir`/
`mode`/`sortKey`/`sortAscending`/`showHidden` ทั้งหมดโดยตรง แยกออกจากกันไม่ได้จริง
เลยย้ายไปด้วยกันทั้งก้อน — ถ้าไม่ตรงกับที่คิดไว้ ทักได้เลยครับ ยังปรับได้อยู่

`themeKey` **ไม่ย้าย** — เป็น setting ของทั้งแอป ไม่ใช่ของการเรียกดูโฟลเดอร์ ตามที่แผนระบุไว้ชัดเจน

## สิ่งที่ยังอยู่ใน MainViewModel.kt เหมือนเดิม

`themeKey`, clipboard, dialog-open flags, multi-select, copy/move + archive + compress
progress, conflict-resolution batches, search (query/state) — รอ step 2-4 ต่อไป

## ผลกระทบที่ต้องแก้ตาม (เพราะแยก ViewModel)

1. **MainActivity.kt** — เพิ่ม `internal val directoryViewModel: DirectoryViewModel by viewModels()`
   คู่กับ `viewModel` เดิม (ตัวใหม่แยก instance กันคนละ ViewModel แต่ผูกกับ Activity เดียวกัน
   รอด rotation ได้เหมือนกัน)

2. **16 ไฟล์ helper** ที่เรียก `viewModel.xxx` ตรงๆ (ตามแบบ round 18-20 ที่เคยเอา wrapper ออก)
   เปลี่ยนเป็น `directoryViewModel.xxx` เฉพาะ field ที่ย้ายไป — ตรวจแล้วทีละไฟล์ ไม่มีจุดตกหล่น:
   `CategoryShortcuts.kt`, `ClipboardHelper.kt`, `CompressDialog.kt`, `DirectoryStateObserver.kt`,
   `DragDropHelper.kt`, `FileClickHelper.kt`, `FileItemActionsHelper.kt`, `MainViewBindingHelper.kt`,
   `NavigationDrawerHelper.kt`, `PermissionFlowHelper.kt`, `SearchHelper.kt`,
   `SelectionModeController.kt`, `SettingsHelper.kt`, `TrashUiController.kt`,
   `WindowsAndHistoryHelper.kt`

3. **`onSearchQueryChanged()` / `runSearchImmediate()` / `runSearchNow()`** (ยังอยู่ใน
   MainViewModel) — เดิมอ่าน `_sortKey`/`_sortAscending` ของตัวเองตรงๆ ตอนสร้าง comparator
   ตอนนี้ต้องรับเป็นพารามิเตอร์แทน (แพทเทิร์นเดียวกับ `showHidden` ที่ผ่านเข้ามาอยู่แล้ว)
   — ห้าม ViewModel อ้างถึงกันเองข้ามคลาส เลยเลือกวิธีนี้แทนที่จะให้ MainViewModel ถือ
   reference ไปยัง DirectoryViewModel โดยตรง จุดเรียกอยู่ที่ `SearchHelper.kt` (3 จุด) แก้แล้ว

4. **`DirectoryStateObserver.kt`** — toast "ไม่สามารถเข้าถึงโฟลเดอร์นี้ได้" เดิมออกทาง
   `viewModel.events` (SharedFlow กลางของ MainViewModel) ตอนนี้ DirectoryViewModel มี
   `toastEvents: SharedFlow<String>` ของตัวเองแยกต่างหาก (เพราะ DirectoryViewModel
   เข้าไม่ถึง `_events` ส่วน private ของ MainViewModel) — เพิ่ม `launch { }` อีกตัวไป
   collect คู่กับตัวเดิม

## เทสต์

- ย้าย test ของ field ที่ย้าย (Round 14 + Round 16 + Round 17 sections) จาก
  `MainViewModelTest.kt` ไปไฟล์ใหม่ `DirectoryViewModelTest.kt`
- แก้ `MainActivityRotationTest.kt`, `CategoryShortcutsRobolectricTest.kt`,
  `DirectoryStateObserverTest.kt`, `ProgressDialogRotationTest.kt` — เพิ่ม
  `directoryViewModelOf()` helper คู่กับ `viewModelOf()` เดิม, แก้ `awaitInitialLoadSettled()`
  ให้รับ `DirectoryViewModel` แทน (เพราะ `directoryState` ย้ายไปแล้ว)
- แก้ `NavigationDrawerHelperTest.kt`, `SearchHelperTest.kt`, `SelectionModeControllerTest.kt`,
  `SettingsHelperTest.kt` — เปลี่ยน `activity.viewModel.xxx` เป็น `activity.directoryViewModel.xxx`
  เฉพาะ field ที่ย้าย (ตรวจแล้ว `activity.viewModel.themeKey`/clipboard ไม่ถูกแตะ)

## ยังไม่ได้ทำ (สำคัญ — ต้องรัน CI ก่อนไปต่อ)

- **ไม่ได้ build/run gradle test จริง** เพราะแซนด์บ็อกซ์นี้ไม่มี network/gradlew (ข้อจำกัด
  เดิมเหมือนทุกรอบที่ผ่านมา) — ตรวจด้วยการอ่าน cross-reference แบบ static แทน (grep ทุก
  field ที่ย้าย ทุกไฟล์ในโปรเจกต์ ทั้ง main และ test ไม่เจอจุดตกหล่น) แต่ยังต้องรอ CI
  ยืนยัน GREEN จริงก่อนเชื่อ 100%
- **step 2-4 ของแผน** (FileOperationViewModel, ArchiveOperationViewModel,
  SearchFilterViewModel) ยังไม่เริ่ม — ตามแผน "ทำทีละตัว" รอ step นี้ผ่าน CI ก่อน

## ไฟล์ที่แนบมา

ไฟล์ที่เปลี่ยน/ใหม่ทั้งหมด (28 ไฟล์ .kt) อยู่ใน `filemanager/` โครงสร้างเดิม พร้อมก็อปแทนที่
ไฟล์เดิมในโปรเจกต์ได้เลย
